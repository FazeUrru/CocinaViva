'use client'

import Link from 'next/link'
import { ChefHat, Heart, Mail, Instagram, Facebook, Twitter } from 'lucide-react'

export function Footer() {
  return (
    <footer className="mt-auto border-t bg-muted/30">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl">
              <img
                src="/images/logo.png"
                alt="CocinaViva"
                className="h-8 w-8 rounded-lg object-cover"
              />
              <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                CocinaViva
              </span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Tu cocina integral. Descubre recetas deliciosas, organiza tus ingredientes y comparte con la comunidad.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold text-sm uppercase tracking-wider">Navegación</h3>
            <nav className="flex flex-col gap-2">
              <Link href="/recetas" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Recetario
              </Link>
              <Link href="/destacados" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Destacados
              </Link>
              <Link href="/comunidad" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Comunidad
              </Link>
              <Link href="/crear" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Crear Receta
              </Link>
            </nav>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <h3 className="font-semibold text-sm uppercase tracking-wider">Categorías</h3>
            <nav className="flex flex-col gap-2">
              <Link href="/recetas?toolType=tradicional" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Cocina Tradicional
              </Link>
              <Link href="/recetas?toolType=thermomix" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Thermomix
              </Link>
              <Link href="/recetas?toolType=crockpot" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Crockpot
              </Link>
              <Link href="/recetas?isGlutenFree=true" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Sin Gluten
              </Link>
            </nav>
          </div>

          {/* Social */}
          <div className="space-y-4">
            <h3 className="font-semibold text-sm uppercase tracking-wider">Síguenos</h3>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                <Mail className="h-5 w-5" />
              </a>
            </div>
            <p className="text-xs text-muted-foreground">
              Hecho con <Heart className="inline h-3 w-3 text-red-500" /> para amantes de la cocina
            </p>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} CocinaViva. Todos los derechos reservados.
          </p>
          <div className="flex gap-4 text-xs text-muted-foreground">
            <Link href="#" className="hover:text-foreground transition-colors">
              Términos de uso
            </Link>
            <Link href="#" className="hover:text-foreground transition-colors">
              Privacidad
            </Link>
            <Link href="#" className="hover:text-foreground transition-colors">
              Cookies
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
