'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  ChefHat,
  Search,
  Heart,
  History,
  ShoppingCart,
  Users,
  PlusCircle,
  Menu,
  X,
  Timer,
  Image as ImageIcon,
  Home,
  Sparkles,
  Trophy,
  Crown,
  Settings,
  User,
  LogIn,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useShoppingListStore, useUserStore } from '@/store'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Progress } from '@/components/ui/progress'

const navItems = [
  { href: '/', label: 'Inicio', icon: Home },
  { href: '/recetas', label: 'Recetario', icon: ChefHat },
  { href: '/generador', label: 'Generador', icon: Sparkles },
  { href: '/destacados', label: 'Destacados', icon: Heart },
  { href: '/favoritos', label: 'Favoritos', icon: Heart },
  { href: '/historial', label: 'Historial', icon: History },
  { href: '/compras', label: 'Compras', icon: ShoppingCart },
  { href: '/comunidad', label: 'Comunidad', icon: Users },
  { href: '/crear', label: 'Crear Receta', icon: PlusCircle },
  { href: '/galeria', label: 'Galería', icon: ImageIcon },
]

export function Navigation() {
  const pathname = usePathname()
  const [searchQuery, setSearchQuery] = useState('')
  const [isOpen, setIsOpen] = useState(false)
  const { items } = useShoppingListStore()
  const { isAuthenticated, userName, userEmail } = useUserStore()
  const uncheckedCount = items.filter(item => !item.isChecked).length

  // Demo user points and achievements
  const userPoints = 2450
  const totalPoints = 10000
  const achievementsUnlocked = 87
  const totalAchievements = 300
  const userPlan = 'ultra' // 'basic', 'ultra', 'masterchef'

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/recetas?search=${encodeURIComponent(searchQuery)}`
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <img
            src="/images/logo.png"
            alt="CocinaViva"
            className="h-8 w-8 rounded-lg object-cover"
          />
          <span className="hidden sm:inline bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
            CocinaViva
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.slice(0, 4).map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
                    : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Search Bar - Desktop */}
        <form onSubmit={handleSearch} className="hidden md:flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar recetas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-48 xl:w-64 pl-10"
            />
          </div>
        </form>

        {/* Right Side Actions */}
        <div className="flex items-center gap-1 sm:gap-2">
          {/* Achievements Button */}
          <Link href="/logros">
            <Button variant="ghost" size="sm" className="hidden sm:flex gap-2">
              <Trophy className="h-4 w-4 text-yellow-500" />
              <span className="hidden lg:inline">Logros</span>
              <Badge className="bg-yellow-500 text-xs">
                {achievementsUnlocked}/{totalAchievements}
              </Badge>
            </Button>
          </Link>

          {/* Plans Button */}
          <Link href="/planes">
            <Button variant="ghost" size="sm" className="hidden sm:flex gap-2">
              <Crown className="h-4 w-4 text-purple-500" />
              <span className="hidden lg:inline">Planes</span>
              {userPlan !== 'basic' && (
                <Badge className="bg-purple-500 text-xs capitalize">
                  {userPlan}
                </Badge>
              )}
            </Button>
          </Link>

          {/* Timer Quick Access */}
          <Link href="/temporizadores">
            <Button variant="ghost" size="icon">
              <Timer className="h-5 w-5" />
            </Button>
          </Link>

          {/* Shopping Cart with Badge */}
          <Link href="/compras" className="hidden sm:block">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {uncheckedCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-orange-500">
                  {uncheckedCount}
                </Badge>
              )}
            </Button>
          </Link>

          {/* User Menu or Login */}
          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="gap-2">
                  <Avatar className="h-6 w-6">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-gradient-to-r from-orange-500 to-green-500 text-white text-xs">
                      {userName?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden lg:inline">{userName}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="px-2 py-2">
                  <div className="font-medium">{userName}</div>
                  <div className="text-xs text-muted-foreground">{userEmail}</div>
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span>Puntos: {userPoints.toLocaleString()}</span>
                      <span>{Math.round((userPoints / totalPoints) * 100)}%</span>
                    </div>
                    <Progress value={(userPoints / totalPoints) * 100} className="h-1" />
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/perfil" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Mi Perfil
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/ajustes" className="flex items-center gap-2">
                    <Settings className="h-4 w-4" />
                    Ajustes
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/logros" className="flex items-center gap-2">
                    <Trophy className="h-4 w-4" />
                    Logros ({achievementsUnlocked}/{totalAchievements})
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/planes" className="flex items-center gap-2">
                    <Crown className="h-4 w-4" />
                    Planes y Suscripción
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link href="/login">
              <Button size="sm" className="bg-gradient-to-r from-orange-500 to-green-500">
                <LogIn className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Iniciar sesión</span>
              </Button>
            </Link>
          )}

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <img
                    src="/images/logo.png"
                    alt="CocinaViva"
                    className="h-8 w-8 rounded-lg object-cover"
                  />
                  <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                    CocinaViva
                  </span>
                </SheetTitle>
              </SheetHeader>

              {/* User Info Mobile */}
              <div className="mt-4 p-3 bg-muted rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar>
                    <AvatarFallback className="bg-gradient-to-r from-orange-500 to-green-500 text-white">
                      {userName?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{userName || 'Usuario Demo'}</div>
                    <div className="text-xs text-muted-foreground">{userPlan} plan</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Puntos</span>
                    <span className="font-medium">{userPoints.toLocaleString()}</span>
                  </div>
                  <Progress value={(userPoints / totalPoints) * 100} className="h-2" />
                  <div className="flex items-center justify-between text-sm">
                    <span>Logros</span>
                    <span className="font-medium">{achievementsUnlocked}/{totalAchievements}</span>
                  </div>
                </div>
              </div>

              {/* Mobile Search */}
              <form onSubmit={handleSearch} className="mt-6 mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Buscar recetas..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10"
                  />
                </div>
              </form>

              {/* Quick Actions Mobile */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                <Link href="/logros" onClick={() => setIsOpen(false)}>
                  <Button variant="outline" className="w-full">
                    <Trophy className="h-4 w-4 mr-2 text-yellow-500" />
                    Logros
                  </Button>
                </Link>
                <Link href="/planes" onClick={() => setIsOpen(false)}>
                  <Button variant="outline" className="w-full">
                    <Crown className="h-4 w-4 mr-2 text-purple-500" />
                    Planes
                  </Button>
                </Link>
              </div>

              {/* Mobile Navigation */}
              <nav className="flex flex-col gap-1">
                {navItems.map((item) => {
                  const Icon = item.icon
                  const isActive = pathname === item.href
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                        isActive
                          ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
                          : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      {item.label}
                    </Link>
                  )
                })}
              </nav>

              {/* Settings Links */}
              <div className="mt-4 pt-4 border-t">
                <Link
                  href="/ajustes"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium hover:bg-muted"
                >
                  <Settings className="h-5 w-5" />
                  Ajustes
                </Link>
                <Link
                  href="/perfil"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium hover:bg-muted"
                >
                  <User className="h-5 w-5" />
                  Ajustes de Perfil
                </Link>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
