'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Check,
  X,
  Crown,
  Zap,
  Gift,
  Clock,
  ChevronDown,
  ChevronUp,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { subscriptionPlans, annualOffer, isOfferActive, getOfferTimeRemaining } from '@/data/plans'
import { cn } from '@/lib/utils'

const comparisonFeatures = [
  { name: 'Recetas disponibles', basic: '500', ultra: '800', masterchef: '1000+' },
  { name: 'Búsqueda simple', basic: true, ultra: true, masterchef: true },
  { name: 'Búsqueda avanzada con filtros', basic: false, ultra: true, masterchef: true },
  { name: 'Favoritos', basic: '10', ultra: 'Ilimitado', masterchef: 'Ilimitado' },
  { name: 'Crear recetas propias', basic: true, ultra: true, masterchef: true },
  { name: 'Reseñas de recetas', basic: true, ultra: true, masterchef: true },
  { name: 'Reseñas verificadas', basic: false, ultra: true, masterchef: true },
  { name: 'Filtros Pro (Populares/Cooksnaps)', basic: false, ultra: true, masterchef: true },
  { name: 'Filtros IA', basic: false, ultra: false, masterchef: true },
  { name: 'Logros disponibles', basic: '75', ultra: '175', masterchef: '250' },
  { name: 'Modo Thermomix', basic: false, ultra: true, masterchef: true },
  { name: 'Planificador semanal', basic: false, ultra: true, masterchef: true },
  { name: 'Planificador avanzado', basic: false, ultra: false, masterchef: true },
  { name: 'Calculadora nutricional', basic: false, ultra: true, masterchef: true },
  { name: 'Calculadora avanzada', basic: false, ultra: false, masterchef: true },
  { name: 'Asistente de voz', basic: false, ultra: false, masterchef: true },
  { name: 'Sin publicidad', basic: false, ultra: true, masterchef: true },
  { name: 'Acceso anticipado', basic: false, ultra: true, masterchef: true },
  { name: 'Soporte prioritario 24/7', basic: false, ultra: false, masterchef: true },
  { name: 'Sincronización en la nube', basic: false, ultra: false, masterchef: true },
]

export function PlansPage() {
  const [showComparison, setShowComparison] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(getOfferTimeRemaining())
  const offerActive = isOfferActive()

  useEffect(() => {
    if (!offerActive) return

    const interval = setInterval(() => {
      setTimeRemaining(getOfferTimeRemaining())
    }, 1000)

    return () => clearInterval(interval)
  }, [offerActive])

  const getFeatureValue = (value: boolean | string) => {
    if (typeof value === 'boolean') {
      return value ? <Check className="h-5 w-5 text-green-500" /> : <X className="h-5 w-5 text-gray-300" />
    }
    return <span className="font-medium">{value}</span>
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl font-bold mb-4">
              Elige tu plan perfecto
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Desde principiantes hasta chefs profesionales, tenemos el plan ideal para ti
            </p>
          </motion.div>
        </div>

        {/* Offer Banner */}
        {offerActive && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-8"
          >
            <Card className="bg-gradient-to-r from-orange-500 to-green-500 text-white overflow-hidden">
              <CardContent className="py-6 px-8">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <Gift className="h-12 w-12" />
                    <div>
                      <h3 className="text-2xl font-bold">¡Oferta Especial!</h3>
                      <p className="text-white/90">13% de descuento en planes anuales</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 bg-white/20 rounded-lg px-4 py-2">
                    <Clock className="h-5 w-5" />
                    <div className="text-center">
                      <div className="text-sm">Termina en</div>
                      <div className="text-lg font-mono font-bold">
                        {timeRemaining.days}d {timeRemaining.hours}h {timeRemaining.minutes}m {timeRemaining.seconds}s
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {subscriptionPlans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={cn(
                "relative",
                plan.highlighted && "md:-mt-4 md:mb-4"
              )}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10">
                  <Badge className="bg-orange-500 text-white px-4 py-1">
                    {plan.badge}
                  </Badge>
                </div>
              )}
              <Card className={cn(
                "h-full flex flex-col",
                plan.highlighted && "border-2 border-orange-500 shadow-xl"
              )}>
                <CardHeader className="text-center pb-2">
                  <CardTitle className="text-2xl flex items-center justify-center gap-2">
                    {plan.id === 'masterchef' && <Crown className="h-6 w-6 text-yellow-500" />}
                    {plan.id === 'ultra' && <Zap className="h-6 w-6 text-blue-500" />}
                    {plan.name}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {plan.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  {/* Price */}
                  <div className="text-center mb-6">
                    {plan.price === 0 ? (
                      <div className="text-4xl font-bold text-green-600">Gratis</div>
                    ) : (
                      <div>
                        <div className="flex items-center justify-center gap-2">
                          <span className="text-2xl text-muted-foreground line-through">
                            €{plan.originalPrice}
                          </span>
                          <span className="text-4xl font-bold">€{plan.price}</span>
                        </div>
                        <div className="text-muted-foreground">/mes</div>
                        {plan.trialDays && (
                          <div className="text-sm text-green-600 mt-1">
                            {plan.trialDays} días de prueba gratis
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Features */}
                  <ul className="space-y-3">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button
                    className={cn(
                      "w-full",
                      plan.highlighted 
                        ? "bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                        : "",
                      plan.price === 0 && "bg-gray-100 text-gray-800 hover:bg-gray-200"
                    )}
                    variant={plan.highlighted ? "default" : "outline"}
                  >
                    {plan.price === 0 ? 'Comenzar Gratis' : 'Comenzar prueba gratis'}
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Comparison Toggle */}
        <div className="text-center mb-6">
          <Button
            variant="outline"
            onClick={() => setShowComparison(!showComparison)}
            className="gap-2"
          >
            {showComparison ? 'Ocultar' : 'Ver'} comparación detallada
            {showComparison ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </Button>
        </div>

        {/* Comparison Table */}
        {showComparison && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b bg-muted/50">
                        <th className="text-left p-4 font-medium">Características</th>
                        <th className="text-center p-4 font-medium">Básico</th>
                        <th className="text-center p-4 font-medium bg-orange-50 dark:bg-orange-900/20">
                          <div className="flex items-center justify-center gap-1">
                            <Zap className="h-4 w-4 text-blue-500" />
                            Ultra
                          </div>
                        </th>
                        <th className="text-center p-4 font-medium bg-yellow-50 dark:bg-yellow-900/20">
                          <div className="flex items-center justify-center gap-1">
                            <Crown className="h-4 w-4 text-yellow-500" />
                            MasterChef
                          </div>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {comparisonFeatures.map((feature, index) => (
                        <tr
                          key={feature.name}
                          className={cn(
                            "border-b",
                            index % 2 === 0 && "bg-muted/30"
                          )}
                        >
                          <td className="p-4 font-medium">{feature.name}</td>
                          <td className="text-center p-4">
                            {getFeatureValue(feature.basic)}
                          </td>
                          <td className="text-center p-4 bg-orange-50/50 dark:bg-orange-900/10">
                            {getFeatureValue(feature.ultra)}
                          </td>
                          <td className="text-center p-4 bg-yellow-50/50 dark:bg-yellow-900/10">
                            {getFeatureValue(feature.masterchef)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Annual Discount Info */}
        {offerActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mt-8 text-center"
          >
            <p className="text-muted-foreground">
              💰 Paga anualmente y ahorra un <strong>13%</strong> en cualquier plan
            </p>
          </motion.div>
        )}
      </div>
    </div>
  )
}
