import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Recipe, Timer, ShoppingItem } from '@/types'

// Current User Store (simulated)
interface UserState {
  userId: string
  userName: string
  userEmail: string
  isAuthenticated: boolean
  setUserId: (id: string) => void
  setUserName: (name: string) => void
  setUserEmail: (email: string) => void
  login: (id: string, name: string, email: string) => void
  logout: () => void
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      userId: 'demo-user',
      userName: 'Usuario Demo',
      userEmail: 'demo@cocinaviva.com',
      isAuthenticated: true,
      setUserId: (id) => set({ userId: id }),
      setUserName: (name) => set({ userName: name }),
      setUserEmail: (email) => set({ userEmail: email }),
      login: (id, name, email) => set({ 
        userId: id, 
        userName: name, 
        userEmail: email, 
        isAuthenticated: true 
      }),
      logout: () => set({ 
        userId: '', 
        userName: '', 
        userEmail: '', 
        isAuthenticated: false 
      }),
    }),
    { name: 'cocinaviva-user' }
  )
)

// Timer Store
interface TimerState {
  timers: Timer[]
  addTimer: (timer: Omit<Timer, 'id' | 'createdAt'>) => string
  removeTimer: (id: string) => void
  updateTimer: (id: string, updates: Partial<Timer>) => void
  startTimer: (id: string) => void
  pauseTimer: (id: string) => void
  resetTimer: (id: string) => void
  tickTimer: (id: string) => void
  clearAllTimers: () => void
}

export const useTimerStore = create<TimerState>()(
  persist(
    (set, get) => ({
      timers: [],
      addTimer: (timerData) => {
        const id = `timer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        const timer: Timer = {
          ...timerData,
          id,
          createdAt: new Date(),
        }
        set((state) => ({ timers: [...state.timers, timer] }))
        return id
      },
      removeTimer: (id) => {
        set((state) => ({ timers: state.timers.filter((t) => t.id !== id) }))
      },
      updateTimer: (id, updates) => {
        set((state) => ({
          timers: state.timers.map((t) => (t.id === id ? { ...t, ...updates } : t)),
        }))
      },
      startTimer: (id) => {
        set((state) => ({
          timers: state.timers.map((t) =>
            t.id === id ? { ...t, isRunning: true, isPaused: false } : t
          ),
        }))
      },
      pauseTimer: (id) => {
        set((state) => ({
          timers: state.timers.map((t) =>
            t.id === id ? { ...t, isRunning: false, isPaused: true } : t
          ),
        }))
      },
      resetTimer: (id) => {
        const timer = get().timers.find((t) => t.id === id)
        if (timer) {
          set((state) => ({
            timers: state.timers.map((t) =>
              t.id === id ? { ...t, remaining: t.duration, isRunning: false, isPaused: false } : t
            ),
          }))
        }
      },
      tickTimer: (id) => {
        set((state) => ({
          timers: state.timers.map((t) => {
            if (t.id === id && t.isRunning) {
              const newRemaining = Math.max(0, t.remaining - 1)
              return { ...t, remaining: newRemaining, isRunning: newRemaining > 0 }
            }
            return t
          }),
        }))
      },
      clearAllTimers: () => set({ timers: [] }),
    }),
    { name: 'cocinaviva-timers' }
  )
)

// Shopping List Store
interface ShoppingListState {
  items: ShoppingItem[]
  addItem: (item: Omit<ShoppingItem, 'id' | 'addedAt'>) => void
  removeItem: (id: string) => void
  updateItem: (id: string, updates: Partial<ShoppingItem>) => void
  toggleItem: (id: string) => void
  clearChecked: () => void
  clearAll: () => void
  addRecipeIngredients: (recipe: Recipe) => void
}

export const useShoppingListStore = create<ShoppingListState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (itemData) => {
        const item: ShoppingItem = {
          ...itemData,
          id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          addedAt: new Date(),
        }
        set((state) => ({ items: [...state.items, item] }))
      },
      removeItem: (id) => {
        set((state) => ({ items: state.items.filter((i) => i.id !== id) }))
      },
      updateItem: (id, updates) => {
        set((state) => ({
          items: state.items.map((i) => (i.id === id ? { ...i, ...updates } : i)),
        }))
      },
      toggleItem: (id) => {
        set((state) => ({
          items: state.items.map((i) => (i.id === id ? { ...i, isChecked: !i.isChecked } : i)),
        }))
      },
      clearChecked: () => {
        set((state) => ({ items: state.items.filter((i) => !i.isChecked) }))
      },
      clearAll: () => set({ items: [] }),
      addRecipeIngredients: (recipe) => {
        const newItems: ShoppingItem[] = recipe.ingredients.map((ri) => ({
          id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          shoppingListId: 'default',
          ingredientId: ri.ingredientId,
          customName: null,
          quantity: ri.quantity,
          unit: ri.unit,
          isChecked: false,
          notes: ri.notes,
          addedAt: new Date(),
          ingredient: ri.ingredient,
        }))
        set((state) => ({ items: [...state.items, ...newItems] }))
      },
    }),
    { name: 'cocinaviva-shopping' }
  )
)

// Recipe Step Tracking Store
interface StepTrackingState {
  currentRecipeId: string | null
  currentStep: number
  totalSteps: number
  completedSteps: Set<number>
  handsFreeMode: boolean
  setRecipe: (recipeId: string, totalSteps: number) => void
  nextStep: () => void
  prevStep: () => void
  goToStep: (step: number) => void
  toggleStepComplete: (step: number) => void
  setHandsFreeMode: (enabled: boolean) => void
  reset: () => void
}

export const useStepTrackingStore = create<StepTrackingState>()(
  persist(
    (set, get) => ({
      currentRecipeId: null,
      currentStep: 0,
      totalSteps: 0,
      completedSteps: new Set(),
      handsFreeMode: false,
      setRecipe: (recipeId, totalSteps) => {
        set({
          currentRecipeId: recipeId,
          currentStep: 0,
          totalSteps,
          completedSteps: new Set(),
        })
      },
      nextStep: () => {
        const { currentStep, totalSteps } = get()
        if (currentStep < totalSteps - 1) {
          set({ currentStep: currentStep + 1 })
        }
      },
      prevStep: () => {
        const { currentStep } = get()
        if (currentStep > 0) {
          set({ currentStep: currentStep - 1 })
        }
      },
      goToStep: (step) => {
        const { totalSteps } = get()
        if (step >= 0 && step < totalSteps) {
          set({ currentStep: step })
        }
      },
      toggleStepComplete: (step) => {
        const { completedSteps } = get()
        const newCompleted = new Set(completedSteps)
        if (newCompleted.has(step)) {
          newCompleted.delete(step)
        } else {
          newCompleted.add(step)
        }
        set({ completedSteps: newCompleted })
      },
      setHandsFreeMode: (enabled) => set({ handsFreeMode: enabled }),
      reset: () => {
        set({
          currentRecipeId: null,
          currentStep: 0,
          totalSteps: 0,
          completedSteps: new Set(),
          handsFreeMode: false,
        })
      },
    }),
    {
      name: 'cocinaviva-step-tracking',
      storage: {
        getItem: (name) => {
          const str = localStorage.getItem(name)
          if (!str) return null
          const data = JSON.parse(str)
          return {
            ...data,
            state: {
              ...data.state,
              completedSteps: new Set(data.state.completedSteps || []),
            },
          }
        },
        setItem: (name, value) => {
          const data = {
            ...value,
            state: {
              ...value.state,
              completedSteps: Array.from(value.state.completedSteps || []),
            },
          }
          localStorage.setItem(name, JSON.stringify(data))
        },
        removeItem: (name) => localStorage.removeItem(name),
      },
    }
  )
)

// Offline Store
interface OfflineState {
  savedRecipes: string[]
  saveRecipe: (recipeId: string) => void
  removeRecipe: (recipeId: string) => void
  isRecipeSaved: (recipeId: string) => boolean
}

export const useOfflineStore = create<OfflineState>()(
  persist(
    (set, get) => ({
      savedRecipes: [],
      saveRecipe: (recipeId) => {
        const { savedRecipes } = get()
        if (!savedRecipes.includes(recipeId)) {
          set({ savedRecipes: [...savedRecipes, recipeId] })
        }
      },
      removeRecipe: (recipeId) => {
        set((state) => ({
          savedRecipes: state.savedRecipes.filter((id) => id !== recipeId),
        }))
      },
      isRecipeSaved: (recipeId) => {
        return get().savedRecipes.includes(recipeId)
      },
    }),
    { name: 'cocinaviva-offline' }
  )
)

// UI Store
interface UIState {
  currentView: 'home' | 'recipes' | 'recipe-detail' | 'step-tracking' | 'shopping' | 'favorites' | 'history' | 'community' | 'create' | 'gallery'
  sidebarOpen: boolean
  searchQuery: string
  setCurrentView: (view: UIState['currentView']) => void
  toggleSidebar: () => void
  setSearchQuery: (query: string) => void
}

export const useUIStore = create<UIState>()((set) => ({
  currentView: 'home',
  sidebarOpen: false,
  searchQuery: '',
  setCurrentView: (view) => set({ currentView: view }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  setSearchQuery: (query) => set({ searchQuery: query }),
}))
