// Subscription Plans
export interface SubscriptionPlan {
  id: 'basico' | 'ultra' | 'masterchef'
  name: string
  description: string
  price: number
  originalPrice?: number
  period: 'mes' | 'año'
  features: string[]
  highlighted?: boolean
  badge?: string
  trialDays?: number
  discount?: number
  achievements: number
  recipes: number
  favoritesLimit: number | 'ilimitado'
  hasAdvancedSearch: boolean
  hasVerifiedReviews: boolean
  hasNoAds: boolean
  hasIAFilters: boolean
  hasProFilters: boolean
  exclusiveFeatures?: string[]
  monthlyPrice?: number
  annualPrice?: number
  youngDiscount?: number
}

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'basico',
    name: 'Básico',
    description: 'Perfecto para empezar a cocinar',
    price: 0,
    monthlyPrice: 0,
    annualPrice: 0,
    period: 'mes',
    recipes: 500,
    achievements: 100,
    favoritesLimit: 15,
    hasAdvancedSearch: false,
    hasVerifiedReviews: false,
    hasNoAds: true,
    hasIAFilters: false,
    hasProFilters: false,
    features: [
      'Acceso a 500 recetas',
      'Búsqueda simple',
      'Favoritos (hasta 15)',
      'Crear recetas propias (Gratis)',
      'Reseñas de recetas',
      'Temporizador gratuito',
      'Lista de compras gratuita',
      '100 logros disponibles',
      'Sin publicidad',
    ],
  },
  {
    id: 'ultra',
    name: 'Ultra',
    description: 'Para cocineros entusiastas - Prueba 7 días gratis',
    price: 6.07,
    monthlyPrice: 6.07, // Precio mensual SIN descuento
    annualPrice: 62.64, // Precio anual CON 14% descuento: 6.07 * 12 * 0.86 = 62.64
    originalPrice: 6.99,
    period: 'mes',
    trialDays: 7,
    highlighted: true,
    badge: 'Popular',
    discount: 14,
    youngDiscount: 20, // Carne joven 20%
    recipes: 800,
    achievements: 200,
    favoritesLimit: 27,
    hasAdvancedSearch: true,
    hasVerifiedReviews: true,
    hasNoAds: true,
    hasIAFilters: false,
    hasProFilters: true,
    features: [
      'Acceso a 800 recetas',
      'Búsqueda avanzada con filtros',
      'Favoritos (27/mes)',
      'Crear recetas propias',
      'Reseñas verificadas',
      'Filtros Pro (desbloqueados)',
      '200 logros disponibles',
      'Modo Thermomix completo',
      'Planificador semanal',
      'Calculadora nutricional',
      'Sin publicidad',
      'Acceso anticipado a funciones',
      '7 días de prueba gratis',
      'Filtros IA y Pro desbloqueados en prueba',
    ],
    exclusiveFeatures: [
      'Filtros Pro desbloqueados durante la prueba',
      'Filtros IA de prueba por 7 días',
      'Contador regresivo de prueba',
    ],
  },
  {
    id: 'masterchef',
    name: 'MasterChef',
    description: 'La experiencia culinaria completa - Premium',
    price: 11.13,
    monthlyPrice: 11.13, // Precio mensual SIN descuento
    annualPrice: 114.85, // Precio anual CON 14% descuento: 11.13 * 12 * 0.86 = 114.85
    originalPrice: 12.80,
    period: 'mes',
    trialDays: 7,
    badge: 'Premium',
    discount: 14,
    youngDiscount: 20, // Carne joven 20%
    recipes: 2400, // 500 + 450 Thermomix + 450 tradicionales + otras
    achievements: 300,
    favoritesLimit: 'ilimitado',
    hasAdvancedSearch: true,
    hasVerifiedReviews: true,
    hasNoAds: true,
    hasIAFilters: true,
    hasProFilters: true,
    features: [
      'Acceso a 2.400+ recetas completas',
      'Filtros IA y Pro ilimitados',
      'Favoritos ilimitados',
      'Crear recetas propias',
      'Reseñas verificadas',
      'TODOS los logros disponibles (300)',
      'Modo Thermomix completo',
      'Planificador semanal avanzado',
      'Calculadora nutricional avanzada',
      'Asistente de voz inteligente (IA)',
      'Recetas exclusivas de chefs',
      'Acceso anticipado a nuevas funciones',
      'Sin publicidad',
      'Soporte prioritario 24/7',
      'Sincronización en la nube',
      '7 días de prueba gratis',
    ],
    exclusiveFeatures: [
      'Asistente de voz con IA avanzada',
      'Recetas exclusivas de chefs famosos',
      'Sincronización multi-dispositivo',
    ],
  },
]

// Discount Plans View
export const discountOptions = [
  {
    id: 'monthly',
    name: 'Mensual',
    description: 'Sin descuento',
    discount: 0,
  },
  {
    id: 'annual',
    name: 'Anual',
    description: '14% de descuento',
    discount: 14,
  },
  {
    id: 'young',
    name: 'Carne Joven',
    description: '20% de descuento (18-25 años)',
    discount: 20,
    requirement: 'Verificación de edad requerida',
  },
]

// FAQ - Preguntas Frecuentes
export const faqs = [
  {
    question: '¿Puedo cancelar mi suscripción en cualquier momento?',
    answer: 'Sí, puedes cancelar tu suscripción en cualquier momento desde la configuración de tu cuenta. Seguirás teniendo acceso hasta el final del período de pago.',
  },
  {
    question: '¿Qué pasa después de los 7 días de prueba?',
    answer: 'Después de los 7 días de prueba gratuita, se te cobrará automáticamente el plan seleccionado. Puedes cancelar antes de que termine la prueba si no deseas continuar.',
  },
  {
    question: '¿Los filtros IA y Pro son gratuitos?',
    answer: 'Los filtros IA y Pro están desbloqueados durante los 7 días de prueba del plan Ultra. Después, los filtros Pro permanecen activos en Ultra, mientras que los filtros IA requieren el plan MasterChef.',
  },
  {
    question: '¿El temporizador y la lista de compras son gratuitos?',
    answer: 'Sí, el temporizador y la lista de compras son completamente gratuitos en todos los planes, incluido el plan Básico.',
  },
  {
    question: '¿Cuántos favoritos puedo tener en cada plan?',
    answer: 'Básico: 15 favoritos, Ultra: 27 favoritos/mes, MasterChef: favoritos ilimitados.',
  },
  {
    question: '¿Hay publicidad en el plan gratuito?',
    answer: 'No, CocinaViva no muestra publicidad en ningún plan, incluido el plan Básico gratuito.',
  },
  {
    question: '¿Cómo funciona el descuento anual del 14%?',
    answer: 'Si eliges pagar anualmente en lugar de mensualmente, obtienes un 14% de descuento en el precio total. El pago se realiza por adelantado.',
  },
  {
    question: '¿Qué es el descuento Carne Joven?',
    answer: 'Si tienes entre 18 y 25 años, puedes obtener un 20% de descuento en cualquier plan de pago. Se requiere verificación de edad mediante documento oficial.',
  },
  {
    question: '¿Puedo cambiar de plan más tarde?',
    answer: 'Sí, puedes actualizar o degradar tu plan en cualquier momento. Si actualizas, el cambio es inmediato. Si degradas, el cambio se aplicará al final del período actual.',
  },
  {
    question: '¿Qué métodos de pago aceptan?',
    answer: 'Aceptamos tarjetas de crédito/débito (Visa, Mastercard, American Express), PayPal, Apple Pay y Google Pay.',
  },
  {
    question: '¿Los logros se consiguen o se regalan?',
    answer: 'Los logros se consiguen progresivamente a medida que usas la app, cocinas recetas y permaneces activo. No se regalan, deben ganarse.',
  },
]

// Annual discount offer - Actualizado a 14%
export const annualOffer = {
  discount: 14,
  endDate: new Date('2025-02-28T23:59:59'),
  description: 'Descuento anual del 14% en todos los planes',
}

// Check if offer is active
export function isOfferActive(): boolean {
  return new Date() < annualOffer.endDate
}

// Get time remaining for offer
export function getOfferTimeRemaining(): { days: number; hours: number; minutes: number; seconds: number } {
  const now = new Date()
  const diff = annualOffer.endDate.getTime() - now.getTime()
  
  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0 }
  }
  
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
  const seconds = Math.floor((diff % (1000 * 60)) / 1000)
  
  return { days, hours, minutes, seconds }
}

// Calculate price with discount
export function calculatePrice(plan: SubscriptionPlan, discountType: 'monthly' | 'annual' | 'young'): number {
  if (plan.price === 0) return 0
  
  switch (discountType) {
    case 'monthly':
      return plan.monthlyPrice || plan.price
    case 'annual':
      return plan.annualPrice || plan.price * 12 * 0.86
    case 'young':
      return (plan.monthlyPrice || plan.price) * 0.80 // 20% descuento
    default:
      return plan.price
  }
}
