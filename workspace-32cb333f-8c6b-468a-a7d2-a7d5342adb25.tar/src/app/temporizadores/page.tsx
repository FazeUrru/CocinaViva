'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Timer,
  Plus,
  Play,
  Pause,
  RotateCcw,
  Trash2,
  Clock,
  AlarmClock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useTimerStore } from '@/store'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

const presetTimers = [
  { name: 'Hervir agua', duration: 5 * 60, icon: '🫖' },
  { name: 'Huevo duro', duration: 10 * 60, icon: '🥚' },
  { name: 'Arroz', duration: 20 * 60, icon: '🍚' },
  { name: 'Pasta', duration: 12 * 60, icon: '🍝' },
  { name: 'Carne al horno', duration: 45 * 60, icon: '🥩' },
  { name: 'Galletas', duration: 15 * 60, icon: '🍪' },
]

export default function TemporizadoresPage() {
  const { timers, addTimer, removeTimer, startTimer, pauseTimer, resetTimer, tickTimer } = useTimerStore()
  const [newTimerName, setNewTimerName] = useState('')
  const [newTimerMinutes, setNewTimerMinutes] = useState(10)
  const [newTimerSeconds, setNewTimerSeconds] = useState(0)
  const [dialogOpen, setDialogOpen] = useState(false)

  // Timer tick effect
  useEffect(() => {
    const interval = setInterval(() => {
      timers.forEach(timer => {
        if (timer.isRunning) {
          tickTimer(timer.id)
          const updatedTimer = timers.find(t => t.id === timer.id)
          if (updatedTimer && updatedTimer.remaining <= 1) {
            toast.success(`¡${timer.name} completado!`)
            // Play sound
            try {
              const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2teleVoMWhqE0+zSqWUQE5K3z+7SmEgVLnO8yefOn0UUPICxv7OrmEMSIYGtq6fLmlUfKF9vYF9SJyYoGh4YHhcmJyQeGhwcHCEhHRwcHBwhIR0cHBwcISEdHBwcHCEhHRwcHBwhIR0cHBwcISEdHBwcHCEhHRwcHBwhIR0cHBw=')
              audio.play().catch(() => {})
            } catch (e) {
              console.log('Audio not supported')
            }
          }
        }
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [timers, tickTimer])

  const addCustomTimer = () => {
    const duration = newTimerMinutes * 60 + newTimerSeconds
    if (duration <= 0) {
      toast.error('El tiempo debe ser mayor a 0')
      return
    }
    addTimer({
      name: newTimerName || 'Temporizador',
      duration,
      remaining: duration,
      isRunning: false,
      isPaused: false,
    })
    setNewTimerName('')
    setNewTimerMinutes(10)
    setNewTimerSeconds(0)
    setDialogOpen(false)
    toast.success('Temporizador añadido')
  }

  const addPresetTimer = (preset: typeof presetTimers[0]) => {
    addTimer({
      name: preset.name,
      duration: preset.duration,
      remaining: preset.duration,
      isRunning: false,
      isPaused: false,
    })
    toast.success(`${preset.name} añadido`)
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const getProgress = (timer: typeof timers[0]) => {
    return ((timer.duration - timer.remaining) / timer.duration) * 100
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Timer className="h-8 w-8 text-orange-500" />
              Temporizadores
            </h1>
            <p className="text-muted-foreground">
              Gestiona múltiples temporizadores para tu cocina
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          {/* Add Timer Dialog */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-xl font-semibold">Temporizadores rápidos</h2>
              <p className="text-muted-foreground text-sm">Selecciona un temporizador predefinido</p>
            </div>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-orange-500 to-green-500">
                  <Plus className="h-4 w-4 mr-2" />
                  Nuevo temporizador
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Crear temporizador</DialogTitle>
                  <DialogDescription>
                    Configura un nuevo temporizador personalizado
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre</Label>
                    <Input
                      id="name"
                      placeholder="Ej: Horno, Pasta..."
                      value={newTimerName}
                      onChange={(e) => setNewTimerName(e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="minutes">Minutos</Label>
                      <Input
                        id="minutes"
                        type="number"
                        min={0}
                        max={999}
                        value={newTimerMinutes}
                        onChange={(e) => setNewTimerMinutes(parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="seconds">Segundos</Label>
                      <Input
                        id="seconds"
                        type="number"
                        min={0}
                        max={59}
                        value={newTimerSeconds}
                        onChange={(e) => setNewTimerSeconds(parseInt(e.target.value) || 0)}
                      />
                    </div>
                  </div>
                  <Button onClick={addCustomTimer} className="w-full">
                    Crear temporizador
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Preset Timers */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4 mb-8">
            {presetTimers.map((preset, index) => (
              <motion.div
                key={preset.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card 
                  className="cursor-pointer hover:shadow-md transition-all hover:border-orange-300"
                  onClick={() => addPresetTimer(preset)}
                >
                  <CardContent className="pt-6 text-center">
                    <div className="text-3xl mb-2">{preset.icon}</div>
                    <div className="font-medium text-sm">{preset.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {Math.floor(preset.duration / 60)} min
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Active Timers */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Temporizadores activos</h2>
            {timers.length === 0 ? (
              <Card className="text-center py-12">
                <CardContent>
                  <AlarmClock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Sin temporizadores</h3>
                  <p className="text-muted-foreground">
                    Añade un temporizador para comenzar
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {timers.map((timer, index) => (
                  <motion.div
                    key={timer.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className={cn(
                      "overflow-hidden",
                      timer.isRunning && "border-orange-500 shadow-lg"
                    )}>
                      <div className="h-1 bg-muted">
                        <div 
                          className="h-full bg-gradient-to-r from-orange-500 to-green-500 transition-all"
                          style={{ width: `${getProgress(timer)}%` }}
                        />
                      </div>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{timer.name}</CardTitle>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeTimer(timer.id)}
                          >
                            <Trash2 className="h-4 w-4 text-muted-foreground" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center mb-4">
                          <div className={cn(
                            "text-5xl font-mono font-bold",
                            timer.remaining < 60 && "text-red-500",
                            timer.isRunning && timer.remaining >= 60 && "text-orange-500"
                          )}>
                            {formatTime(timer.remaining)}
                          </div>
                          {timer.remaining === 0 && (
                            <Badge className="bg-green-500 mt-2">¡Completado!</Badge>
                          )}
                        </div>
                        <div className="flex justify-center gap-2">
                          {timer.isRunning ? (
                            <Button
                              variant="outline"
                              onClick={() => pauseTimer(timer.id)}
                            >
                              <Pause className="h-4 w-4 mr-2" />
                              Pausar
                            </Button>
                          ) : (
                            <Button
                              onClick={() => startTimer(timer.id)}
                              disabled={timer.remaining === 0}
                            >
                              <Play className="h-4 w-4 mr-2" />
                              Iniciar
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            onClick={() => resetTimer(timer.id)}
                          >
                            <RotateCcw className="h-4 w-4 mr-2" />
                            Reiniciar
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
