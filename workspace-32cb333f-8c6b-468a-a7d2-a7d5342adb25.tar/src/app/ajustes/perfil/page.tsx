'use client'

import { useState } from 'react'
import Link from 'next/link'
import {
  User,
  Camera,
  Mail,
  Phone,
  MapPin,
  Calendar,
  ChefHat,
  Edit2,
  Save,
  Trophy,
  Star,
  Clock,
  Heart,
  Recipe,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'

const profileStats = {
  recipes: 24,
  favorites: 15,
  achievements: 12,
  points: 450,
  level: 'Principiante',
  nextLevel: 'Intermedio',
  progressToNext: 45,
}

export default function PerfilPage() {
  const [isEditing, setIsEditing] = useState(false)
  const [profile, setProfile] = useState({
    name: 'Usuario Demo',
    email: 'demo@cocinaviva.com',
    phone: '+34 612 345 678',
    location: 'Madrid, España',
    bio: 'Apasionado de la cocina mediterránea. Me encanta experimentar con nuevas recetas y compartir mis creaciones.',
    website: '',
    instagram: '@cocinaviva',
    birthdate: '1990-01-15',
    gender: 'Prefiero no decir',
    cookingLevel: 'Principiante',
    specialties: ['Española', 'Italiana', 'Postres'],
    dietaryPreferences: ['Sin gluten', 'Vegetariano'],
    cookingGoals: ['Comer más sano', 'Aprender técnicas nuevas', 'Impresionar a amigos'],
  })

  const handleSave = () => {
    setIsEditing(false)
    // Save profile logic
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <User className="h-8 w-8 text-orange-500" />
              Perfil
            </h1>
            <p className="text-muted-foreground">
              Gestiona tu información personal
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Sidebar Navigation */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardContent className="pt-4">
                  <nav className="space-y-1">
                    <Link href="/ajustes" className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted text-muted-foreground">
                      <ChefHat className="h-4 w-4" />
                      Ajustes generales
                    </Link>
                    <Link href="/ajustes/perfil" className="flex items-center gap-2 p-2 rounded-lg bg-orange-50 text-orange-600 font-medium">
                      <User className="h-4 w-4" />
                      Perfil
                    </Link>
                    <Link href="/logros" className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted text-muted-foreground">
                      <Trophy className="h-4 w-4" />
                      Logros
                    </Link>
                  </nav>
                </CardContent>
              </Card>
            </div>

            {/* Profile Content */}
            <div className="lg:col-span-3 space-y-6">
              {/* Profile Header */}
              <Card>
                <CardContent className="pt-6">
                  <div className="flex flex-col sm:flex-row items-center gap-6">
                    <div className="relative">
                      <Avatar className="w-24 h-24">
                        <AvatarImage src="/images/logo.png" />
                        <AvatarFallback className="text-2xl bg-gradient-to-br from-orange-500 to-green-500 text-white">
                          UD
                        </AvatarFallback>
                      </Avatar>
                      <Button size="icon" className="absolute -bottom-1 -right-1 rounded-full h-8 w-8">
                        <Camera className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="flex-1 text-center sm:text-left">
                      <h2 className="text-2xl font-bold">{profile.name}</h2>
                      <p className="text-muted-foreground">{profile.email}</p>
                      <div className="flex flex-wrap gap-2 mt-2 justify-center sm:justify-start">
                        <Badge className="bg-gradient-to-r from-orange-500 to-yellow-500">
                          <Trophy className="h-3 w-3 mr-1" />
                          {profileStats.level}
                        </Badge>
                        <Badge variant="outline">
                          <Star className="h-3 w-3 mr-1" />
                          {profileStats.points} puntos
                        </Badge>
                      </div>
                    </div>
                    <Button
                      variant={isEditing ? "default" : "outline"}
                      onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                      className="bg-gradient-to-r from-orange-500 to-green-500"
                    >
                      {isEditing ? (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Guardar
                        </>
                      ) : (
                        <>
                          <Edit2 className="h-4 w-4 mr-2" />
                          Editar perfil
                        </>
                      )}
                    </Button>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-500">{profileStats.recipes}</div>
                      <div className="text-sm text-muted-foreground">Recetas</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-500">{profileStats.favorites}</div>
                      <div className="text-sm text-muted-foreground">Favoritos</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-500">{profileStats.achievements}</div>
                      <div className="text-sm text-muted-foreground">Logros</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-500">{profileStats.points}</div>
                      <div className="text-sm text-muted-foreground">Puntos</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Personal Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Información personal</CardTitle>
                  <CardDescription>Tus datos básicos</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre completo</Label>
                      <Input
                        id="name"
                        value={profile.name}
                        onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={profile.email}
                        onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={profile.phone}
                        onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Ubicación</Label>
                      <Input
                        id="location"
                        value={profile.location}
                        onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="birthdate">Fecha de nacimiento</Label>
                      <Input
                        id="birthdate"
                        type="date"
                        value={profile.birthdate}
                        onChange={(e) => setProfile({ ...profile, birthdate: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">Género</Label>
                      <Select
                        value={profile.gender}
                        onValueChange={(v) => setProfile({ ...profile, gender: v })}
                        disabled={!isEditing}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Prefiero no decir">Prefiero no decir</SelectItem>
                          <SelectItem value="Masculino">Masculino</SelectItem>
                          <SelectItem value="Femenino">Femenino</SelectItem>
                          <SelectItem value="No binario">No binario</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Biografía</Label>
                    <Textarea
                      id="bio"
                      value={profile.bio}
                      onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                      disabled={!isEditing}
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Social Links */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Redes sociales</CardTitle>
                  <CardDescription>Conecta tus redes para compartir</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="website">Sitio web</Label>
                      <Input
                        id="website"
                        placeholder="https://tu-sitio.com"
                        value={profile.website}
                        onChange={(e) => setProfile({ ...profile, website: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="instagram">Instagram</Label>
                      <Input
                        id="instagram"
                        value={profile.instagram}
                        onChange={(e) => setProfile({ ...profile, instagram: e.target.value })}
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Cooking Preferences */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Preferencias culinarias</CardTitle>
                  <CardDescription>Tu estilo de cocina</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Nivel de cocina</Label>
                    <Select
                      value={profile.cookingLevel}
                      onValueChange={(v) => setProfile({ ...profile, cookingLevel: v })}
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Principiante">Principiante</SelectItem>
                        <SelectItem value="Intermedio">Intermedio</SelectItem>
                        <SelectItem value="Avanzado">Avanzado</SelectItem>
                        <SelectItem value="Experto">Experto</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Especialidades</Label>
                    <div className="flex flex-wrap gap-2">
                      {profile.specialties.map((s) => (
                        <Badge key={s} variant="secondary" className="text-sm">
                          {s}
                          {isEditing && (
                            <button className="ml-1 hover:text-red-500">×</button>
                          )}
                        </Badge>
                      ))}
                      {isEditing && (
                        <Button variant="outline" size="sm">
                          + Añadir
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Preferencias dietéticas</Label>
                    <div className="flex flex-wrap gap-2">
                      {profile.dietaryPreferences.map((p) => (
                        <Badge key={p} className="bg-green-500 text-sm">
                          {p}
                          {isEditing && (
                            <button className="ml-1 hover:text-red-200">×</button>
                          )}
                        </Badge>
                      ))}
                      {isEditing && (
                        <Button variant="outline" size="sm">
                          + Añadir
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Objetivos culinarios</Label>
                    <div className="flex flex-wrap gap-2">
                      {profile.cookingGoals.map((g) => (
                        <Badge key={g} variant="outline" className="text-sm">
                          {g}
                          {isEditing && (
                            <button className="ml-1 hover:text-red-500">×</button>
                          )}
                        </Badge>
                      ))}
                      {isEditing && (
                        <Button variant="outline" size="sm">
                          + Añadir
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Privacy Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Privacidad del perfil</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Perfil público</Label>
                      <p className="text-sm text-muted-foreground">Otros pueden ver tu perfil</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Mostrar estadísticas</Label>
                      <p className="text-sm text-muted-foreground">Mostrar tus recetas y logros</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Mostrar actividad</Label>
                      <p className="text-sm text-muted-foreground">Otros ven cuando cocinas</p>
                    </div>
                    <Switch />
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Permitir mensajes</Label>
                      <p className="text-sm text-muted-foreground">Recibir mensajes de otros usuarios</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
