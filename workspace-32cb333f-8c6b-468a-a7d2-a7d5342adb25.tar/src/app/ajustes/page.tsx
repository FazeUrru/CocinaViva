'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Settings,
  User,
  Bell,
  Moon,
  Globe,
  Lock,
  Eye,
  Volume2,
  Smartphone,
  Mail,
  Shield,
  Palette,
  Timer,
  Utensils,
  Heart,
  Download,
  Trash2,
  HelpCircle,
  Info,
  ChevronRight,
  Type,
  Accessibility,
  Contrast,
  Move,
  Subtitles,
  Hand,
  Zap,
  RefreshCw,
  ShieldCheck,
  Database,
  Users,
  BarChart3,
  FileText,
  Bug,
  Key,
  Server,
  MessageSquare,
  Lightbulb,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import Link from 'next/link'

// 15 Idiomas disponibles
const availableLanguages = [
  'Español', 'English', 'Français', 'Português', 'Deutsch',
  'Italiano', 'Nederlands', 'Polski', 'Русский', '中文',
  '日本語', '한국어', 'العربية', 'हिन्दी', 'Türkçe'
]

// 50 General Settings (actualizado)
const generalSettings = [
  { id: 'g1', name: 'Idioma', description: 'Selecciona el idioma de la aplicación (15 disponibles)', icon: Globe, type: 'select', options: availableLanguages },
  { id: 'g2', name: 'Tema', description: 'Modo claro, oscuro o automático', icon: Moon, type: 'select', options: ['Claro', 'Oscuro', 'Automático'] },
  { id: 'g3', name: 'Notificaciones Push', description: 'Recibir notificaciones en el dispositivo', icon: Bell, type: 'switch', default: true },
  { id: 'g4', name: 'Notificaciones Email', description: 'Recibir actualizaciones por correo', icon: Mail, type: 'switch', default: true },
  { id: 'g5', name: 'Sonidos', description: 'Efectos de sonido en la app', icon: Volume2, type: 'switch', default: true },
  { id: 'g6', name: 'Vibración', description: 'Vibración en notificaciones', icon: Smartphone, type: 'switch', default: true },
  { id: 'g7', name: 'Unidades de medida', description: 'Sistema métrico o imperial', icon: Utensils, type: 'select', options: ['Métrico (g, ml)', 'Imperial (oz, cups)'] },
  { id: 'g8', name: 'Formato de hora', description: 'Reloj de 12 o 24 horas', icon: Timer, type: 'select', options: ['12 horas', '24 horas'] },
  { id: 'g9', name: 'Unidad de temperatura', description: 'Celsius o Fahrenheit', icon: Palette, type: 'select', options: ['Celsius (°C)', 'Fahrenheit (°F)'] },
  { id: 'g10', name: 'Porciones por defecto', description: 'Número de porciones en nuevas recetas', icon: Heart, type: 'select', options: ['2', '3', '4', '5', '6'] },
  { id: 'g11', name: 'Autoguardado de cuenta', description: 'Guarda tu cuenta automáticamente', icon: Shield, type: 'switch', default: true },
  { id: 'g12', name: 'Descarga automática', description: 'Descargar recetas para uso offline', icon: Download, type: 'switch', default: false },
  { id: 'g13', name: 'Calidad de imagen', description: 'Calidad de las imágenes descargadas', icon: Eye, type: 'select', options: ['Alta', 'Media', 'Baja'] },
  { id: 'g14', name: 'Modo manos libres', description: 'Activar por defecto al cocinar', icon: Volume2, type: 'switch', default: false },
  { id: 'g15', name: 'Velocidad de voz', description: 'Velocidad del asistente de voz', icon: Volume2, type: 'select', options: ['Lenta', 'Normal', 'Rápida'] },
  { id: 'g16', name: 'Voz del asistente', description: 'Voz para el asistente de voz', icon: Volume2, type: 'select', options: ['Masculina', 'Femenina', 'Neutra'] },
  { id: 'g17', name: 'Sonido temporizador', description: 'Tono de alarma del temporizador', icon: Bell, type: 'select', options: ['Clásico', 'Digital', 'Suave', 'Ninguno'] },
  { id: 'g18', name: 'Vibración temporizador', description: 'Vibrar al finalizar temporizador', icon: Smartphone, type: 'switch', default: true },
  { id: 'g19', name: 'Recordatorios', description: 'Recordatorios de planificación', icon: Bell, type: 'switch', default: true },
  { id: 'g20', name: 'Sincronización', description: 'Sincronizar datos en la nube', icon: Globe, type: 'switch', default: true },
  { id: 'g21', name: 'Backup automático', description: 'Copia de seguridad automática', icon: Download, type: 'switch', default: true },
  { id: 'g22', name: 'Frecuencia backup', description: 'Cada cuánto hacer backup', icon: Timer, type: 'select', options: ['Diario', 'Semanal', 'Mensual'] },
  { id: 'g23', name: 'Datos móviles', description: 'Usar datos móviles para descargas', icon: Smartphone, type: 'switch', default: false },
  { id: 'g24', name: 'WiFi solo', description: 'Descargas solo con WiFi', icon: Globe, type: 'switch', default: true },
  { id: 'g25', name: 'Animaciones', description: 'Animaciones de la interfaz', icon: Palette, type: 'switch', default: true },
  { id: 'g26', name: 'Efectos parallax', description: 'Efectos visuales de profundidad', icon: Eye, type: 'switch', default: true },
  { id: 'g27', name: 'Autoplay videos', description: 'Reproducir videos automáticamente', icon: Globe, type: 'switch', default: false },
  { id: 'g28', name: 'Calidad video', description: 'Calidad de reproducción de video', icon: Eye, type: 'select', options: ['Auto', 'HD', 'SD'] },
  { id: 'g29', name: 'Subtítulos', description: 'Mostrar subtítulos en videos', icon: Globe, type: 'switch', default: true },
  { id: 'g30', name: 'Idioma subtítulos', description: 'Idioma de los subtítulos', icon: Globe, type: 'select', options: availableLanguages.slice(0, 5) },
  { id: 'g31', name: 'Publicidad personalizada', description: 'Anuncios basados en intereses', icon: Eye, type: 'switch', default: false },
  { id: 'g32', name: 'Analytics', description: 'Ayudar a mejorar la app', icon: Info, type: 'switch', default: true },
  { id: 'g33', name: 'Reportes de errores', description: 'Enviar errores automáticamente', icon: HelpCircle, type: 'switch', default: true },
  { id: 'g34', name: 'Ubicación', description: 'Usar ubicación para recetas locales', icon: Globe, type: 'switch', default: false },
  { id: 'g35', name: 'Cámara', description: 'Permitir acceso a la cámara', icon: Eye, type: 'switch', default: true },
  { id: 'g36', name: 'Micrófono', description: 'Permitir acceso al micrófono', icon: Volume2, type: 'switch', default: true },
  { id: 'g37', name: 'Galería', description: 'Permitir acceso a fotos', icon: Heart, type: 'switch', default: true },
  { id: 'g38', name: 'Contactos', description: 'Permitir acceso a contactos', icon: User, type: 'switch', default: false },
  { id: 'g39', name: 'Calendario', description: 'Sincronizar con calendario', icon: Timer, type: 'switch', default: false },
  { id: 'g40', name: 'Navegación privada', description: 'No guardar historial de búsqueda', icon: Lock, type: 'switch', default: false },
  { id: 'g41', name: 'Borrado automático', description: 'Borrar caché automáticamente', icon: Trash2, type: 'switch', default: false },
  { id: 'g42', name: 'Tamaño de fuente', description: 'Tamaño del texto', icon: Palette, type: 'select', options: ['Pequeño', 'Normal', 'Grande', 'Extra grande'] },
  { id: 'g43', name: 'Alto contraste', description: 'Modo de alto contraste', icon: Eye, type: 'switch', default: false },
  { id: 'g44', name: 'Reducir movimiento', description: 'Minimizar animaciones', icon: Palette, type: 'switch', default: false },
  { id: 'g45', name: 'Lector de pantalla', description: 'Optimizar para lectores de pantalla', icon: Volume2, type: 'switch', default: false },
  { id: 'g46', name: 'Atajos de teclado', description: 'Habilitar atajos de teclado', icon: Smartphone, type: 'switch', default: true },
  { id: 'g47', name: 'Gestos', description: 'Navegación por gestos', icon: Smartphone, type: 'switch', default: true },
  { id: 'g48', name: 'Modo Zen', description: 'Interfaz minimalista', icon: Moon, type: 'switch', default: false },
  { id: 'g49', name: 'Desarrollo', description: 'Mostrar opciones de desarrollador', icon: Info, type: 'switch', default: false },
  { id: 'g50', name: 'Actualizaciones automáticas', description: 'Actualizar la app automáticamente', icon: RefreshCw, type: 'switch', default: true },
]

// Accessibility Settings
const accessibilitySettings = [
  { id: 'a1', name: 'Tamaño de Texto en Recetas', description: 'Ajusta el tamaño del texto en las recetas', icon: Type, type: 'select', options: ['Pequeño', 'Mediano', 'Grande', 'Extra grande'], default: 'mediano' },
  { id: 'a2', name: 'Tipografía Global', description: 'Ajusta el tamaño de la tipografía de toda la aplicación', icon: Type, type: 'select', options: ['Pequeño (12px)', 'Mediano (14px)', 'Grande (16px)', 'Enorme (20px)'], default: 'mediano' },
  { id: 'a3', name: 'Modo Daltónico', description: 'Ajusta los colores para daltonismo', icon: Eye, type: 'select', options: ['Desactivado', 'Protanopia', 'Deuteranopia', 'Tritanopia', 'Monocromático'], default: 'desactivado' },
  { id: 'a4', name: 'Navegación por Teclado', description: 'Mejora la navegación usando solo el teclado', icon: Accessibility, type: 'switch', default: false },
  { id: 'a5', name: 'Lector de Pantalla Mejorado', description: 'Añade más contexto para lectores de pantalla', icon: Volume2, type: 'switch', default: false },
  { id: 'a6', name: 'Fuente para Dislexia', description: 'Utiliza tipografías adaptadas para dislexia', icon: Type, type: 'switch', default: false },
  { id: 'a7', name: 'Espaciado Interlineal Ampliado', description: 'Aumenta el espacio entre líneas', icon: Move, type: 'switch', default: false },
  { id: 'a8', name: 'Sin Temporizadores Automáticos', description: 'Evita que los temporizadores se inicien sin tu acción', icon: Timer, type: 'switch', default: false },
  { id: 'a9', name: 'Asistencia de Contraste Automático', description: 'Ajusta el contraste de texto según el fondo en imágenes', icon: Contrast, type: 'switch', default: false },
  { id: 'a10', name: 'Filtros Daltónicos Avanzados', description: 'Ajuste de filtros para múltiples tipos de daltonismo', icon: Eye, type: 'select', options: ['Ninguno', 'Protanopia severa', 'Deuteranopia severa', 'Tritanopia severa', 'Acromatopsia'], default: 'ninguno' },
  { id: 'a11', name: 'Subtítulos en Videos', description: 'Muestra siempre subtítulos en contenido multimedia', icon: Subtitles, type: 'switch', default: true },
  { id: 'a12', name: 'Lectura con Velocidad Ajustable', description: 'Control para dictado más lento o rápido del texto', icon: Volume2, type: 'select', options: ['Muy lenta', 'Lenta', 'Normal', 'Rápida', 'Muy rápida'], default: 'normal' },
  { id: 'a13', name: 'Controles Táctiles Ampliados', description: 'Aumenta el área de toque de todos los botones', icon: Hand, type: 'switch', default: false },
  { id: 'a14', name: 'Modo Manos Libres Total', description: 'Control absoluto con comandos de voz avanzados', icon: Zap, type: 'switch', default: false },
  { id: 'a15', name: 'Reducción de Movimiento', description: 'Elimina las animaciones complejas', icon: Move, type: 'switch', default: false },
  { id: 'a16', name: 'Dictado de Ingredientes Lento', description: 'Lee los ingredientes a velocidad reducida', icon: Volume2, type: 'switch', default: false },
]

// 14 Admin Settings
const adminSettings = [
  { id: 'adm1', name: 'Panel de Administración', description: 'Acceder al panel de admin', icon: ShieldCheck, type: 'link' },
  { id: 'adm2', name: 'Gestión de Usuarios', description: 'Administrar cuentas de usuario', icon: Users, type: 'link' },
  { id: 'adm3', name: 'Estadísticas Globales', description: 'Ver métricas de la aplicación', icon: BarChart3, type: 'link' },
  { id: 'adm4', name: 'Base de Datos', description: 'Gestionar la base de datos', icon: Database, type: 'link' },
  { id: 'adm5', name: 'Moderación de Contenido', description: 'Revisar contenido reportado', icon: Shield, type: 'link' },
  { id: 'adm6', name: 'Gestión de Recetas', description: 'Administrar recetas del sistema', icon: Utensils, type: 'link' },
  { id: 'adm7', name: 'Logs del Sistema', description: 'Ver registros de actividad', icon: FileText, type: 'link' },
  { id: 'adm8', name: 'Reportes de Bugs', description: 'Ver y gestionar bugs reportados', icon: Bug, type: 'link' },
  { id: 'adm9', name: 'Gestión de API Keys', description: 'Administrar claves de API', icon: Key, type: 'link' },
  { id: 'adm10', name: 'Configuración del Servidor', description: 'Ajustes del servidor', icon: Server, type: 'link' },
  { id: 'adm11', name: 'Mensajes a Usuarios', description: 'Enviar notificaciones globales', icon: MessageSquare, type: 'link' },
  { id: 'adm12', name: 'Gestión de Planes', description: 'Administrar planes y precios', icon: Heart, type: 'link' },
  { id: 'adm13', name: 'Backup del Sistema', description: 'Realizar copias de seguridad', icon: Download, type: 'link' },
  { id: 'adm14', name: 'Restaurar Sistema', description: 'Restaurar desde backup', icon: RefreshCw, type: 'link' },
]

// 50 Profile Settings
const profileSettings = [
  { id: 'p1', name: 'Nombre', description: 'Tu nombre visible', icon: User, type: 'text', default: '' },
  { id: 'p2', name: 'Apellido', description: 'Tu apellido', icon: User, type: 'text', default: '' },
  { id: 'p3', name: 'Email', description: 'Correo electrónico', icon: Mail, type: 'email', default: '' },
  { id: 'p4', name: 'Teléfono', description: 'Número de teléfono', icon: Smartphone, type: 'tel', default: '' },
  { id: 'p5', name: 'Foto de perfil', description: 'Imagen de tu avatar', icon: User, type: 'image' },
  { id: 'p6', name: 'Portada', description: 'Imagen de portada del perfil', icon: Palette, type: 'image' },
  { id: 'p7', name: 'Biografía', description: 'Cuéntanos sobre ti', icon: Info, type: 'textarea', default: '' },
  { id: 'p8', name: 'Ubicación', description: 'Tu ciudad o país', icon: Globe, type: 'text', default: '' },
  { id: 'p9', name: 'Sitio web', description: 'Tu página personal', icon: Globe, type: 'url', default: '' },
  { id: 'p10', name: 'Instagram', description: 'Usuario de Instagram', icon: Globe, type: 'text', default: '' },
  { id: 'p11', name: 'Twitter/X', description: 'Usuario de X', icon: Globe, type: 'text', default: '' },
  { id: 'p12', name: 'Facebook', description: 'Perfil de Facebook', icon: Globe, type: 'text', default: '' },
  { id: 'p13', name: 'YouTube', description: 'Canal de YouTube', icon: Globe, type: 'text', default: '' },
  { id: 'p14', name: 'TikTok', description: 'Usuario de TikTok', icon: Globe, type: 'text', default: '' },
  { id: 'p15', name: 'Pinterest', description: 'Perfil de Pinterest', icon: Globe, type: 'text', default: '' },
  { id: 'p16', name: 'Nivel de cocina', description: 'Tu experiencia culinaria', icon: Utensils, type: 'select', options: ['Principiante', 'Intermedio', 'Avanzado', 'Profesional'] },
  { id: 'p17', name: 'Especialidad', description: 'Tu tipo de cocina favorita', icon: Heart, type: 'select', options: ['Española', 'Italiana', 'Mexicana', 'Asiática', 'Mediterránea', 'Otra'] },
  { id: 'p18', name: 'Preferencia alimentaria', description: 'Tipo de dieta', icon: Heart, type: 'select', options: ['Omnívoro', 'Vegetariano', 'Vegano', 'Keto', 'Paleo', 'Otro'] },
  { id: 'p19', name: 'Alergias', description: 'Alergias alimentarias', icon: Shield, type: 'multiselect', options: ['Nueces', 'Lácteos', 'Huevos', 'Mariscos', 'Gluten', 'Ninguna'] },
  { id: 'p20', name: 'Restricciones', description: 'Restricciones alimentarias', icon: Shield, type: 'multiselect', options: ['Sin gluten', 'Sin lactosa', 'Sin azúcar', 'Bajo en sodio', 'Ninguna'] },
  { id: 'p21', name: 'Objetivo', description: 'Tu objetivo culinario', icon: Heart, type: 'select', options: ['Aprender a cocinar', 'Mejorar técnicas', 'Cocinar saludable', 'Impresionar', 'Profesional'] },
  { id: 'p22', name: 'Frecuencia cocina', description: 'Cuánto cocinas', icon: Timer, type: 'select', options: ['Diario', 'Varias veces por semana', 'Semanal', 'Ocasional'] },
  { id: 'p23', name: 'Personas en casa', description: 'Para cuántos cocinas', icon: User, type: 'select', options: ['1', '2', '3-4', '5+', 'Variable'] },
  { id: 'p24', name: 'Equipamiento', description: 'Utensilios disponibles', icon: Utensils, type: 'multiselect', options: ['Thermomix', 'Crockpot', 'Horno', 'Airfryer', 'Robot de cocina', 'Básico'] },
  { id: 'p25', name: 'Perfil público', description: 'Mostrar perfil públicamente', icon: Eye, type: 'switch', default: true },
  { id: 'p26', name: 'Mostrar recetas', description: 'Mostrar mis recetas en el perfil', icon: Eye, type: 'switch', default: true },
  { id: 'p27', name: 'Mostrar favoritos', description: 'Mostrar recetas favoritas', icon: Eye, type: 'switch', default: false },
  { id: 'p28', name: 'Mostrar logros', description: 'Mostrar logros desbloqueados', icon: Eye, type: 'switch', default: true },
  { id: 'p29', name: 'Mostrar estadísticas', description: 'Mostrar estadísticas de cocina', icon: Eye, type: 'switch', default: true },
  { id: 'p30', name: 'Permitir mensajes', description: 'Recibir mensajes de otros usuarios', icon: Mail, type: 'switch', default: true },
  { id: 'p31', name: 'Permitir comentarios', description: 'Recibir comentarios en recetas', icon: Mail, type: 'switch', default: true },
  { id: 'p32', name: 'Notificaciones seguidores', description: 'Aviso de nuevos seguidores', icon: Bell, type: 'switch', default: true },
  { id: 'p33', name: 'Notificaciones retos', description: 'Aviso de retos y competiciones', icon: Bell, type: 'switch', default: true },
  { id: 'p34', name: 'Notificaciones comentarios', description: 'Aviso de nuevos comentarios', icon: Bell, type: 'switch', default: true },
  { id: 'p35', name: 'Notificaciones likes', description: 'Aviso de likes recibidos', icon: Bell, type: 'switch', default: false },
  { id: 'p36', name: 'Newsletter', description: 'Recibir novedades por email', icon: Mail, type: 'switch', default: true },
  { id: 'p37', name: 'Promociones', description: 'Recibir ofertas y promociones', icon: Mail, type: 'switch', default: true },
  { id: 'p38', name: 'Consejos de cocina', description: 'Recibir tips semanales', icon: Mail, type: 'switch', default: true },
  { id: 'p39', name: 'Recetas sugeridas', description: 'Sugerencias personalizadas', icon: Heart, type: 'switch', default: true },
  { id: 'p40', name: 'Verificación email', description: 'Email verificado', icon: Shield, type: 'info', default: 'Verificado' },
  { id: 'p41', name: 'Verificación teléfono', description: 'Teléfono verificado', icon: Shield, type: 'info', default: 'No verificado' },
  { id: 'p42', name: 'Autenticación 2FA', description: 'Doble factor de autenticación', icon: Lock, type: 'switch', default: false },
  { id: 'p43', name: 'PIN de acceso', description: 'PIN para entrar a la app', icon: Lock, type: 'switch', default: false },
  { id: 'p44', name: 'Biometría', description: 'Desbloqueo con huella/rostro', icon: Lock, type: 'switch', default: false },
  { id: 'p45', name: 'Sesiones activas', description: 'Gestionar dispositivos conectados', icon: Smartphone, type: 'link' },
  { id: 'p46', name: 'Historial de actividad', description: 'Ver tu actividad reciente', icon: Timer, type: 'link' },
  { id: 'p47', name: 'Descargar mis datos', description: 'Exportar todos tus datos', icon: Download, type: 'link' },
  { id: 'p48', name: 'Desactivar cuenta', description: 'Desactivar temporalmente', icon: User, type: 'link' },
  { id: 'p49', name: 'Eliminar cuenta', description: 'Eliminar permanentemente', icon: Trash2, type: 'link' },
  { id: 'p50', name: 'ID de usuario', description: 'Tu identificador único', icon: Info, type: 'info', default: 'USR-XXXXXX' },
]

// App Info
const appInfo = [
  { id: 'app1', name: 'Versión de la app', description: 'CocinaViva v2.5.3', icon: Info, type: 'info' },
  { id: 'app2', name: 'Última actualización', description: '21 de Febrero, 2026', icon: RefreshCw, type: 'info' },
  { id: 'app3', name: 'Actualizaciones automáticas', description: 'Activado', icon: RefreshCw, type: 'info' },
]

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('general')

  const renderSetting = (setting: typeof generalSettings[0]) => {
    const Icon = setting.icon

    return (
      <div
        key={setting.id}
        className="flex items-center justify-between p-4 rounded-lg hover:bg-muted/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
            <Icon className="h-5 w-5 text-muted-foreground" />
          </div>
          <div>
            <div className="font-medium">{setting.name}</div>
            <div className="text-sm text-muted-foreground">{setting.description}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {setting.type === 'switch' && (
            <Switch defaultChecked={setting.default as boolean} />
          )}
          {setting.type === 'select' && (
            <Select defaultValue={(setting.options as string[])[0]}>
              <SelectTrigger className="w-[180px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(setting.options as string[]).map(opt => (
                  <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {setting.type === 'text' && (
            <Input className="w-[200px]" placeholder={setting.default as string} />
          )}
          {setting.type === 'email' && (
            <Input className="w-[200px]" type="email" placeholder={setting.default as string} />
          )}
          {setting.type === 'info' && (
            <span className="text-sm text-muted-foreground">{setting.default as string}</span>
          )}
          {setting.type === 'link' && (
            <Button variant="ghost" size="sm">
              <ChevronRight className="h-4 w-4" />
            </Button>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Settings className="h-8 w-8 text-orange-500" />
              Ajustes
            </h1>
            <p className="text-muted-foreground">
              Personaliza tu experiencia en CocinaViva
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          {/* Quick Access Buttons */}
          <div className="flex flex-wrap gap-4 mb-8">
            <Link href="/logros">
              <Button className="bg-gradient-to-r from-orange-500 to-green-500">
                🏆 Ver Logros (300)
              </Button>
            </Link>
            <Link href="/planes">
              <Button variant="outline">
                💎 Ver Planes
              </Button>
            </Link>
            <Link href="/login">
              <Button variant="outline" className="gap-2">
                🔐 Iniciar Sesión
              </Button>
            </Link>
            <a href="mailto:iiiribasu2010@gmail.com?subject=Sugerencia para CocinaViva">
              <Button variant="outline" className="gap-2">
                <Lightbulb className="h-4 w-4" />
                Sugerir Función
              </Button>
            </a>
          </div>

          {/* Tipografía Global Banner */}
          <Card className="mb-6 border-2 border-orange-500/30 bg-orange-50 dark:bg-orange-950/20">
            <CardContent className="py-4">
              <div className="flex items-center gap-4">
                <Type className="h-8 w-8 text-orange-500" />
                <div className="flex-1">
                  <h3 className="font-semibold">Tipografía Global</h3>
                  <p className="text-sm text-muted-foreground">
                    Cambia el tamaño de letra de toda la aplicación en la pestaña de Accesibilidad
                  </p>
                </div>
                <Select defaultValue="Mediano (14px)">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pequeño (12px)">Pequeño (12px)</SelectItem>
                    <SelectItem value="Mediano (14px)">Mediano (14px)</SelectItem>
                    <SelectItem value="Grande (16px)">Grande (16px)</SelectItem>
                    <SelectItem value="Enorme (20px)">Enorme (20px)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6 flex flex-wrap">
              <TabsTrigger value="general" className="gap-2">
                <Settings className="h-4 w-4" />
                Generales
              </TabsTrigger>
              <TabsTrigger value="accessibility" className="gap-2">
                <Accessibility className="h-4 w-4" />
                Accesibilidad
              </TabsTrigger>
              <TabsTrigger value="profile" className="gap-2">
                <User className="h-4 w-4" />
                Perfil
              </TabsTrigger>
              <TabsTrigger value="admin" className="gap-2">
                <ShieldCheck className="h-4 w-4" />
                Admin
              </TabsTrigger>
              <TabsTrigger value="info" className="gap-2">
                <Info className="h-4 w-4" />
                Info App
              </TabsTrigger>
            </TabsList>

            <TabsContent value="general">
              <Card>
                <CardHeader>
                  <CardTitle>Ajustes Generales ({generalSettings.length})</CardTitle>
                  <CardDescription>
                    Configura la aplicación según tus preferencias
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 divide-y max-h-[600px] overflow-y-auto">
                  {generalSettings.map(renderSetting)}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="accessibility">
              <Card>
                <CardHeader>
                  <CardTitle>Accesibilidad ({accessibilitySettings.length})</CardTitle>
                  <CardDescription>
                    Configuración de accesibilidad y adaptaciones visuales
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 divide-y max-h-[600px] overflow-y-auto">
                  {accessibilitySettings.map(renderSetting)}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>Ajustes de Perfil ({profileSettings.length})</CardTitle>
                  <CardDescription>
                    Gestiona tu información personal y privacidad
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 divide-y max-h-[600px] overflow-y-auto">
                  {profileSettings.map(renderSetting)}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="admin">
              <Card>
                <CardHeader>
                  <CardTitle>Panel de Administración ({adminSettings.length})</CardTitle>
                  <CardDescription>
                    Herramientas de administración del sistema
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 divide-y">
                  {adminSettings.map(renderSetting)}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="info">
              <Card>
                <CardHeader>
                  <CardTitle>Información de la Aplicación</CardTitle>
                  <CardDescription>
                    Versión y configuración de la cuenta
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0 divide-y">
                  {appInfo.map(renderSetting)}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
