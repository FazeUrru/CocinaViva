'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  ChefHat,
  Mail,
  Lock,
  Eye,
  EyeOff,
  Chrome,
  Apple,
  Facebook,
  X as XIcon,
  ArrowLeft,
  Shield,
  CheckCircle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Checkbox } from '@/components/ui/checkbox'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [rememberMe, setRememberMe] = useState(true)
  const [autoSave, setAutoSave] = useState(true)
  const [loginMethod, setLoginMethod] = useState<'social' | 'email' | null>(null)

  // Check for saved session
  useEffect(() => {
    const savedSession = localStorage.getItem('cocinaviva_session')
    if (savedSession) {
      // Auto-login if session exists
      router.push('/')
    }
  }, [router])

  const handleSocialLogin = async (provider: 'google' | 'apple' | 'facebook' | 'x') => {
    setIsLoading(true)
    setLoginMethod('social')
    
    // Simulate OAuth login
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Save session
    const session = {
      provider,
      email: `user@${provider}.com`,
      name: 'Usuario CocinaViva',
      avatar: null,
      autoSave: autoSave,
      createdAt: new Date().toISOString(),
    }
    
    localStorage.setItem('cocinaviva_session', JSON.stringify(session))
    setIsLoading(false)
    router.push('/')
  }

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setLoginMethod('email')
    
    // Simulate email login
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Save session
    const session = {
      provider: 'email',
      email: email,
      name: 'Usuario CocinaViva',
      avatar: null,
      autoSave: autoSave,
      rememberMe: rememberMe,
      createdAt: new Date().toISOString(),
    }
    
    localStorage.setItem('cocinaviva_session', JSON.stringify(session))
    setIsLoading(false)
    router.push('/')
  }

  const socialProviders = [
    { id: 'google', name: 'Google', icon: Chrome, color: 'bg-white text-gray-800 border-gray-300 hover:bg-gray-50', onClick: () => handleSocialLogin('google') },
    { id: 'apple', name: 'Apple', icon: Apple, color: 'bg-black text-white hover:bg-gray-900', onClick: () => handleSocialLogin('apple') },
    { id: 'facebook', name: 'Facebook', icon: Facebook, color: 'bg-blue-600 text-white hover:bg-blue-700', onClick: () => handleSocialLogin('facebook') },
    { id: 'x', name: 'X (Twitter)', icon: XIcon, color: 'bg-gray-900 text-white hover:bg-gray-800', onClick: () => handleSocialLogin('x') },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1 flex items-center justify-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          {/* Back Button */}
          <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6">
            <ArrowLeft className="h-4 w-4" />
            Volver al inicio
          </Link>

          <Card className="border-2">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-orange-500 to-green-500 flex items-center justify-center mb-4">
                <ChefHat className="h-8 w-8 text-white" />
              </div>
              <CardTitle className="text-2xl">Iniciar Sesión</CardTitle>
              <CardDescription>
                Accede a tu cuenta para disfrutar de todas las funciones
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {/* Social Login Buttons */}
              <div className="space-y-3">
                <p className="text-sm text-center text-muted-foreground">
                  Inicia sesión con tu cuenta favorita
                </p>
                
                <div className="grid grid-cols-2 gap-3">
                  {socialProviders.map((provider) => {
                    const Icon = provider.icon
                    return (
                      <Button
                        key={provider.id}
                        type="button"
                        variant="outline"
                        className={`${provider.color} h-12 gap-2`}
                        onClick={provider.onClick}
                        disabled={isLoading}
                      >
                        {isLoading && loginMethod === 'social' ? (
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                          >
                            <Icon className="h-5 w-5" />
                          </motion.div>
                        ) : (
                          <>
                            <Icon className="h-5 w-5" />
                            {provider.name}
                          </>
                        )}
                      </Button>
                    )
                  })}
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <Separator className="w-full" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">
                    O continúa con email
                  </span>
                </div>
              </div>

              {/* Email Login Form */}
              <form onSubmit={handleEmailLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="remember"
                      checked={rememberMe}
                      onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                    />
                    <Label htmlFor="remember" className="text-sm cursor-pointer">
                      Recordarme
                    </Label>
                  </div>
                  <Link href="/recuperar" className="text-sm text-orange-500 hover:underline">
                    ¿Olvidaste tu contraseña?
                  </Link>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="autosave"
                    checked={autoSave}
                    onCheckedChange={(checked) => setAutoSave(checked as boolean)}
                  />
                  <Label htmlFor="autosave" className="text-sm cursor-pointer flex items-center gap-2">
                    <Shield className="h-4 w-4 text-green-500" />
                    Autoguardado de cuenta
                  </Label>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                  disabled={isLoading}
                >
                  {isLoading && loginMethod === 'email' ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="flex items-center gap-2"
                    >
                      <CheckCircle className="h-5 w-5" />
                      Iniciando sesión...
                    </motion.div>
                  ) : (
                    'Iniciar Sesión'
                  )}
                </Button>
              </form>

              {/* Register Link */}
              <div className="text-center text-sm">
                <span className="text-muted-foreground">¿No tienes cuenta? </span>
                <Link href="/registro" className="text-orange-500 hover:underline font-medium">
                  Regístrate gratis
                </Link>
              </div>

              {/* Benefits */}
              <div className="bg-muted/50 rounded-lg p-4 space-y-2">
                <p className="text-sm font-medium text-center">Beneficios de tu cuenta:</p>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Sincroniza tus recetas favoritas
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Accede a tu historial desde cualquier dispositivo
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Desbloquea logros y puntos
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Comparte tus recetas con la comunidad
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-3 w-3 text-green-500" />
                    Guardado automático de tu progreso
                  </li>
                </ul>
              </div>

              {/* Terms */}
              <p className="text-xs text-center text-muted-foreground">
                Al iniciar sesión, aceptas nuestros{' '}
                <Link href="/terminos" className="text-orange-500 hover:underline">
                  Términos de Servicio
                </Link>{' '}
                y{' '}
                <Link href="/privacidad" className="text-orange-500 hover:underline">
                  Política de Privacidad
                </Link>
              </p>
            </CardContent>
          </Card>

          {/* Security Info */}
          <div className="mt-6 flex items-center justify-center gap-4 text-muted-foreground">
            <div className="flex items-center gap-1 text-xs">
              <Shield className="h-4 w-4 text-green-500" />
              Conexión segura
            </div>
            <div className="flex items-center gap-1 text-xs">
              <Lock className="h-4 w-4 text-green-500" />
              Datos encriptados
            </div>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  )
}
