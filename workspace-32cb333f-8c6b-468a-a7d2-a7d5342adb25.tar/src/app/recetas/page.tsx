'use client'

import { useState, useEffect, use } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Search,
  Filter,
  Grid,
  List,
  Clock,
  Users,
  Star,
  ChefHat,
  Thermometer,
  Soup,
  X,
  ChevronDown,
  Sparkles,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'

// Demo recipes data
const allRecipes = [
  {
    id: '1',
    title: 'Paella Valenciana',
    description: 'La auténtica paella valenciana con pollo, conejo y judías verdes',
    imageUrl: '/images/recipes/paella.png',
    prepTime: 20,
    cookTime: 40,
    totalTime: 60,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.8,
    ratingCount: 156,
    mealType: 'almuerzo',
  },
  {
    id: '2',
    title: 'Hamburguesa Gourmet',
    description: 'Hamburguesa casera con carne seleccionada y vegetales frescos',
    imageUrl: '/images/recipes/burger.png',
    prepTime: 15,
    cookTime: 10,
    totalTime: 25,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.5,
    ratingCount: 89,
    mealType: 'almuerzo',
  },
  {
    id: '3',
    title: 'Ensalada Mediterránea',
    description: 'Ensalada fresca con ingredientes mediterráneos',
    imageUrl: '/images/recipes/salad.png',
    prepTime: 10,
    cookTime: 0,
    totalTime: 10,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.7,
    ratingCount: 203,
    mealType: 'almuerzo',
  },
  {
    id: '4',
    title: 'Tarta de Chocolate',
    description: 'Deliciosa tarta de chocolate con frutos rojos',
    imageUrl: '/images/recipes/chocolate-cake.png',
    prepTime: 30,
    cookTime: 45,
    totalTime: 75,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.9,
    ratingCount: 312,
    mealType: 'postre',
  },
  {
    id: '5',
    title: 'Gazpacho Andaluz',
    description: 'Refrescante sopa fría de tomate tradicional',
    imageUrl: '/images/recipes/gazpacho.png',
    prepTime: 15,
    cookTime: 0,
    totalTime: 15,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.6,
    ratingCount: 178,
    mealType: 'almuerzo',
  },
  {
    id: '6',
    title: 'Pasta Carbonara',
    description: 'Auténtica pasta carbonara italiana con guanciale',
    imageUrl: '/images/recipes/carbonara.png',
    prepTime: 10,
    cookTime: 20,
    totalTime: 30,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.7,
    ratingCount: 245,
    mealType: 'cena',
  },
  {
    id: '7',
    title: 'Desayuno Completo',
    description: 'Un desayuno nutritivo con croissants y frutas',
    imageUrl: '/images/recipes/breakfast.png',
    prepTime: 10,
    cookTime: 15,
    totalTime: 25,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.4,
    ratingCount: 67,
    mealType: 'desayuno',
  },
  {
    id: '8',
    title: 'Alitas de Pollo Crujientes',
    description: 'Alitas de pollo doradas y crujientes con especias',
    imageUrl: '/images/recipes/chicken-wings.png',
    prepTime: 20,
    cookTime: 30,
    totalTime: 50,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.6,
    ratingCount: 134,
    mealType: 'cena',
  },
]

const mealTypes = [
  { value: 'desayuno', label: 'Desayuno', icon: '🥐' },
  { value: 'almuerzo', label: 'Almuerzo', icon: '🍽️' },
  { value: 'cena', label: 'Cena', icon: '🌙' },
  { value: 'postre', label: 'Postre', icon: '🍰' },
  { value: 'snack', label: 'Snack', icon: '🍿' },
]

const difficulties = [
  { value: 'facil', label: 'Fácil', color: 'bg-green-500' },
  { value: 'medio', label: 'Medio', color: 'bg-yellow-500' },
  { value: 'dificil', label: 'Difícil', color: 'bg-red-500' },
]

export default function RecetasPage({
  searchParams,
}: {
  searchParams: Promise<{
    search?: string
    toolType?: string
    isGlutenFree?: string
    mealType?: string
    difficulty?: string
  }>
}) {
  const params = use(searchParams)
  
  const [search, setSearch] = useState(params.search || '')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [filters, setFilters] = useState({
    toolType: params.toolType || 'all',
    isGlutenFree: params.isGlutenFree === 'true',
    mealType: params.mealType || 'all',
    difficulty: params.difficulty || 'all',
    maxTime: 120,
  })
  const [showFilters, setShowFilters] = useState(false)

  // Filter recipes
  const filteredRecipes = allRecipes.filter(recipe => {
    if (search && !recipe.title.toLowerCase().includes(search.toLowerCase()) && 
        !recipe.description.toLowerCase().includes(search.toLowerCase())) {
      return false
    }
    if (filters.toolType !== 'all' && recipe.toolType !== filters.toolType) {
      return false
    }
    if (filters.isGlutenFree && !recipe.isGlutenFree) {
      return false
    }
    if (filters.mealType !== 'all' && recipe.mealType !== filters.mealType) {
      return false
    }
    if (filters.difficulty !== 'all' && recipe.difficulty !== filters.difficulty) {
      return false
    }
    if (recipe.totalTime > filters.maxTime) {
      return false
    }
    return true
  })

  const updateFilter = (key: string, value: string | boolean | number) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  const clearFilters = () => {
    setFilters({
      toolType: 'all',
      isGlutenFree: false,
      mealType: 'all',
      difficulty: 'all',
      maxTime: 120,
    })
    setSearch('')
  }

  const activeFiltersCount = [
    filters.toolType !== 'all',
    filters.isGlutenFree,
    filters.mealType !== 'all',
    filters.difficulty !== 'all',
    filters.maxTime < 120,
  ].filter(Boolean).length

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <ChefHat className="h-8 w-8 text-orange-500" />
              Recetario
            </h1>
            <p className="text-muted-foreground">
              Explora nuestra colección de {allRecipes.length}+ recetas deliciosas
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="border-b bg-background sticky top-16 z-40">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-wrap items-center gap-4">
              {/* Search */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar por nombre o ingrediente..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>

              {/* Filter Button - Mobile */}
              <Sheet open={showFilters} onOpenChange={setShowFilters}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtros
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 h-5 w-5 p-0 flex items-center justify-center bg-orange-500">
                        {activeFiltersCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                    <SheetDescription>
                      Refina tu búsqueda de recetas
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <FilterContent 
                      filters={filters} 
                      updateFilter={updateFilter} 
                      clearFilters={clearFilters}
                      onApply={() => setShowFilters(false)}
                    />
                  </div>
                </SheetContent>
              </Sheet>

              {/* Desktop Filters */}
              <div className="hidden lg:flex items-center gap-4">
                <Select value={filters.toolType} onValueChange={(v) => updateFilter('toolType', v)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Tipo de cocina" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los tipos</SelectItem>
                    <SelectItem value="tradicional">
                      <div className="flex items-center gap-2">
                        <ChefHat className="h-4 w-4" />
                        Tradicional
                      </div>
                    </SelectItem>
                    <SelectItem value="thermomix">
                      <div className="flex items-center gap-2">
                        <Thermometer className="h-4 w-4" />
                        Thermomix
                      </div>
                    </SelectItem>
                    <SelectItem value="crockpot">
                      <div className="flex items-center gap-2">
                        <Soup className="h-4 w-4" />
                        Crockpot
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.mealType} onValueChange={(v) => updateFilter('mealType', v)}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Tipo de plato" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {mealTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.icon} {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filters.difficulty} onValueChange={(v) => updateFilter('difficulty', v)}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Dificultad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    {difficulties.map(diff => (
                      <SelectItem key={diff.value} value={diff.value}>
                        {diff.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="glutenFree"
                    checked={filters.isGlutenFree}
                    onCheckedChange={(checked) => updateFilter('isGlutenFree', checked === true)}
                  />
                  <Label htmlFor="glutenFree" className="text-sm cursor-pointer">
                    Sin Gluten
                  </Label>
                </div>

                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="h-4 w-4 mr-1" />
                    Limpiar
                  </Button>
                )}
              </div>

              {/* View Mode Toggle */}
              <div className="flex items-center border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Results */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            {/* Results Count */}
            <div className="mb-6">
              <p className="text-muted-foreground">
                Mostrando {filteredRecipes.length} de {allRecipes.length} recetas
              </p>
            </div>

            {filteredRecipes.length === 0 ? (
              <div className="text-center py-16">
                <ChefHat className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No se encontraron recetas</h3>
                <p className="text-muted-foreground mb-4">
                  Prueba a modificar los filtros de búsqueda
                </p>
                <Button onClick={clearFilters}>
                  Limpiar filtros
                </Button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                        <div className="relative h-48 overflow-hidden">
                          <img
                            src={recipe.imageUrl}
                            alt={recipe.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute top-3 left-3 flex gap-2">
                            {recipe.isGlutenFree && (
                              <Badge className="bg-green-500 hover:bg-green-600">
                                Sin Gluten
                              </Badge>
                            )}
                          </div>
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-yellow-500 hover:bg-yellow-600">
                              <Star className="h-3 w-3 mr-1 fill-white" />
                              {recipe.averageRating.toFixed(1)}
                            </Badge>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                          <CardDescription className="line-clamp-2">
                            {recipe.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {recipe.totalTime} min
                            </div>
                            <div className="flex items-center gap-1">
                              <Users className="h-4 w-4" />
                              4 pers.
                            </div>
                            <Badge variant="outline" className={cn(
                              "text-xs",
                              recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                              recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                              recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                            )}>
                              {recipe.difficulty === 'facil' ? 'Fácil' : 
                               recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                            </Badge>
                          </div>
                        </CardContent>
                        <CardFooter className="pt-0">
                          <Badge variant="secondary" className="text-xs">
                            {recipe.toolType === 'tradicional' ? '🍳 Tradicional' : 
                             recipe.toolType === 'thermomix' ? '⚡ Thermomix' : '🍲 Crockpot'}
                          </Badge>
                        </CardFooter>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="hover:shadow-lg transition-all cursor-pointer group">
                        <div className="flex">
                          <div className="w-40 h-32 relative flex-shrink-0 overflow-hidden rounded-l-lg">
                            <img
                              src={recipe.imageUrl}
                              alt={recipe.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                          </div>
                          <div className="flex-1 p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                                <CardDescription className="line-clamp-1 mt-1">
                                  {recipe.description}
                                </CardDescription>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                <span className="font-medium">{recipe.averageRating.toFixed(1)}</span>
                                <span className="text-muted-foreground text-sm">({recipe.ratingCount})</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {recipe.totalTime} min
                              </div>
                              <Badge variant="outline" className={cn(
                                "text-xs",
                                recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                                recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                                recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                              )}>
                                {recipe.difficulty === 'facil' ? 'Fácil' : 
                                 recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                              </Badge>
                              {recipe.isGlutenFree && (
                                <Badge className="bg-green-500 text-xs">Sin Gluten</Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

// Filter Content Component
function FilterContent({ 
  filters, 
  updateFilter, 
  clearFilters,
  onApply 
}: { 
  filters: typeof useState<{toolType: string; isGlutenFree: boolean; mealType: string; difficulty: string; maxTime: number}> extends [infer T, ...any] ? T : never
  updateFilter: (key: string, value: string | boolean | number) => void
  clearFilters: () => void
  onApply: () => void
}) {
  return (
    <div className="space-y-6">
      {/* Tool Type */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Tipo de Cocina</Label>
        <div className="grid grid-cols-2 gap-2">
          {[
            { value: 'all', label: 'Todos' },
            { value: 'tradicional', label: 'Tradicional' },
            { value: 'thermomix', label: 'Thermomix' },
            { value: 'crockpot', label: 'Crockpot' },
          ].map(option => (
            <Button
              key={option.value}
              variant={filters.toolType === option.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('toolType', option.value)}
              className="justify-start"
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Meal Type */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Tipo de Plato</Label>
        <div className="flex flex-wrap gap-2">
          {mealTypes.map(type => (
            <Button
              key={type.value}
              variant={filters.mealType === type.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('mealType', filters.mealType === type.value ? '' : type.value)}
            >
              {type.icon} {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Difficulty */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Dificultad</Label>
        <div className="flex gap-2">
          {difficulties.map(diff => (
            <Button
              key={diff.value}
              variant={filters.difficulty === diff.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('difficulty', filters.difficulty === diff.value ? '' : diff.value)}
            >
              {diff.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Max Time */}
      <div>
        <Label className="text-sm font-medium mb-3 block">
          Tiempo máximo: {filters.maxTime} minutos
        </Label>
        <Slider
          value={[filters.maxTime]}
          onValueChange={([value]) => updateFilter('maxTime', value)}
          max={180}
          step={15}
        />
      </div>

      {/* Gluten Free */}
      <div className="flex items-center space-x-2">
        <Checkbox
          id="glutenFreeMobile"
          checked={filters.isGlutenFree}
          onCheckedChange={(checked) => updateFilter('isGlutenFree', checked === true)}
        />
        <Label htmlFor="glutenFreeMobile" className="cursor-pointer">
          Solo recetas sin gluten
        </Label>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={clearFilters} className="flex-1">
          Limpiar
        </Button>
        <Button onClick={onApply} className="flex-1">
          Aplicar
        </Button>
      </div>
    </div>
  )
}
