'use client'

import { useState, useEffect, use, useCallback, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  ArrowLeft,
  Check,
  Clock,
  Mic,
  MicOff,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  X,
  Timer,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { useTimerStore } from '@/store'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import Link from 'next/link'

// Demo recipe data
const recipeData = {
  id: '1',
  title: 'Paella Valenciana',
  imageUrl: '/images/recipes/paella.png',
  totalTime: 60,
  steps: [
    {
      id: '1',
      stepNumber: 1,
      instruction: 'Calentar el aceite en la paellera a fuego medio-alto. Cuando el aceite esté caliente, añadir el pollo y el conejo troceados.',
      duration: 5,
      tip: 'El aceite debe cubrir bien el fondo de la paellera para que la carne se dore uniformemente.'
    },
    {
      id: '2',
      stepNumber: 2,
      instruction: 'Dorar la carne por todos lados durante unos 10-15 minutos. Es importante que la carne quede bien dorada para que suelte sus jugos y sabor.',
      duration: 15,
      tip: 'No tengas prisa en este paso, un buen dorado es clave para el sabor final.'
    },
    {
      id: '3',
      stepNumber: 3,
      instruction: 'Apartar la carne hacia los bordes de la paellera y añadir las judías verdes y el garrofón en el centro. Sofreír durante 5 minutos.',
      duration: 5,
      tip: 'Las verduras deben quedar ligeramente doradas pero no quemadas.'
    },
    {
      id: '4',
      stepNumber: 4,
      instruction: 'Hacer un hueco en el centro, añadir el tomate triturado y sofreír hasta que pierda el agua.',
      duration: 5,
      tip: 'El tomate debe quedar oscuro y concentrado.'
    },
    {
      id: '5',
      stepNumber: 5,
      instruction: 'Añadir el pimentón dulce, remover rápidamente e inmediatamente añadir el agua caliente para que no se queme el pimentón.',
      duration: 1,
      tip: 'El pimentón quemado amarga el plato, así que añade el agua rápido.'
    },
    {
      id: '6',
      stepNumber: 6,
      instruction: 'Añadir el azafrán en hebras y la sal. Dejar hervir durante 15-20 minutos para que se haga el caldo.',
      duration: 20,
      tip: 'El caldo debe estar bien sabroso antes de añadir el arroz.'
    },
    {
      id: '7',
      stepNumber: 7,
      instruction: 'Añadir el arroz en forma de cruz o caballón. Distribuir uniformemente por toda la paellera. Subir el fuego al máximo.',
      duration: 1,
      tip: 'No remuevas el arroz una vez distribuido, déjalo cocinar.'
    },
    {
      id: '8',
      stepNumber: 8,
      instruction: 'Cocinar a fuego fuerte durante 8-10 minutos, luego bajar el fuego y cocinar otros 8-10 minutos hasta que el arroz esté en su punto.',
      duration: 18,
      tip: 'El arroz debe quedar seco y con el famoso socarrat en el fondo.'
    },
    {
      id: '9',
      stepNumber: 9,
      instruction: 'Retirar del fuego y dejar reposar 5 minutos antes de servir. El arroz terminará de cocinarse con el calor residual.',
      duration: 5,
      tip: 'Tapar con un paño limpio durante el reposo para que se termine de hacer.'
    },
  ],
}

export default function StepByStepPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const recipe = recipeData
  
  const [currentStep, setCurrentStep] = useState(0)
  const [completedSteps, setCompletedSteps] = useState<Set<number>>(new Set())
  const [isHandsFree, setIsHandsFree] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isListening, setIsListening] = useState(false)
  
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const { addTimer } = useTimerStore()
  
  const currentStepData = recipe.steps[currentStep]
  const totalSteps = recipe.steps.length
  const progress = ((currentStep + 1) / totalSteps) * 100

  // Text-to-speech
  const speak = useCallback((text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'es-ES'
      utterance.rate = 0.85
      utterance.onend = () => setIsSpeaking(false)
      utterance.onerror = () => setIsSpeaking(false)
      window.speechSynthesis.speak(utterance)
      setIsSpeaking(true)
    }
  }, [])

  const stopSpeaking = useCallback(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }, [])

  // Navigation functions - defined before useEffect
  const nextStep = useCallback(() => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1)
      stopSpeaking()
    } else {
      toast.success('¡Receta completada!')
    }
  }, [currentStep, totalSteps, stopSpeaking])

  const prevStep = useCallback(() => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1)
      stopSpeaking()
    }
  }, [currentStep, stopSpeaking])

  const goToStep = useCallback((step: number) => {
    if (step >= 0 && step < totalSteps) {
      setCurrentStep(step)
      stopSpeaking()
    }
  }, [totalSteps, stopSpeaking])

  const toggleCompleteStep = useCallback(() => {
    setCompletedSteps(prev => {
      const newSet = new Set(prev)
      if (newSet.has(currentStep)) {
        newSet.delete(currentStep)
      } else {
        newSet.add(currentStep)
      }
      return newSet
    })
  }, [currentStep])

  const startStepTimer = useCallback(() => {
    if (currentStepData.duration) {
      addTimer({
        name: `Paso ${currentStepData.stepNumber}`,
        duration: currentStepData.duration * 60,
        remaining: currentStepData.duration * 60,
        isRunning: true,
        isPaused: false,
      })
      toast.success(`Temporizador de ${currentStepData.duration} minutos iniciado`)
    }
  }, [currentStepData, addTimer])

  // Speak current step
  const speakCurrentStep = useCallback(() => {
    const text = `Paso ${currentStepData.stepNumber}. ${currentStepData.instruction}${
      currentStepData.tip ? `. Consejo: ${currentStepData.tip}` : ''
    }`
    speak(text)
  }, [currentStepData, speak])

  // Voice recognition for hands-free mode
  useEffect(() => {
    if (isHandsFree && 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.webkitSpeechRecognition || window.SpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.lang = 'es-ES'
      
      recognitionRef.current.onresult = (event) => {
        const last = event.results.length - 1
        const command = event.results[last][0].transcript.toLowerCase().trim()
        
        console.log('Voice command:', command)
        
        if (command.includes('siguiente') || command.includes('adelante') || command.includes('next')) {
          nextStep()
          speak('Siguiente paso')
        } else if (command.includes('anterior') || command.includes('atrás') || command.includes('back')) {
          prevStep()
          speak('Paso anterior')
        } else if (command.includes('repetir') || command.includes('repit') || command.includes('otra vez')) {
          speakCurrentStep()
        } else if (command.includes('completado') || command.includes('listo') || command.includes('hecho')) {
          toggleCompleteStep()
        } else if (command.includes('temporizador') || command.includes('timer')) {
          startStepTimer()
        } else if (command.includes('parar voz') || command.includes('silencio')) {
          stopSpeaking()
        }
      }
      
      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error)
        if (event.error !== 'no-speech') {
          setIsListening(false)
        }
      }
      
      recognitionRef.current.onend = () => {
        if (isHandsFree && isListening) {
          recognitionRef.current?.start()
        }
      }
      
      return () => {
        recognitionRef.current?.stop()
      }
    }
  }, [isHandsFree, isListening, nextStep, prevStep, speakCurrentStep, toggleCompleteStep, startStepTimer, speak, stopSpeaking])

  // Toggle hands-free mode
  const toggleHandsFree = () => {
    if (isHandsFree) {
      setIsHandsFree(false)
      setIsListening(false)
      recognitionRef.current?.stop()
      stopSpeaking()
      toast.info('Modo manos libres desactivado')
    } else {
      setIsHandsFree(true)
      setIsListening(true)
      recognitionRef.current?.start()
      speak('Modo manos libres activado. Di "siguiente", "anterior" o "repetir" para navegar.')
      toast.success('Modo manos libres activado')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-green-50 dark:from-gray-900 dark:to-gray-800">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link href={`/recetas/${id}`}>
            <Button variant="ghost" size="sm">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver a la receta
            </Button>
          </Link>
          
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="text-sm">
              {currentStep + 1} / {totalSteps}
            </Badge>
            <Button
              variant={isHandsFree ? 'default' : 'outline'}
              size="sm"
              onClick={toggleHandsFree}
              className={cn(isHandsFree && 'bg-gradient-to-r from-orange-500 to-green-500')}
            >
              {isHandsFree ? (
                <>
                  <Mic className="h-4 w-4 mr-2" />
                  Manos Libres
                </>
              ) : (
                <>
                  <MicOff className="h-4 w-4 mr-2" />
                  Activar Voz
                </>
              )}
            </Button>
            <Link href={`/recetas/${id}`}>
              <Button variant="ghost" size="icon">
                <X className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Progress Bar */}
        <Progress value={progress} className="h-1" />
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Recipe Title */}
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold mb-2">{recipe.title}</h1>
            <p className="text-muted-foreground">Tiempo total: {recipe.totalTime} minutos</p>
          </div>

          {/* Current Step */}
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="overflow-hidden">
                {/* Step Image */}
                <div className="relative h-48 bg-gradient-to-br from-orange-100 to-green-100 dark:from-orange-900/30 dark:to-green-900/30">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-8xl font-bold text-orange-200 dark:text-orange-800">
                      {currentStepData.stepNumber}
                    </span>
                  </div>
                  {completedSteps.has(currentStep) && (
                    <div className="absolute inset-0 bg-green-500/20 flex items-center justify-center">
                      <div className="w-20 h-20 rounded-full bg-green-500 flex items-center justify-center">
                        <Check className="h-10 w-10 text-white" />
                      </div>
                    </div>
                  )}
                </div>

                <CardContent className="p-6">
                  {/* Step Content */}
                  <div className="mb-6">
                    <Badge className="mb-4">
                      Paso {currentStepData.stepNumber} de {totalSteps}
                    </Badge>
                    <p className="text-xl leading-relaxed">
                      {currentStepData.instruction}
                    </p>
                  </div>

                  {/* Timer for this step */}
                  {currentStepData.duration && (
                    <div className="mb-6 p-4 bg-muted rounded-lg">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Clock className="h-5 w-5 text-orange-500" />
                          <span className="font-medium">
                            Tiempo sugerido: {currentStepData.duration} minutos
                          </span>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={startStepTimer}
                        >
                          <Timer className="h-4 w-4 mr-2" />
                          Iniciar temporizador
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Tip */}
                  {currentStepData.tip && (
                    <div className="mb-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                      <p className="text-yellow-800 dark:text-yellow-200">
                        <strong>💡 Consejo:</strong> {currentStepData.tip}
                      </p>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center justify-between gap-4">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={prevStep}
                      disabled={currentStep === 0}
                    >
                      <SkipBack className="h-5 w-5 mr-2" />
                      Anterior
                    </Button>

                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={isSpeaking ? stopSpeaking : speakCurrentStep}
                      >
                        {isSpeaking ? (
                          <VolumeX className="h-5 w-5" />
                        ) : (
                          <Volume2 className="h-5 w-5" />
                        )}
                      </Button>
                      <Button
                        variant={completedSteps.has(currentStep) ? 'default' : 'outline'}
                        size="icon"
                        onClick={toggleCompleteStep}
                        className={cn(
                          completedSteps.has(currentStep) && 'bg-green-500 hover:bg-green-600'
                        )}
                      >
                        <Check className="h-5 w-5" />
                      </Button>
                    </div>

                    <Button
                      size="lg"
                      onClick={nextStep}
                      className="bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                    >
                      {currentStep === totalSteps - 1 ? 'Finalizar' : 'Siguiente'}
                      {currentStep < totalSteps - 1 && <SkipForward className="h-5 w-5 ml-2" />}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </AnimatePresence>

          {/* Step Indicators */}
          <div className="mt-8 flex justify-center gap-2">
            {recipe.steps.map((step, index) => (
              <button
                key={step.id}
                onClick={() => goToStep(index)}
                className={cn(
                  "w-3 h-3 rounded-full transition-all",
                  index === currentStep && "w-8 bg-orange-500",
                  index !== currentStep && completedSteps.has(index) && "bg-green-500",
                  index !== currentStep && !completedSteps.has(index) && "bg-muted-foreground/30 hover:bg-muted-foreground/50"
                )}
              />
            ))}
          </div>

          {/* Voice Commands Help */}
          {isHandsFree && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg"
            >
              <div className="flex items-center gap-2 mb-2">
                <Mic className="h-5 w-5 text-orange-500" />
                <span className="font-medium">Comandos de voz activos</span>
                <div className={cn(
                  "w-2 h-2 rounded-full ml-auto",
                  isListening ? "bg-green-500 animate-pulse" : "bg-red-500"
                )} />
              </div>
              <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                <div>• "Siguiente" - Avanzar paso</div>
                <div>• "Anterior" - Retroceder</div>
                <div>• "Repetir" - Escuchar paso actual</div>
                <div>• "Completado" - Marcar como hecho</div>
                <div>• "Temporizador" - Iniciar timer</div>
                <div>• "Silencio" - Parar narración</div>
              </div>
            </motion.div>
          )}
        </div>
      </main>
    </div>
  )
}
