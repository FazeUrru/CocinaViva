'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Check,
  X,
  Crown,
  Zap,
  Gift,
  Clock,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  Star,
  Sparkles,
  Brain,
  Cloud,
  UserCheck,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { subscriptionPlans, annualOffer, isOfferActive, getOfferTimeRemaining, faqs, discountOptions, calculatePrice } from '@/data/plans'
import { cn } from '@/lib/utils'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'

const comparisonFeatures = [
  { name: 'Recetas disponibles', basic: '500', ultra: '800', masterchef: '2.400+' },
  { name: 'Búsqueda simple', basic: true, ultra: true, masterchef: true },
  { name: 'Búsqueda avanzada con filtros', basic: false, ultra: true, masterchef: true },
  { name: 'Favoritos', basic: '15', ultra: '27/mes', masterchef: 'Ilimitado' },
  { name: 'Crear recetas propias', basic: true, ultra: true, masterchef: true },
  { name: 'Reseñas de recetas', basic: true, ultra: true, masterchef: true },
  { name: 'Reseñas verificadas', basic: false, ultra: true, masterchef: true },
  { name: 'Filtros Pro', basic: false, ultra: 'Prueba 7 días*', masterchef: true },
  { name: 'Filtros IA', basic: false, ultra: 'Prueba 7 días*', masterchef: true },
  { name: 'Logros disponibles', basic: '100', ultra: '200', masterchef: '300 (TODOS)' },
  { name: 'Modo Thermomix', basic: false, ultra: true, masterchef: true },
  { name: 'Planificador semanal', basic: false, ultra: true, masterchef: true },
  { name: 'Sin publicidad', basic: true, ultra: true, masterchef: true },
  { name: 'Soporte prioritario 24/7', basic: false, ultra: false, masterchef: true },
  { name: 'Sincronización en la nube', basic: false, ultra: false, masterchef: true },
  { name: 'Temporizador gratuito', basic: true, ultra: true, masterchef: true },
  { name: 'Lista de compras gratuita', basic: true, ultra: true, masterchef: true },
]

// 3 Funcionalidades exclusivas MasterChef
const masterchefExclusiveFeatures = [
  {
    icon: Brain,
    name: 'Asistente de Voz con IA',
    description: 'Control total por voz con inteligencia artificial',
  },
  {
    icon: Star,
    name: 'Recetas Exclusivas de Chefs',
    description: 'Acceso a recetas de chefs famosos',
  },
  {
    icon: Cloud,
    name: 'Sincronización Multi-dispositivo',
    description: 'Tus datos en todos tus dispositivos',
  },
]

export default function PlanesPage() {
  const [showComparison, setShowComparison] = useState(false)
  const [showFAQs, setShowFAQs] = useState(false)
  const [timeRemaining, setTimeRemaining] = useState(getOfferTimeRemaining())
  const [trialTimeRemaining, setTrialTimeRemaining] = useState({ days: 7, hours: 0, minutes: 0, seconds: 0 })
  const [selectedDiscount, setSelectedDiscount] = useState<'monthly' | 'annual' | 'young'>('monthly')
  const offerActive = isOfferActive()

  useEffect(() => {
    const savedTrialStart = localStorage.getItem('trial_start')
    if (!savedTrialStart) {
      localStorage.setItem('trial_start', new Date().toISOString())
    }

    const interval = setInterval(() => {
      setTimeRemaining(getOfferTimeRemaining())
      
      const trialStart = new Date(savedTrialStart || new Date())
      const trialEnd = new Date(trialStart.getTime() + 7 * 24 * 60 * 60 * 1000)
      const now = new Date()
      const diff = trialEnd.getTime() - now.getTime()
      
      if (diff > 0) {
        setTrialTimeRemaining({
          days: Math.floor(diff / (1000 * 60 * 60 * 24)),
          hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((diff % (1000 * 60)) / 1000),
        })
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const getFeatureValue = (value: boolean | string) => {
    if (typeof value === 'boolean') {
      return value ? <Check className="h-4 w-4 text-green-500" /> : <X className="h-4 w-4 text-gray-300" />
    }
    return <span className="text-xs font-medium">{value}</span>
  }

  const getDisplayPrice = (plan: typeof subscriptionPlans[0]) => {
    if (plan.price === 0) return 0
    
    switch (selectedDiscount) {
      case 'monthly':
        return plan.monthlyPrice || plan.price
      case 'annual':
        return plan.annualPrice ? (plan.annualPrice / 12).toFixed(2) : plan.price
      case 'young':
        return ((plan.monthlyPrice || plan.price) * 0.80).toFixed(2)
      default:
        return plan.price
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <div className="bg-gradient-to-br from-orange-50 via-white to-green-50 dark:from-gray-900 dark:via-gray-900 dark:to-gray-800 py-6 md:py-12">
          <div className="container mx-auto px-4">
            {/* Header */}
            <div className="text-center mb-6 md:mb-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h1 className="text-2xl md:text-4xl font-bold mb-2 md:mb-4">
                  Elige tu plan perfecto
                </h1>
                <p className="text-base md:text-xl text-muted-foreground max-w-2xl mx-auto">
                  Precios en Euros (€) • Sin publicidad en ningún plan
                </p>
              </motion.div>
            </div>

            {/* Discount Selector */}
            <div className="flex justify-center mb-6">
              <Tabs value={selectedDiscount} onValueChange={(v) => setSelectedDiscount(v as typeof selectedDiscount)}>
                <TabsList className="grid grid-cols-3 w-full max-w-md">
                  <TabsTrigger value="monthly" className="text-xs md:text-sm">Mensual</TabsTrigger>
                  <TabsTrigger value="annual" className="text-xs md:text-sm">Anual (-14%)</TabsTrigger>
                  <TabsTrigger value="young" className="text-xs md:text-sm">Carne Joven (-20%)</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Discount Info Banner */}
            {selectedDiscount === 'annual' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-6 max-w-2xl mx-auto"
              >
                <Card className="bg-gradient-to-r from-green-500 to-teal-500 text-white">
                  <CardContent className="py-3 px-4 text-center">
                    <Gift className="h-5 w-5 inline mr-2" />
                    <span className="font-medium">¡14% de descuento con el plan anual!</span>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {selectedDiscount === 'young' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="mb-6 max-w-2xl mx-auto"
              >
                <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                  <CardContent className="py-3 px-4 text-center">
                    <UserCheck className="h-5 w-5 inline mr-2" />
                    <span className="font-medium">¡20% de descuento para menores de 25 años! Verificación requerida</span>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Plans Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-12">
              {subscriptionPlans.map((plan, index) => (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={cn(
                    "relative",
                    plan.highlighted && "md:-mt-2 md:mb-2"
                  )}
                >
                  {plan.badge && (
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-10">
                      <Badge className="bg-orange-500 text-white px-3 py-0.5 text-xs">
                        {plan.badge}
                      </Badge>
                    </div>
                  )}
                  <Card className={cn(
                    "h-full flex flex-col",
                    plan.highlighted && "border-2 border-orange-500 shadow-lg"
                  )}>
                    <CardHeader className="text-center pb-1 pt-4">
                      <CardTitle className="text-lg md:text-xl flex items-center justify-center gap-1">
                        {plan.id === 'masterchef' && <Crown className="h-5 w-5 text-yellow-500" />}
                        {plan.id === 'ultra' && <Zap className="h-5 w-5 text-blue-500" />}
                        {plan.name}
                      </CardTitle>
                      <CardDescription className="text-xs md:text-sm">
                        {plan.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex-1">
                      {/* Price */}
                      <div className="text-center mb-4">
                        {plan.price === 0 ? (
                          <div className="text-2xl md:text-3xl font-bold text-green-600">Gratis</div>
                        ) : (
                          <div>
                            <div className="flex items-center justify-center gap-1">
                              {selectedDiscount !== 'monthly' && (
                                <span className="text-lg text-muted-foreground line-through">
                                  €{plan.monthlyPrice}
                                </span>
                              )}
                              <span className="text-2xl md:text-3xl font-bold">€{getDisplayPrice(plan)}</span>
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {selectedDiscount === 'annual' ? '/mes (facturación anual)' : '/mes'}
                            </div>
                            {plan.trialDays && (
                              <div className="text-xs text-green-600 mt-0.5 font-medium">
                                {plan.trialDays} días prueba gratis → luego se cobra
                              </div>
                            )}
                          </div>
                        )}
                      </div>

                      {/* Trial Counter */}
                      {plan.trialDays && (
                        <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-2 mb-3 text-center">
                          <div className="text-xs text-muted-foreground">Tiempo prueba restante</div>
                          <div className="text-sm font-mono font-bold text-orange-500">
                            {trialTimeRemaining.days}d {trialTimeRemaining.hours}h {trialTimeRemaining.minutes}m {trialTimeRemaining.seconds}s
                          </div>
                        </div>
                      )}

                      {/* Exclusive Features for MasterChef */}
                      {plan.id === 'masterchef' && (
                        <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg p-2 mb-3">
                          <h4 className="font-semibold text-xs mb-2 flex items-center gap-1">
                            <Sparkles className="h-3 w-3 text-yellow-500" />
                            Exclusivo Premium
                          </h4>
                          <div className="space-y-1">
                            {masterchefExclusiveFeatures.map((feature) => {
                              const Icon = feature.icon
                              return (
                                <div key={feature.name} className="flex items-center gap-1">
                                  <Icon className="h-3 w-3 text-yellow-500" />
                                  <div className="text-[10px] font-medium">{feature.name}</div>
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      )}

                      {/* Features */}
                      <ul className="space-y-1.5">
                        {plan.features.slice(0, 8).map((feature, i) => (
                          <li key={i} className="flex items-start gap-1">
                            <Check className="h-3.5 w-3.5 text-green-500 flex-shrink-0 mt-0.5" />
                            <span className="text-xs">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Button
                        className={cn(
                          "w-full text-sm h-9",
                          plan.highlighted 
                            ? "bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                            : "",
                          plan.price === 0 && "bg-gray-100 text-gray-800 hover:bg-gray-200"
                        )}
                        variant={plan.highlighted ? "default" : "outline"}
                      >
                        {plan.price === 0 ? 'Comenzar Gratis' : `Probar ${plan.trialDays} días`}
                      </Button>
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Comparison Toggle */}
            <div className="text-center mb-4">
              <Button
                variant="outline"
                onClick={() => setShowComparison(!showComparison)}
                className="gap-2 text-sm"
              >
                {showComparison ? 'Ocultar' : 'Ver'} comparación
                {showComparison ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </div>

            {/* Comparison Table */}
            <AnimatePresence>
              {showComparison && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-6 overflow-x-auto"
                >
                  <Card>
                    <CardContent className="p-0">
                      <table className="w-full text-xs md:text-sm">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left p-2 md:p-3 font-medium">Características</th>
                            <th className="text-center p-2 md:p-3 font-medium">Básico</th>
                            <th className="text-center p-2 md:p-3 font-medium bg-orange-50 dark:bg-orange-900/20">
                              <Zap className="h-3 w-3 inline text-blue-500" /> Ultra
                            </th>
                            <th className="text-center p-2 md:p-3 font-medium bg-yellow-50 dark:bg-yellow-900/20">
                              <Crown className="h-3 w-3 inline text-yellow-500" /> MasterChef
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {comparisonFeatures.map((feature, index) => (
                            <tr key={feature.name} className={cn("border-b", index % 2 === 0 && "bg-muted/30")}>
                              <td className="p-2 md:p-3 font-medium">{feature.name}</td>
                              <td className="text-center p-2 md:p-3">{getFeatureValue(feature.basic)}</td>
                              <td className="text-center p-2 md:p-3 bg-orange-50/50 dark:bg-orange-900/10">{getFeatureValue(feature.ultra)}</td>
                              <td className="text-center p-2 md:p-3 bg-yellow-50/50 dark:bg-yellow-900/10">{getFeatureValue(feature.masterchef)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* FAQs */}
            <div className="text-center mb-4">
              <Button
                variant="outline"
                onClick={() => setShowFAQs(!showFAQs)}
                className="gap-2 text-sm"
              >
                <HelpCircle className="h-4 w-4" />
                {showFAQs ? 'Ocultar' : 'Ver'} FAQs
                {showFAQs ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </div>

            <AnimatePresence>
              {showFAQs && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mb-6"
                >
                  <Card>
                    <CardHeader className="py-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <HelpCircle className="h-4 w-4" />
                        Preguntas Frecuentes
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {faqs.map((faq, index) => (
                        <div key={index} className="border-b pb-2 last:border-0">
                          <h4 className="font-medium text-xs mb-1">{faq.question}</h4>
                          <p className="text-xs text-muted-foreground">{faq.answer}</p>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Free features note */}
            <div className="text-center">
              <Card className="inline-block">
                <CardContent className="py-2 px-4">
                  <p className="text-xs text-muted-foreground">
                    ✅ <strong>Temporizador</strong> y <strong>Lista de compras</strong> gratuitos en todos los planes
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
