'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  ChefHat,
  Search,
  Plus,
  X,
  Sparkles,
  Clock,
  Users,
  Star,
  Blender,
  CookingPot,
  UtensilsCrossed,
  RefreshCw,
  Heart,
  ArrowRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'
import Link from 'next/link'

// Ingredientes populares
const popularIngredients = [
  'Pollo', 'Carne picada', 'Pescado', 'Cerdo', 'Ternera', 'Cordero',
  'Tomate', 'Cebolla', 'Ajo', 'Pimiento', 'Zanahoria', 'Papas',
  'Arroz', 'Pasta', 'Lentejas', 'Garbanzos', 'Frijoles',
  'Huevos', 'Queso', 'Leche', 'Nata', 'Mantequilla',
]

// Herramientas disponibles
const tools = [
  { id: 'thermomix', name: 'Thermomix', icon: Blender, description: 'Robot de cocina Thermomix' },
  { id: 'crockpot', name: 'Crockpot', icon: CookingPot, description: 'Olla lenta Crockpot' },
  { id: 'tradicional', name: 'Tradicional', icon: UtensilsCrossed, description: 'Cocina tradicional' },
]

// Recetas generadas (simulación)
const generateRecipes = (ingredients: string[], tool: string) => {
  const recipeTemplates = {
    thermomix: [
      { name: 'Crema de verduras Thermomix', time: 25, difficulty: 'Fácil', rating: 4.8 },
      { name: 'Arroz con pollo Thermomix', time: 40, difficulty: 'Media', rating: 4.7 },
      { name: 'Sopa de lentejas Thermomix', time: 35, difficulty: 'Fácil', rating: 4.6 },
      { name: 'Puré de papas cremoso Thermomix', time: 20, difficulty: 'Fácil', rating: 4.9 },
      { name: 'Bizcocho de yogur Thermomix', time: 45, difficulty: 'Fácil', rating: 4.8 },
      { name: 'Gazpacho andaluz Thermomix', time: 10, difficulty: 'Fácil', rating: 4.7 },
    ],
    crockpot: [
      { name: 'Estofado de ternera Crockpot', time: 480, difficulty: 'Fácil', rating: 4.9 },
      { name: 'Pulled pork Crockpot', time: 600, difficulty: 'Fácil', rating: 4.8 },
      { name: 'Chili con carne Crockpot', time: 360, difficulty: 'Fácil', rating: 4.7 },
      { name: 'Sopa de lentejas Crockpot', time: 300, difficulty: 'Fácil', rating: 4.6 },
      { name: 'Pollo a la cerveza Crockpot', time: 240, difficulty: 'Fácil', rating: 4.8 },
      { name: 'Costillas BBQ Crockpot', time: 420, difficulty: 'Media', rating: 4.9 },
    ],
    tradicional: [
      { name: 'Tortilla de patatas', time: 30, difficulty: 'Media', rating: 4.9 },
      { name: 'Paella valenciana', time: 60, difficulty: 'Difícil', rating: 4.8 },
      { name: 'Gazpacho andaluz', time: 15, difficulty: 'Fácil', rating: 4.7 },
      { name: 'Fabada asturiana', time: 120, difficulty: 'Media', rating: 4.8 },
      { name: 'Cocido madrileño', time: 180, difficulty: 'Media', rating: 4.7 },
      { name: 'Croquetas de jamón', time: 45, difficulty: 'Media', rating: 4.8 },
    ],
  }

  let recipes = recipeTemplates[tool as keyof typeof recipeTemplates] || recipeTemplates.tradicional
  
  if (ingredients.length > 0) {
    const mainIngredient = ingredients[0].toLowerCase()
    recipes = recipes.map(r => ({
      ...r,
      name: `${r.name} con ${mainIngredient}`,
    }))
  }

  return recipes
}

export default function GeneradorPage() {
  const [ingredients, setIngredients] = useState<string[]>([])
  const [inputValue, setInputValue] = useState('')
  const [selectedTool, setSelectedTool] = useState<string>('')
  const [recipes, setRecipes] = useState<any[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)

  const addIngredient = () => {
    if (inputValue.trim() && !ingredients.includes(inputValue.trim())) {
      setIngredients([...ingredients, inputValue.trim()])
      setInputValue('')
    }
  }

  const removeIngredient = (ingredient: string) => {
    setIngredients(ingredients.filter(i => i !== ingredient))
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      addIngredient()
    }
  }

  const addPopularIngredient = (ingredient: string) => {
    if (!ingredients.includes(ingredient)) {
      setIngredients([...ingredients, ingredient])
    }
  }

  const searchRecipes = async () => {
    if (ingredients.length < 2 || !selectedTool) return
    
    setIsSearching(true)
    setHasSearched(true)
    
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    const results = generateRecipes(ingredients, selectedTool)
    setRecipes(results)
    setIsSearching(false)
  }

  const canSearch = ingredients.length >= 2 && selectedTool

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-6 md:py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-2xl md:text-3xl font-bold mb-2 flex items-center gap-2">
              <Sparkles className="h-6 w-6 md:h-8 md:w-8 text-orange-500" />
              Generador de Recetas
            </h1>
            <p className="text-sm md:text-base text-muted-foreground">
              Introduce 2 ingredientes mínimo y tu herramienta
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-4 md:py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
            {/* Panel de búsqueda */}
            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">¿Qué tienes?</CardTitle>
                  <CardDescription className="text-xs">
                    Mínimo 2 ingredientes
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Input */}
                  <div className="space-y-2">
                    <Label className="text-sm">Ingredientes ({ingredients.length}/2)</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Ej: Pollo, arroz..."
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="text-sm h-9"
                      />
                      <Button onClick={addIngredient} size="icon" variant="outline" className="h-9 w-9">
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Ingredientes seleccionados */}
                  {ingredients.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {ingredients.map((ingredient) => (
                        <Badge
                          key={ingredient}
                          variant="secondary"
                          className="gap-1 text-xs py-0.5 px-2"
                        >
                          {ingredient}
                          <button onClick={() => removeIngredient(ingredient)} className="hover:text-red-500">
                            <X className="h-3 w-3" />
                          </button>
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Populares */}
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Populares:</Label>
                    <div className="flex flex-wrap gap-1">
                      {popularIngredients.slice(0, 8).map((ingredient) => (
                        <Button
                          key={ingredient}
                          variant="ghost"
                          size="sm"
                          className="h-6 text-xs px-2"
                          onClick={() => addPopularIngredient(ingredient)}
                          disabled={ingredients.includes(ingredient)}
                        >
                          + {ingredient}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Herramienta */}
                  <div className="space-y-2">
                    <Label className="text-sm">Herramienta</Label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {tools.map((tool) => {
                        const Icon = tool.icon
                        return (
                          <button
                            key={tool.id}
                            onClick={() => setSelectedTool(tool.id)}
                            className={cn(
                              "p-2 rounded-lg border-2 transition-all text-center",
                              selectedTool === tool.id
                                ? "border-orange-500 bg-orange-50 dark:bg-orange-900/20"
                                : "border-gray-200 hover:border-gray-300"
                            )}
                          >
                            <Icon className={cn(
                              "h-5 w-5 mx-auto mb-0.5",
                              selectedTool === tool.id ? "text-orange-500" : "text-muted-foreground"
                            )} />
                            <div className="text-[10px] font-medium">{tool.name}</div>
                          </button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Botón */}
                  <Button
                    onClick={searchRecipes}
                    disabled={!canSearch || isSearching}
                    className="w-full bg-gradient-to-r from-orange-500 to-green-500 h-9 text-sm"
                  >
                    {isSearching ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Buscando...
                      </>
                    ) : (
                      <>
                        <Search className="h-4 w-4 mr-2" />
                        Buscar recetas
                      </>
                    )}
                  </Button>

                  {!canSearch && (
                    <p className="text-xs text-muted-foreground text-center">
                      {ingredients.length < 2
                        ? `Añade ${2 - ingredients.length} ingrediente más`
                        : 'Selecciona una herramienta'}
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Resultados */}
            <div className="lg:col-span-2">
              {!hasSearched ? (
                <Card className="h-full flex items-center justify-center min-h-[300px]">
                  <CardContent className="text-center py-8">
                    <ChefHat className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                    <h3 className="text-base font-semibold mb-1">¡Encuentra tu receta!</h3>
                    <p className="text-xs text-muted-foreground">
                      Añade 2 ingredientes y selecciona tu herramienta
                    </p>
                  </CardContent>
                </Card>
              ) : isSearching ? (
                <Card className="h-full flex items-center justify-center min-h-[300px]">
                  <CardContent className="text-center py-8">
                    <RefreshCw className="h-12 w-12 mx-auto text-orange-500 mb-3 animate-spin" />
                    <h3 className="text-base font-semibold mb-1">Buscando...</h3>
                    <p className="text-xs text-muted-foreground">
                      Con {tools.find(t => t.id === selectedTool)?.name}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h2 className="text-base font-semibold">{recipes.length} recetas</h2>
                    <Badge variant="outline" className="text-xs">
                      {tools.find(t => t.id === selectedTool)?.name}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {recipes.map((recipe, index) => (
                      <motion.div
                        key={recipe.name}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Card className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardHeader className="p-3 pb-1">
                            <CardTitle className="text-sm leading-tight">{recipe.name}</CardTitle>
                          </CardHeader>
                          <CardContent className="p-3 pt-0">
                            <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                              <div className="flex items-center gap-0.5">
                                <Clock className="h-3 w-3" />
                                {recipe.time} min
                              </div>
                              <div className="flex items-center gap-0.5">
                                <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
                                {recipe.rating}
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <Badge variant="outline" className="text-[10px]">
                                {recipe.difficulty}
                              </Badge>
                              <Button variant="ghost" size="icon" className="h-6 w-6">
                                <Heart className="h-3 w-3" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Info */}
          <div className="mt-6 grid grid-cols-3 gap-2">
            <Card>
              <CardContent className="pt-3 pb-3 text-center">
                <Blender className="h-6 w-6 mx-auto mb-1 text-blue-500" />
                <h3 className="font-semibold text-xs">450+ Thermomix</h3>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-3 pb-3 text-center">
                <CookingPot className="h-6 w-6 mx-auto mb-1 text-green-500" />
                <h3 className="font-semibold text-xs">Crockpot</h3>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-3 pb-3 text-center">
                <UtensilsCrossed className="h-6 w-6 mx-auto mb-1 text-orange-500" />
                <h3 className="font-semibold text-xs">450+ Tradicionales</h3>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
