'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Image as ImageIcon,
  Camera,
  Upload,
  Trash2,
  Heart,
  Calendar,
  ChefHat,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'

// Demo gallery photos
const galleryPhotos = [
  {
    id: '1',
    imageUrl: '/images/recipes/paella.png',
    title: 'Mi paella del domingo',
    recipeId: '1',
    recipeTitle: 'Paella Valenciana',
    takenAt: new Date(Date.now() - 86400000 * 2),
    likes: 24,
  },
  {
    id: '2',
    imageUrl: '/images/recipes/chocolate-cake.png',
    title: 'Tarta de cumpleaños',
    recipeId: '4',
    recipeTitle: 'Tarta de Chocolate',
    takenAt: new Date(Date.now() - 86400000 * 5),
    likes: 45,
  },
  {
    id: '3',
    imageUrl: '/images/recipes/salad.png',
    title: 'Almuerzo saludable',
    recipeId: '3',
    recipeTitle: 'Ensalada Mediterránea',
    takenAt: new Date(Date.now() - 86400000 * 7),
    likes: 18,
  },
  {
    id: '4',
    imageUrl: '/images/recipes/carbonara.png',
    title: 'Pasta night',
    recipeId: '6',
    recipeTitle: 'Pasta Carbonara',
    takenAt: new Date(Date.now() - 86400000 * 10),
    likes: 32,
  },
  {
    id: '5',
    imageUrl: '/images/recipes/gazpacho.png',
    title: 'Verano refrescante',
    recipeId: '5',
    recipeTitle: 'Gazpacho Andaluz',
    takenAt: new Date(Date.now() - 86400000 * 14),
    likes: 15,
  },
  {
    id: '6',
    imageUrl: '/images/recipes/breakfast.png',
    title: 'Desayuno perfecto',
    recipeId: '7',
    recipeTitle: 'Desayuno Completo',
    takenAt: new Date(Date.now() - 86400000 * 20),
    likes: 28,
  },
]

export default function GaleriaPage() {
  const [photos] = useState(galleryPhotos)

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Camera className="h-8 w-8 text-purple-500" />
              Galería de Fotos
            </h1>
            <p className="text-muted-foreground">
              Tus creaciones culinarias capturadas
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          {/* Upload Section */}
          <Card className="mb-8">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold">Sube tus fotos</h2>
                  <p className="text-muted-foreground text-sm">
                    Comparte imágenes de tus platos preparados
                  </p>
                </div>
                <Button className="bg-gradient-to-r from-orange-500 to-green-500">
                  <Upload className="h-4 w-4 mr-2" />
                  Subir foto
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Gallery Grid */}
          {photos.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <ImageIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">Galería vacía</h3>
                <p className="text-muted-foreground mb-4">
                  Sube fotos de tus platos para verlas aquí
                </p>
                <Button>
                  <Camera className="h-4 w-4 mr-2" />
                  Subir primera foto
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {photos.map((photo, index) => (
                <motion.div
                  key={photo.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden group cursor-pointer">
                    <div className="relative aspect-square overflow-hidden">
                      <img
                        src={photo.imageUrl}
                        alt={photo.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                        <div className="flex gap-2">
                          <Button variant="secondary" size="icon">
                            <Heart className="h-5 w-5" />
                          </Button>
                          <Button variant="secondary" size="icon">
                            <Trash2 className="h-5 w-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-medium line-clamp-1">{photo.title}</h3>
                      <div className="flex items-center justify-between mt-2">
                        <Link 
                          href={`/recetas/${photo.recipeId}`}
                          className="text-sm text-muted-foreground hover:text-orange-500 flex items-center gap-1"
                        >
                          <ChefHat className="h-3 w-3" />
                          {photo.recipeTitle}
                        </Link>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Heart className="h-3 w-3" />
                          {photo.likes}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3" />
                        {formatDate(photo.takenAt)}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
