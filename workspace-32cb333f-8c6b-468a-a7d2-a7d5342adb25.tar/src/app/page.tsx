'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion } from 'framer-motion'
import {
  ChefHat,
  Search,
  Timer,
  ShoppingCart,
  Heart,
  Users,
  Sparkles,
  ArrowRight,
  Clock,
  Users as UsersIcon,
  Star,
  Play,
  Thermometer,
  Soup,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'

// Demo data for featured recipes
const featuredRecipes = [
  {
    id: '1',
    title: 'Paella Valenciana',
    description: 'La auténtica paella valenciana con pollo, conejo y judías verdes',
    imageUrl: '/images/recipes/paella.png',
    prepTime: 20,
    cookTime: 40,
    totalTime: 60,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.8,
    ratingCount: 156,
  },
  {
    id: '2',
    title: 'Hamburguesa Gourmet',
    description: 'Hamburguesa casera con carne seleccionada y vegetales frescos',
    imageUrl: '/images/recipes/burger.png',
    prepTime: 15,
    cookTime: 10,
    totalTime: 25,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.5,
    ratingCount: 89,
  },
  {
    id: '3',
    title: 'Ensalada Mediterránea',
    description: 'Ensalada fresca con ingredientes mediterráneos',
    imageUrl: '/images/recipes/salad.png',
    prepTime: 10,
    cookTime: 0,
    totalTime: 10,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.7,
    ratingCount: 203,
  },
  {
    id: '4',
    title: 'Tarta de Chocolate',
    description: 'Deliciosa tarta de chocolate con frutos rojos',
    imageUrl: '/images/recipes/chocolate-cake.png',
    prepTime: 30,
    cookTime: 45,
    totalTime: 75,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.9,
    ratingCount: 312,
  },
  {
    id: '5',
    title: 'Gazpacho Andaluz',
    description: 'Refrescante sopa fría de tomate tradicional',
    imageUrl: '/images/recipes/gazpacho.png',
    prepTime: 15,
    cookTime: 0,
    totalTime: 15,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.6,
    ratingCount: 178,
  },
  {
    id: '6',
    title: 'Pasta Carbonara',
    description: 'Auténtica pasta carbonara italiana con guanciale',
    imageUrl: '/images/recipes/carbonara.png',
    prepTime: 10,
    cookTime: 20,
    totalTime: 30,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.7,
    ratingCount: 245,
  },
]

const categories = [
  { name: 'Desayunos', icon: '🥐', count: 45, href: '/recetas?mealType=desayuno' },
  { name: 'Almuerzos', icon: '🍽️', count: 120, href: '/recetas?mealType=almuerzo' },
  { name: 'Cenas', icon: '🌙', count: 98, href: '/recetas?mealType=cena' },
  { name: 'Postres', icon: '🍰', count: 75, href: '/recetas?mealType=postre' },
  { name: 'Snacks', icon: '🍿', count: 32, href: '/recetas?mealType=snack' },
  { name: 'Sin Gluten', icon: '🌾', count: 56, href: '/recetas?isGlutenFree=true' },
]

const toolCategories = [
  { 
    name: 'Cocina Tradicional', 
    icon: ChefHat, 
    count: 490, 
    href: '/recetas?toolType=tradicional',
    color: 'from-orange-500 to-red-500',
    description: 'Recetas clásicas para cocinar de forma tradicional'
  },
  { 
    name: 'Thermomix', 
    icon: Thermometer, 
    count: 150, 
    href: '/recetas?toolType=thermomix',
    color: 'from-blue-500 to-cyan-500',
    description: 'Recetas optimizadas para Thermomix'
  },
  { 
    name: 'Crockpot', 
    icon: Soup, 
    count: 85, 
    href: '/recetas?toolType=crockpot',
    color: 'from-green-500 to-emerald-500',
    description: 'Recetas de cocción lenta para Crockpot'
  },
]

const features = [
  {
    icon: Search,
    title: 'Búsqueda por Ingredientes',
    description: 'Encuentra recetas según los ingredientes que tienes en casa'
  },
  {
    icon: Timer,
    title: 'Temporizador Integrado',
    description: 'Múltiples temporizadores para seguir tus recetas al detalle'
  },
  {
    icon: ShoppingCart,
    title: 'Lista de Compras',
    description: 'Genera automáticamente tu lista de compras desde las recetas'
  },
  {
    icon: Play,
    title: 'Modo Manos Libres',
    description: 'Navega por los pasos de la receta con comandos de voz'
  },
  {
    icon: Heart,
    title: 'Favoritos y Colecciones',
    description: 'Guarda tus recetas favoritas y organízalas en colecciones'
  },
  {
    icon: Users,
    title: 'Comunidad Activa',
    description: 'Participa en retos culinarios y comparte tus creaciones'
  },
]

const activeChallenges = [
  {
    id: '1',
    title: 'Reto Semanal: Postres de Verano',
    description: 'Comparte tu mejor postre refrescante',
    participants: 45,
    endDate: '2024-12-31',
    imageUrl: '/images/recipes/chocolate-cake.png',
  },
  {
    id: '2',
    title: 'Cocina Sin Gluten',
    description: 'Recetas deliciosas aptas para celíacos',
    participants: 32,
    endDate: '2024-12-25',
    imageUrl: '/images/recipes/salad.png',
  },
]

export default function Home() {
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-br from-orange-50 via-white to-green-50 dark:from-orange-950/20 dark:via-background dark:to-green-950/20">
          <div className="absolute inset-0 bg-[url('/images/banners/hero-banner.png')] bg-cover bg-center opacity-10" />
          <div className="container mx-auto px-4 py-16 md:py-24">
            <div className="max-w-3xl mx-auto text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h1 className="text-4xl md:text-6xl font-bold mb-6">
                  <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                    CocinaViva
                  </span>
                </h1>
                <p className="text-xl md:text-2xl text-muted-foreground mb-8">
                  Tu cocina integral. Descubre recetas deliciosas, organiza tus ingredientes y comparte con la comunidad.
                </p>
              </motion.div>

              {/* Search Bar */}
              <motion.form
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                onSubmit={(e) => {
                  e.preventDefault()
                  if (searchQuery.trim()) {
                    window.location.href = `/recetas?search=${encodeURIComponent(searchQuery)}`
                  }
                }}
                className="relative max-w-xl mx-auto mb-8"
              >
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="¿Qué quieres cocinar hoy?"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-14 pl-12 pr-4 text-lg rounded-full shadow-lg border-2 focus:border-orange-500"
                />
                <Button 
                  type="submit"
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                >
                  Buscar
                </Button>
              </motion.form>

              {/* Quick Stats */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="flex flex-wrap justify-center gap-8 text-center"
              >
                <div>
                  <div className="text-3xl font-bold text-orange-600">725+</div>
                  <div className="text-sm text-muted-foreground">Recetas</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600">250+</div>
                  <div className="text-sm text-muted-foreground">Ingredientes</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">15K+</div>
                  <div className="text-sm text-muted-foreground">Usuarios</div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Tool Categories */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-bold mb-4">Cocina a tu manera</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Elige el tipo de cocina que más te guste: tradicional, Thermomix o Crockpot
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {toolCategories.map((category, index) => {
                const Icon = category.icon
                return (
                  <motion.div
                    key={category.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link href={category.href}>
                      <Card className="h-full hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group cursor-pointer">
                        <CardHeader>
                          <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                            <Icon className="h-7 w-7 text-white" />
                          </div>
                          <CardTitle className="flex items-center justify-between">
                            {category.name}
                            <Badge variant="secondary">{category.count}</Badge>
                          </CardTitle>
                          <CardDescription>{category.description}</CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button variant="ghost" className="w-full group-hover:bg-orange-50 group-hover:text-orange-600">
                            Ver recetas <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </CardFooter>
                      </Card>
                    </Link>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Featured Recipes */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center justify-between mb-8"
            >
              <div>
                <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
                  <Sparkles className="h-8 w-8 text-orange-500" />
                  Recetas Destacadas
                </h2>
                <p className="text-muted-foreground">
                  Las recetas más populares de nuestra comunidad
                </p>
              </div>
              <Link href="/destacados">
                <Button variant="outline" className="hidden sm:flex">
                  Ver todas <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredRecipes.map((recipe, index) => (
                <motion.div
                  key={recipe.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={`/recetas/${recipe.id}`}>
                    <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                      <div className="relative h-48 overflow-hidden">
                        <img
                          src={recipe.imageUrl}
                          alt={recipe.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-3 left-3 flex gap-2">
                          {recipe.isGlutenFree && (
                            <Badge className="bg-green-500 hover:bg-green-600">
                              Sin Gluten
                            </Badge>
                          )}
                          <Badge variant="secondary" className="bg-white/90 text-gray-800">
                            {recipe.toolType === 'tradicional' ? 'Tradicional' : 
                             recipe.toolType === 'thermomix' ? 'Thermomix' : 'Crockpot'}
                          </Badge>
                        </div>
                        <div className="absolute top-3 right-3">
                          <Badge className="bg-yellow-500 hover:bg-yellow-600">
                            <Star className="h-3 w-3 mr-1 fill-white" />
                            {recipe.averageRating.toFixed(1)}
                          </Badge>
                        </div>
                      </div>
                      <CardHeader className="pb-2">
                        <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                        <CardDescription className="line-clamp-2">
                          {recipe.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {recipe.totalTime} min
                          </div>
                          <div className="flex items-center gap-1">
                            <UsersIcon className="h-4 w-4" />
                            4 pers.
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {recipe.difficulty === 'facil' ? 'Fácil' : 
                             recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>

            <div className="mt-8 text-center sm:hidden">
              <Link href="/destacados">
                <Button variant="outline">
                  Ver todas las recetas <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Categories */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-8"
            >
              <h2 className="text-3xl font-bold mb-4">Explora por Categoría</h2>
              <p className="text-muted-foreground">
                Encuentra el tipo de receta perfecta para cada momento
              </p>
            </motion.div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
              {categories.map((category, index) => (
                <motion.div
                  key={category.name}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                >
                  <Link href={category.href}>
                    <Card className="hover:shadow-md transition-all cursor-pointer hover:border-orange-300">
                      <CardContent className="pt-6 text-center">
                        <div className="text-4xl mb-2">{category.icon}</div>
                        <div className="font-medium">{category.name}</div>
                        <div className="text-sm text-muted-foreground">{category.count} recetas</div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-bold mb-4">Todo lo que necesitas</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                CocinaViva te ofrece todas las herramientas para disfrutar cocinando
              </p>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon
                return (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-md transition-all">
                      <CardHeader>
                        <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-orange-500 to-green-500 flex items-center justify-center mb-4">
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <CardTitle className="text-lg">{feature.title}</CardTitle>
                        <CardDescription>{feature.description}</CardDescription>
                      </CardHeader>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Active Challenges */}
        <section className="py-16 bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center justify-between mb-8"
            >
              <div>
                <h2 className="text-3xl font-bold mb-2 flex items-center gap-2">
                  <Users className="h-8 w-8 text-green-500" />
                  Retos Activos
                </h2>
                <p className="text-muted-foreground">
                  Únete a los retos semanales de nuestra comunidad
                </p>
              </div>
              <Link href="/comunidad">
                <Button variant="outline" className="hidden sm:flex">
                  Ver comunidad <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {activeChallenges.map((challenge, index) => (
                <motion.div
                  key={challenge.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden hover:shadow-lg transition-all cursor-pointer group">
                    <div className="flex">
                      <div className="w-32 h-32 relative flex-shrink-0">
                        <img
                          src={challenge.imageUrl}
                          alt={challenge.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>
                      <div className="flex-1 p-4">
                        <CardTitle className="text-lg mb-2">{challenge.title}</CardTitle>
                        <CardDescription className="mb-3">{challenge.description}</CardDescription>
                        <div className="flex items-center gap-4 text-sm">
                          <Badge variant="secondary">
                            <UsersIcon className="h-3 w-3 mr-1" />
                            {challenge.participants} participantes
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
            >
              <Card className="bg-gradient-to-r from-orange-500 to-green-500 text-white overflow-hidden">
                <CardContent className="py-12 px-8 text-center">
                  <h2 className="text-3xl font-bold mb-4">
                    ¿Tienes una receta increíble?
                  </h2>
                  <p className="text-white/90 mb-6 max-w-xl mx-auto">
                    Comparte tus recetas con la comunidad y participa en los retos semanales
                  </p>
                  <Link href="/crear">
                    <Button size="lg" variant="secondary" className="bg-white text-orange-600 hover:bg-white/90">
                      <ChefHat className="mr-2 h-5 w-5" />
                      Crear mi receta
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
