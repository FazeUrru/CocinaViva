import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/recipes - List recipes with filters
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    
    const search = searchParams.get('search') || ''
    const toolType = searchParams.get('toolType') || 'all'
    const isGlutenFree = searchParams.get('isGlutenFree')
    const difficulty = searchParams.get('difficulty') || ''
    const mealType = searchParams.get('mealType') || ''
    const cuisineType = searchParams.get('cuisineType') || ''
    const maxTime = searchParams.get('maxTime')
    const categoryId = searchParams.get('categoryId') || ''
    const page = parseInt(searchParams.get('page') || '1')
    const pageSize = parseInt(searchParams.get('pageSize') || '20')
    const isFeatured = searchParams.get('isFeatured')

    const where: Record<string, unknown> = {
      isPublic: true,
    }

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ]
    }

    if (toolType && toolType !== 'all') {
      where.toolType = toolType
    }

    if (isGlutenFree === 'true') {
      where.isGlutenFree = true
    }

    if (difficulty) {
      where.difficulty = difficulty
    }

    if (mealType) {
      where.mealType = mealType
    }

    if (cuisineType) {
      where.cuisineType = cuisineType
    }

    if (maxTime) {
      where.totalTime = { lte: parseInt(maxTime) }
    }

    if (categoryId) {
      where.categoryId = categoryId
    }

    if (isFeatured === 'true') {
      where.isFeatured = true
    }

    const [recipes, total] = await Promise.all([
      db.recipe.findMany({
        where,
        include: {
          category: true,
          tags: {
            include: {
              tag: true,
            },
          },
          ingredients: {
            include: {
              ingredient: true,
            },
            take: 5,
          },
        },
        orderBy: [
          { isFeatured: 'desc' },
          { averageRating: 'desc' },
          { createdAt: 'desc' },
        ],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.recipe.count({ where }),
    ])

    return NextResponse.json({
      success: true,
      data: {
        items: recipes,
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize),
      },
    })
  } catch (error) {
    console.error('Error fetching recipes:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener las recetas' },
      { status: 500 }
    )
  }
}

// POST /api/recipes - Create new recipe
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      title,
      description,
      imageUrl,
      prepTime,
      cookTime,
      totalTime,
      servings,
      difficulty,
      cuisineType,
      mealType,
      toolType,
      isGlutenFree,
      isPublic,
      categoryId,
      authorId,
      ingredients,
      steps,
      tags,
    } = body

    // Generate slug from title
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9áéíóúñü\s-]/g, '')
      .replace(/\s+/g, '-')
      .substring(0, 100)

    const recipe = await db.recipe.create({
      data: {
        title,
        slug,
        description,
        imageUrl,
        prepTime,
        cookTime,
        totalTime,
        servings,
        difficulty,
        cuisineType,
        mealType,
        toolType: toolType || 'tradicional',
        isGlutenFree: isGlutenFree || false,
        isPublic: isPublic !== false,
        categoryId,
        authorId,
        ingredients: ingredients
          ? {
              create: ingredients.map((ing: { ingredientId: string; quantity: number; unit: string; notes?: string }, index: number) => ({
                ingredientId: ing.ingredientId,
                quantity: ing.quantity,
                unit: ing.unit,
                notes: ing.notes,
                order: index,
              })),
            }
          : undefined,
        steps: steps
          ? {
              create: steps.map((step: { instruction: string; duration?: number; tip?: string }, index: number) => ({
                stepNumber: index + 1,
                instruction: step.instruction,
                duration: step.duration,
                tip: step.tip,
              })),
            }
          : undefined,
        tags: tags
          ? {
              create: tags.map((tagId: string) => ({
                tagId,
              })),
            }
          : undefined,
      },
      include: {
        ingredients: {
          include: {
            ingredient: true,
          },
        },
        steps: true,
        tags: {
          include: {
            tag: true,
          },
        },
      },
    })

    return NextResponse.json({ success: true, data: recipe })
  } catch (error) {
    console.error('Error creating recipe:', error)
    return NextResponse.json(
      { success: false, error: 'Error al crear la receta' },
      { status: 500 }
    )
  }
}
