import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/challenges - Get active challenges
export async function GET() {
  try {
    const challenges = await db.challenge.findMany({
      where: {
        isActive: true,
        endDate: { gte: new Date() },
      },
      include: {
        participants: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
        },
        posts: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
            recipe: true,
            comments: {
              include: {
                user: {
                  select: {
                    id: true,
                    name: true,
                    avatar: true,
                  },
                },
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
        _count: {
          select: {
            participants: true,
            posts: true,
          },
        },
      },
      orderBy: { startDate: 'desc' },
    })

    return NextResponse.json({ success: true, data: challenges })
  } catch (error) {
    console.error('Error fetching challenges:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener los retos' },
      { status: 500 }
    )
  }
}
