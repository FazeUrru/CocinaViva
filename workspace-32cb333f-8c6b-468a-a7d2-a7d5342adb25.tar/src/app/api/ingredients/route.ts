import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/ingredients - List all ingredients
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category') || ''
    const search = searchParams.get('search') || ''

    const where: Record<string, unknown> = {}

    if (category) {
      where.category = category
    }

    if (search) {
      where.name = { contains: search }
    }

    const ingredients = await db.ingredient.findMany({
      where,
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ success: true, data: ingredients })
  } catch (error) {
    console.error('Error fetching ingredients:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener los ingredientes' },
      { status: 500 }
    )
  }
}
