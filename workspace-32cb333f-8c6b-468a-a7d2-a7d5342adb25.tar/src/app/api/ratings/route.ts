import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/ratings - Get ratings for a recipe
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const recipeId = searchParams.get('recipeId')
    const userId = searchParams.get('userId')

    if (!recipeId) {
      return NextResponse.json(
        { success: false, error: 'recipeId es requerido' },
        { status: 400 }
      )
    }

    if (userId) {
      // Get user's rating for this recipe
      const userRating = await db.rating.findUnique({
        where: {
          recipeId_userId: { recipeId, userId },
        },
      })
      return NextResponse.json({ success: true, data: userRating })
    }

    // Get all ratings for this recipe
    const ratings = await db.rating.findMany({
      where: { recipeId },
      select: { rating: true },
    })

    const averageRating = ratings.length > 0
      ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
      : 0

    return NextResponse.json({
      success: true,
      data: {
        average: averageRating,
        count: ratings.length,
        distribution: {
          5: ratings.filter(r => r.rating === 5).length,
          4: ratings.filter(r => r.rating === 4).length,
          3: ratings.filter(r => r.rating === 3).length,
          2: ratings.filter(r => r.rating === 2).length,
          1: ratings.filter(r => r.rating === 1).length,
        },
      },
    })
  } catch (error) {
    console.error('Error fetching ratings:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener las valoraciones' },
      { status: 500 }
    )
  }
}

// POST /api/ratings - Add/update rating
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { recipeId, userId, rating } = body

    if (!recipeId || !userId || rating === undefined) {
      return NextResponse.json(
        { success: false, error: 'recipeId, userId y rating son requeridos' },
        { status: 400 }
      )
    }

    if (rating < 1 || rating > 5) {
      return NextResponse.json(
        { success: false, error: 'La valoración debe estar entre 1 y 5' },
        { status: 400 }
      )
    }

    // Upsert rating
    const ratingRecord = await db.rating.upsert({
      where: {
        recipeId_userId: { recipeId, userId },
      },
      update: { rating },
      create: { recipeId, userId, rating },
    })

    // Update recipe average rating
    const ratings = await db.rating.findMany({
      where: { recipeId },
      select: { rating: true },
    })

    const averageRating = ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length

    await db.recipe.update({
      where: { id: recipeId },
      data: {
        averageRating,
        ratingCount: ratings.length,
      },
    })

    return NextResponse.json({
      success: true,
      data: {
        rating: ratingRecord,
        average: averageRating,
        count: ratings.length,
      },
    })
  } catch (error) {
    console.error('Error adding rating:', error)
    return NextResponse.json(
      { success: false, error: 'Error al agregar la valoración' },
      { status: 500 }
    )
  }
}
