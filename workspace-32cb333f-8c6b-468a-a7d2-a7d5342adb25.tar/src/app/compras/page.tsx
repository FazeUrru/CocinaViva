'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  ShoppingCart,
  Plus,
  Check,
  Trash2,
  X,
  Search,
  ChefHat,
  List,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useShoppingListStore } from '@/store'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

// Demo ingredients database
const ingredientsDB = [
  { id: '1', name: 'Arroz', category: 'cereales', unit: 'g' },
  { id: '2', name: 'Pollo', category: 'carnes', unit: 'g' },
  { id: '3', name: 'Tomate', category: 'verduras', unit: 'unidades' },
  { id: '4', name: 'Cebolla', category: 'verduras', unit: 'unidades' },
  { id: '5', name: 'Ajo', category: 'verduras', unit: 'dientes' },
  { id: '6', name: 'Aceite de oliva', category: 'aceites', unit: 'ml' },
  { id: '7', name: 'Sal', category: 'condimentos', unit: 'g' },
  { id: '8', name: 'Pimienta', category: 'condimentos', unit: 'g' },
  { id: '9', name: 'Leche', category: 'lacteos', unit: 'ml' },
  { id: '10', name: 'Huevos', category: 'huevos', unit: 'unidades' },
]

export default function ComprasPage() {
  const { items, addItem, removeItem, toggleItem, clearChecked, clearAll } = useShoppingListStore()
  const [newItemName, setNewItemName] = useState('')
  const [newItemQuantity, setNewItemQuantity] = useState(1)
  const [newItemUnit, setNewItemUnit] = useState('unidades')
  const [searchQuery, setSearchQuery] = useState('')

  const addCustomItem = () => {
    if (!newItemName.trim()) {
      toast.error('Ingresa un nombre para el item')
      return
    }
    addItem({
      shoppingListId: 'default',
      ingredientId: null,
      customName: newItemName,
      quantity: newItemQuantity,
      unit: newItemUnit,
      isChecked: false,
      notes: null,
    })
    setNewItemName('')
    setNewItemQuantity(1)
    toast.success('Item añadido a la lista')
  }

  const addIngredientFromDB = (ingredient: typeof ingredientsDB[0]) => {
    const existing = items.find(item => 
      item.customName === ingredient.name || item.ingredientId === ingredient.id
    )
    if (existing) {
      toast.info(`${ingredient.name} ya está en la lista`)
      return
    }
    addItem({
      shoppingListId: 'default',
      ingredientId: ingredient.id,
      customName: ingredient.name,
      quantity: 1,
      unit: ingredient.unit,
      isChecked: false,
      notes: null,
    })
    toast.success(`${ingredient.name} añadido`)
  }

  const filteredIngredients = ingredientsDB.filter(ing =>
    ing.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const uncheckedItems = items.filter(item => !item.isChecked)
  const checkedItems = items.filter(item => item.isChecked)

  const units = ['unidades', 'g', 'kg', 'ml', 'l', 'cucharadas', 'cucharaditas', 'piezas']

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <ShoppingCart className="h-8 w-8 text-orange-500" />
              Lista de Compras
            </h1>
            <p className="text-muted-foreground">
              Gestiona los ingredientes que necesitas para tus recetas
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Shopping List */}
            <div className="lg:col-span-2 space-y-6">
              {/* Quick Add */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Plus className="h-5 w-5" />
                    Añadir item
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    <Input
                      placeholder="Nombre del ingrediente"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      className="flex-1 min-w-[200px]"
                      onKeyDown={(e) => e.key === 'Enter' && addCustomItem()}
                    />
                    <Input
                      type="number"
                      min={0.1}
                      step={0.1}
                      value={newItemQuantity}
                      onChange={(e) => setNewItemQuantity(parseFloat(e.target.value) || 1)}
                      className="w-20"
                    />
                    <select
                      value={newItemUnit}
                      onChange={(e) => setNewItemUnit(e.target.value)}
                      className="border rounded-md px-3 py-2 text-sm"
                    >
                      {units.map(unit => (
                        <option key={unit} value={unit}>{unit}</option>
                      ))}
                    </select>
                    <Button onClick={addCustomItem}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Items List */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <List className="h-5 w-5" />
                        Tu lista
                      </CardTitle>
                      <CardDescription>
                        {items.length} items • {uncheckedItems.length} pendientes
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {checkedItems.length > 0 && (
                        <Button variant="outline" size="sm" onClick={clearChecked}>
                          <X className="h-4 w-4 mr-1" />
                          Limpiar completados
                        </Button>
                      )}
                      {items.length > 0 && (
                        <Button variant="outline" size="sm" onClick={clearAll}>
                          <Trash2 className="h-4 w-4 mr-1" />
                          Vaciar lista
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {items.length === 0 ? (
                    <div className="text-center py-12">
                      <ChefHat className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Lista vacía</h3>
                      <p className="text-muted-foreground">
                        Añade ingredientes desde las recetas o manualmente
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Unchecked Items */}
                      {uncheckedItems.length > 0 && (
                        <div className="space-y-2">
                          {uncheckedItems.map((item) => (
                            <motion.div
                              key={item.id}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors"
                            >
                              <Checkbox
                                checked={item.isChecked}
                                onCheckedChange={() => toggleItem(item.id)}
                              />
                              <div className="flex-1">
                                <span className="font-medium">{item.customName}</span>
                                {item.notes && (
                                  <span className="text-sm text-muted-foreground ml-2">
                                    ({item.notes})
                                  </span>
                                )}
                              </div>
                              <Badge variant="outline">
                                {item.quantity} {item.unit}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeItem(item.id)}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground" />
                              </Button>
                            </motion.div>
                          ))}
                        </div>
                      )}

                      {/* Separator */}
                      {checkedItems.length > 0 && uncheckedItems.length > 0 && (
                        <Separator />
                      )}

                      {/* Checked Items */}
                      {checkedItems.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm text-muted-foreground font-medium">
                            Completados ({checkedItems.length})
                          </p>
                          {checkedItems.map((item) => (
                            <motion.div
                              key={item.id}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                            >
                              <Checkbox
                                checked={item.isChecked}
                                onCheckedChange={() => toggleItem(item.id)}
                              />
                              <div className="flex-1">
                                <span className="font-medium line-through text-muted-foreground">
                                  {item.customName}
                                </span>
                              </div>
                              <Badge variant="outline" className="opacity-50">
                                {item.quantity} {item.unit}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeItem(item.id)}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground" />
                              </Button>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Quick Add from Database */}
            <div className="space-y-6">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg">Ingredientes comunes</CardTitle>
                  <CardDescription>
                    Añade rápidamente ingredientes frecuentes
                  </CardDescription>
                  <div className="relative mt-2">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar ingrediente..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {filteredIngredients.map((ing) => (
                      <button
                        key={ing.id}
                        onClick={() => addIngredientFromDB(ing)}
                        className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors text-left"
                      >
                        <span>{ing.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {ing.unit}
                        </Badge>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
