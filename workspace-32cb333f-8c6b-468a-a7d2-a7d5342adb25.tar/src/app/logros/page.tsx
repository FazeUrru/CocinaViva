'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Trophy,
  Lock,
  CheckCircle2,
  Filter,
  Search,
  Star,
  Zap,
  Target,
  Crown,
  Eye,
  EyeOff,
  Settings,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { achievements, totalPointsAvailable } from '@/data/achievements'
import { cn } from '@/lib/utils'
import Link from 'next/link'

const categoryIcons = {
  cocina: Trophy,
  social: Target,
  exploracion: Search,
  especial: Star,
  maestro: Crown,
}

const categoryColors = {
  cocina: 'from-orange-500 to-red-500',
  social: 'from-blue-500 to-purple-500',
  exploracion: 'from-green-500 to-teal-500',
  especial: 'from-yellow-500 to-orange-500',
  maestro: 'from-purple-500 to-pink-500',
}

const rarityColors = {
  comun: 'bg-gray-100 text-gray-800 border-gray-300',
  raro: 'bg-blue-100 text-blue-800 border-blue-300',
  epico: 'bg-purple-100 text-purple-800 border-purple-300',
  legendario: 'bg-yellow-100 text-yellow-800 border-yellow-300',
}

export default function LogrosPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedRarity, setSelectedRarity] = useState<string>('all')
  const [hideUnlocked, setHideUnlocked] = useState(false)
  const [showOnlyUnlocked, setShowOnlyUnlocked] = useState(false)
  const [autoHideUnlocked, setAutoHideUnlocked] = useState(true) // Por defecto ocultar no conseguidos

  // Calculate stats - Los logros se consiguen con el tiempo y permanencia
  const unlockedCount = achievements.filter(a => a.unlocked).length
  const totalPoints = achievements.filter(a => a.unlocked).reduce((sum, a) => sum + a.points, 0)
  const progressPercentage = (unlockedCount / achievements.length) * 100

  // Filter achievements - Los no conseguidos se ocultan automáticamente
  const filteredAchievements = achievements.filter(achievement => {
    // Auto-ocultar no conseguidos si está activado
    if (autoHideUnlocked && !achievement.unlocked) {
      return false
    }
    
    if (searchQuery && !achievement.name.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }
    if (selectedCategory !== 'all' && achievement.category !== selectedCategory) {
      return false
    }
    if (selectedRarity !== 'all' && achievement.rarity !== selectedRarity) {
      return false
    }
    if (hideUnlocked && achievement.unlocked) {
      return false
    }
    if (showOnlyUnlocked && !achievement.unlocked) {
      return false
    }
    return true
  })

  // Group by category
  const groupedAchievements = achievements
    .filter(a => !autoHideUnlocked || a.unlocked) // Aplicar filtro de auto-ocultar
    .reduce((acc, achievement) => {
      if (!acc[achievement.category]) {
        acc[achievement.category] = []
      }
      acc[achievement.category].push(achievement)
      return acc
    }, {} as Record<string, typeof achievements>)

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Trophy className="h-8 w-8 text-yellow-500" />
              Logros
            </h1>
            <p className="text-muted-foreground">
              Desbloquea {achievements.length} logros ganándolos con tu permanencia y actividad
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-500">{unlockedCount}</div>
                  <div className="text-sm text-muted-foreground">de {achievements.length} logros</div>
                  <Progress value={progressPercentage} className="mt-2 h-2" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-500">{totalPoints.toLocaleString()}</div>
                  <div className="text-sm text-muted-foreground">puntos ganados</div>
                  <div className="text-xs text-muted-foreground mt-1">de {totalPointsAvailable.toLocaleString()} totales</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-500">
                    {achievements.filter(a => a.rarity === 'legendario' && a.unlocked).length}
                  </div>
                  <div className="text-sm text-muted-foreground">legendarios</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-500">
                    {achievements.filter(a => a.rarity === 'epico' && a.unlocked).length}
                  </div>
                  <div className="text-sm text-muted-foreground">épicos</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Settings for hiding achievements */}
          <Card className="mb-6">
            <CardContent className="py-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-6">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="auto-hide"
                      checked={autoHideUnlocked}
                      onCheckedChange={setAutoHideUnlocked}
                    />
                    <Label htmlFor="auto-hide" className="flex items-center gap-2 cursor-pointer">
                      {autoHideUnlocked ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      Ocultar no conseguidos
                    </Label>
                  </div>
                </div>
                <Link href="/ajustes">
                  <Button variant="outline" size="sm" className="gap-2">
                    <Settings className="h-4 w-4" />
                    Más ajustes
                  </Button>
                </Link>
              </div>
              {autoHideUnlocked && (
                <p className="text-sm text-muted-foreground mt-2">
                  Los logros no conseguidos se ocultan automáticamente. ¡Sigue cocinando para desbloquearlos!
                </p>
              )}
            </CardContent>
          </Card>

          {/* Search and Filters */}
          <div className="flex flex-wrap gap-4 mb-6">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar logros desbloqueados..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
              <TabsList>
                <TabsTrigger value="all">Todos</TabsTrigger>
                <TabsTrigger value="cocina">Cocina</TabsTrigger>
                <TabsTrigger value="social">Social</TabsTrigger>
                <TabsTrigger value="exploracion">Exploración</TabsTrigger>
                <TabsTrigger value="especial">Especial</TabsTrigger>
                <TabsTrigger value="maestro">Maestro</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Achievements Grid */}
          {selectedCategory === 'all' ? (
            // Show grouped by category
            Object.entries(groupedAchievements).map(([category, categoryAchievements]) => {
              const Icon = categoryIcons[category as keyof typeof categoryIcons]
              const colorClass = categoryColors[category as keyof typeof categoryColors]
              const unlockedInCategory = categoryAchievements.filter(a => a.unlocked).length

              return (
                <div key={category} className="mb-8">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={cn("w-10 h-10 rounded-lg bg-gradient-to-br flex items-center justify-center", colorClass)}>
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-xl font-semibold capitalize">{category}</h2>
                      <p className="text-sm text-muted-foreground">
                        {unlockedInCategory} desbloqueados
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {categoryAchievements.slice(0, 8).map((achievement) => (
                      <AchievementCard key={achievement.id} achievement={achievement} />
                    ))}
                  </div>
                </div>
              )
            })
          ) : (
            // Show filtered achievements
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredAchievements.map((achievement) => (
                <AchievementCard key={achievement.id} achievement={achievement} />
              ))}
            </div>
          )}

          {filteredAchievements.length === 0 && autoHideUnlocked && (
            <div className="text-center py-12">
              <Lock className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-semibold mb-2">¡Aún no hay logros desbloqueados!</h3>
              <p className="text-muted-foreground">
                Los logros se consiguen cocinando, permaneciendo en la app y participando en la comunidad.
              </p>
              <Link href="/recetas">
                <Button className="mt-4 bg-gradient-to-r from-orange-500 to-green-500">
                  Empezar a cocinar
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}

function AchievementCard({ achievement }: { achievement: typeof achievements[0] }) {
  const progressPercentage = (achievement.progress / achievement.requirement) * 100

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card className={cn(
        "relative overflow-hidden transition-all",
        achievement.unlocked && "border-green-500/50"
      )}>
        {achievement.unlocked && (
          <div className="absolute top-2 right-2">
            <CheckCircle2 className="h-5 w-5 text-green-500" />
          </div>
        )}
        <CardHeader className="pb-2">
          <div className="flex items-center gap-3">
            <div className={cn(
              "w-12 h-12 rounded-lg flex items-center justify-center text-2xl",
              achievement.unlocked ? "bg-gradient-to-br from-orange-500 to-green-500" : "bg-muted"
            )}>
              {achievement.unlocked ? achievement.icon : <Lock className="h-5 w-5 text-muted-foreground" />}
            </div>
            <div className="flex-1">
              <CardTitle className="text-base">{achievement.name}</CardTitle>
              <Badge variant="outline" className={cn("text-xs mt-1", rarityColors[achievement.rarity])}>
                {achievement.rarity}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-1">
              <Zap className="h-4 w-4 text-yellow-500" />
              <span className="font-medium">{achievement.points} pts</span>
            </div>
            <div className="text-muted-foreground">
              {achievement.progress}/{achievement.requirement}
            </div>
          </div>
          {!achievement.unlocked && achievement.progress > 0 && (
            <Progress value={progressPercentage} className="mt-2 h-1.5" />
          )}
        </CardContent>
      </Card>
    </motion.div>
  )
}
