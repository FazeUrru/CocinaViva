import { db } from '../src/lib/db'

async function seed() {
  console.log('🌱 Iniciando seed de la base de datos...')

  // Crear categorías
  const categories = await Promise.all([
    db.category.upsert({
      where: { slug: 'desayunos' },
      update: {},
      create: { name: 'Desayunos', slug: 'desayunos', icon: '🥐', description: 'Recetas para empezar el día' },
    }),
    db.category.upsert({
      where: { slug: 'almuerzos' },
      update: {},
      create: { name: 'Almuerzos', slug: 'almuerzos', icon: '🍽️', description: 'Platos principales para el mediodía' },
    }),
    db.category.upsert({
      where: { slug: 'cenas' },
      update: {},
      create: { name: 'Cenas', slug: 'cenas', icon: '🌙', description: 'Recetas para la noche' },
    }),
    db.category.upsert({
      where: { slug: 'postres' },
      update: {},
      create: { name: 'Postres', slug: 'postres', icon: '🍰', description: 'Dulces y postres deliciosos' },
    }),
    db.category.upsert({
      where: { slug: 'snacks' },
      update: {},
      create: { name: 'Snacks', slug: 'snacks', icon: '🍿', description: 'Aperitivos y bocadillos' },
    }),
  ])
  console.log(`✅ Creadas ${categories.length} categorías`)

  // Crear etiquetas
  const tags = await Promise.all([
    db.tag.upsert({ where: { slug: 'sin-gluten' }, update: {}, create: { name: 'Sin Gluten', slug: 'sin-gluten', color: '#22c55e' } }),
    db.tag.upsert({ where: { slug: 'vegetariano' }, update: {}, create: { name: 'Vegetariano', slug: 'vegetariano', color: '#10b981' } }),
    db.tag.upsert({ where: { slug: 'vegano' }, update: {}, create: { name: 'Vegano', slug: 'vegano', color: '#059669' } }),
    db.tag.upsert({ where: { slug: 'tradicional' }, update: {}, create: { name: 'Tradicional', slug: 'tradicional', color: '#f97316' } }),
    db.tag.upsert({ where: { slug: 'mediterranea' }, update: {}, create: { name: 'Mediterránea', slug: 'mediterranea', color: '#3b82f6' } }),
    db.tag.upsert({ where: { slug: 'rapido' }, update: {}, create: { name: 'Rápido', slug: 'rapido', color: '#eab308' } }),
    db.tag.upsert({ where: { slug: 'saludable' }, update: {}, create: { name: 'Saludable', slug: 'saludable', color: '#14b8a6' } }),
  ])
  console.log(`✅ Creadas ${tags.length} etiquetas`)

  // Crear ingredientes base
  const ingredientData = [
    { name: 'Arroz', slug: 'arroz', category: 'cereales', unit: 'g', calories: 130, isGlutenFree: true },
    { name: 'Pollo', slug: 'pollo', category: 'carnes', unit: 'g', calories: 165, isGlutenFree: true },
    { name: 'Tomate', slug: 'tomate', category: 'verduras', unit: 'unidades', calories: 18, isGlutenFree: true },
    { name: 'Cebolla', slug: 'cebolla', category: 'verduras', unit: 'unidades', calories: 40, isGlutenFree: true },
    { name: 'Ajo', slug: 'ajo', category: 'verduras', unit: 'dientes', calories: 4, isGlutenFree: true },
    { name: 'Aceite de oliva', slug: 'aceite-oliva', category: 'aceites', unit: 'ml', calories: 884, isGlutenFree: true },
    { name: 'Sal', slug: 'sal', category: 'condimentos', unit: 'g', calories: 0, isGlutenFree: true },
    { name: 'Pimienta', slug: 'pimienta', category: 'condimentos', unit: 'g', calories: 251, isGlutenFree: true },
    { name: 'Leche', slug: 'leche', category: 'lacteos', unit: 'ml', calories: 42, isGlutenFree: true },
    { name: 'Huevos', slug: 'huevos', category: 'huevos', unit: 'unidades', calories: 155, isGlutenFree: true },
    { name: 'Harina de trigo', slug: 'harina-trigo', category: 'cereales', unit: 'g', calories: 364, isGlutenFree: false },
    { name: 'Azúcar', slug: 'azucar', category: 'endulzantes', unit: 'g', calories: 387, isGlutenFree: true },
    { name: 'Mantequilla', slug: 'mantequilla', category: 'lacteos', unit: 'g', calories: 717, isGlutenFree: true },
    { name: 'Chocolate', slug: 'chocolate', category: 'otros', unit: 'g', calories: 546, isGlutenFree: true },
    { name: 'Pasta', slug: 'pasta', category: 'cereales', unit: 'g', calories: 131, isGlutenFree: false },
    { name: 'Carne de res', slug: 'carne-res', category: 'carnes', unit: 'g', calories: 250, isGlutenFree: true },
    { name: 'Pescado', slug: 'pescado', category: 'pescados', unit: 'g', calories: 136, isGlutenFree: true },
    { name: 'Pimientos', slug: 'pimientos', category: 'verduras', unit: 'unidades', calories: 31, isGlutenFree: true },
    { name: 'Judías verdes', slug: 'judias-verdes', category: 'verduras', unit: 'g', calories: 31, isGlutenFree: true },
    { name: 'Gambas', slug: 'gambas', category: 'mariscos', unit: 'g', calories: 99, isGlutenFree: true },
  ]

  let ingredientsCreated = 0
  for (const ing of ingredientData) {
    await db.ingredient.upsert({
      where: { slug: ing.slug },
      update: {},
      create: ing,
    })
    ingredientsCreated++
  }
  console.log(`✅ Creados ${ingredientsCreated} ingredientes`)

  // Crear usuario demo
  const demoUser = await db.user.upsert({
    where: { email: 'demo@cocinaviva.com' },
    update: {},
    create: {
      id: 'demo-user',
      email: 'demo@cocinaviva.com',
      name: 'Usuario Demo',
    },
  })
  console.log(`✅ Usuario demo creado`)

  // Crear recetas de ejemplo
  const recipesData = [
    {
      title: 'Paella Valenciana',
      slug: 'paella-valenciana',
      description: 'La auténtica paella valenciana con pollo, conejo y judías verdes. Un plato tradicional español que captura la esencia de la cocina mediterránea.',
      imageUrl: '/images/recipes/paella.png',
      prepTime: 20,
      cookTime: 40,
      totalTime: 60,
      servings: 4,
      difficulty: 'medio',
      cuisineType: 'española',
      mealType: 'almuerzo',
      toolType: 'tradicional',
      isGlutenFree: true,
      isFeatured: true,
      featuredAt: new Date(),
      categoryId: categories.find(c => c.slug === 'almuerzos')?.id,
    },
    {
      title: 'Hamburguesa Gourmet',
      slug: 'hamburguesa-gourmet',
      description: 'Hamburguesa casera con carne seleccionada y vegetales frescos. Una delicia para los amantes de la carne.',
      imageUrl: '/images/recipes/burger.png',
      prepTime: 15,
      cookTime: 10,
      totalTime: 25,
      servings: 4,
      difficulty: 'facil',
      cuisineType: 'americana',
      mealType: 'almuerzo',
      toolType: 'tradicional',
      isGlutenFree: false,
      isFeatured: true,
      featuredAt: new Date(),
      categoryId: categories.find(c => c.slug === 'almuerzos')?.id,
    },
    {
      title: 'Ensalada Mediterránea',
      slug: 'ensalada-mediterranea',
      description: 'Ensalada fresca con ingredientes mediterráneos. Perfecta para días calurosos.',
      imageUrl: '/images/recipes/salad.png',
      prepTime: 10,
      cookTime: 0,
      totalTime: 10,
      servings: 2,
      difficulty: 'facil',
      cuisineType: 'mediterranea',
      mealType: 'almuerzo',
      toolType: 'tradicional',
      isGlutenFree: true,
      isFeatured: true,
      featuredAt: new Date(),
      categoryId: categories.find(c => c.slug === 'almuerzos')?.id,
    },
    {
      title: 'Tarta de Chocolate',
      slug: 'tarta-chocolate',
      description: 'Deliciosa tarta de chocolate con frutos rojos. El postre perfecto para cualquier ocasión.',
      imageUrl: '/images/recipes/chocolate-cake.png',
      prepTime: 30,
      cookTime: 45,
      totalTime: 75,
      servings: 8,
      difficulty: 'medio',
      cuisineType: 'internacional',
      mealType: 'postre',
      toolType: 'tradicional',
      isGlutenFree: false,
      isFeatured: true,
      featuredAt: new Date(),
      categoryId: categories.find(c => c.slug === 'postres')?.id,
    },
    {
      title: 'Gazpacho Andaluz',
      slug: 'gazpacho-andaluz',
      description: 'Refrescante sopa fría de tomate tradicional. Perfecta para el verano.',
      imageUrl: '/images/recipes/gazpacho.png',
      prepTime: 15,
      cookTime: 0,
      totalTime: 15,
      servings: 4,
      difficulty: 'facil',
      cuisineType: 'española',
      mealType: 'almuerzo',
      toolType: 'tradicional',
      isGlutenFree: true,
      categoryId: categories.find(c => c.slug === 'almuerzos')?.id,
    },
    {
      title: 'Pasta Carbonara',
      slug: 'pasta-carbonara',
      description: 'Auténtica pasta carbonara italiana con guanciale. Un clásico de la cocina romana.',
      imageUrl: '/images/recipes/carbonara.png',
      prepTime: 10,
      cookTime: 20,
      totalTime: 30,
      servings: 4,
      difficulty: 'medio',
      cuisineType: 'italiana',
      mealType: 'cena',
      toolType: 'tradicional',
      isGlutenFree: false,
      categoryId: categories.find(c => c.slug === 'cenas')?.id,
    },
    {
      title: 'Desayuno Completo',
      slug: 'desayuno-completo',
      description: 'Un desayuno nutritivo con croissants, frutas y café. La mejor forma de empezar el día.',
      imageUrl: '/images/recipes/breakfast.png',
      prepTime: 10,
      cookTime: 15,
      totalTime: 25,
      servings: 2,
      difficulty: 'facil',
      cuisineType: 'internacional',
      mealType: 'desayuno',
      toolType: 'tradicional',
      isGlutenFree: false,
      categoryId: categories.find(c => c.slug === 'desayunos')?.id,
    },
    {
      title: 'Alitas de Pollo Crujientes',
      slug: 'alitas-pollo-crujientes',
      description: 'Alitas de pollo doradas y crujientes con especias. Perfectas para compartir.',
      imageUrl: '/images/recipes/chicken-wings.png',
      prepTime: 20,
      cookTime: 30,
      totalTime: 50,
      servings: 4,
      difficulty: 'facil',
      cuisineType: 'americana',
      mealType: 'cena',
      toolType: 'tradicional',
      isGlutenFree: false,
      categoryId: categories.find(c => c.slug === 'cenas')?.id,
    },
  ]

  for (const recipeData of recipesData) {
    const existingRecipe = await db.recipe.findUnique({
      where: { slug: recipeData.slug },
    })

    if (!existingRecipe) {
      const recipe = await db.recipe.create({
        data: recipeData,
      })

      // Añadir etiquetas
      const tagNames = recipeData.isGlutenFree ? ['Sin Gluten', 'Tradicional'] : ['Tradicional']
      for (const tagName of tagNames) {
        const tag = tags.find(t => t.name === tagName)
        if (tag) {
          await db.recipeTag.create({
            data: { recipeId: recipe.id, tagId: tag.id },
          })
        }
      }
    }
  }
  console.log(`✅ Creadas ${recipesData.length} recetas de ejemplo`)

  // Crear temporizadores predefinidos
  const timerPresets = [
    { name: 'Hervir agua', duration: 5 * 60, isDefault: true },
    { name: 'Huevo duro', duration: 10 * 60, isDefault: true },
    { name: 'Arroz', duration: 20 * 60, isDefault: true },
    { name: 'Pasta', duration: 12 * 60, isDefault: true },
    { name: 'Carne al horno', duration: 45 * 60, isDefault: true },
    { name: 'Galletas', duration: 15 * 60, isDefault: true },
  ]

  for (const preset of timerPresets) {
    await db.timerPreset.upsert({
      where: { name: preset.name },
      update: {},
      create: preset,
    })
  }
  console.log(`✅ Creados ${timerPresets.length} temporizadores predefinidos`)

  console.log('🎉 Seed completado exitosamente!')
}

seed()
  .catch((e) => {
    console.error('❌ Error en seed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
