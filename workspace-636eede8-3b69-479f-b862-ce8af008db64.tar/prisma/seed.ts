// Script para generar 2000 recetas únicas (1000 tradicionales + 1000 Thermomix)
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// ==================== DATOS BASE ====================

const CATEGORIAS = ['entrantes', 'primeros', 'segundos', 'postres', 'bebidas', 'salsas'];
const DIFICULTADES = ['facil', 'medio', 'dificil'];
const COCINAS = [
  'espanola', 'italiana', 'mexicana', 'francesa', 'china', 'japonesa', 'india', 
  'arabe', 'griega', 'peruana', 'argentina', 'colombiana', 'venezolana',
  'alemana', 'britanica', 'rusa', 'tailandesa', 'vietnamita', 'coreana', 'turca'
];

const INGREDIENTES_BASE = {
  vegetales: ['tomate', 'cebolla', 'ajo', 'pimiento', 'zanahoria', 'patata', 'calabacin', 'berenjena', 'espinacas', 'acelgas', 'guisantes', 'judias verdes', 'coliflor', 'brocoli', 'lechuga', 'pepino', 'apio', 'puerro', 'cebollino', 'perejil', 'cilantro', 'albahaca', 'oregano', 'romero', 'tomillo', 'menta', 'eneldo', 'hinojo'],
  carnes: ['pollo', 'ternera', 'cerdo', 'cordero', 'conejo', 'pavo', 'pato', 'codorniz', 'perdiz', 'liebre', 'ciervo', 'jabali'],
  embutidos: ['jamon serrano', 'jamon iberico', 'bacon', 'chorizo', 'salchichon', 'morcilla', 'lomo embuchado', 'fuete', 'sobrasada', 'botillo'],
  pescados: ['merluza', 'bacalao', 'salmon', 'atun', 'sardinas', 'boquerones', 'calamares', 'gambas', 'langostinos', 'mejillones', 'almejas', 'pulpo', 'sepia', 'rape', 'lenguado', 'dorada', 'lubina', 'besugo', 'caballa', 'bonito'],
  lacteos: ['leche', 'nata', 'queso', 'yogur', 'mantequilla', 'requeson', 'cuajada', 'crema de leche', 'mozzarella', 'parmesano', 'gorgonzola', 'camembert', 'brie', 'feta', 'ricotta', 'queso de cabra', 'queso azul'],
  cereales: ['arroz', 'pasta', 'pan', 'harina de trigo', 'harina de maiz', 'avena', 'maiz', 'trigo', 'cuscus', 'quinoa', 'bulgur', 'semola'],
  frutas: ['manzana', 'pera', 'platano', 'naranja', 'limon', 'lima', 'fresa', 'frambuesa', 'arandano', 'uva', 'melon', 'sandia', 'piña', 'mango', 'papaya', 'ciruela', 'melocoton', 'albaricoque', 'cereza', 'granada', 'higo', 'datil', 'uva pasa'],
  especias: ['sal', 'pimienta negra', 'pimienta blanca', 'pimenton dulce', 'pimenton picante', 'azafran', 'canela', 'comino', 'clavo', 'nuez moscada', 'jengibre', 'curcuma', 'cardamomo', 'anis', 'pimienta de cayena', 'paprika', 'curry'],
  aceites: ['aceite de oliva virgen', 'aceite de oliva', 'aceite de girasol', 'aceite de coco'],
  legumbres: ['garbanzos', 'lentejas', 'alubias blancas', 'alubias rojas', 'habas', 'guisantes secos', 'soja'],
  frutos_secos: ['almendra', 'nuez', 'avellana', 'pistacho', 'piñones', 'cacahuete', 'pistacho', 'anacardo'],
  condimentos: ['vinagre de vino', 'vinagre de manzana', 'salsa de soja', 'mostaza', 'mayonesa', 'miel', 'azucar', 'azucar moreno', 'vino blanco', 'vino tinto', 'cerveza', 'brandy', 'jerez']
};

// Imágenes por cocina y categoría usando Unsplash con IDs específicos
const IMAGENES_POR_COCINA_Y_CATEGORIA: Record<string, Record<string, string[]>> = {
  espanola: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Jamón
      'https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&auto=format&fit=crop', // Aceitunas
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Queso
    ],
    primeros: [
      'https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?w=800&auto=format&fit=crop', // Gazpacho
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Sopa
      'https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?w=800&auto=format&fit=crop', // Pasta
    ],
    segundos: [
      'https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=800&auto=format&fit=crop', // Paella
      'https://images.unsplash.com/photo-1518492104633-130d0cc84637?w=800&auto=format&fit=crop', // Pollo
      'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&auto=format&fit=crop', // Carne
      'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop', // Cerdo
    ],
    postres: [
      'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=800&auto=format&fit=crop', // Postre
      'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&auto=format&fit=crop', // Tarta
      'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&auto=format&fit=crop', // Crema
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=800&auto=format&fit=crop', // Vino
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Café
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Salsa
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Pesto
    ],
  },
  italiana: {
    entrantes: [
      'https://images.unsplash.com/photo-1572695157366-5e585ab2b69f?w=800&auto=format&fit=crop', // Bruschetta
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Antipasto
    ],
    primeros: [
      'https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=800&auto=format&fit=crop', // Pasta
      'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?w=800&auto=format&fit=crop', // Spaghetti
      'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&auto=format&fit=crop', // Risotto
    ],
    segundos: [
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Pizza
      'https://images.unsplash.com/photo-1432139555190-58524dae6a55?w=800&auto=format&fit=crop', // Lasagna
      'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop', // Carne
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Tiramisu
      'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=800&auto=format&fit=crop', // Panna cotta
      'https://images.unsplash.com/photo-1562440499-64c9a111f713?w=800&auto=format&fit=crop', // Gelato
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Espresso
      'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=800&auto=format&fit=crop', // Vino
    ],
    salsas: [
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Pesto
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Salsa tomate
    ],
  },
  mexicana: {
    entrantes: [
      'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&auto=format&fit=crop', // Guacamole
      'https://images.unsplash.com/photo-1559847844-5315695dadae?w=800&auto=format&fit=crop', // Nachos
      'https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&auto=format&fit=crop', // Queso
    ],
    primeros: [
      'https://images.unsplash.com/photo-1613514785940-daed07799d9b?w=800&auto=format&fit=crop', // Sopa tortilla
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Sopa
    ],
    segundos: [
      'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&auto=format&fit=crop', // Tacos
      'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=800&auto=format&fit=crop', // Burrito
      'https://images.unsplash.com/photo-1582234372722-50d7ccc30ebd?w=800&auto=format&fit=crop', // Enchiladas
      'https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?w=800&auto=format&fit=crop', // Fajitas
    ],
    postres: [
      'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=800&auto=format&fit=crop', // Churros
      'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&auto=format&fit=crop', // Tres leches
      'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&auto=format&fit=crop', // Flan
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Margarita
      'https://images.unsplash.com/photo-1541687192681-4d1bdd04f241?w=800&auto=format&fit=crop', // Horchata
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Salsa
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Mole
    ],
  },
  francesa: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Foie gras
      'https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&auto=format&fit=crop', // Escargots
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Soupe à l'oignon
      'https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?w=800&auto=format&fit=crop', // Bouillabaisse
    ],
    segundos: [
      'https://images.unsplash.com/photo-1432139555190-58524dae6a55?w=800&auto=format&fit=crop', // Coq au vin
      'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop', // Ratatouille
      'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&auto=format&fit=crop', // Steak
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Crème brûlée
      'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=800&auto=format&fit=crop', // Macarons
      'https://images.unsplash.com/photo-1562440499-64c9a111f713?w=800&auto=format&fit=crop', // Éclair
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=800&auto=format&fit=crop', // Champagne
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Café
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Salsa
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Beurre blanc
    ],
  },
  china: {
    entrantes: [
      'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=800&auto=format&fit=crop', // Dim sum
      'https://images.unsplash.com/photo-1606491956689-2ea866880c84?w=800&auto=format&fit=crop', // Spring rolls
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Wonton soup
      'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop', // Hot pot
    ],
    segundos: [
      'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=800&auto=format&fit=crop', // Fried rice
      'https://images.unsplash.com/photo-1525755662778-989d0524087e?w=800&auto=format&fit=crop', // Noodles
      'https://images.unsplash.com/photo-1529694157872-4e0c0f3b238b?w=800&auto=format&fit=crop', // Pato
    ],
    postres: [
      'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=800&auto=format&fit=crop', // Mooncake
      'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&auto=format&fit=crop', // Tangyuan
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Té
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Bubble tea
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Soy sauce
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Hoisin
    ],
  },
  japonesa: {
    entrantes: [
      'https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=800&auto=format&fit=crop', // Edamame
      'https://images.unsplash.com/photo-1579877447354-0f8f6d6deffa?w=800&auto=format&fit=crop', // Gyoza
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Miso soup
      'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&auto=format&fit=crop', // Ramen
    ],
    segundos: [
      'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=800&auto=format&fit=crop', // Sushi
      'https://images.unsplash.com/photo-1617196034796-73dfa7b1fd56?w=800&auto=format&fit=crop', // Tempura
      'https://images.unsplash.com/photo-1555126634-323283e090fa?w=800&auto=format&fit=crop', // Teriyaki
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Mochi
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Dorayaki
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Matcha
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Sake
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Soy sauce
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Wasabi
    ],
  },
  india: {
    entrantes: [
      'https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop', // Samosas
      'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=800&auto=format&fit=crop', // Pakora
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Dal
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Curry
    ],
    segundos: [
      'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=800&auto=format&fit=crop', // Biryani
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Butter chicken
      'https://images.unsplash.com/photo-1574653853027-5382a3d23a15?w=800&auto=format&fit=crop', // Tandoori
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Gulab jamun
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Kheer
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Chai
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Lassi
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Chutney
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Raita
    ],
  },
  arabe: {
    entrantes: [
      'https://images.unsplash.com/photo-1546793665-c74683a33fb4?w=800&auto=format&fit=crop', // Hummus
      'https://images.unsplash.com/photo-1593001874117-c99c800e3eb7?w=800&auto=format&fit=crop', // Falafel
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Lentil soup
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Harira
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Shawarma
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Kebab
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Mansaf
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Baklava
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Kunafa
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Mint tea
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Arabic coffee
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Tahini
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Garlic sauce
    ],
  },
  griega: {
    entrantes: [
      'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=800&auto=format&fit=crop', // Greek salad
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Tzatziki
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Avgolemono
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Lentil soup
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Gyros
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Souvlaki
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Moussaka
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Baklava
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Galaktoboureko
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Ouzo
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Frappé
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Tzatziki
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Taramasalata
    ],
  },
  peruana: {
    entrantes: [
      'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&auto=format&fit=crop', // Ceviche
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Causa
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Chupe
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Sopa
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Lomo saltado
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Aji de gallina
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Arroz con pollo
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Picarones
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Suspiro
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Pisco sour
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Chicha
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Salsa
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Aji
    ],
  },
  argentina: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Empanadas
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Provoleta
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Locro
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Sopa
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Asado
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Milanesa
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Choripán
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Dulce de leche
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Alfajores
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Malbec
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Mate
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Chimichurri
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Salsa
    ],
  },
  colombiana: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Arepa
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Empanadas
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Ajiaco
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Sancocho
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Bandeja paisa
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Lechona
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Carne asada
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Postre de natas
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Tres leches
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Aguapanela
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Jugo
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Hogao
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Aji
    ],
  },
  venezolana: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Tequeños
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Arepa
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Sopa
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Mondongo
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Pabellón
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Cachapa
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Asado negro
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Quesillo
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Bienmesabe
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Papelón
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Chicha
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Guasacaca
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Salsa
    ],
  },
  alemana: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Pretzel
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Brezel
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Kartoffelsuppe
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Eintopf
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Bratwurst
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Schnitzel
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Schweinshaxe
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Apfelstrudel
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Schwarzwälder
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Bier
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Glühwein
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Senf
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Curry ketchup
    ],
  },
  britanica: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Scotch egg
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Pasty
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Soup
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Broth
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Fish and chips
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Roast beef
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Shepherd's pie
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Trifle
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Crumble
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Tea
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Ale
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Gravy
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Mint sauce
    ],
  },
  rusa: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Caviar
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Blini
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Borscht
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Solyanka
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Beef stroganoff
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Pelmeni
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Chicken Kiev
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Medovik
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Pryaniki
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Vodka
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Kvass
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Smetana
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Sauce
    ],
  },
  tailandesa: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Spring rolls
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Satay
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Tom yum
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Tom kha
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Pad thai
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Green curry
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Red curry
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Mango sticky rice
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Thai tea
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Thai iced tea
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Coconut shake
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Nam chim
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Sriracha
    ],
  },
  vietnamita: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Summer rolls
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Spring rolls
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Pho
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Bun bo
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Banh mi
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Bun cha
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Com tam
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Che
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Banh flan
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Ca phe sua da
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Sinh to
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Nuoc cham
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Hoisin
    ],
  },
  coreana: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Kimchi
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Pajeon
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Kimchi jjigae
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Doenjang
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Bibimbap
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Bulgogi
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Korean BBQ
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Bingsu
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Hotteok
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Soju
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Makgeolli
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Gochujang
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Ssamjang
    ],
  },
  turca: {
    entrantes: [
      'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop', // Meze
      'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop', // Dolma
    ],
    primeros: [
      'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop', // Soup
      'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&auto=format&fit=crop', // Lentil soup
    ],
    segundos: [
      'https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=800&auto=format&fit=crop', // Kebab
      'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop', // Pide
      'https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?w=800&auto=format&fit=crop', // Lahmacun
    ],
    postres: [
      'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop', // Baklava
      'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop', // Kunafa
    ],
    bebidas: [
      'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=800&auto=format&fit=crop', // Turkish tea
      'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop', // Turkish coffee
    ],
    salsas: [
      'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop', // Cacik
      'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop', // Haydari
    ],
  },
};

// Imágenes por categoría (fallback)
const IMAGENES_POR_CATEGORIA: Record<string, string[]> = {
  entrantes: [
    'https://images.unsplash.com/photo-1541014741259-de529411b96a?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1626200419199-391ae4be7a41?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&auto=format&fit=crop',
  ],
  primeros: [
    'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?w=800&auto=format&fit=crop',
  ],
  segundos: [
    'https://images.unsplash.com/photo-1432139555190-58524dae6a55?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1518492104633-130d0cc84637?w=800&auto=format&fit=crop',
  ],
  postres: [
    'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=800&auto=format&fit=crop',
  ],
  bebidas: [
    'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1534353473418-4cfa6c56fd38?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1541687192681-4d1bdd04f241?w=800&auto=format&fit=crop',
  ],
  salsas: [
    'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1585325701165-351af917e782?w=800&auto=format&fit=crop',
  ],
};

// Nombres únicos de recetas por cocina
const NOMBRES_RECETAS: Record<string, string[]> = {
  espanola: [
    'Paella Valenciana', 'Gazpacho Andaluz', 'Tortilla de Patatas', 'Cocido Madrileno', 'Fabada Asturiana',
    'Pulpo a la Gallega', 'Marmitako de Atun', 'Lechazo al Horno', 'Gambas al Ajillo', 'Patatas Bravas',
    'Croquetas de Jamon', 'Ensaladilla Rusa', 'Huevos Rotos con Jamon', 'Callos a la Madrilena', 'Migas Extremeñas',
    'Bacalao al Pil Pil', 'Rape a la Vizcaina', 'Chuletillas de Cordero', 'Cochinillo Asado', 'Morcilla de Burgos',
    'Cecina de Leon', 'Botillo Elbano', 'Pote Gallego', 'Lacon con Grelos', 'Empanada Gallega',
    'Pimientos de Padron', 'Filloas Gallegas', 'Esqueixada Catalana', 'Escudella Carn d\'Olla', 'Canalones a la Catalana',
    'Fidea de Marisco', 'Arroz con Costra', 'Gachas Manchegas', 'Pisto Manchego', 'Asadillo Manchego',
    'Atascaburras Manchego', 'Morteruelo Cuenca', 'Galianos Albacete', 'Tiznao Ciudad Real', 'Gachas de Pastor',
    'Perdiz Escabechada', 'Liebre a la Royal', 'Guiso de Caza', 'Chuleton de Avila', 'Judiones de la Granja',
    'Pinchos Morunos', 'Zorongollo Extremeño', 'Ajoarriero Navarro', 'Menestra de Verduras', 'Cardo con Almendras'
  ],
  italiana: [
    'Pizza Margherita Napoletana', 'Pasta alla Carbonara', 'Risotto alla Milanese', 'Lasagna alla Bolognese', 'Tiramisu Classico',
    'Bruschetta al Pomodoro', 'Carpaccio di Manzo', 'Minestrone della Nonna', 'Osso Buco alla Milanese', 'Saltimbocca alla Romana',
    'Polenta con Funghi', 'Gnocchi al Pesto Genovese', 'Caponata Siciliana', 'Arancini di Riso', 'Panna Cotta con Frutti di Bosco',
    'Cannoli Siciliani', 'Focaccia Genovese', 'Calzone Napoletano', 'Ravioli di Ricotta', 'Tortellini in Brodo',
    'Spaghetti alla Bolognese', 'Penne all\'Arrabbiata', 'Fettuccine Alfredo', 'Rigatoni al Forno', 'Linguine alle Vongole',
    'Ossobuco con Polenta', 'Cotoletta alla Milanese', 'Vitello Tonnato', 'Bresaola con Rucola', 'Prosciutto di Parma con Melone',
    'Mozzarella di Bufala', 'Burrata con Prosciutto', 'Pesto alla Genovese', 'Salsa Bolognese', 'Pasta alla Puttanesca',
    'Bucatini all\'Amatriciana', 'Spaghetti Cacio e Pepe', 'Bucatini alla Gricia', 'Pasta alla Norma', 'Pasta alla Boscaiola',
    'Pasta Pomodoro e Basilico', 'Pasta Quattro Formaggi', 'Pasta con Salmone', 'Pasta con Gamberetti', 'Pasta ai Funghi Porcini',
    'Tagliatelle al Tartufo', 'Risotto ai Funghi', 'Risotto al Nero di Seppia', 'Risotto agli Scampi', 'Risotto con Zafferano'
  ],
  mexicana: [
    'Tacos al Pastor', 'Guacamole Tradicional', 'Enchiladas Verdes', 'Quesadillas de Queso', 'Pozole Rojo',
    'Mole Poblano', 'Chiles en Nogada', 'Tamales de Cerdo', 'Cochinita Pibil', 'Ceviche de Camaron',
    'Tostadas de Tinga', 'Nachos con Queso', 'Fajitas de Pollo', 'Burritos de Carne', 'Huevos Rancheros',
    'Chilaquiles Verdes', 'Sopes con Carne', 'Gorditas de Chicharron', 'Huaraches con Frijoles', 'Flautas de Pollo',
    'Tacos de Carne Asada', 'Tacos de Pescado', 'Tacos de Birria', 'Tacos de Carnitas', 'Tacos de Suadero',
    'Pambazos de Papa', 'Cemita Poblana', 'Torta Cubana', 'Torta de Milanesa', 'Queso Fundido con Chorizo',
    'Esquites con Mayonesa', 'Elotes con Chile', 'Nopales a la Mexicana', 'Flor de Calabaza', 'Huitlacoche con Huevo',
    'Sopa de Tortilla', 'Sopa de Frijol', 'Sopa de Lima', 'Sopa de Mariscos', 'Sopa Azteca',
    'Arroz con Leche Mexicano', 'Flan Napolitano', 'Churros con Chocolate', 'Buñuelos de Viento', 'Capirotada Cuaresmeña',
    'Pastel Tres Leches', 'Carlota de Limon', 'Gelatina de Mosaico', 'Nieve de Garrafa', 'Paletas de Frutas'
  ],
  francesa: [
    'Coq au Vin', 'Ratatouille Nicoise', 'Bouillabaisse Marsellense', 'Boeuf Bourguignon', 'Quiche Lorraine',
    'Croissant au Beurre', 'Baguette Tradition', 'Soupe a l\'Oignon', 'Escargots de Bourgogne', 'Foie Gras Maison',
    'Creme Brulee', 'Mille-Feuille', 'Eclair au Chocolat', 'Macarons Parisienses', 'Souffle au Chocolat',
    'Cassoulet Toulousain', 'Confit de Canard', 'Magret de Canard', 'Steak Tartare', 'Steak Frites',
    'Pot-au-Feu', 'Blanquette de Veau', 'Navarin d\'Agneau', 'Lapin a la Moutarde', 'Poulet Basquaise',
    'Pissaladiere Nizarda', 'Tian de Legumes', 'Salade Nicoise', 'Salade de Chevre Chaud', 'Croque Monsieur',
    'Croque Madame', 'Pain au Chocolat', 'Brioche Parisienne', 'Pain de Campagne', 'Fougasse Provenzal',
    'Profiteroles', 'Paris-Brest', 'Opera Gateau', 'Saint-Honore', 'Tarte Tatin',
    'Clafoutis aux Cerises', 'Fondant au Chocolat', 'Ile Flottante', 'Peche Melba', 'Poire Belle Helene',
    'Galette Bretonne', 'Crepes Suzette', 'Crepes Normandes', 'Kouign-Amann', 'Far Breton'
  ],
  china: [
    'Arroz Frito Cantones', 'Pollo Kung Pao', 'Cerdo Agridulce', 'Rollitos de Primavera', 'Dim Sum Variados',
    'Pato Pekin', 'Mapo Tofu', 'Sopa de Wonton', 'Hot Pot Sichuan', 'Xiao Long Bao',
    'Chow Mein', 'Fideos de Arroz con Carne', 'Pollo al Limon', 'Cerdo Char Siu', 'Costillas BBQ Chinas',
    'Sopa de Maiz con Pollo', 'Sopa de Aleta de Tiburon', 'Tofu Salteado con Verduras', 'Berenjena con Ajo', 'Pescado al Vapor',
    'Langostinos con Te', 'Bollos al Vapor', 'Panecillos Mantou', 'Jiaozi de Cerdo', 'Pollo con Anacardos',
    'Ternera con Cebolleta', 'Cerdo con Judias Verdes', 'Pescado Agridulce', 'Pulpo con Chile', 'Calamares Salteados',
    'Mejillones al Vapor', 'Almejas con Judias Negras', 'Gambas al Ajillo Chino', 'Tarta de Huevo', 'Bolas de Sesamo',
    'Pastel de Luna', 'Bolas de Arroz Glutinoso', 'Gelatina de Mango', 'Tofu con Leche de Soja', 'Te Verde con Leche'
  ],
  japonesa: [
    'Sushi Variado', 'Sashimi Fresco', 'Ramen de Cerdo', 'Tempura de Langostinos', 'Pollo Teriyaki',
    'Miso Soup', 'Udon con Verduras', 'Soba Fria', 'Onigiri de Salmon', 'Gyoza al Vapor',
    'Yakitori de Pollo', 'Okonomiyaki', 'Takoyaki', 'Katsu Curry', 'Tonkatsu',
    'Unagi Don', 'Katsudon', 'Oyakodon', 'Gyudon', 'Kaisendon',
    'Edamame con Sal', 'Hiyayakko Tofu', 'Tamagoyaki', 'Sunomono de Pepino', 'Tsukemono',
    'Sukiyaki', 'Shabu-Shabu', 'Nabe de Invierno', 'Oden', 'Yosenabe',
    'Mochi de Te Verde', 'Dorayaki', 'Taiyaki de Crema', 'Anko Dulce', 'Matcha Ice Cream',
    'Wagashi Tradicional', 'Daifuku de Fresa', 'Dango con Miel', 'Yokan de Frijoles', 'Melon Pan'
  ],
  india: [
    'Butter Chicken', 'Biryani de Cordero', 'Chicken Tikka Masala', 'Samosas de Verduras', 'Naan al Horno',
    'Dal Makhani', 'Palak Paneer', 'Tandoori Chicken', 'Vindaloo de Cerdo', 'Korma de Pollo',
    'Rogan Josh', 'Chana Masala', 'Aloo Gobi', 'Malai Kofta', 'Paneer Tikka',
    'Dosa con Chutney', 'Idli con Sambar', 'Vada Frita', 'Batura con Chole', 'Paratha con Mantequilla',
    'Raita de Pepino', 'Chutney de Mango', 'Chutney de Coco', 'Pickle de Mango', 'Papadum Crujiente',
    'Pakora de Verduras', 'Bhaji de Cebolla', 'Kati Roll', 'Pani Puri', 'Bhel Puri',
    'Gulab Jamun', 'Kheer de Arroz', 'Rasgulla', 'Jalebi Crujiente', 'Ladoo de Coco',
    'Barfi de Almendras', 'Kulfi de Pistacho', 'Falooda con Fideos', 'Lassi de Mango', 'Masala Chai'
  ],
  arabe: [
    'Hummus con Pan', 'Falafel Frito', 'Shawarma de Cordero', 'Kebab de Carne', 'Baklava con Miel',
    'Tabbouleh', 'Baba Ganoush', 'Kibbeh Frito', 'Fatayer de Espinacas', 'Manakish con Queso',
    'Fattoush', 'Muhammara', 'Labneh con Aceite', 'Foul Medames', 'Mujadara con Yogur',
    'Mansaf Jordano', 'Machboos Kuwaiti', 'Kabsa Saudita', 'Mandi Yemeni', 'Haneeth de Cordero',
    'Sambousek de Carne', 'Fatayer de Queso', 'Arayes con Carne', 'Kafta a la Parrilla', 'Shish Tawook',
    'Shish Kebab', 'Adana Kebab', 'Doner Kebab', 'Iskender con Yogur', 'Testi Kebab Turco',
    'Kunafa con Queso', 'Basbousa de Coco', 'Umm Ali Egipcio', 'Maamoul con Datiles', 'Date Maamoul'
  ],
  griega: [
    'Moussaka con Carne', 'Souvlaki de Cerdo', 'Gyros con Tzatziki', 'Tzatziki Casero', 'Horiatiki Salata',
    'Spanakopita', 'Tiropita de Queso', 'Dolmades con Arroz', 'Pastitsio al Horno', 'Stifado de Ternera',
    'Saganaki Frito', 'Keftedes con Yogur', 'Taramasalata', 'Fasolada con Pan', 'Avgolemono',
    'Lemonato de Pollo', 'Briam al Horno', 'Gemista con Arroz', 'Kleftiko de Cordero', 'Kotosoupa Avgolemono',
    'Baklava con Miel', 'Galaktoboureko', 'Loukoumades con Miel', 'Kataifi con Nueces', 'Ravani de Sémola',
    'Melomakarona', 'Kourabiedes', 'Diples de Miel', 'Halva con Nueces', 'Bougatsa de Crema'
  ],
  peruana: [
    'Ceviche de Pescado', 'Lomo Saltado', 'Aji de Gallina', 'Causa Limeña', 'Anticuchos de Corazon',
    'Papa a la Huancaina', 'Rocoto Relleno', 'Arroz con Pollo', 'Tallarines Verdes', 'Seco de Res',
    'Carapulcra con Chancho', 'Pachamanca Criolla', 'Tacu Tacu', 'Chicharron de Cerdo', 'Lechon al Horno',
    'Arroz con Mariscos', 'Jalea de Pescado', 'Parihuela de Mariscos', 'Tiradito de Pescado', 'Chupe de Camarones',
    'Picarones con Miel', 'Suspiro a la Limeña', 'Arroz con Leche', 'Mazamorra Morada', 'Turron de Doña Pepa'
  ],
  argentina: [
    'Asado de Tira', 'Empanadas de Carne', 'Milanesa de Ternera', 'Locro Criollo', 'Choripan con Chimichurri',
    'Matambre a la Pizza', 'Provoleta con Oregano', 'Humita en Chala', 'Carbonada en Zapallo', 'Pastel de Papa',
    'Pollo al Disco', 'Cordero Patagonico', 'Chivito al Asador', 'Parrillada Completa', 'Vacio con Sal',
    'Dulce de Leche', 'Alfajores de Maicena', 'Facturas de Panaderia', 'Churros con Chocolate', 'Pastelitos de Membrillo'
  ],
  colombiana: [
    'Bandeja Paisa', 'Arepas de Queso', 'Sancocho de Gallina', 'Lechona Tolimense', 'Empanadas Colombianas',
    'Ajiaco Santafereño', 'Tamales Colombianos', 'Cazuela de Mariscos', 'Mojarra Frita', 'Carne Desmechada',
    'Patacones con Hogao', 'Papa Salada', 'Huevos Pericos', 'Caldo de Costilla', 'Changua con Pan',
    'Arroz con Coco', 'Posta Negra Cartagenera', 'Carimañolas de Yuca', 'Aborrajados de Platano', 'Cholados Caleños'
  ],
  venezolana: [
    'Arepa Rellena', 'Pabellon Criollo', 'Cachapa con Queso', 'Tequeños de Queso', 'Hallaca Navideña',
    'Asado Negro', 'Patacon de Plátano', 'Empanada de Carne', 'Pelua con Queso', 'Reina Pepiada',
    'Domino con Queso', 'Catira de Pollo', 'Perico Revuelto', 'Huevos Motuleños', 'Caraotas Negras',
    'Arroz con Pollo', 'Chicharron Criollo', 'Mondongo Venezolano', 'Sancocho de Pescado', 'Quesillo de Coco'
  ],
  alemana: [
    'Bratwurst con Chucrut', 'Sauerbraten de Ternera', 'Schnitzel de Cerdo', 'Pretzel con Mantequilla', 'Sauerkraut con Salchichas',
    'Spaetzle con Queso', 'Kartoffelsalat', 'Schweinshaxe Asado', 'Rouladen de Ternera', 'Maultaschen con Mantequilla',
    'Currywurst con Salsa', 'Frikadellen', 'Eintopf de Verduras', 'Gruenkohl con Salchicha', 'Labskaus del Norte',
    'Apfelstrudel', 'Schwarzwälder Kirschtorte', 'Stollen Navideño', 'Lebkuchen', 'Berliner Pfannkuchen'
  ],
  britanica: [
    'Fish and Chips', 'Shepherds Pie', 'Bangers and Mash', 'Roast Beef con Yorkshire', 'Yorkshire Pudding',
    'Full English Breakfast', 'Chicken Tikka Masala', 'Cornish Pasty', 'Scotch Egg', 'Welsh Rarebit',
    'Steak and Kidney Pie', 'Cottage Pie de Cordero', 'Toad in the Hole', 'Ploughmans Lunch', 'Lancashire Hotpot',
    'Trifle de Frutas', 'Sticky Toffee Pudding', 'Scones con Crema', 'Victoria Sponge', 'Apple Crumble'
  ],
  rusa: [
    'Borscht con Nata', 'Beef Stroganoff', 'Pelmeni de Carne', 'Blini con Caviar', 'Caviar con Crema',
    'Olivier Salad', 'Chicken Kiev', 'Shashlik de Cerdo', 'Golubtsy de Col', 'Kasha con Setas',
    'Pirozhki de Col', 'Varenyky de Patata', 'Solyanka de Carne', 'Okroshka Fria', 'Kholodets de Cerdo',
    'Medovik de Miel', 'Ptichye Moloko', 'Pryaniki con Miel', 'Kulich Pascual', 'Paskha de Cuajada'
  ],
  tailandesa: [
    'Pad Thai con Gambas', 'Tom Yum Goong', 'Green Curry de Pollo', 'Red Curry de Ternera', 'Massaman Curry de Cordero',
    'Som Tam Thai', 'Khao Pad con Pollo', 'Pad See Ew', 'Laab de Cerdo', 'Satay de Pollo',
    'Spring Rolls Thai', 'Tom Kha Gai', 'Panang Curry', 'Yellow Curry de Pato', 'Pineapple Fried Rice',
    'Mango Sticky Rice', 'Thai Tea Frio', 'Coconut Ice Cream', 'Khanom Tom', 'Tub Tim Krob'
  ],
  vietnamita: [
    'Pho Bo de Ternera', 'Banh Mi de Cerdo', 'Spring Rolls Vietnamese', 'Summer Rolls Fresco', 'Bun Cha de Cerdo',
    'Cao Lau de Fideos', 'Com Tam con Cerdo', 'Banh Xeo de Camarones', 'Hu Tieu Nam Vang', 'Mi Quang de Pollo',
    'Cha Ca de Pescado', 'Banh Cuon de Cerdo', 'Goj Cuon Fresco', 'Chao Long de Cerdo', 'Bun Bo Hue',
    'Banh Flan Vietnamita', 'Che de Frijoles', 'Ca Phe Sua Da', 'Banh Cam de Sesamo', 'Banh Ran de Frijoles'
  ],
  coreana: [
    'Kimchi Tradicional', 'Bibimbap de Verduras', 'Bulgogi de Ternera', 'Korean BBQ de Cerdo', 'Japchae de Fideos',
    'Tteokbokki Picante', 'Samgyeopsal Asado', 'Korean Fried Chicken', 'Sundubu Jjigae', 'Kimchi Jjigae',
    'Doenjang Jjigae', 'Pajeon de Cebolleta', 'Jjajangmyeon', 'Kimbap de Verduras', 'Korean Corn Dog',
    'Hotteok de Miel', 'Bingsu de Patata', 'Songpyeon de Arroz', 'Yakgwa con Miel', 'Dasik de Te'
  ],
  turca: [
    'Kebab de Adana', 'Baklava con Pistachos', 'Pide Turco', 'Lahmacun de Carne', 'Meze Turco',
    'Doner Kebab', 'Kofte de Ternera', 'Manti de Carne', 'Menemen de Huevos', 'Imam Bayildi',
    'Sis Kebab de Cordero', 'Adana Kebab Picante', 'Iskender con Yogur', 'Cag Kebab', 'Testi Kebab Cappadocia',
    'Kunefe con Queso', 'Turkish Delight', 'Sutlac de Arroz', 'Kazandibi con Caramelo', 'Tavuk Gogsu'
  ]
};

// Funciones auxiliares determinísticas basadas en índice
function getElementByIndex<T>(arr: T[], index: number): T {
  return arr[index % arr.length];
}

function getIntByIndex(min: number, max: number, seed: number): number {
  // Usar una fórmula determinística
  const range = max - min + 1;
  return min + (seed * 7919) % range;
}

function shuffleArraySeeded<T>(arr: T[], seed: number): T[] {
  const newArr = [...arr];
  // Usar una permutación determinística basada en seed
  for (let i = newArr.length - 1; i > 0; i--) {
    const j = Math.abs((seed * (i + 1) * 31) % (i + 1));
    [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
  }
  return newArr;
}

function generarIngredientes(categoria: string, cocina: string, seed: number): { nombre: string; cantidad: number; unidad: string }[] {
  const ingredientes: { nombre: string; cantidad: number; unidad: string }[] = [];
  const numIngredientes = 5 + (seed % 10); // 5-14 ingredientes
  
  const todosIngredientes = [
    ...INGREDIENTES_BASE.vegetales,
    ...INGREDIENTES_BASE.carnes,
    ...INGREDIENTES_BASE.pescados,
    ...INGREDIENTES_BASE.lacteos,
    ...INGREDIENTES_BASE.cereales,
    ...INGREDIENTES_BASE.frutas,
    ...INGREDIENTES_BASE.especias,
    ...INGREDIENTES_BASE.legumbres,
    ...INGREDIENTES_BASE.frutos_secos,
    ...INGREDIENTES_BASE.condimentos,
  ];
  
  const seleccionados = shuffleArraySeeded(todosIngredientes, seed).slice(0, numIngredientes);
  
  const unidades = ['g', 'kg', 'ml', 'l', 'unidad', 'cucharada', 'cucharadita', 'rama', 'hoja', 'diente'];
  
  seleccionados.forEach((ing, i) => {
    const cantidad = getIntByIndex(1, 500, seed + i);
    let unidad = getElementByIndex(unidades, seed + i);
    
    if (ing.includes('aceite') || ing.includes('vinagre') || ing.includes('salsa')) {
      unidad = 'ml';
    } else if (ing.includes('carne') || ing.includes('pollo') || ing.includes('pescado') || ing.includes('cerdo') || ing.includes('ternera') || ing.includes('cordero')) {
      unidad = 'g';
    } else if (ing.includes('huevo')) {
      unidad = 'unidad';
    }
    
    ingredientes.push({ nombre: ing, cantidad, unidad });
  });
  
  // Siempre añadir sal y aceite si no están
  if (!ingredientes.find(i => i.nombre === 'sal')) {
    ingredientes.push({ nombre: 'sal', cantidad: 1, unidad: 'cucharadita' });
  }
  if (!ingredientes.find(i => i.nombre.includes('aceite de oliva'))) {
    ingredientes.push({ nombre: 'aceite de oliva virgen', cantidad: 3, unidad: 'cucharadas' });
  }
  
  return ingredientes;
}

function generarPasos(ingredientes: { nombre: string; cantidad: number; unidad: string }[], esThermomix: boolean, seed: number): { paso: number; descripcion: string; tiempo?: number }[] {
  const pasos: { paso: number; descripcion: string; tiempo?: number }[] = [];
  const numPasos = 5 + (seed % 7); // 5-11 pasos
  
  const accionesBase = [
    'Picar finamente', 'Cortar en trozos', 'Trocear', 'Pelar y trocear', 'Lavar y escurrir', 'Secar con papel',
    'Sofreír a fuego medio', 'Rehogar sin dorar', 'Saltear a fuego alto', 'Freír en abundante aceite', 'Hervir en agua con sal', 'Cocer al vapor',
    'Hornear a temperatura media', 'Asar en el horno', 'Grillar a la plancha', 'Cocer al baño maría', 'Escalfar en agua', 'Pochar lentamente',
    'Mezclar con cuchara', 'Batir hasta integrar', 'Montar a punto de nieve', 'Emulsionar con varillas', 'Integrar con movimiento', 'Incorporar poco a poco',
    'Rectificar de sal', 'Sazonar al gusto', 'Aliñar con aceite', 'Emplatar con estilo', 'Decorar con hierbas', 'Servir inmediatamente'
  ];
  
  const accionesThermomix = [
    'Introducir en el vaso y triturar', 'Programar velocidad progresiva', 'Incorporar por el bocal', 'Mezclar en el vaso', 'Colocar en el cestillo',
    'Programar temperatura y tiempo', 'Triturar a velocidad alta', 'Integrar con espátula', 'Retirar el cubilete', 'Verter en el vaso',
  ];
  
  const tiemposThermomix = [
    { tiempo: 5, velocidad: 'velocidad 1' },
    { tiempo: 8, velocidad: 'velocidad 2' },
    { tiempo: 10, velocidad: 'velocidad 3' },
    { tiempo: 4, velocidad: 'velocidad 4' },
    { tiempo: 6, velocidad: 'velocidad cuchara' },
  ];
  
  for (let i = 0; i < numPasos; i++) {
    let descripcion = '';
    let tiempo = 0;
    
    const ingredienteAleatorio = ingredientes.length > 0 ? getElementByIndex(ingredientes, seed + i).nombre : 'los ingredientes';
    const accion = getElementByIndex(accionesBase, seed + i);
    
    if (esThermomix && i > 0) {
      const configThermomix = getElementByIndex(tiemposThermomix, seed + i);
      const accionTM = getElementByIndex(accionesThermomix, seed + i + 100);
      descripcion = `${accionTM} ${ingredienteAleatorio}. Programar ${configThermomix.tiempo} minutos a ${configThermomix.velocidad}.`;
      tiempo = configThermomix.tiempo;
    } else {
      descripcion = `${accion} ${ingredienteAleatorio}. ${getElementByIndex(['Continuar removiendo', 'Esperar a que dore ligeramente', 'Cocinar a fuego medio durante unos minutos', 'Añadir al resto de ingredientes', 'Reservar para después'], seed + i + 50)}.`;
      tiempo = getIntByIndex(2, 15, seed + i);
    }
    
    pasos.push({ paso: i + 1, descripcion, tiempo });
  }
  
  // Paso final
  pasos.push({
    paso: numPasos + 1,
    descripcion: esThermomix 
      ? 'Servir caliente y disfrutar de esta deliciosa receta preparada con Thermomix.'
      : 'Servir caliente y disfrutar de este plato tradicional.',
    tiempo: 0
  });
  
  return pasos;
}

function generarImagen(categoria: string, cocina: string, seed: number): { principal: string; adicionales: string[] } {
  // Primero intentar usar imágenes específicas de la cocina
  const imagenesCocina = IMAGENES_POR_COCINA_Y_CATEGORIA[cocina];
  let imagenesCategoria: string[];
  
  if (imagenesCocina && imagenesCocina[categoria]) {
    imagenesCategoria = imagenesCocina[categoria];
  } else {
    // Fallback a imágenes por categoría general
    imagenesCategoria = IMAGENES_POR_CATEGORIA[categoria] || IMAGENES_POR_CATEGORIA['primeros'];
  }
  
  const principal = getElementByIndex(imagenesCategoria, seed);
  const adicionales = shuffleArraySeeded(imagenesCategoria, seed + 100).slice(0, 3);
  
  return { principal, adicionales };
}

// ==================== LOGROS ====================

const LOGROS: { codigo: string; nombre: string; descripcion: string; categoria: string; icono: string; rareza: string; puntos: number; orden: number; oculto: boolean; requisito: number }[] = [
  // === ONBOARDING - Primeros Pasos (15 logros) ===
  { codigo: 'bienvenido', nombre: 'Bienvenido a CocinaViva', descripcion: 'Abre la aplicación por primera vez', categoria: 'onboarding', icono: '👋', rareza: 'comun', puntos: 10, orden: 1, oculto: false, requisito: 1 },
  { codigo: 'primera_receta', nombre: 'Primera Receta', descripcion: 'Visualiza tu primera receta', categoria: 'onboarding', icono: '📖', rareza: 'comun', puntos: 15, orden: 2, oculto: false, requisito: 1 },
  { codigo: 'configuracion_inicial', nombre: 'Personalización', descripcion: 'Configura tus preferencias por primera vez', categoria: 'onboarding', icono: '⚙️', rareza: 'comun', puntos: 10, orden: 3, oculto: false, requisito: 1 },
  { codigo: 'primer_favorito', nombre: 'Favorito Inicial', descripcion: 'Añade tu primera receta a favoritos', categoria: 'onboarding', icono: '❤️', rareza: 'comun', puntos: 15, orden: 4, oculto: false, requisito: 1 },
  { codigo: 'primera_lista', nombre: 'Lista de Compra', descripcion: 'Crea tu primera lista de la compra', categoria: 'onboarding', icono: '🛒', rareza: 'comun', puntos: 20, orden: 5, oculto: false, requisito: 1 },
  { codigo: 'primer_menu', nombre: 'Planificación Semanal', descripcion: 'Crea tu primer menú semanal', categoria: 'onboarding', icono: '📅', rareza: 'poco_comun', puntos: 25, orden: 6, oculto: false, requisito: 1 },
  { codigo: 'explorador_inicio', nombre: 'Explorador Novato', descripcion: 'Navega por 5 secciones diferentes', categoria: 'onboarding', icono: '🔍', rareza: 'comun', puntos: 15, orden: 7, oculto: false, requisito: 5 },
  { codigo: 'tema_personalizado', nombre: 'Estilo Personal', descripcion: 'Cambia el tema de la aplicación', categoria: 'onboarding', icono: '🎨', rareza: 'comun', puntos: 10, orden: 8, oculto: false, requisito: 1 },
  { codigo: 'idioma_config', nombre: 'Políglota', descripcion: 'Cambia el idioma de la aplicación', categoria: 'onboarding', icono: '🌐', rareza: 'comun', puntos: 10, orden: 9, oculto: false, requisito: 1 },
  { codigo: 'tutorial_completo', nombre: 'Aprendiz Completo', descripcion: 'Completa el tutorial inicial', categoria: 'onboarding', icono: '🎓', rareza: 'poco_comun', puntos: 30, orden: 10, oculto: false, requisito: 1 },
  { codigo: 'primer_thermomix', nombre: 'Thermomix Discovery', descripcion: 'Visualiza tu primera receta Thermomix', categoria: 'onboarding', icono: '🤖', rareza: 'comun', puntos: 15, orden: 11, oculto: false, requisito: 1 },
  { codigo: 'primer_tradicional', nombre: 'Tradicionalista', descripcion: 'Visualiza tu primera receta tradicional', categoria: 'onboarding', icono: '🥘', rareza: 'comun', puntos: 15, orden: 12, oculto: false, requisito: 1 },
  { codigo: 'busqueda_simple', nombre: 'Buscador', descripcion: 'Realiza tu primera búsqueda', categoria: 'onboarding', icono: '🔎', rareza: 'comun', puntos: 10, orden: 13, oculto: false, requisito: 1 },
  { codigo: 'filtro_usado', nombre: 'Filtrador', descripcion: 'Usa un filtro por primera vez', categoria: 'onboarding', icono: '🎯', rareza: 'comun', puntos: 10, orden: 14, oculto: false, requisito: 1 },
  { codigo: 'onboarding_master', nombre: 'Master Onboarding', descripcion: 'Completa todas las tareas iniciales', categoria: 'onboarding', icono: '🏆', rareza: 'raro', puntos: 50, orden: 15, oculto: true, requisito: 14 },

  // === RECETAS - Maestro Recetas (50 logros) ===
  { codigo: 'recetas_10', nombre: 'Curioso Culinario', descripcion: 'Visualiza 10 recetas', categoria: 'recetas', icono: '👀', rareza: 'comun', puntos: 20, orden: 1, oculto: false, requisito: 10 },
  { codigo: 'recetas_25', nombre: 'Explorador de Recetas', descripcion: 'Visualiza 25 recetas', categoria: 'recetas', icono: '🔍', rareza: 'comun', puntos: 30, orden: 2, oculto: false, requisito: 25 },
  { codigo: 'recetas_50', nombre: 'Descubridor Culinario', descripcion: 'Visualiza 50 recetas', categoria: 'recetas', icono: '📖', rareza: 'comun', puntos: 40, orden: 3, oculto: false, requisito: 50 },
  { codigo: 'recetas_100', nombre: 'Catador de Recetas', descripcion: 'Visualiza 100 recetas', categoria: 'recetas', icono: '👨‍🍳', rareza: 'poco_comun', puntos: 60, orden: 4, oculto: false, requisito: 100 },
  { codigo: 'recetas_250', nombre: 'Gourmet Experimentado', descripcion: 'Visualiza 250 recetas', categoria: 'recetas', icono: '🍽️', rareza: 'poco_comun', puntos: 100, orden: 5, oculto: false, requisito: 250 },
  { codigo: 'recetas_500', nombre: 'Chef Experto', descripcion: 'Visualiza 500 recetas', categoria: 'recetas', icono: '⭐', rareza: 'raro', puntos: 200, orden: 6, oculto: false, requisito: 500 },
  { codigo: 'recetas_1000', nombre: 'Maestro Culinario', descripcion: 'Visualiza 1000 recetas', categoria: 'recetas', icono: '👑', rareza: 'epico', puntos: 400, orden: 7, oculto: false, requisito: 1000 },
  { codigo: 'recetas_2000', nombre: 'Biblioteca Viva', descripcion: 'Visualiza TODAS las recetas', categoria: 'recetas', icono: '📚', rareza: 'legendario', puntos: 1000, orden: 8, oculto: true, requisito: 2000 },
  { codigo: 'cocinar_1', nombre: 'Primera Cocción', descripcion: 'Cocina tu primera receta', categoria: 'recetas', icono: '🍳', rareza: 'comun', puntos: 25, orden: 9, oculto: false, requisito: 1 },
  { codigo: 'cocinar_5', nombre: 'Cocinillas', descripcion: 'Cocina 5 recetas', categoria: 'recetas', icono: '👨‍🍳', rareza: 'comun', puntos: 40, orden: 10, oculto: false, requisito: 5 },
  { codigo: 'cocinar_10', nombre: 'Cocinero Aficionado', descripcion: 'Cocina 10 recetas', categoria: 'recetas', icono: '🥘', rareza: 'comun', puntos: 60, orden: 11, oculto: false, requisito: 10 },
  { codigo: 'cocinar_25', nombre: 'Cocinero Entusiasta', descripcion: 'Cocina 25 recetas', categoria: 'recetas', icono: '🍳', rareza: 'poco_comun', puntos: 100, orden: 12, oculto: false, requisito: 25 },
  { codigo: 'cocinar_50', nombre: 'Cocinero Experto', descripcion: 'Cocina 50 recetas', categoria: 'recetas', icono: '⭐', rareza: 'poco_comun', puntos: 180, orden: 13, oculto: false, requisito: 50 },
  { codigo: 'cocinar_100', nombre: 'Chef Profesional', descripcion: 'Cocina 100 recetas', categoria: 'recetas', icono: '🏆', rareza: 'raro', puntos: 350, orden: 14, oculto: false, requisito: 100 },
  { codigo: 'cocinar_250', nombre: 'Chef Ejecutivo', descripcion: 'Cocina 250 recetas', categoria: 'recetas', icono: '👨‍🍳', rareza: 'epico', puntos: 600, orden: 15, oculto: false, requisito: 250 },
  { codigo: 'cocinar_500', nombre: 'Maestro de los Fogones', descripcion: 'Cocina 500 recetas', categoria: 'recetas', icono: '🔥', rareza: 'legendario', puntos: 1200, orden: 16, oculto: true, requisito: 500 },
  { codigo: 'favoritos_5', nombre: 'Coleccionista Inicial', descripcion: 'Añade 5 recetas a favoritos', categoria: 'recetas', icono: '💖', rareza: 'comun', puntos: 25, orden: 17, oculto: false, requisito: 5 },
  { codigo: 'favoritos_10', nombre: 'Favoritos Frecuentes', descripcion: 'Añade 10 recetas a favoritos', categoria: 'recetas', icono: '❤️', rareza: 'comun', puntos: 40, orden: 18, oculto: false, requisito: 10 },
  { codigo: 'favoritos_25', nombre: 'Coleccionista', descripcion: 'Añade 25 recetas a favoritos', categoria: 'recetas', icono: '💕', rareza: 'poco_comun', puntos: 80, orden: 19, oculto: false, requisito: 25 },
  { codigo: 'favoritos_50', nombre: 'Mega Coleccionista', descripcion: 'Añade 50 recetas a favoritos', categoria: 'recetas', icono: '💗', rareza: 'raro', puntos: 150, orden: 20, oculto: false, requisito: 50 },
  { codigo: 'favoritos_100', nombre: 'Biblioteca de Favoritos', descripcion: 'Añade 100 recetas a favoritos', categoria: 'recetas', icono: '❤️‍🔥', rareza: 'epico', puntos: 300, orden: 21, oculto: false, requisito: 100 },
  { codigo: 'valorar_1', nombre: 'Crítico Inicial', descripcion: 'Valora tu primera receta', categoria: 'recetas', icono: '⭐', rareza: 'comun', puntos: 15, orden: 22, oculto: false, requisito: 1 },
  { codigo: 'valorar_10', nombre: 'Opinador', descripcion: 'Valora 10 recetas', categoria: 'recetas', icono: '🌟', rareza: 'comun', puntos: 40, orden: 23, oculto: false, requisito: 10 },
  { codigo: 'valorar_25', nombre: 'Crítico Culinario', descripcion: 'Valora 25 recetas', categoria: 'recetas', icono: '✨', rareza: 'poco_comun', puntos: 80, orden: 24, oculto: false, requisito: 25 },
  { codigo: 'valorar_50', nombre: 'Juez Gastronómico', descripcion: 'Valora 50 recetas', categoria: 'recetas', icono: '🎖️', rareza: 'raro', puntos: 150, orden: 25, oculto: false, requisito: 50 },
  { codigo: 'valorar_100', nombre: 'Crítico Profesional', descripcion: 'Valora 100 recetas', categoria: 'recetas', icono: '🏅', rareza: 'epico', puntos: 300, orden: 26, oculto: false, requisito: 100 },
  { codigo: 'compartir_1', nombre: 'Compartidor', descripcion: 'Comparte una receta', categoria: 'recetas', icono: '📤', rareza: 'comun', puntos: 20, orden: 27, oculto: false, requisito: 1 },
  { codigo: 'compartir_10', nombre: 'Social Culinario', descripcion: 'Comparte 10 recetas', categoria: 'recetas', icono: '🔗', rareza: 'poco_comun', puntos: 60, orden: 28, oculto: false, requisito: 10 },
  { codigo: 'compartir_25', nombre: 'Influencer de Cocina', descripcion: 'Comparte 25 recetas', categoria: 'recetas', icono: '📲', rareza: 'raro', puntos: 120, orden: 29, oculto: false, requisito: 25 },
  { codigo: 'imprimir_1', nombre: 'Tradicionalista', descripcion: 'Imprime una receta', categoria: 'recetas', icono: '🖨️', rareza: 'comun', puntos: 15, orden: 30, oculto: false, requisito: 1 },
  { codigo: 'imprimir_10', nombre: 'Archivo de Cocina', descripcion: 'Imprime 10 recetas', categoria: 'recetas', icono: '📄', rareza: 'poco_comun', puntos: 50, orden: 31, oculto: false, requisito: 10 },
  { codigo: 'termomix_10', nombre: 'Thermomix Fan', descripcion: 'Cocina 10 recetas Thermomix', categoria: 'recetas', icono: '🤖', rareza: 'comun', puntos: 50, orden: 32, oculto: false, requisito: 10 },
  { codigo: 'termomix_50', nombre: 'Robot Chef', descripcion: 'Cocina 50 recetas Thermomix', categoria: 'recetas', icono: '🦾', rareza: 'poco_comun', puntos: 150, orden: 33, oculto: false, requisito: 50 },
  { codigo: 'termomix_100', nombre: 'Maestro Thermomix', descripcion: 'Cocina 100 recetas Thermomix', categoria: 'recetas', icono: '⚡', rareza: 'raro', puntos: 300, orden: 34, oculto: false, requisito: 100 },
  { codigo: 'tradicional_10', nombre: 'Tradicionalista', descripcion: 'Cocina 10 recetas tradicionales', categoria: 'recetas', icono: '🥘', rareza: 'comun', puntos: 50, orden: 35, oculto: false, requisito: 10 },
  { codigo: 'tradicional_50', nombre: 'Guardián de Tradiciones', descripcion: 'Cocina 50 recetas tradicionales', categoria: 'recetas', icono: '🏺', rareza: 'poco_comun', puntos: 150, orden: 36, oculto: false, requisito: 50 },
  { codigo: 'tradicional_100', nombre: 'Heredero Culinario', descripcion: 'Cocina 100 recetas tradicionales', categoria: 'recetas', icono: '👴', rareza: 'raro', puntos: 300, orden: 37, oculto: false, requisito: 100 },
  { codigo: 'rapida_10', nombre: 'Cocina Express', descripcion: 'Cocina 10 recetas en menos de 30 min', categoria: 'recetas', icono: '⚡', rareza: 'comun', puntos: 40, orden: 38, oculto: false, requisito: 10 },
  { codigo: 'rapida_25', nombre: 'Velocista Culinario', descripcion: 'Cocina 25 recetas en menos de 30 min', categoria: 'recetas', icono: '🏃', rareza: 'poco_comun', puntos: 100, orden: 39, oculto: false, requisito: 25 },
  { codigo: 'dificil_5', nombre: 'Retador', descripcion: 'Cocina 5 recetas difíciles', categoria: 'recetas', icono: '🔥', rareza: 'poco_comun', puntos: 80, orden: 40, oculto: false, requisito: 5 },
  { codigo: 'dificil_10', nombre: 'Desafiante', descripcion: 'Cocina 10 recetas difíciles', categoria: 'recetas', icono: '💪', rareza: 'raro', puntos: 180, orden: 41, oculto: false, requisito: 10 },
  { codigo: 'dificil_25', nombre: 'Maestro del Reto', descripcion: 'Cocina 25 recetas difíciles', categoria: 'recetas', icono: '🏆', rareza: 'epico', puntos: 400, orden: 42, oculto: false, requisito: 25 },
  { codigo: 'postres_10', nombre: 'Dulce Tentación', descripcion: 'Cocina 10 postres', categoria: 'recetas', icono: '🍰', rareza: 'comun', puntos: 40, orden: 43, oculto: false, requisito: 10 },
  { codigo: 'postres_25', nombre: 'Pastelero', descripcion: 'Cocina 25 postres', categoria: 'recetas', icono: '🎂', rareza: 'poco_comun', puntos: 100, orden: 44, oculto: false, requisito: 25 },
  { codigo: 'postres_50', nombre: 'Repostero Maestro', descripcion: 'Cocina 50 postres', categoria: 'recetas', icono: '🧁', rareza: 'raro', puntos: 250, orden: 45, oculto: false, requisito: 50 },
  { codigo: 'entrantes_10', nombre: 'Aperitivo Master', descripcion: 'Cocina 10 entrantes', categoria: 'recetas', icono: '🥗', rareza: 'comun', puntos: 40, orden: 46, oculto: false, requisito: 10 },
  { codigo: 'sopas_10', nombre: 'Sopero', descripcion: 'Cocina 10 sopas o cremas', categoria: 'recetas', icono: '🍲', rareza: 'comun', puntos: 40, orden: 47, oculto: false, requisito: 10 },
  { codigo: 'salsas_10', nombre: 'Maestro de Salsas', descripcion: 'Cocina 10 salsas', categoria: 'recetas', icono: '🫕', rareza: 'poco_comun', puntos: 60, orden: 48, oculto: false, requisito: 10 },
  { codigo: 'receta_perfecta', nombre: 'Perfeccionista', descripcion: 'Cocina una receta siguiendo todos los pasos', categoria: 'recetas', icono: '✅', rareza: 'poco_comun', puntos: 50, orden: 49, oculto: true, requisito: 1 },
  { codigo: 'recetario_completo', nombre: 'Recetario Completo', descripcion: 'Completa cocinar todas las categorías', categoria: 'recetas', icono: '📚', rareza: 'legendario', puntos: 800, orden: 50, oculto: true, requisito: 1 },

  // === SALUD - 30 logros ===
  { codigo: 'salud_info', nombre: 'Informado', descripcion: 'Consulta información nutricional', categoria: 'salud', icono: '📊', rareza: 'comun', puntos: 15, orden: 1, oculto: false, requisito: 1 },
  { codigo: 'bajo_calorias_5', nombre: 'Control de Calorías', descripcion: 'Cocina 5 recetas bajas en calorías', categoria: 'salud', icono: '🥗', rareza: 'comun', puntos: 30, orden: 2, oculto: false, requisito: 5 },
  { codigo: 'bajo_calorias_15', nombre: 'Cocina Light', descripcion: 'Cocina 15 recetas bajas en calorías', categoria: 'salud', icono: '💚', rareza: 'poco_comun', puntos: 70, orden: 3, oculto: false, requisito: 15 },
  { codigo: 'vegetariano_5', nombre: 'Verduras Primero', descripcion: 'Cocina 5 recetas vegetarianas', categoria: 'salud', icono: '🥬', rareza: 'comun', puntos: 30, orden: 4, oculto: false, requisito: 5 },
  { codigo: 'vegetariano_15', nombre: 'Verduriano', descripcion: 'Cocina 15 recetas vegetarianas', categoria: 'salud', icono: '🥦', rareza: 'poco_comun', puntos: 70, orden: 5, oculto: false, requisito: 15 },
  { codigo: 'vegetariano_30', nombre: 'Vegetariano Convencido', descripcion: 'Cocina 30 recetas vegetarianas', categoria: 'salud', icono: '🌱', rareza: 'raro', puntos: 150, orden: 6, oculto: false, requisito: 30 },
  { codigo: 'vegano_5', nombre: 'Vegano Explorador', descripcion: 'Cocina 5 recetas veganas', categoria: 'salud', icono: '🌿', rareza: 'poco_comun', puntos: 50, orden: 7, oculto: false, requisito: 5 },
  { codigo: 'vegano_15', nombre: 'Vegano Comprometido', descripcion: 'Cocina 15 recetas veganas', categoria: 'salud', icono: '🍃', rareza: 'raro', puntos: 120, orden: 8, oculto: false, requisito: 15 },
  { codigo: 'sin_gluten_5', nombre: 'Sin Gluten Novato', descripcion: 'Cocina 5 recetas sin gluten', categoria: 'salud', icono: '🌾', rareza: 'comun', puntos: 30, orden: 9, oculto: false, requisito: 5 },
  { codigo: 'sin_gluten_15', nombre: 'Experto Sin Gluten', descripcion: 'Cocina 15 recetas sin gluten', categoria: 'salud', icono: '🍞', rareza: 'poco_comun', puntos: 70, orden: 10, oculto: false, requisito: 15 },
  { codigo: 'sin_lactosa_5', nombre: 'Lactosa Free', descripcion: 'Cocina 5 recetas sin lactosa', categoria: 'salud', icono: '🥛', rareza: 'comun', puntos: 30, orden: 11, oculto: false, requisito: 5 },
  { codigo: 'equilibrado_7', nombre: 'Semana Equilibrada', descripcion: 'Planifica una semana con menús equilibrados', categoria: 'salud', icono: '⚖️', rareza: 'poco_comun', puntos: 80, orden: 12, oculto: false, requisito: 7 },
  { codigo: 'verduras_dia_7', nombre: 'Verdura Diaria', descripcion: 'Incluye verduras en 7 menús seguidos', categoria: 'salud', icono: '🥕', rareza: 'poco_comun', puntos: 70, orden: 13, oculto: false, requisito: 7 },
  { codigo: 'fruta_dia_7', nombre: 'Fruta Diaria', descripcion: 'Incluye fruta en 7 postres seguidos', categoria: 'salud', icono: '🍎', rareza: 'comun', puntos: 50, orden: 14, oculto: false, requisito: 7 },
  { codigo: 'proteina_10', nombre: 'Proteína Adecuada', descripcion: 'Cocina 10 recetas con alta proteína', categoria: 'salud', icono: '🥩', rareza: 'comun', puntos: 40, orden: 15, oculto: false, requisito: 10 },
  { codigo: 'pescado_5', nombre: 'Pescado Fresco', descripcion: 'Cocina 5 recetas de pescado', categoria: 'salud', icono: '🐟', rareza: 'comun', puntos: 35, orden: 16, oculto: false, requisito: 5 },
  { codigo: 'pescado_15', nombre: 'Amigo del Mar', descripcion: 'Cocina 15 recetas de pescado', categoria: 'salud', icono: '🐠', rareza: 'poco_comun', puntos: 80, orden: 17, oculto: false, requisito: 15 },
  { codigo: 'legumbres_5', nombre: 'Legumbres Lover', descripcion: 'Cocina 5 recetas de legumbres', categoria: 'salud', icono: '🫘', rareza: 'comun', puntos: 30, orden: 18, oculto: false, requisito: 5 },
  { codigo: 'legumbres_15', nombre: 'Proteína Vegetal', descripcion: 'Cocina 15 recetas de legumbres', categoria: 'salud', icono: '🥜', rareza: 'poco_comun', puntos: 70, orden: 19, oculto: false, requisito: 15 },
  { codigo: 'hidratacion', nombre: 'Bien Hidratado', descripcion: 'Prepara 10 bebidas saludables', categoria: 'salud', icono: '💧', rareza: 'comun', puntos: 40, orden: 20, oculto: false, requisito: 10 },
  { codigo: 'batidos_5', nombre: 'Batido Master', descripcion: 'Prepara 5 batidos saludables', categoria: 'salud', icono: '🥤', rareza: 'comun', puntos: 35, orden: 21, oculto: false, requisito: 5 },
  { codigo: 'ensaladas_10', nombre: 'Ensaladillo', descripcion: 'Cocina 10 ensaladas', categoria: 'salud', icono: '🥗', rareza: 'comun', puntos: 40, orden: 22, oculto: false, requisito: 10 },
  { codigo: 'ensaladas_25', nombre: 'Rey de las Ensaladas', descripcion: 'Cocina 25 ensaladas', categoria: 'salud', icono: '🥬', rareza: 'poco_comun', puntos: 100, orden: 23, oculto: false, requisito: 25 },
  { codigo: 'calorias_control', nombre: 'Control Calórico', descripcion: 'Supervisa calorías en 50 recetas', categoria: 'salud', icono: '📈', rareza: 'poco_comun', puntos: 80, orden: 24, oculto: false, requisito: 50 },
  { codigo: 'dieta_variada', nombre: 'Dieta Variada', descripcion: 'Cocina recetas de 10 cocinas diferentes', categoria: 'salud', icono: '🌍', rareza: 'raro', puntos: 150, orden: 25, oculto: false, requisito: 10 },
  { codigo: 'salud_mental', nombre: 'Cocina Terapia', descripcion: 'Cocina 20 recetas para relajarte', categoria: 'salud', icono: '🧘', rareza: 'poco_comun', puntos: 90, orden: 26, oculto: true, requisito: 20 },
  { codigo: 'organico_10', nombre: 'Orgánico Fan', descripcion: 'Usa ingredientes orgánicos en 10 recetas', categoria: 'salud', icono: '🌿', rareza: 'poco_comun', puntos: 70, orden: 27, oculto: false, requisito: 10 },
  { codigo: 'temporal_10', nombre: 'Productos de Temporada', descripcion: 'Cocina 10 recetas con productos de temporada', categoria: 'salud', icono: '🍂', rareza: 'poco_comun', puntos: 60, orden: 28, oculto: false, requisito: 10 },
  { codigo: 'salud_master', nombre: 'Maestro de la Salud', descripcion: 'Completa todos los logros de salud básicos', categoria: 'salud', icono: '🏥', rareza: 'epico', puntos: 400, orden: 29, oculto: true, requisito: 20 },
  { codigo: 'nutricionista', nombre: 'Nutricionista Honorario', descripcion: 'Consulta info nutricional 100 veces', categoria: 'salud', icono: '🎓', rareza: 'raro', puntos: 200, orden: 30, oculto: false, requisito: 100 },

  // === CONSTANCIA - 35 logros ===
  { codigo: 'login_1', nombre: 'Bienvenido de Nuevo', descripcion: 'Abre la aplicación 2 días seguidos', categoria: 'constancia', icono: '📅', rareza: 'comun', puntos: 15, orden: 1, oculto: false, requisito: 2 },
  { codigo: 'login_7', nombre: 'Semana Constante', descripcion: 'Abre la aplicación 7 días seguidos', categoria: 'constancia', icono: '📆', rareza: 'comun', puntos: 50, orden: 2, oculto: false, requisito: 7 },
  { codigo: 'login_14', nombre: 'Dos Semanas', descripcion: 'Abre la aplicación 14 días seguidos', categoria: 'constancia', icono: '🗓️', rareza: 'poco_comun', puntos: 100, orden: 3, oculto: false, requisito: 14 },
  { codigo: 'login_30', nombre: 'Mes Perfecto', descripcion: 'Abre la aplicación 30 días seguidos', categoria: 'constancia', icono: '📅', rareza: 'raro', puntos: 250, orden: 4, oculto: false, requisito: 30 },
  { codigo: 'login_60', nombre: 'Dos Meses', descripcion: 'Abre la aplicación 60 días seguidos', categoria: 'constancia', icono: '🗓️', rareza: 'epico', puntos: 500, orden: 5, oculto: false, requisito: 60 },
  { codigo: 'login_100', nombre: 'Cien Días', descripcion: 'Abre la aplicación 100 días seguidos', categoria: 'constancia', icono: '💯', rareza: 'legendario', puntos: 1000, orden: 6, oculto: true, requisito: 100 },
  { codigo: 'cocinar_semana_1', nombre: 'Cocinero Semanal', descripcion: 'Cocina al menos una receta cada día por una semana', categoria: 'constancia', icono: '👨‍🍳', rareza: 'poco_comun', puntos: 80, orden: 7, oculto: false, requisito: 7 },
  { codigo: 'cocinar_semana_2', nombre: 'Quince Días Cocinando', descripcion: 'Cocina cada día por 2 semanas', categoria: 'constancia', icono: '🍳', rareza: 'raro', puntos: 180, orden: 8, oculto: false, requisito: 14 },
  { codigo: 'cocinar_semana_4', nombre: 'Mes Cocinando', descripcion: 'Cocina cada día por un mes', categoria: 'constancia', icono: '🔥', rareza: 'epico', puntos: 400, orden: 9, oculto: false, requisito: 30 },
  { codigo: 'menu_semana_4', nombre: 'Planificador Mensual', descripcion: 'Crea menús para 4 semanas seguidas', categoria: 'constancia', icono: '📋', rareza: 'poco_comun', puntos: 120, orden: 10, oculto: false, requisito: 4 },
  { codigo: 'menu_semana_12', nombre: 'Planificador Trimestral', descripcion: 'Crea menús para 12 semanas seguidas', categoria: 'constancia', icono: '📝', rareza: 'raro', puntos: 280, orden: 11, oculto: false, requisito: 12 },
  { codigo: 'lista_semana_4', nombre: 'Compras Organizadas', descripcion: 'Crea listas de compra por 4 semanas', categoria: 'constancia', icono: '🛒', rareza: 'comun', puntos: 60, orden: 12, oculto: false, requisito: 4 },
  { codigo: 'lista_completa_constancia_10', nombre: 'Compras Eficientes', descripcion: 'Completa 10 listas de compra al 100%', categoria: 'constancia', icono: '✅', rareza: 'poco_comun', puntos: 100, orden: 13, oculto: false, requisito: 10 },
  { codigo: 'receta_nueva_7', nombre: 'Explorador Semanal', descripcion: 'Prueba una receta nueva cada día por una semana', categoria: 'constancia', icono: '🔍', rareza: 'poco_comun', puntos: 90, orden: 14, oculto: false, requisito: 7 },
  { codigo: 'receta_nueva_30', nombre: 'Explorador Mensual', descripcion: 'Prueba una receta nueva cada día por un mes', categoria: 'constancia', icono: '🧭', rareza: 'raro', puntos: 250, orden: 15, oculto: false, requisito: 30 },
  { codigo: 'favorito_nuevo_7', nombre: 'Favoritos Constantes', descripcion: 'Añade un favorito cada día por una semana', categoria: 'constancia', icono: '💖', rareza: 'comun', puntos: 50, orden: 16, oculto: false, requisito: 7 },
  { codigo: 'horario_fijo_7', nombre: 'Horario Estable', descripcion: 'Usa la app a la misma hora por 7 días', categoria: 'constancia', icono: '⏰', rareza: 'poco_comun', puntos: 70, orden: 17, oculto: true, requisito: 7 },
  { codigo: 'desafio_diario_5', nombre: 'Desafíos Diarios', descripcion: 'Completa 5 desafíos diarios', categoria: 'constancia', icono: '🎯', rareza: 'comun', puntos: 50, orden: 18, oculto: false, requisito: 5 },
  { codigo: 'desafio_diario_15', nombre: 'Retador Diario', descripcion: 'Completa 15 desafíos diarios', categoria: 'constancia', icono: '🏆', rareza: 'poco_comun', puntos: 120, orden: 19, oculto: false, requisito: 15 },
  { codigo: 'desafio_diario_30', nombre: 'Maestro de Desafíos', descripcion: 'Completa 30 desafíos diarios', categoria: 'constancia', icono: '👑', rareza: 'raro', puntos: 280, orden: 20, oculto: false, requisito: 30 },
  { codigo: 'desafio_semanal_4', nombre: 'Desafíos Semanales', descripcion: 'Completa 4 desafíos semanales', categoria: 'constancia', icono: '🗓️', rareza: 'poco_comun', puntos: 150, orden: 21, oculto: false, requisito: 4 },
  { codigo: 'desafio_semanal_12', nombre: 'Retador Semanal', descripcion: 'Completa 12 desafíos semanales', categoria: 'constancia', icono: '🏅', rareza: 'raro', puntos: 350, orden: 22, oculto: false, requisito: 12 },
  { codigo: 'noche_cocina_5', nombre: 'Cocina Nocturna', descripcion: 'Cocina 5 veces después de las 8PM', categoria: 'constancia', icono: '🌙', rareza: 'comun', puntos: 40, orden: 23, oculto: true, requisito: 5 },
  { codigo: 'manana_cocina_5', nombre: 'Cocina Matutina', descripcion: 'Cocina 5 veces antes de las 9AM', categoria: 'constancia', icono: '🌅', rareza: 'comun', puntos: 40, orden: 24, oculto: true, requisito: 5 },
  { codigo: 'finde_cocina_10', nombre: 'Cocina de Finde', descripcion: 'Cocina 10 veces en fin de semana', categoria: 'constancia', icono: '🎉', rareza: 'comun', puntos: 50, orden: 25, oculto: false, requisito: 10 },
  { codigo: 'rapido_30_10', nombre: 'Cocina Rápida Constante', descripcion: 'Cocina 10 recetas en menos de 30 min en días seguidos', categoria: 'constancia', icono: '⚡', rareza: 'poco_comun', puntos: 100, orden: 26, oculto: false, requisito: 10 },
  { codigo: 'verano_cocina_20', nombre: 'Cocina de Verano', descripcion: 'Cocina 20 recetas durante el verano', categoria: 'constancia', icono: '☀️', rareza: 'poco_comun', puntos: 80, orden: 27, oculto: false, requisito: 20 },
  { codigo: 'invierno_cocina_20', nombre: 'Cocina de Invierno', descripcion: 'Cocina 20 recetas durante el invierno', categoria: 'constancia', icono: '❄️', rareza: 'poco_comun', puntos: 80, orden: 28, oculto: false, requisito: 20 },
  { codigo: 'otoño_cocina_20', nombre: 'Cocina de Otoño', descripcion: 'Cocina 20 recetas durante el otoño', categoria: 'constancia', icono: '🍂', rareza: 'poco_comun', puntos: 80, orden: 29, oculto: false, requisito: 20 },
  { codigo: 'primavera_cocina_20', nombre: 'Cocina de Primavera', descripcion: 'Cocina 20 recetas durante la primavera', categoria: 'constancia', icono: '🌸', rareza: 'poco_comun', puntos: 80, orden: 30, oculto: false, requisito: 20 },
  { codigo: 'aniversario_1', nombre: 'Primer Aniversario', descripcion: 'Usa la app durante un año', categoria: 'constancia', icono: '🎂', rareza: 'legendario', puntos: 1500, orden: 31, oculto: true, requisito: 365 },
  { codigo: 'fiestas_10', nombre: 'Cocina Navideña', descripcion: 'Cocina 10 recetas en fechas navideñas', categoria: 'constancia', icono: '🎄', rareza: 'poco_comun', puntos: 100, orden: 32, oculto: false, requisito: 10 },
  { codigo: 'especial_5', nombre: 'Ocasiones Especiales', descripcion: 'Cocina 5 recetas para eventos especiales', categoria: 'constancia', icono: '🎊', rareza: 'raro', puntos: 200, orden: 33, oculto: false, requisito: 5 },
  { codigo: 'constancia_suprema', nombre: 'Constancia Suprema', descripcion: 'Completa todos los logros de constancia', categoria: 'constancia', icono: '🏅', rareza: 'legendario', puntos: 2000, orden: 34, oculto: true, requisito: 33 },
  { codigo: 'record_personal', nombre: 'Récord Personal', descripcion: 'Supera tu propio récord de días consecutivos', categoria: 'constancia', icono: '📈', rareza: 'raro', puntos: 150, orden: 35, oculto: true, requisito: 1 },

  // === COMUNIDAD - 30 logros ===
  { codigo: 'compartir_receta_5', nombre: 'Compartidor Activo', descripcion: 'Comparte 5 recetas con amigos', categoria: 'comunidad', icono: '📤', rareza: 'comun', puntos: 40, orden: 1, oculto: false, requisito: 5 },
  { codigo: 'compartir_receta_20', nombre: 'Influencer de Cocina', descripcion: 'Comparte 20 recetas', categoria: 'comunidad', icono: '📲', rareza: 'poco_comun', puntos: 120, orden: 2, oculto: false, requisito: 20 },
  { codigo: 'compartir_receta_50', nombre: 'Embajador Culinario', descripcion: 'Comparte 50 recetas', categoria: 'comunidad', icono: '🌍', rareza: 'raro', puntos: 280, orden: 3, oculto: false, requisito: 50 },
  { codigo: 'comentario_1', nombre: 'Primer Comentario', descripcion: 'Deja tu primer comentario', categoria: 'comunidad', icono: '💬', rareza: 'comun', puntos: 15, orden: 4, oculto: false, requisito: 1 },
  { codigo: 'comentario_10', nombre: 'Comentador', descripcion: 'Deja 10 comentarios', categoria: 'comunidad', icono: '💭', rareza: 'comun', puntos: 50, orden: 5, oculto: false, requisito: 10 },
  { codigo: 'comentario_25', nombre: 'Opinador Experto', descripcion: 'Deja 25 comentarios', categoria: 'comunidad', icono: '🗣️', rareza: 'poco_comun', puntos: 100, orden: 6, oculto: false, requisito: 25 },
  { codigo: 'comentario_50', nombre: 'Voz de la Comunidad', descripcion: 'Deja 50 comentarios', categoria: 'comunidad', icono: '📣', rareza: 'raro', puntos: 200, orden: 7, oculto: false, requisito: 50 },
  { codigo: 'recibir_like_10', nombre: 'Popular', descripcion: 'Recibe 10 likes en tus comentarios', categoria: 'comunidad', icono: '👍', rareza: 'poco_comun', puntos: 80, orden: 8, oculto: false, requisito: 10 },
  { codigo: 'recibir_like_50', nombre: 'Muy Popular', descripcion: 'Recibe 50 likes en tus comentarios', categoria: 'comunidad', icono: '⭐', rareza: 'raro', puntos: 180, orden: 9, oculto: false, requisito: 50 },
  { codigo: 'dar_like_10', nombre: 'Generoso', descripcion: 'Da 10 likes a otros usuarios', categoria: 'comunidad', icono: '💚', rareza: 'comun', puntos: 30, orden: 10, oculto: false, requisito: 10 },
  { codigo: 'dar_like_50', nombre: 'Muy Generoso', descripcion: 'Da 50 likes a otros usuarios', categoria: 'comunidad', icono: '💜', rareza: 'poco_comun', puntos: 100, orden: 11, oculto: false, requisito: 50 },
  { codigo: 'invitar_amigo_1', nombre: 'Invitador', descripcion: 'Invita a un amigo a usar la app', categoria: 'comunidad', icono: '✉️', rareza: 'comun', puntos: 50, orden: 12, oculto: false, requisito: 1 },
  { codigo: 'invitar_amigo_5', nombre: 'Embajador', descripcion: 'Invita a 5 amigos', categoria: 'comunidad', icono: '🎁', rareza: 'poco_comun', puntos: 180, orden: 13, oculto: false, requisito: 5 },
  { codigo: 'invitar_amigo_10', nombre: 'Networker', descripcion: 'Invita a 10 amigos', categoria: 'comunidad', icono: '🔗', rareza: 'raro', puntos: 350, orden: 14, oculto: false, requisito: 10 },
  { codigo: 'cocinar_grupo_5', nombre: 'Cocina Social', descripcion: 'Cocina 5 recetas para grupos (+6 personas)', categoria: 'comunidad', icono: '👨‍👩‍👧‍👦', rareza: 'comun', puntos: 60, orden: 15, oculto: false, requisito: 5 },
  { codigo: 'cocinar_grupo_15', nombre: 'Anfitrión', descripcion: 'Cocina 15 recetas para grupos', categoria: 'comunidad', icono: '🏠', rareza: 'poco_comun', puntos: 150, orden: 16, oculto: false, requisito: 15 },
  { codigo: 'cocinar_grupo_30', nombre: 'Gran Anfitrión', descripcion: 'Cocina 30 recetas para grupos', categoria: 'comunidad', icono: '🎉', rareza: 'raro', puntos: 300, orden: 17, oculto: false, requisito: 30 },
  { codigo: 'receta_familiar_10', nombre: 'Cocina Familiar', descripcion: 'Cocina 10 recetas familiares', categoria: 'comunidad', icono: '👨‍👩‍👧', rareza: 'comun', puntos: 50, orden: 18, oculto: false, requisito: 10 },
  { codigo: 'receta_ninos_5', nombre: 'Para los Peques', descripcion: 'Cocina 5 recetas para niños', categoria: 'comunidad', icono: '👶', rareza: 'comun', puntos: 40, orden: 19, oculto: false, requisito: 5 },
  { codigo: 'receta_ninos_15', nombre: 'Chef Infantil', descripcion: 'Cocina 15 recetas para niños', categoria: 'comunidad', icono: '🧒', rareza: 'poco_comun', puntos: 100, orden: 20, oculto: false, requisito: 15 },
  { codigo: 'potluck_5', nombre: 'Potluck Master', descripcion: 'Lleva 5 recetas a reuniones', categoria: 'comunidad', icono: '🥘', rareza: 'poco_comun', puntos: 100, orden: 21, oculto: false, requisito: 5 },
  { codigo: 'regalar_receta_5', nombre: 'Regalo Culinario', descripcion: 'Comparte 5 recetas como regalo', categoria: 'comunidad', icono: '🎁', rareza: 'poco_comun', puntos: 80, orden: 22, oculto: false, requisito: 5 },
  { codigo: 'follower_10', nombre: 'Seguido', descripcion: 'Consigue 10 seguidores', categoria: 'comunidad', icono: '👥', rareza: 'poco_comun', puntos: 100, orden: 23, oculto: false, requisito: 10 },
  { codigo: 'follower_50', nombre: 'Influencer Culinario', descripcion: 'Consigue 50 seguidores', categoria: 'comunidad', icono: '🌟', rareza: 'raro', puntos: 250, orden: 24, oculto: false, requisito: 50 },
  { codigo: 'seguir_10', nombre: 'Curioso', descripcion: 'Sigue a 10 cocineros', categoria: 'comunidad', icono: '👁️', rareza: 'comun', puntos: 40, orden: 25, oculto: false, requisito: 10 },
  { codigo: 'seguir_25', nombre: 'Seguidor Activo', descripcion: 'Sigue a 25 cocineros', categoria: 'comunidad', icono: '👀', rareza: 'poco_comun', puntos: 100, orden: 26, oculto: false, requisito: 25 },
  { codigo: 'reto_comunidad_5', nombre: 'Retador Social', descripcion: 'Participa en 5 retos de comunidad', categoria: 'comunidad', icono: '🎯', rareza: 'poco_comun', puntos: 120, orden: 27, oculto: false, requisito: 5 },
  { codigo: 'reto_comunidad_15', nombre: 'Campeón Comunitario', descripcion: 'Gana 15 retos de comunidad', categoria: 'comunidad', icono: '🏆', rareza: 'raro', puntos: 300, orden: 28, oculto: false, requisito: 15 },
  { codigo: 'comunidad_hero', nombre: 'Héroe de la Comunidad', descripcion: 'Completa todos los logros sociales', categoria: 'comunidad', icono: '🦸', rareza: 'epico', puntos: 600, orden: 29, oculto: true, requisito: 28 },
  { codigo: 'comunidad_legend', nombre: 'Leyenda Social', descripcion: 'Alcanza 100 seguidores y 500 likes', categoria: 'comunidad', icono: '👑', rareza: 'legendario', puntos: 1200, orden: 30, oculto: true, requisito: 100 },

  // === ORGANIZACIÓN - 30 logros ===
  { codigo: 'lista_1', nombre: 'Primera Lista', descripcion: 'Crea tu primera lista de compra', categoria: 'organizacion', icono: '📝', rareza: 'comun', puntos: 20, orden: 1, oculto: false, requisito: 1 },
  { codigo: 'lista_5', nombre: 'Organizado', descripcion: 'Crea 5 listas de compra', categoria: 'organizacion', icono: '📋', rareza: 'comun', puntos: 50, orden: 2, oculto: false, requisito: 5 },
  { codigo: 'lista_15', nombre: 'Planificador de Compras', descripcion: 'Crea 15 listas de compra', categoria: 'organizacion', icono: '📑', rareza: 'poco_comun', puntos: 100, orden: 3, oculto: false, requisito: 15 },
  { codigo: 'lista_completa_1', nombre: 'Lista Perfecta', descripcion: 'Completa una lista al 100%', categoria: 'organizacion', icono: '✅', rareza: 'comun', puntos: 25, orden: 4, oculto: false, requisito: 1 },
  { codigo: 'lista_completa_10', nombre: 'Comprador Eficiente', descripcion: 'Completa 10 listas al 100%', categoria: 'organizacion', icono: '🎯', rareza: 'poco_comun', puntos: 80, orden: 5, oculto: false, requisito: 10 },
  { codigo: 'lista_completa_25', nombre: 'Comprador Impecable', descripcion: 'Completa 25 listas al 100%', categoria: 'organizacion', icono: '💯', rareza: 'raro', puntos: 180, orden: 6, oculto: false, requisito: 25 },
  { codigo: 'menu_1', nombre: 'Primer Menú', descripcion: 'Crea tu primer menú semanal', categoria: 'organizacion', icono: '📅', rareza: 'comun', puntos: 25, orden: 7, oculto: false, requisito: 1 },
  { codigo: 'menu_4', nombre: 'Planificador Mensual', descripcion: 'Crea 4 menús semanales', categoria: 'organizacion', icono: '🗓️', rareza: 'comun', puntos: 60, orden: 8, oculto: false, requisito: 4 },
  { codigo: 'menu_12', nombre: 'Planificador Trimestral', descripcion: 'Crea 12 menús semanales', categoria: 'organizacion', icono: '📆', rareza: 'poco_comun', puntos: 150, orden: 9, oculto: false, requisito: 12 },
  { codigo: 'menu_completo', nombre: 'Menú Completo', descripcion: 'Planifica las 21 comidas de una semana', categoria: 'organizacion', icono: '✨', rareza: 'poco_comun', puntos: 100, orden: 10, oculto: false, requisito: 21 },
  { codigo: 'menu_variado', nombre: 'Menú Variado', descripcion: 'Planifica recetas de 5 cocinas diferentes en una semana', categoria: 'organizacion', icono: '🌍', rareza: 'poco_comun', puntos: 80, orden: 11, oculto: false, requisito: 5 },
  { codigo: 'agenda_1', nombre: 'Primera Planificación', descripcion: 'Planifica tu primera receta en el calendario', categoria: 'organizacion', icono: '📆', rareza: 'comun', puntos: 20, orden: 12, oculto: false, requisito: 1 },
  { codigo: 'agenda_7', nombre: 'Semana Planificada', descripcion: 'Planifica 7 recetas en el calendario', categoria: 'organizacion', icono: '📋', rareza: 'comun', puntos: 50, orden: 13, oculto: false, requisito: 7 },
  { codigo: 'agenda_30', nombre: 'Mes Planificado', descripcion: 'Planifica 30 recetas en el calendario', categoria: 'organizacion', icono: '🗓️', rareza: 'poco_comun', puntos: 120, orden: 14, oculto: false, requisito: 30 },
  { codigo: 'favoritos_categoria_5', nombre: 'Favoritos Organizados', descripcion: 'Añade favoritos de 5 categorías', categoria: 'organizacion', icono: '📁', rareza: 'comun', puntos: 40, orden: 15, oculto: false, requisito: 5 },
  { codigo: 'favoritos_cocina_5', nombre: 'Cocinas Favoritas', descripcion: 'Añade favoritos de 5 cocinas diferentes', categoria: 'organizacion', icono: '🌎', rareza: 'comun', puntos: 40, orden: 16, oculto: false, requisito: 5 },
  { codigo: 'etiqueta_1', nombre: 'Etiquetador', descripcion: 'Crea tu primera etiqueta personalizada', categoria: 'organizacion', icono: '🏷️', rareza: 'comun', puntos: 15, orden: 17, oculto: false, requisito: 1 },
  { codigo: 'etiqueta_5', nombre: 'Organizador por Etiquetas', descripcion: 'Crea 5 etiquetas personalizadas', categoria: 'organizacion', icono: '🔖', rareza: 'comun', puntos: 40, orden: 18, oculto: false, requisito: 5 },
  { codigo: 'etiqueta_uso_10', nombre: 'Uso de Etiquetas', descripcion: 'Etiqueta 10 recetas', categoria: 'organizacion', icono: '📌', rareza: 'poco_comun', puntos: 60, orden: 19, oculto: false, requisito: 10 },
  { codigo: 'nota_1', nombre: 'Tomador de Notas', descripcion: 'Añade tu primera nota a una receta', categoria: 'organizacion', icono: '📝', rareza: 'comun', puntos: 15, orden: 20, oculto: false, requisito: 1 },
  { codigo: 'nota_10', nombre: 'Anotador Activo', descripcion: 'Añade 10 notas a recetas', categoria: 'organizacion', icono: '✏️', rareza: 'comun', puntos: 50, orden: 21, oculto: false, requisito: 10 },
  { codigo: 'nota_25', nombre: 'Recetario Anotado', descripcion: 'Añade 25 notas a recetas', categoria: 'organizacion', icono: '📓', rareza: 'poco_comun', puntos: 100, orden: 22, oculto: false, requisito: 25 },
  { codigo: 'exportar_1', nombre: 'Exportador', descripcion: 'Exporta tu primera lista o menú', categoria: 'organizacion', icono: '📤', rareza: 'comun', puntos: 20, orden: 23, oculto: false, requisito: 1 },
  { codigo: 'exportar_10', nombre: 'Archivador', descripcion: 'Exporta 10 listas o menús', categoria: 'organizacion', icono: '💾', rareza: 'poco_comun', puntos: 80, orden: 24, oculto: false, requisito: 10 },
  { codigo: 'backup_1', nombre: 'Previsor', descripcion: 'Realiza tu primera copia de seguridad', categoria: 'organizacion', icono: '💿', rareza: 'poco_comun', puntos: 50, orden: 25, oculto: false, requisito: 1 },
  { codigo: 'backup_5', nombre: 'Siempre Seguro', descripcion: 'Realiza 5 copias de seguridad', categoria: 'organizacion', icono: '🔒', rareza: 'raro', puntos: 150, orden: 26, oculto: false, requisito: 5 },
  { codigo: 'categoria_todas', nombre: 'Todas las Categorías', descripcion: 'Usa recetas de todas las categorías', categoria: 'organizacion', icono: '📚', rareza: 'raro', puntos: 200, orden: 27, oculto: false, requisito: 6 },
  { codigo: 'cocina_10', nombre: 'Diez Cocinas', descripcion: 'Usa recetas de 10 cocinas diferentes', categoria: 'organizacion', icono: '🌐', rareza: 'poco_comun', puntos: 100, orden: 28, oculto: false, requisito: 10 },
  { codigo: 'cocina_todas', nombre: 'Gastrónomo Mundial', descripcion: 'Usa recetas de todas las cocinas', categoria: 'organizacion', icono: '🌍', rareza: 'legendario', puntos: 800, orden: 29, oculto: true, requisito: 20 },
  { codigo: 'organizacion_master', nombre: 'Maestro Organizador', descripcion: 'Completa todos los logros de organización', categoria: 'organizacion', icono: '🏆', rareza: 'epico', puntos: 500, orden: 30, oculto: true, requisito: 29 },

  // === EXPLORADOR - 40 logros ===
  { codigo: 'buscar_1', nombre: 'Primer Buscador', descripcion: 'Realiza tu primera búsqueda', categoria: 'explorador', icono: '🔍', rareza: 'comun', puntos: 10, orden: 1, oculto: false, requisito: 1 },
  { codigo: 'buscar_10', nombre: 'Buscador Activo', descripcion: 'Realiza 10 búsquedas', categoria: 'explorador', icono: '🔎', rareza: 'comun', puntos: 30, orden: 2, oculto: false, requisito: 10 },
  { codigo: 'buscar_50', nombre: 'Investigador', descripcion: 'Realiza 50 búsquedas', categoria: 'explorador', icono: '🔍', rareza: 'poco_comun', puntos: 80, orden: 3, oculto: false, requisito: 50 },
  { codigo: 'buscar_100', nombre: 'Buscador Experto', descripcion: 'Realiza 100 búsquedas', categoria: 'explorador', icono: '🔎', rareza: 'raro', puntos: 180, orden: 4, oculto: false, requisito: 100 },
  { codigo: 'filtro_1', nombre: 'Filtrador Inicial', descripcion: 'Usa un filtro por primera vez', categoria: 'explorador', icono: '🎯', rareza: 'comun', puntos: 10, orden: 5, oculto: false, requisito: 1 },
  { codigo: 'filtro_10', nombre: 'Filtrador', descripcion: 'Usa filtros 10 veces', categoria: 'explorador', icono: '🏷️', rareza: 'comun', puntos: 40, orden: 6, oculto: false, requisito: 10 },
  { codigo: 'filtro_50', nombre: 'Maestro de Filtros', descripcion: 'Usa filtros 50 veces', categoria: 'explorador', icono: '🎯', rareza: 'poco_comun', puntos: 100, orden: 7, oculto: false, requisito: 50 },
  { codigo: 'cocina_espanola_10', nombre: 'Cocina Española', descripcion: 'Explora 10 recetas españolas', categoria: 'explorador', icono: '🇪🇸', rareza: 'comun', puntos: 30, orden: 8, oculto: false, requisito: 10 },
  { codigo: 'cocina_italiana_10', nombre: 'Cocina Italiana', descripcion: 'Explora 10 recetas italianas', categoria: 'explorador', icono: '🇮🇹', rareza: 'comun', puntos: 30, orden: 9, oculto: false, requisito: 10 },
  { codigo: 'cocina_mexicana_10', nombre: 'Cocina Mexicana', descripcion: 'Explora 10 recetas mexicanas', categoria: 'explorador', icono: '🇲🇽', rareza: 'comun', puntos: 30, orden: 10, oculto: false, requisito: 10 },
  { codigo: 'cocina_francesa_10', nombre: 'Cocina Francesa', descripcion: 'Explora 10 recetas francesas', categoria: 'explorador', icono: '🇫🇷', rareza: 'comun', puntos: 30, orden: 11, oculto: false, requisito: 10 },
  { codigo: 'cocina_china_10', nombre: 'Cocina China', descripcion: 'Explora 10 recetas chinas', categoria: 'explorador', icono: '🇨🇳', rareza: 'comun', puntos: 30, orden: 12, oculto: false, requisito: 10 },
  { codigo: 'cocina_japonesa_10', nombre: 'Cocina Japonesa', descripcion: 'Explora 10 recetas japonesas', categoria: 'explorador', icono: '🇯🇵', rareza: 'comun', puntos: 30, orden: 13, oculto: false, requisito: 10 },
  { codigo: 'cocina_india_10', nombre: 'Cocina India', descripcion: 'Explora 10 recetas indias', categoria: 'explorador', icono: '🇮🇳', rareza: 'comun', puntos: 30, orden: 14, oculto: false, requisito: 10 },
  { codigo: 'cocina_arabe_10', nombre: 'Cocina Árabe', descripcion: 'Explora 10 recetas árabes', categoria: 'explorador', icono: '🇸🇦', rareza: 'comun', puntos: 30, orden: 15, oculto: false, requisito: 10 },
  { codigo: 'cocina_griega_10', nombre: 'Cocina Griega', descripcion: 'Explora 10 recetas griegas', categoria: 'explorador', icono: '🇬🇷', rareza: 'comun', puntos: 30, orden: 16, oculto: false, requisito: 10 },
  { codigo: 'cocina_peruana_10', nombre: 'Cocina Peruana', descripcion: 'Explora 10 recetas peruanas', categoria: 'explorador', icono: '🇵🇪', rareza: 'comun', puntos: 30, orden: 17, oculto: false, requisito: 10 },
  { codigo: 'cocina_argentina_10', nombre: 'Cocina Argentina', descripcion: 'Explora 10 recetas argentinas', categoria: 'explorador', icono: '🇦🇷', rareza: 'comun', puntos: 30, orden: 18, oculto: false, requisito: 10 },
  { codigo: 'cocina_colombiana_10', nombre: 'Cocina Colombiana', descripcion: 'Explora 10 recetas colombianas', categoria: 'explorador', icono: '🇨🇴', rareza: 'comun', puntos: 30, orden: 19, oculto: false, requisito: 10 },
  { codigo: 'cocina_venezolana_10', nombre: 'Cocina Venezolana', descripcion: 'Explora 10 recetas venezolanas', categoria: 'explorador', icono: '🇻🇪', rareza: 'comun', puntos: 30, orden: 20, oculto: false, requisito: 10 },
  { codigo: 'cocina_alemana_10', nombre: 'Cocina Alemana', descripcion: 'Explora 10 recetas alemanas', categoria: 'explorador', icono: '🇩🇪', rareza: 'comun', puntos: 30, orden: 21, oculto: false, requisito: 10 },
  { codigo: 'cocina_britanica_10', nombre: 'Cocina Británica', descripcion: 'Explora 10 recetas británicas', categoria: 'explorador', icono: '🇬🇧', rareza: 'comun', puntos: 30, orden: 22, oculto: false, requisito: 10 },
  { codigo: 'cocina_rusa_10', nombre: 'Cocina Rusa', descripcion: 'Explora 10 recetas rusas', categoria: 'explorador', icono: '🇷🇺', rareza: 'comun', puntos: 30, orden: 23, oculto: false, requisito: 10 },
  { codigo: 'cocina_tailandesa_10', nombre: 'Cocina Tailandesa', descripcion: 'Explora 10 recetas tailandesas', categoria: 'explorador', icono: '🇹🇭', rareza: 'comun', puntos: 30, orden: 24, oculto: false, requisito: 10 },
  { codigo: 'cocina_vietnamita_10', nombre: 'Cocina Vietnamita', descripcion: 'Explora 10 recetas vietnamitas', categoria: 'explorador', icono: '🇻🇳', rareza: 'comun', puntos: 30, orden: 25, oculto: false, requisito: 10 },
  { codigo: 'cocina_coreana_10', nombre: 'Cocina Coreana', descripcion: 'Explora 10 recetas coreanas', categoria: 'explorador', icono: '🇰🇷', rareza: 'comun', puntos: 30, orden: 26, oculto: false, requisito: 10 },
  { codigo: 'cocina_turca_10', nombre: 'Cocina Turca', descripcion: 'Explora 10 recetas turcas', categoria: 'explorador', icono: '🇹🇷', rareza: 'comun', puntos: 30, orden: 27, oculto: false, requisito: 10 },
  { codigo: 'cocinas_5', nombre: 'Viajero Culinario', descripcion: 'Explora recetas de 5 cocinas diferentes', categoria: 'explorador', icono: '🗺️', rareza: 'poco_comun', puntos: 80, orden: 28, oculto: false, requisito: 5 },
  { codigo: 'cocinas_10', nombre: 'Globetrotter Culinario', descripcion: 'Explora recetas de 10 cocinas diferentes', categoria: 'explorador', icono: '🌍', rareza: 'poco_comun', puntos: 150, orden: 29, oculto: false, requisito: 10 },
  { codigo: 'cocinas_15', nombre: 'Ciudadano del Mundo', descripcion: 'Explora recetas de 15 cocinas diferentes', categoria: 'explorador', icono: '🌐', rareza: 'raro', puntos: 250, orden: 30, oculto: false, requisito: 15 },
  { codigo: 'cocinas_20', nombre: 'Embajador Gastronómico', descripcion: 'Explora recetas de todas las cocinas', categoria: 'explorador', icono: '🌎', rareza: 'epico', puntos: 500, orden: 31, oculto: false, requisito: 20 },
  { codigo: 'categoria_entrantes_20', nombre: 'Entrantes Explorer', descripcion: 'Explora 20 recetas de entrantes', categoria: 'explorador', icono: '🥗', rareza: 'comun', puntos: 40, orden: 32, oculto: false, requisito: 20 },
  { codigo: 'categoria_primeros_20', nombre: 'Primeros Explorer', descripcion: 'Explora 20 recetas de primeros', categoria: 'explorador', icono: '🍝', rareza: 'comun', puntos: 40, orden: 33, oculto: false, requisito: 20 },
  { codigo: 'categoria_segundos_20', nombre: 'Segundos Explorer', descripcion: 'Explora 20 recetas de segundos', categoria: 'explorador', icono: '🍖', rareza: 'comun', puntos: 40, orden: 34, oculto: false, requisito: 20 },
  { codigo: 'categoria_postres_20', nombre: 'Postres Explorer', descripcion: 'Explora 20 recetas de postres', categoria: 'explorador', icono: '🍰', rareza: 'comun', puntos: 40, orden: 35, oculto: false, requisito: 20 },
  { codigo: 'categoria_bebidas_20', nombre: 'Bebidas Explorer', descripcion: 'Explora 20 recetas de bebidas', categoria: 'explorador', icono: '🍹', rareza: 'comun', puntos: 40, orden: 36, oculto: false, requisito: 20 },
  { codigo: 'categoria_salsas_20', nombre: 'Salsas Explorer', descripcion: 'Explora 20 recetas de salsas', categoria: 'explorador', icono: '🫕', rareza: 'comun', puntos: 40, orden: 37, oculto: false, requisito: 20 },
  { codigo: 'todas_categorias', nombre: 'Explorador de Categorías', descripcion: 'Explora todas las categorías', categoria: 'explorador', icono: '📂', rareza: 'raro', puntos: 200, orden: 38, oculto: false, requisito: 6 },
  { codigo: 'receta_oculta', nombre: 'Descubridor Oculto', descripcion: 'Encuentra una receta secreta', categoria: 'explorador', icono: '🔮', rareza: 'epico', puntos: 300, orden: 39, oculto: true, requisito: 1 },
  { codigo: 'explorador_supremo', nombre: 'Explorador Supremo', descripcion: 'Completa todos los logros de exploración', categoria: 'explorador', icono: '🏆', rareza: 'legendario', puntos: 1000, orden: 40, oculto: true, requisito: 39 },

  // === EFICIENCIA - 30 logros ===
  { codigo: 'rapida_1', nombre: 'Primera Receta Rápida', descripcion: 'Cocina una receta en menos de 20 minutos', categoria: 'eficiencia', icono: '⚡', rareza: 'comun', puntos: 20, orden: 1, oculto: false, requisito: 1 },
  { codigo: 'rapida_5', nombre: 'Cocina Express', descripcion: 'Cocina 5 recetas en menos de 20 minutos', categoria: 'eficiencia', icono: '🏃', rareza: 'comun', puntos: 50, orden: 2, oculto: false, requisito: 5 },
  { codigo: 'rapida_15', nombre: 'Velocista Culinario', descripcion: 'Cocina 15 recetas en menos de 20 minutos', categoria: 'eficiencia', icono: '⚡', rareza: 'poco_comun', puntos: 100, orden: 3, oculto: false, requisito: 15 },
  { codigo: 'rapida_30', nombre: 'Maestro del Tiempo', descripcion: 'Cocina 30 recetas en menos de 20 minutos', categoria: 'eficiencia', icono: '⏱️', rareza: 'raro', puntos: 200, orden: 4, oculto: false, requisito: 30 },
  { codigo: 'super_rapida_1', nombre: 'Súper Rápido', descripcion: 'Cocina una receta en menos de 10 minutos', categoria: 'eficiencia', icono: '🚀', rareza: 'poco_comun', puntos: 50, orden: 5, oculto: false, requisito: 1 },
  { codigo: 'super_rapida_10', nombre: 'Rayo de Cocina', descripcion: 'Cocina 10 recetas en menos de 10 minutos', categoria: 'eficiencia', icono: '⚡', rareza: 'raro', puntos: 180, orden: 6, oculto: false, requisito: 10 },
  { codigo: 'ingredientes_min_3', nombre: 'Minimalista', descripcion: 'Cocina una receta con solo 3 ingredientes', categoria: 'eficiencia', icono: '3️⃣', rareza: 'comun', puntos: 25, orden: 7, oculto: false, requisito: 1 },
  { codigo: 'ingredientes_min_10', nombre: 'Cocina Minimalista', descripcion: 'Cocina 10 recetas con menos de 5 ingredientes', categoria: 'eficiencia', icono: '🧘', rareza: 'poco_comun', puntos: 80, orden: 8, oculto: false, requisito: 10 },
  { codigo: 'aprovechamiento_5', nombre: 'Sin Desperdicio', descripcion: 'Usa sobras de 5 recetas anteriores', categoria: 'eficiencia', icono: '♻️', rareza: 'comun', puntos: 50, orden: 9, oculto: false, requisito: 5 },
  { codigo: 'batch_1', nombre: 'Batch Cooking', descripcion: 'Cocina 3 recetas a la vez', categoria: 'eficiencia', icono: '📦', rareza: 'poco_comun', puntos: 60, orden: 10, oculto: false, requisito: 3 },
  { codigo: 'batch_5', nombre: 'Maestro del Batch', descripcion: 'Realiza 5 sesiones de batch cooking', categoria: 'eficiencia', icono: '🥡', rareza: 'raro', puntos: 150, orden: 11, oculto: false, requisito: 5 },
  { codigo: 'multitasking_5', nombre: 'Multitarea', descripcion: 'Cocina 2 recetas simultáneamente', categoria: 'eficiencia', icono: '🔄', rareza: 'poco_comun', puntos: 70, orden: 12, oculto: false, requisito: 5 },
  { codigo: 'congelar_5', nombre: 'Congelador Pro', descripcion: 'Congela 5 recetas para después', categoria: 'eficiencia', icono: '❄️', rareza: 'comun', puntos: 40, orden: 13, oculto: false, requisito: 5 },
  { codigo: 'congelar_15', nombre: 'Reserva Estratégica', descripcion: 'Congela 15 recetas', categoria: 'eficiencia', icono: '🧊', rareza: 'poco_comun', puntos: 100, orden: 14, oculto: false, requisito: 15 },
  { codigo: 'preparacion_10', nombre: 'Preparador', descripcion: 'Prepara ingredientes con antelación 10 veces', categoria: 'eficiencia', icono: '🔪', rareza: 'comun', puntos: 50, orden: 15, oculto: false, requisito: 10 },
  { codigo: 'mise_en_place_5', nombre: 'Mise en Place', descripcion: 'Prepara todos los ingredientes antes de cocinar 5 veces', categoria: 'eficiencia', icono: '🍽️', rareza: 'poco_comun', puntos: 80, orden: 16, oculto: false, requisito: 5 },
  { codigo: 'termomix_rapido_10', nombre: 'Thermomix Express', descripcion: 'Cocina 10 recetas Thermomix en menos de 30 min', categoria: 'eficiencia', icono: '🤖', rareza: 'poco_comun', puntos: 100, orden: 17, oculto: false, requisito: 10 },
  { codigo: 'limpiar_mientras_5', nombre: 'Limpieza Simultánea', descripcion: 'Limpia mientras cocinas 5 veces', categoria: 'eficiencia', icono: '🧽', rareza: 'comun', puntos: 40, orden: 18, oculto: true, requisito: 5 },
  { codigo: 'organizar_nevera_1', nombre: 'Nevera Organizada', descripcion: 'Organiza tu nevera según ingredientes', categoria: 'eficiencia', icono: '🧊', rareza: 'comun', puntos: 30, orden: 19, oculto: false, requisito: 1 },
  { codigo: 'planificar_ahorro_5', nombre: 'Ahorrador', descripcion: 'Planifica 5 menús ahorrando ingredientes', categoria: 'eficiencia', icono: '💰', rareza: 'poco_comun', puntos: 80, orden: 20, oculto: false, requisito: 5 },
  { codigo: 'receta_aprovechada_10', nombre: 'Aprovechamiento Total', descripcion: 'Aprovecha ingredientes de 10 recetas', categoria: 'eficiencia', icono: '🔄', rareza: 'poco_comun', puntos: 90, orden: 21, oculto: false, requisito: 10 },
  { codigo: 'cocinar_2_en_1_5', nombre: 'Doble Rendimiento', descripcion: 'Cocina 2 platos con los mismos ingredientes 5 veces', categoria: 'eficiencia', icono: '👯', rareza: 'poco_comun', puntos: 80, orden: 22, oculto: false, requisito: 5 },
  { codigo: 'sobras_creativas_5', nombre: 'Creativo con Sobras', descripcion: 'Crea 5 recetas nuevas con sobras', categoria: 'eficiencia', icono: '✨', rareza: 'raro', puntos: 150, orden: 23, oculto: false, requisito: 5 },
  { codigo: 'menu_rotacion_4', nombre: 'Menú Rotativo', descripcion: 'Usa un sistema de rotación por 4 semanas', categoria: 'eficiencia', icono: '🔄', rareza: 'raro', puntos: 180, orden: 24, oculto: false, requisito: 4 },
  { codigo: 'compra_mensual_1', nombre: 'Compra Mensual', descripcion: 'Haz la compra de todo un mes', categoria: 'eficiencia', icono: '🛒', rareza: 'poco_comun', puntos: 100, orden: 25, oculto: false, requisito: 1 },
  { codigo: 'tiempo_record_1', nombre: 'Récord de Tiempo', descripcion: 'Supera tu mejor tiempo en una receta', categoria: 'eficiencia', icono: '🏆', rareza: 'poco_comun', puntos: 50, orden: 26, oculto: true, requisito: 1 },
  { codigo: 'eficiencia_80_10', nombre: '80% Eficiencia', descripcion: 'Alcanza 80% de eficiencia en 10 recetas', categoria: 'eficiencia', icono: '📊', rareza: 'raro', puntos: 200, orden: 27, oculto: false, requisito: 10 },
  { codigo: 'perfeccionista_5', nombre: 'Perfeccionista', descripcion: 'Cocina 5 recetas siguiendo exactamente las instrucciones', categoria: 'eficiencia', icono: '✅', rareza: 'poco_comun', puntos: 100, orden: 28, oculto: false, requisito: 5 },
  { codigo: 'eficiencia_master', nombre: 'Maestro de la Eficiencia', descripcion: 'Completa todos los logros de eficiencia', categoria: 'eficiencia', icono: '⚡', rareza: 'epico', puntos: 500, orden: 29, oculto: true, requisito: 28 },
  { codigo: 'tiempo_minimo', nombre: 'Tiempo Mínimo', descripcion: 'Cocina una receta en tiempo récord', categoria: 'eficiencia', icono: '⏱️', rareza: 'legendario', puntos: 600, orden: 30, oculto: true, requisito: 1 },

  // === CREATIVIDAD - 30 logros ===
  { codigo: 'modificar_1', nombre: 'Primer Cambio', descripcion: 'Modifica una receta por primera vez', categoria: 'creatividad', icono: '✏️', rareza: 'comun', puntos: 20, orden: 1, oculto: false, requisito: 1 },
  { codigo: 'modificar_10', nombre: 'Creativo', descripcion: 'Modifica 10 recetas', categoria: 'creatividad', icono: '🎨', rareza: 'comun', puntos: 50, orden: 2, oculto: false, requisito: 10 },
  { codigo: 'modificar_25', nombre: 'Innovador', descripcion: 'Modifica 25 recetas', categoria: 'creatividad', icono: '💡', rareza: 'poco_comun', puntos: 100, orden: 3, oculto: false, requisito: 25 },
  { codigo: 'sustituir_1', nombre: 'Sustituidor', descripcion: 'Sustituye un ingrediente por primera vez', categoria: 'creatividad', icono: '🔄', rareza: 'comun', puntos: 15, orden: 4, oculto: false, requisito: 1 },
  { codigo: 'sustituir_10', nombre: 'Maestro de Sustitutos', descripcion: 'Sustituye ingredientes en 10 recetas', categoria: 'creatividad', icono: '🔀', rareza: 'poco_comun', puntos: 70, orden: 5, oculto: false, requisito: 10 },
  { codigo: 'fusion_1', nombre: 'Fusión Culinaria', descripcion: 'Combina ingredientes de dos cocinas', categoria: 'creatividad', icono: '🌐', rareza: 'poco_comun', puntos: 60, orden: 6, oculto: false, requisito: 1 },
  { codigo: 'fusion_5', nombre: 'Maestro de Fusión', descripcion: 'Crea 5 recetas de fusión', categoria: 'creatividad', icono: '🔗', rareza: 'raro', puntos: 180, orden: 7, oculto: false, requisito: 5 },
  { codigo: 'propia_1', nombre: 'Primera Receta Propia', descripcion: 'Crea tu primera receta personal', categoria: 'creatividad', icono: '📝', rareza: 'poco_comun', puntos: 80, orden: 8, oculto: false, requisito: 1 },
  { codigo: 'propia_5', nombre: 'Creador de Recetas', descripcion: 'Crea 5 recetas personales', categoria: 'creatividad', icono: '👨‍🍳', rareza: 'raro', puntos: 200, orden: 9, oculto: false, requisito: 5 },
  { codigo: 'propia_10', nombre: 'Chef Creador', descripcion: 'Crea 10 recetas personales', categoria: 'creatividad', icono: '⭐', rareza: 'epico', puntos: 400, orden: 10, oculto: false, requisito: 10 },
  { codigo: 'variacion_5', nombre: 'Variador', descripcion: 'Crea 5 variaciones de una receta', categoria: 'creatividad', icono: '🔀', rareza: 'poco_comun', puntos: 80, orden: 11, oculto: false, requisito: 5 },
  { codigo: 'nombre_creativo_1', nombre: 'Nombre Original', descripcion: 'Pon un nombre creativo a una receta', categoria: 'creatividad', icono: '✨', rareza: 'comun', puntos: 20, orden: 12, oculto: false, requisito: 1 },
  { codigo: 'presentacion_5', nombre: 'Artista de la Presentación', descripcion: 'Presenta 5 recetas de forma creativa', categoria: 'creatividad', icono: '🎨', rareza: 'poco_comun', puntos: 100, orden: 13, oculto: false, requisito: 5 },
  { codigo: 'foto_1', nombre: 'Fotógrafo Culinario', descripcion: 'Haz una foto a tu receta', categoria: 'creatividad', icono: '📸', rareza: 'comun', puntos: 20, orden: 14, oculto: false, requisito: 1 },
  { codigo: 'foto_10', nombre: 'InstaChef', descripcion: 'Haz 10 fotos a tus recetas', categoria: 'creatividad', icono: '📱', rareza: 'poco_comun', puntos: 80, orden: 15, oculto: false, requisito: 10 },
  { codigo: 'foto_25', nombre: 'Foodie Profesional', descripcion: 'Haz 25 fotos a tus recetas', categoria: 'creatividad', icono: '📷', rareza: 'raro', puntos: 180, orden: 16, oculto: false, requisito: 25 },
  { codigo: 'decoracion_5', nombre: 'Decorador', descripcion: 'Decora 5 recetas de forma especial', categoria: 'creatividad', icono: '🎀', rareza: 'poco_comun', puntos: 80, orden: 17, oculto: false, requisito: 5 },
  { codigo: 'plating_10', nombre: 'Maestro del Plating', descripcion: 'Crea 10 presentaciones artísticas', categoria: 'creatividad', icono: '🍽️', rareza: 'raro', puntos: 200, orden: 18, oculto: false, requisito: 10 },
  { codigo: 'tematica_1', nombre: 'Chef Temático', descripcion: 'Crea una receta temática', categoria: 'creatividad', icono: '🎭', rareza: 'poco_comun', puntos: 60, orden: 19, oculto: false, requisito: 1 },
  { codigo: 'tematica_5', nombre: 'Temático Pro', descripcion: 'Crea 5 recetas temáticas', categoria: 'creatividad', icono: '🎪', rareza: 'raro', puntos: 150, orden: 20, oculto: false, requisito: 5 },
  { codigo: 'infantil_5', nombre: 'Chef Infantil', descripcion: 'Crea 5 recetas divertidas para niños', categoria: 'creatividad', icono: '🧒', rareza: 'poco_comun', puntos: 80, orden: 21, oculto: false, requisito: 5 },
  { codigo: 'colores_5', nombre: 'Arcoíris Culinario', descripcion: 'Crea 5 recetas coloridas', categoria: 'creatividad', icono: '🌈', rareza: 'poco_comun', puntos: 90, orden: 22, oculto: false, requisito: 5 },
  { codigo: 'experimento_5', nombre: 'Experimentador', descripcion: 'Realiza 5 experimentos culinarios', categoria: 'creatividad', icono: '🧪', rareza: 'poco_comun', puntos: 100, orden: 23, oculto: false, requisito: 5 },
  { codigo: 'arriesgado_5', nombre: 'Arriesgado', descripcion: 'Prueba 5 combinaciones atrevidas', categoria: 'creatividad', icono: '🎲', rareza: 'raro', puntos: 150, orden: 24, oculto: false, requisito: 5 },
  { codigo: 'exito_creativo_10', nombre: 'Éxito Creativo', descripcion: '10 recetas modificadas con éxito', categoria: 'creatividad', icono: '✅', rareza: 'poco_comun', puntos: 120, orden: 25, oculto: false, requisito: 10 },
  { codigo: 'version_dulce_5', nombre: 'Versión Dulce', descripcion: 'Convierte 5 recetas saladas en dulces', categoria: 'creatividad', icono: '🍬', rareza: 'raro', puntos: 180, orden: 26, oculto: false, requisito: 5 },
  { codigo: 'version_salada_5', nombre: 'Versión Salada', descripcion: 'Convierte 5 recetas dulces en saladas', categoria: 'creatividad', icono: '🧂', rareza: 'raro', puntos: 180, orden: 27, oculto: false, requisito: 5 },
  { codigo: 'toque_personal_20', nombre: 'Toque Personal', descripcion: 'Añade tu toque personal a 20 recetas', categoria: 'creatividad', icono: '✨', rareza: 'raro', puntos: 250, orden: 28, oculto: false, requisito: 20 },
  { codigo: 'creatividad_master', nombre: 'Maestro Creativo', descripcion: 'Completa todos los logros de creatividad', categoria: 'creatividad', icono: '🏆', rareza: 'epico', puntos: 500, orden: 29, oculto: true, requisito: 28 },
  { codigo: 'genio_culinario', nombre: 'Genio Culinario', descripcion: 'Crea una receta que otros cocinen', categoria: 'creatividad', icono: '🌟', rareza: 'legendario', puntos: 1000, orden: 30, oculto: true, requisito: 1 },

  // === ÉLITE - 30 logros (Legendarios y Épicos) ===
  { codigo: 'elite_inicio', nombre: 'Élite Iniciado', descripcion: 'Desbloquea 50 logros', categoria: 'elite', icono: '🌟', rareza: 'epico', puntos: 500, orden: 1, oculto: false, requisito: 50 },
  { codigo: 'elite_avanzado', nombre: 'Élite Avanzado', descripcion: 'Desbloquea 100 logros', categoria: 'elite', icono: '⭐', rareza: 'epico', puntos: 800, orden: 2, oculto: false, requisito: 100 },
  { codigo: 'elite_master', nombre: 'Élite Master', descripcion: 'Desbloquea 200 logros', categoria: 'elite', icono: '🏆', rareza: 'legendario', puntos: 1500, orden: 3, oculto: false, requisito: 200 },
  { codigo: 'elite_gran_master', nombre: 'Gran Master Élite', descripcion: 'Desbloquea 300 logros', categoria: 'elite', icono: '👑', rareza: 'legendario', puntos: 2500, orden: 4, oculto: false, requisito: 300 },
  { codigo: 'xp_1000', nombre: 'Mil Puntos', descripcion: 'Acumula 1000 puntos XP', categoria: 'elite', icono: '💰', rareza: 'poco_comun', puntos: 100, orden: 5, oculto: false, requisito: 1000 },
  { codigo: 'xp_5000', nombre: 'Cinco Mil Puntos', descripcion: 'Acumula 5000 puntos XP', categoria: 'elite', icono: '💎', rareza: 'raro', puntos: 300, orden: 6, oculto: false, requisito: 5000 },
  { codigo: 'xp_10000', nombre: 'Diez Mil Puntos', descripcion: 'Acumula 10000 puntos XP', categoria: 'elite', icono: '🏆', rareza: 'epico', puntos: 600, orden: 7, oculto: false, requisito: 10000 },
  { codigo: 'xp_25000', nombre: 'Veinticinco Mil Puntos', descripcion: 'Acumula 25000 puntos XP', categoria: 'elite', icono: '👑', rareza: 'legendario', puntos: 1200, orden: 8, oculto: false, requisito: 25000 },
  { codigo: 'xp_max', nombre: 'XP Legendario', descripcion: 'Acumula todos los puntos XP posibles', categoria: 'elite', icono: '💯', rareza: 'legendario', puntos: 3000, orden: 9, oculto: true, requisito: 50000 },
  { codigo: 'todas_categorias_master', nombre: 'Maestro de Categorías', descripcion: 'Completa todas las categorías de logros', categoria: 'elite', icono: '📂', rareza: 'legendario', puntos: 2000, orden: 10, oculto: false, requisito: 10 },
  { codigo: 'legendario_1', nombre: 'Primer Legendario', descripcion: 'Desbloquea tu primer logro legendario', categoria: 'elite', icono: '🔴', rareza: 'epico', puntos: 500, orden: 11, oculto: false, requisito: 1 },
  { codigo: 'legendario_5', nombre: 'Cinco Legendarios', descripcion: 'Desbloquea 5 logros legendarios', categoria: 'elite', icono: '🔴', rareza: 'legendario', puntos: 1500, orden: 12, oculto: false, requisito: 5 },
  { codigo: 'legendario_10', nombre: 'Diez Legendarios', descripcion: 'Desbloquea 10 logros legendarios', categoria: 'elite', icono: '🔴', rareza: 'legendario', puntos: 3000, orden: 13, oculto: false, requisito: 10 },
  { codigo: 'epico_10', nombre: 'Diez Épicos', descripcion: 'Desbloquea 10 logros épicos', categoria: 'elite', icono: '🟠', rareza: 'epico', puntos: 500, orden: 14, oculto: false, requisito: 10 },
  { codigo: 'epico_25', nombre: 'Veinticinco Épicos', descripcion: 'Desbloquea 25 logros épicos', categoria: 'elite', icono: '🟠', rareza: 'legendario', puntos: 1200, orden: 15, oculto: false, requisito: 25 },
  { codigo: 'raro_50', nombre: 'Cincuenta Raros', descripcion: 'Desbloquea 50 logros raros', categoria: 'elite', icono: '🟣', rareza: 'epico', puntos: 600, orden: 16, oculto: false, requisito: 50 },
  { codigo: 'poco_comun_100', nombre: 'Cien Poco Comunes', descripcion: 'Desbloquea 100 logros poco comunes', categoria: 'elite', icono: '🔵', rareza: 'raro', puntos: 400, orden: 17, oculto: false, requisito: 100 },
  { codigo: 'comun_200', nombre: 'Doscientos Comunes', descripcion: 'Desbloquea 200 logros comunes', categoria: 'elite', icono: '🟢', rareza: 'poco_comun', puntos: 300, orden: 18, oculto: false, requisito: 200 },
  { codigo: 'completar_onboarding', nombre: 'Onboarding Completo', descripcion: 'Completa todos los logros de inicio', categoria: 'elite', icono: '🎓', rareza: 'raro', puntos: 200, orden: 19, oculto: false, requisito: 15 },
  { codigo: 'completar_recetas', nombre: 'Recetas Master', descripcion: 'Completa todos los logros de recetas', categoria: 'elite', icono: '👨‍🍳', rareza: 'legendario', puntos: 2000, orden: 20, oculto: false, requisito: 50 },
  { codigo: 'completar_salud', nombre: 'Salud Master', descripcion: 'Completa todos los logros de salud', categoria: 'elite', icono: '💚', rareza: 'epico', puntos: 800, orden: 21, oculto: false, requisito: 30 },
  { codigo: 'completar_constancia', nombre: 'Constancia Master', descripcion: 'Completa todos los logros de constancia', categoria: 'elite', icono: '🔥', rareza: 'legendario', puntos: 2000, orden: 22, oculto: false, requisito: 35 },
  { codigo: 'completar_comunidad', nombre: 'Comunidad Master', descripcion: 'Completa todos los logros de comunidad', categoria: 'elite', icono: '👥', rareza: 'legendario', puntos: 1500, orden: 23, oculto: false, requisito: 30 },
  { codigo: 'completar_organizacion', nombre: 'Organización Master', descripcion: 'Completa todos los logros de organización', categoria: 'elite', icono: '📦', rareza: 'epico', puntos: 800, orden: 24, oculto: false, requisito: 30 },
  { codigo: 'completar_explorador', nombre: 'Explorador Master', descripcion: 'Completa todos los logros de explorador', categoria: 'elite', icono: '🌍', rareza: 'legendario', puntos: 2000, orden: 25, oculto: false, requisito: 40 },
  { codigo: 'completar_eficiencia', nombre: 'Eficiencia Master', descripcion: 'Completa todos los logros de eficiencia', categoria: 'elite', icono: '⚡', rareza: 'epico', puntos: 800, orden: 26, oculto: false, requisito: 30 },
  { codigo: 'completar_creatividad', nombre: 'Creatividad Master', descripcion: 'Completa todos los logros de creatividad', categoria: 'elite', icono: '🎨', rareza: 'legendario', puntos: 1500, orden: 27, oculto: false, requisito: 30 },
  { codigo: 'coleccionista_rarezas', nombre: 'Coleccionista de Rarezas', descripcion: 'Desbloquea al menos 1 de cada rareza', categoria: 'elite', icono: '🏆', rareza: 'epico', puntos: 400, orden: 28, oculto: false, requisito: 5 },
  { codigo: 'platinum', nombre: 'Platinum', descripcion: 'Completa TODOS los logros', categoria: 'elite', icono: '🏆', rareza: 'legendario', puntos: 10000, orden: 29, oculto: true, requisito: 350 },
  { codigo: 'cocinaviva_legend', nombre: 'Leyenda CocinaViva', descripcion: 'Conviértete en la máxima leyenda', categoria: 'elite', icono: '👑', rareza: 'legendario', puntos: 20000, orden: 30, oculto: true, requisito: 1 },
];

async function main() {
  console.log('🌱 Limpiando base de datos...');
  await prisma.receta.deleteMany();
  await prisma.logroUsuario.deleteMany();
  await prisma.logro.deleteMany();
  await prisma.configuracion.upsert({
    where: { id: 'config' },
    update: {},
    create: { id: 'config' }
  });
  
  console.log('✅ Base de datos limpia');
  
  // Crear logros
  console.log('📝 Creando 350 logros...');
  for (const logro of LOGROS) {
    await prisma.logro.create({
      data: logro
    });
  }
  console.log(`✅ ${LOGROS.length} logros creados`);
  
  // Crear progreso de usuario para todos los logros
  console.log('📝 Creando progreso de logros para usuario...');
  const logrosCreados = await prisma.logro.findMany();
  
  for (const logro of logrosCreados) {
    // Determinar estado del logro basado en rareza y categoría
    let desbloqueado = false;
    let progreso = 0;
    
    // Desbloquear todos los logros comunes de onboarding (primeros pasos)
    if (logro.categoria === 'onboarding' && logro.rareza === 'comun' && logro.orden <= 5) {
      desbloqueado = true;
      progreso = 100;
    }
    // Dar progreso aleatorio a logros no desbloqueados
    else if (logro.rareza === 'comun') {
      progreso = Math.floor(Math.random() * 100);
      if (progreso >= 100) {
        desbloqueado = true;
        progreso = 100;
      }
    } else if (logro.rareza === 'poco_comun') {
      progreso = Math.floor(Math.random() * 80);
    } else if (logro.rareza === 'raro') {
      progreso = Math.floor(Math.random() * 60);
    } else if (logro.rareza === 'epico') {
      progreso = Math.floor(Math.random() * 40);
    } else if (logro.rareza === 'legendario') {
      progreso = Math.floor(Math.random() * 20);
    }
    
    await prisma.logroUsuario.create({
      data: {
        logroId: logro.id,
        desbloqueado,
        fechaDesbloqueo: desbloqueado ? new Date() : null,
        progreso
      }
    });
  }
  console.log('✅ Progreso de logros creado');
  
  // Modificadores para generar más nombres únicos
  const MODIFICADORES_REGIONALES = [
    'Tradicional', 'Casero', 'De la Abuela', 'Al Estilo Clásico', 
    'De Autor', 'De Mercado', 'Campestre', 'Urbano', 'Festivo', 'De Temporada',
    'Premium', 'Selecto', 'Especial', 'Del Chef', 'Gourmet',
    'Regional', 'Local', 'Artesano', 'Rústico', 'Elegante'
  ];
  
  const MODIFICADORES_SABOR = [
    'Intenso', 'Suave', 'Aromático', 'Picante', 'Dulce', 
    'Ahumado', 'Crujiente', 'Cremoso', 'Ligero', 'Reconfortante'
  ];
  
  // Función para expandir nombres de recetas
  function expandirNombres(baseNames: string[], cocina: string): string[] {
    const expanded: string[] = [...baseNames];
    
    // Añadir variantes con modificadores
    for (const nombre of baseNames) {
      for (const mod of MODIFICADORES_REGIONALES.slice(0, 3)) {
        if (expanded.length < 50) {
          expanded.push(`${nombre} ${mod}`);
        }
      }
    }
    
    return expanded;
  }
  
  // Generar recetas tradicionales únicas
  console.log('📝 Generando 1000 recetas tradicionales únicas...');
  
  const recetasUnicas = new Set<string>();
  let recetasTradicionales = 0;
  let seed = 1;
  
  const cocinas = Object.keys(NOMBRES_RECETAS);
  const targetTradicionales = 1000;
  
  // Primero añadir todas las recetas con nombres únicos
  for (const cocina of cocinas) {
    if (recetasTradicionales >= targetTradicionales) break;
    
    const nombresBase = NOMBRES_RECETAS[cocina] || [];
    const nombresExpandidos = expandirNombres(nombresBase, cocina);
    
    for (let idx = 0; idx < nombresExpandidos.length && recetasTradicionales < targetTradicionales; idx++) {
      const nombre = nombresExpandidos[idx];
      const nombreCompleto = `${nombre} (Tradicional)`;
      
      if (recetasUnicas.has(nombreCompleto)) continue;
      recetasUnicas.add(nombreCompleto);
      
      const categoria = getElementByIndex(CATEGORIAS, seed);
      const dificultad = getElementByIndex(DIFICULTADES, seed);
      const tiempoPreparacion = getIntByIndex(10, 45, seed);
      const tiempoCoccion = getIntByIndex(10, 90, seed);
      const tiempoTotal = tiempoPreparacion + tiempoCoccion;
      const calorias = getIntByIndex(150, 700, seed);
      const porciones = getIntByIndex(2, 6, seed);
      
      const ingredientes = generarIngredientes(categoria, cocina, seed);
      const pasos = generarPasos(ingredientes, false, seed);
      const imagenes = generarImagen(categoria, cocina, seed);
      
      const consejos = [
        'Servir caliente para disfrutar de todo su sabor.',
        'Puedes prepararlo con antelación y calentar antes de servir.',
        'Acompañar con pan fresco recién horneado.',
        'Ideal para cenas familiares especiales.',
        'Perfecto para ocasiones especiales y celebraciones.',
        'Se puede congelar hasta 3 meses en recipiente hermético.',
        'Mejor si se deja reposar 10 minutos antes de servir.',
        'Añadir hierbas frescas justo antes de servir.',
        'El secreto está en la calidad de los ingredientes.',
        'No escatimes en el tiempo de cocción para mejores resultados.',
      ];
      
      await prisma.receta.create({
        data: {
          nombre,
          descripcion: `Deliciosa receta tradicional ${cocina} de ${categoria}. Una preparación auténtica con ingredientes frescos y todo el sabor de la cocina tradicional.`,
          tiempoPreparacion,
          tiempoCoccion,
          tiempoTotal,
          dificultad,
          porciones,
          calorias,
          tipo: 'tradicional',
          categoria,
          cocina,
          imagen: imagenes.principal,
          imagenes: JSON.stringify(imagenes.adicionales),
          ingredientes: JSON.stringify(ingredientes),
          pasos: JSON.stringify(pasos),
          consejos: getElementByIndex(consejos, seed),
          valoracion: Number((3.5 + (seed % 15) / 10).toFixed(1)),
          numValoraciones: getIntByIndex(20, 300, seed)
        }
      });
      
      recetasTradicionales++;
      seed++;
      
      if (recetasTradicionales % 100 === 0) {
        console.log(`   ✓ ${recetasTradicionales} recetas tradicionales generadas`);
      }
      
      if (recetasTradicionales >= 1000) break;
    }
    
    if (recetasTradicionales >= 1000) break;
  }
  
  console.log(`✅ ${recetasTradicionales} recetas tradicionales creadas`);
  
  // Generar recetas Thermomix únicas
  console.log('📝 Generando 1000 recetas Thermomix únicas...');
  
  let recetasThermomix = 0;
  const targetThermomix = 1000;
  
  for (const cocina of cocinas) {
    if (recetasThermomix >= targetThermomix) break;
    
    const nombresBase = NOMBRES_RECETAS[cocina] || [];
    const nombresExpandidos = expandirNombres(nombresBase, cocina);
    
    for (let idx = 0; idx < nombresExpandidos.length && recetasThermomix < targetThermomix; idx++) {
      const nombreBase = nombresExpandidos[idx];
      const nombre = `${nombreBase} Thermomix`;
      const nombreCompleto = `${nombre} (Thermomix)`;
      
      if (recetasUnicas.has(nombreCompleto)) continue;
      recetasUnicas.add(nombreCompleto);
      
      const categoria = getElementByIndex(CATEGORIAS, seed);
      const dificultad = getElementByIndex(DIFICULTADES, seed);
      const tiempoPreparacion = getIntByIndex(5, 25, seed);
      const tiempoCoccion = getIntByIndex(5, 45, seed);
      const tiempoTotal = tiempoPreparacion + tiempoCoccion;
      const calorias = getIntByIndex(150, 650, seed);
      const porciones = getIntByIndex(2, 6, seed);
      
      const ingredientes = generarIngredientes(categoria, cocina, seed);
      const pasos = generarPasos(ingredientes, true, seed);
      const imagenes = generarImagen(categoria, cocina, seed);
      
      const consejosThermomix = [
        'Utilizar la Thermomix para obtener una textura perfecta y homogénea.',
        'Ideal para preparar en Thermomix TM5 o TM6 con excelentes resultados.',
        'Puedes ajustar la velocidad según tu preferencia personal.',
        'Los tiempos indicados son para Thermomix TM6, ajusta si usas TM5.',
        'Consulta el libro de instrucciones para variaciones creativas.',
        'Perfecto para preparar con antelación y calentar después.',
        'El vaso debe estar bien cerrado durante la cocción.',
        'Utiliza la función de pesada para medir ingredientes con precisión.',
        'Aprovecha la función Varoma para cocinar al vapor.',
        'Los tiempos de triturado pueden variar según los ingredientes.',
      ];
      
      await prisma.receta.create({
        data: {
          nombre,
          descripcion: `Versión Thermomix de la receta tradicional ${cocina}. Preparación fácil y rápida con tu robot de cocina para resultados perfectos.`,
          tiempoPreparacion,
          tiempoCoccion,
          tiempoTotal,
          dificultad,
          porciones,
          calorias,
          tipo: 'thermomix',
          categoria,
          cocina,
          imagen: imagenes.principal,
          imagenes: JSON.stringify(imagenes.adicionales),
          ingredientes: JSON.stringify(ingredientes),
          pasos: JSON.stringify(pasos),
          consejos: getElementByIndex(consejosThermomix, seed),
          valoracion: Number((3.5 + (seed % 15) / 10).toFixed(1)),
          numValoraciones: getIntByIndex(15, 250, seed)
        }
      });
      
      recetasThermomix++;
      seed++;
      
      if (recetasThermomix % 100 === 0) {
        console.log(`   ✓ ${recetasThermomix} recetas Thermomix generadas`);
      }
      
      if (recetasThermomix >= 1000) break;
    }
    
    if (recetasThermomix >= 1000) break;
  }
  
  console.log(`✅ ${recetasThermomix} recetas Thermomix creadas`);
  
  // Crear lista de compra de ejemplo
  console.log('📝 Creando lista de compra de ejemplo...');
  await prisma.listaCompra.create({
    data: {
      nombre: 'Lista semanal',
      items: {
        create: [
          { ingrediente: 'Tomate', cantidad: 500, unidad: 'g', orden: 0 },
          { ingrediente: 'Cebolla', cantidad: 3, unidad: 'unidad', orden: 1 },
          { ingrediente: 'Ajo', cantidad: 1, unidad: 'cabeza', orden: 2 },
          { ingrediente: 'Aceite de oliva virgen', cantidad: 500, unidad: 'ml', orden: 3 },
          { ingrediente: 'Arroz', cantidad: 1, unidad: 'kg', orden: 4 },
        ]
      }
    }
  });
  
  // Crear menú de ejemplo
  await prisma.menu.create({
    data: {
      nombre: 'Menú Semanal Familiar',
      descripcion: 'Un menú equilibrado para toda la semana con recetas tradicionales y Thermomix'
    }
  });
  
  console.log('🎉 ¡Semilla completada con éxito!');
  console.log(`📊 Total: ${recetasTradicionales + recetasThermomix} recetas únicas en la base de datos`);
  console.log(`📊 Recetas únicas rastreadas: ${recetasUnicas.size}`);
}

main()
  .catch(e => {
    console.error('❌ Error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
