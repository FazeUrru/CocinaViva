#!/bin/bash

# Script para mantener el servidor de CocinaViva funcionando de forma estable
# Mata cualquier proceso existente primero
pkill -9 -f "next dev" 2>/dev/null
pkill -9 -f "next" 2>/dev/null
sleep 2

# Iniciar el servidor en segundo plano con nohup
cd /home/z/my-project
nohup bun run dev > /home/z/my-project/server.log 2>&1 &

# Esperar a que el servidor inicie
sleep 5

# Verificar que el servidor está corriendo
if pgrep -f "next dev" > /dev/null; then
    echo "✅ Servidor iniciado correctamente"
    echo "PID: $(pgrep -f 'next dev')"
    tail -10 /home/z/my-project/server.log
else
    echo "❌ Error al iniciar el servidor"
    cat /home/z/my-project/server.log
fi
