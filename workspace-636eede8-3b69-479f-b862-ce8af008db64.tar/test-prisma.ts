import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Available models:', Object.keys(prisma).filter(k => !k.startsWith('_') && !k.startsWith('$')));
  
  const logroCount = await prisma.logro.count();
  console.log('Logros count:', logroCount);
  
  const recetaCount = await prisma.receta.count();
  console.log('Recetas count:', recetaCount);
  
  await prisma.$disconnect();
}

main().catch(e => {
  console.error('Error:', e);
  process.exit(1);
});
