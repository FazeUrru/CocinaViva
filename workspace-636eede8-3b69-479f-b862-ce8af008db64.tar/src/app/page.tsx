'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { useTheme } from 'next-themes';
import {
  Search, Heart, ShoppingCart, Calendar, Settings, ChefHat,
  Clock, Users, Flame, Star, Share2, Printer, ChevronLeft,
  ChevronRight, X, Check, Plus, Minus, Trash2, Download,
  Upload, HelpCircle, Sun, Moon, Monitor, Volume2, VolumeX,
  Sparkles, Filter, RefreshCw, Home, BookOpen, Utensils,
  Trophy, Target, BarChart3, Lock, Unlock, Gift, Zap, Eye,
  EyeOff, Type, Image as ImageIcon, List, Layout, SortAsc, Shield,
  Accessibility, Contrast, Volume1, User, FileText, Maximize2, EyeIcon,
  Mic, MicOff, Timer, Calculator, DollarSign, Replace, StickyNote,
  FolderPlus, Refrigerator, Scale, Hash, AlertCircle, Play, Pause,
  Bot, PieChart, CalendarDays, Headphones, Wand2, Loader2, Send,
  Code, Edit, Database, Wrench, Palette, RefreshCw as RefreshCw2, Trophy as Trophy2,
  ArrowUpDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useAppStore, type Receta } from '@/lib/store';
import { toast } from 'sonner';

// ==================== TIPOS ====================

interface Logro {
  id: string;
  codigo: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  icono: string;
  rareza: string;
  puntos: number;
  orden: number;
  oculto: boolean;
  requisito: number;
}

interface LogroUsuario {
  id: string;
  logroId: string;
  desbloqueado: boolean;
  fechaDesbloqueo: string | null;
  progreso: number;
  logro: Logro;
}

interface Desafio {
  id: string;
  nombre: string;
  descripcion: string;
  tipo: string;
  fechaInicio: string;
  fechaFin: string;
  recompensa: number;
  activo: boolean;
}

interface DesafioUsuario {
  id: string;
  desafioId: string;
  completado: boolean;
  progreso: number;
  desafio: Desafio;
}

// ==================== STORE DE CONFIGURACIÓN LOCAL ====================

interface LocalConfig {
  idioma: 'es' | 'en' | 'ca' | 'gl' | 'eu' | 'fr' | 'de' | 'it' | 'pt' | 'ru' | 'zh' | 'ja' | 'ko' | 'ar' | 'hi' | 'nl' | 'pl' | 'tr' | 'vi' | 'th' | 'sv' | 'da' | 'no' | 'fi' | 'el';
  sistemaUnidades: 'metrico' | 'imperial';
  tamanoFuente: 'pequeno' | 'mediano' | 'grande' | 'xl';
  notificaciones: boolean;
  restricciones: string[];
  numeroComensales: number;
  unidadTiempo: 'minutos' | 'horas';
  regionGastronomica: string;
  animaciones: boolean;
  sonidos: boolean;
  autoguardado: boolean;
  vistaCompacta: boolean;
  calidadImagenes: 'alta' | 'media' | 'baja';
  mostrarAyuda: boolean;
  
  // Visualización y Lectura
  vistaPasos: 'lista' | 'tarjetas';
  ocultarFotos: boolean;
  
  // Orden predeterminado
  ordenRecetas: 'alfabetico' | 'mejorValoradas' | 'masRecientes' | 'tiempoCoccion';
  
  // Privacidad y Cuenta
  perfilPublico: boolean;
  ocultarHistorial: boolean;
  
  // Accesibilidad
  altoContraste: boolean;
  reducirMovimiento: boolean;
  ttsActivo: boolean;

  // Ajustes de Usuario (10 nuevos)
  nivelCocina: 'principiante' | 'aficionado' | 'intermedio' | 'avanzado' | 'experto';
  biografia: string;
  ubicacion: string;
  mostrarLogros: boolean;
  sugerenciasSemanales: boolean;
  idiomaRecetas: string;
  cocinaFavorita: string;
  recetasPorPagina: number;
  confirmarEliminar: boolean;
}

const defaultConfig: LocalConfig = {
  idioma: 'es',
  sistemaUnidades: 'metrico',
  tamanoFuente: 'mediano',
  notificaciones: true,
  restricciones: [],
  numeroComensales: 4,
  unidadTiempo: 'minutos',
  regionGastronomica: 'espanola',
  animaciones: true,
  sonidos: true,
  autoguardado: true,
  vistaCompacta: false,
  calidadImagenes: 'alta',
  mostrarAyuda: false,
  
  // Visualización y Lectura
  vistaPasos: 'lista',
  ocultarFotos: false,
  
  // Orden predeterminado
  ordenRecetas: 'mejorValoradas',
  
  // Privacidad y Cuenta
  perfilPublico: false,
  ocultarHistorial: false,
  
  // Accesibilidad
  altoContraste: false,
  reducirMovimiento: false,
  ttsActivo: false,

  // Ajustes de Usuario (10 nuevos)
  nivelCocina: 'aficionado',
  biografia: '',
  ubicacion: '',
  mostrarLogros: true,
  sugerenciasSemanales: true,
  idiomaRecetas: 'es',
  cocinaFavorita: 'espanola',
  recetasPorPagina: 12,
  confirmarEliminar: true,
};

function useLocalConfig() {
  const [config, setConfigState] = useState<LocalConfig>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cocinaviva-local-config');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {
          console.error('Error loading config');
        }
      }
    }
    return defaultConfig;
  });
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      setMounted(true);
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  const setConfig = useCallback((updates: Partial<LocalConfig>) => {
    setConfigState(prev => {
      const newConfig = { ...prev, ...updates };
      if (typeof window !== 'undefined') {
        localStorage.setItem('cocinaviva-local-config', JSON.stringify(newConfig));
        // Dispatch custom event to notify other components
        window.dispatchEvent(new CustomEvent('cocinaviva-config-change'));
      }
      return newConfig;
    });
  }, []);

  const exportarDatos = useCallback(() => {
    const datos = JSON.stringify(config, null, 2);
    const blob = new Blob([datos], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cocinaviva-config.json';
    a.click();
    URL.revokeObjectURL(url);
    toast.success('Configuración exportada correctamente');
  }, [config]);

  const importarDatos = useCallback((datos: string) => {
    try {
      const parsed = JSON.parse(datos);
      setConfigState(prev => {
        const newConfig = { ...prev, ...parsed };
        if (typeof window !== 'undefined') {
          localStorage.setItem('cocinaviva-local-config', JSON.stringify(newConfig));
        }
        return newConfig;
      });
      toast.success('Configuración importada correctamente');
    } catch {
      toast.error('Error al importar configuración');
    }
  }, []);

  return { config, setConfig, exportarDatos, importarDatos, mounted };
}

// ==================== COMPONENTES DE LOGROS ====================

function PanelLogros({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [logros, setLogros] = useState<Logro[]>([]);
  const [logrosUsuario, setLogrosUsuario] = useState<LogroUsuario[]>([]);
  const [categoriaActiva, setCategoriaActiva] = useState<string>('todas');
  const [logroExpandido, setLogroExpandido] = useState<Logro | null>(null);
  const [esFullsceen, setEsFullscreen] = useState(false);

  useEffect(() => {
    if (abierto) {
      fetch('/api/achievements?v=2')
        .then(res => res.json())
        .then(data => {
          setLogros(data.logros || []);
          setLogrosUsuario(data.logrosUsuario || []);
        })
        .catch(console.error);
    }
  }, [abierto]);

  const categorias = [
    { id: 'todas', nombre: 'Todas', icono: '🏆' },
    { id: 'onboarding', nombre: 'Primeros Pasos', icono: '🍳' },
    { id: 'recetas', nombre: 'Maestro Recetas', icono: '👨‍🍳' },
    { id: 'salud', nombre: 'Salud', icono: '💚' },
    { id: 'constancia', nombre: 'Constancia', icono: '🔥' },
    { id: 'comunidad', nombre: 'Comunidad', icono: '👥' },
    { id: 'organizacion', nombre: 'Organización', icono: '📦' },
    { id: 'explorador', nombre: 'Explorador', icono: '🌍' },
    { id: 'eficiencia', nombre: 'Eficiencia', icono: '⚡' },
    { id: 'creatividad', nombre: 'Creatividad', icono: '🎨' },
    { id: 'elite', nombre: 'Élite', icono: '👑' },
  ];

  // Rareza colors and labels
  const rarezaConfig: Record<string, { color: string; bg: string; border: string; label: string; emoji: string; gradient: string }> = {
    comun: { 
      color: 'text-emerald-600', 
      bg: 'bg-emerald-100 dark:bg-emerald-950/50', 
      border: 'border-emerald-300 dark:border-emerald-800', 
      label: 'Común', 
      emoji: '🟢',
      gradient: 'from-emerald-500 to-emerald-600'
    },
    poco_comun: { 
      color: 'text-blue-600', 
      bg: 'bg-blue-100 dark:bg-blue-950/50', 
      border: 'border-blue-300 dark:border-blue-800', 
      label: 'Poco común', 
      emoji: '🔵',
      gradient: 'from-blue-500 to-blue-600'
    },
    raro: { 
      color: 'text-purple-600', 
      bg: 'bg-purple-100 dark:bg-purple-950/50', 
      border: 'border-purple-300 dark:border-purple-800', 
      label: 'Raro', 
      emoji: '🟣',
      gradient: 'from-purple-500 to-purple-600'
    },
    epico: { 
      color: 'text-orange-600', 
      bg: 'bg-orange-100 dark:bg-orange-950/50', 
      border: 'border-orange-300 dark:border-orange-800', 
      label: 'Épico', 
      emoji: '🟠',
      gradient: 'from-orange-500 to-red-500'
    },
    legendario: { 
      color: 'text-red-600', 
      bg: 'bg-gradient-to-br from-red-100 to-yellow-100 dark:from-red-950/50 dark:to-yellow-950/50', 
      border: 'border-yellow-400 dark:border-yellow-700', 
      label: 'Legendario', 
      emoji: '🔴',
      gradient: 'from-red-500 via-yellow-500 to-red-500'
    },
  };

  const getRarezaStyle = (rareza: string) => rarezaConfig[rareza] || rarezaConfig.comun;

  const logrosFiltrados = categoriaActiva === 'todas' 
    ? logros 
    : logros.filter(l => l.categoria === categoriaActiva);

  const getLogroUsuario = (logroId: string) => {
    return logrosUsuario.find(lu => lu.logroId === logroId);
  };

  const totalDesbloqueados = logrosUsuario.filter(lu => lu.desbloqueado).length;
  const totalPuntos = logrosUsuario.reduce((acc, lu) => lu.desbloqueado ? acc + (lu.logro?.puntos || 0) : acc, 0);
  const maxPuntos = logros.reduce((acc, l) => acc + l.puntos, 0);
  const porcentajeCompletado = logros.length > 0 ? Math.round((totalDesbloqueados / logros.length) * 100) : 0;

  // TTS function
  const hablar = (texto: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(texto);
      utterance.lang = 'es-ES';
      utterance.rate = 0.9;
      speechSynthesis.speak(utterance);
    }
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className={`${esFullsceen ? 'max-w-[95vw] max-h-[95vh]' : 'max-w-4xl max-h-[90vh]'} overflow-hidden flex flex-col transition-all duration-300`}>
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Trophy className="h-6 w-6 text-yellow-500" />
              Logros de CocinaViva
            </DialogTitle>
            <Button variant="ghost" size="icon" onClick={() => setEsFullscreen(!esFullsceen)}>
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
          <DialogDescription>
            Desbloquea logros cocinando y explorando la aplicación
          </DialogDescription>
        </DialogHeader>
        
        {/* Stats resumen con XP */}
        <div className="bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-950/30 dark:to-amber-950/30 rounded-lg p-4 border border-yellow-200 dark:border-yellow-800">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="relative">
                <Trophy className="h-8 w-8 text-yellow-500" />
                <span className="absolute -top-1 -right-1 bg-yellow-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                  {porcentajeCompletado}%
                </span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Progreso total</p>
                <p className="font-bold text-lg">{totalDesbloqueados} de {logros.length}</p>
              </div>
            </div>
            
            <div className="text-right">
              <div className="flex items-center gap-2 justify-end">
                <Zap className="h-6 w-6 text-amber-500" />
                <span className="text-2xl font-bold text-amber-600">{totalPuntos.toLocaleString()}</span>
              </div>
              <p className="text-sm text-muted-foreground">de {maxPuntos.toLocaleString()} XP máx</p>
            </div>
          </div>
          
          <Progress value={porcentajeCompletado} className="h-3" />
        </div>

        {/* Categorías */}
        <div className="flex gap-1 flex-wrap pb-2">
          {categorias.map(cat => {
            const count = cat.id === 'todas' ? logros.length : logros.filter(l => l.categoria === cat.id).length;
            const unlocked = cat.id === 'todas' 
              ? totalDesbloqueados 
              : logrosUsuario.filter(lu => lu.desbloqueado && logros.find(l => l.id === lu.logroId)?.categoria === cat.id).length;
            
            return (
              <Button
                key={cat.id}
                variant={categoriaActiva === cat.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCategoriaActiva(cat.id)}
                className="gap-1 relative"
              >
                <span>{cat.icono}</span>
                <span className="hidden sm:inline">{cat.nombre}</span>
                <Badge variant="secondary" className="ml-1 h-5 px-1 text-xs">
                  {unlocked}/{count}
                </Badge>
              </Button>
            );
          })}
        </div>

        {/* Grid de logros */}
        <ScrollArea className="flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-3 p-1">
            {logrosFiltrados.map(logro => {
              const logroUsuario = getLogroUsuario(logro.id);
              const desbloqueado = logroUsuario?.desbloqueado || false;
              const progreso = logroUsuario?.progreso || 0;
              const rarezaStyle = getRarezaStyle(logro.rareza || 'comun');

              return (
                <div
                  key={logro.id}
                  onClick={() => setLogroExpandido(logro)}
                  className={`relative p-3 rounded-lg border transition-all cursor-pointer hover:scale-[1.02] ${
                    desbloqueado 
                      ? 'bg-gradient-to-br from-yellow-50 to-amber-50 dark:from-yellow-950/30 dark:to-amber-950/30 border-yellow-300 dark:border-yellow-800 shadow-lg' 
                      : `${rarezaStyle.bg} ${rarezaStyle.border}`
                  }`}
                >
                  {/* Indicador de rareza */}
                  <div className={`absolute top-2 right-2 w-3 h-3 rounded-full bg-gradient-to-br ${rarezaStyle.gradient}`} />
                  
                  <div className="flex items-start gap-3">
                    <div className={`text-3xl ${!desbloqueado && 'opacity-40 grayscale'}`}>
                      {logro.icono}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-medium text-sm truncate">{logro.nombre}</h3>
                        {desbloqueado && (
                          <Unlock className="h-4 w-4 text-yellow-500 flex-shrink-0" />
                        )}
                        {!desbloqueado && logro.oculto && (
                          <Lock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                        {logro.oculto && !desbloqueado ? '???' : logro.descripcion}
                      </p>
                      
                      {/* Barra de progreso */}
                      {!desbloqueado && progreso > 0 && (
                        <div className="mt-2">
                          <div className="flex justify-between text-xs mb-1">
                            <span className="text-muted-foreground">Progreso</span>
                            <span className="font-medium">{progreso}%</span>
                          </div>
                          <Progress value={progreso} className="h-1.5" />
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                        <Badge variant="secondary" className="text-xs gap-1">
                          <Zap className="h-3 w-3" />
                          {logro.puntos} XP
                        </Badge>
                        <Badge variant="outline" className={`text-xs ${rarezaStyle.color}`}>
                          {rarezaStyle.emoji} {rarezaStyle.label}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
        
        {/* Modal de logro expandido */}
        {logroExpandido && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setLogroExpandido(null)}>
            <div
              className="bg-background rounded-xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200"
              onClick={e => e.stopPropagation()}
            >
              {(() => {
                const logro = logroExpandido;
                const logroUsuario = getLogroUsuario(logro.id);
                const desbloqueado = logroUsuario?.desbloqueado || false;
                const progreso = logroUsuario?.progreso || 0;
                const rarezaStyle = getRarezaStyle(logro.rareza || 'comun');
                
                return (
                  <>
                    <div className="text-center">
                      <div className={`text-6xl mb-4 ${!desbloqueado && 'opacity-40 grayscale'}`}>
                        {logro.icono}
                      </div>
                      <h2 className="text-xl font-bold mb-1">{logro.nombre}</h2>
                      <Badge className={`${rarezaStyle.bg} ${rarezaStyle.color} mb-3`}>
                        {rarezaStyle.emoji} {rarezaStyle.label}
                      </Badge>
                      <p className="text-muted-foreground">{logro.descripcion}</p>
                      
                      <div className="mt-4 flex justify-center gap-4">
                        <div className="text-center">
                          <Zap className="h-6 w-6 mx-auto text-amber-500" />
                          <p className="text-2xl font-bold">{logro.puntos}</p>
                          <p className="text-xs text-muted-foreground">XP</p>
                        </div>
                        {logro.requisito > 1 && (
                          <div className="text-center">
                            <Target className="h-6 w-6 mx-auto text-emerald-500" />
                            <p className="text-2xl font-bold">{logro.requisito}</p>
                            <p className="text-xs text-muted-foreground">Veces</p>
                          </div>
                        )}
                      </div>
                      
                      {!desbloqueado && progreso > 0 && (
                        <div className="mt-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progreso</span>
                            <span className="font-medium">{progreso}%</span>
                          </div>
                          <Progress value={progreso} className="h-2" />
                        </div>
                      )}
                      
                      {desbloqueado && (
                        <div className="mt-4 text-emerald-600 font-medium">
                          ✓ Desbloqueado
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 mt-4">
                      <Button variant="outline" size="sm" onClick={() => hablar(logro.descripcion)}>
                        <Volume1 className="h-4 w-4 mr-1" />
                        Leer
                      </Button>
                      <Button size="sm" onClick={() => setLogroExpandido(null)}>
                        Cerrar
                      </Button>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ==================== COMPONENTES DE DESAFÍOS ====================

function PanelDesafios({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [desafios, setDesafios] = useState<Desafio[]>([]);
  const [desafiosUsuario, setDesafiosUsuario] = useState<DesafioUsuario[]>([]);

  useEffect(() => {
    if (abierto) {
      fetch('/api/desafios')
        .then(res => res.json())
        .then(data => {
          setDesafios(data.desafios || []);
          setDesafiosUsuario(data.desafiosUsuario || []);
        })
        .catch(console.error);
    }
  }, [abierto]);

  const getDesafioUsuario = (desafioId: string) => {
    return desafiosUsuario.find(du => du.desafioId === desafioId);
  };

  const desafiosDiarios = desafios.filter(d => d.tipo === 'diario' && d.activo);
  const desafiosSemanales = desafios.filter(d => d.tipo === 'semanal' && d.activo);

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Target className="h-5 w-5 text-emerald-500" />
            Desafíos
          </DialogTitle>
          <DialogDescription>
            Completa desafíos para ganar puntos y desbloquear logros
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          {/* Desafíos diarios */}
          <div className="mb-6">
            <h3 className="font-semibold flex items-center gap-2 mb-3">
              <Zap className="h-4 w-4 text-amber-500" />
              Desafíos Diarios
            </h3>
            <div className="space-y-3">
              {desafiosDiarios.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="pt-4 text-center text-muted-foreground">
                    No hay desafíos diarios activos
                  </CardContent>
                </Card>
              ) : (
                desafiosDiarios.map(desafio => {
                  const du = getDesafioUsuario(desafio.id);
                  const completado = du?.completado || false;
                  const progreso = du?.progreso || 0;

                  return (
                    <Card key={desafio.id} className={completado ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300' : ''}>
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">{desafio.nombre}</h4>
                              {completado && <Check className="h-4 w-4 text-emerald-500" />}
                            </div>
                            <p className="text-sm text-muted-foreground">{desafio.descripcion}</p>
                            {!completado && progreso > 0 && (
                              <Progress value={progreso} className="h-2 mt-2" />
                            )}
                          </div>
                          <Badge variant={completado ? 'default' : 'secondary'} className="ml-4">
                            <Gift className="h-3 w-3 mr-1" />
                            {desafio.recompensa} pts
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </div>

          {/* Desafíos semanales */}
          <div>
            <h3 className="font-semibold flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-blue-500" />
              Desafíos Semanales
            </h3>
            <div className="space-y-3">
              {desafiosSemanales.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="pt-4 text-center text-muted-foreground">
                    No hay desafíos semanales activos
                  </CardContent>
                </Card>
              ) : (
                desafiosSemanales.map(desafio => {
                  const du = getDesafioUsuario(desafio.id);
                  const completado = du?.completado || false;
                  const progreso = du?.progreso || 0;

                  return (
                    <Card key={desafio.id} className={completado ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-300' : ''}>
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium">{desafio.nombre}</h4>
                              {completado && <Check className="h-4 w-4 text-emerald-500" />}
                            </div>
                            <p className="text-sm text-muted-foreground">{desafio.descripcion}</p>
                            {!completado && progreso > 0 && (
                              <Progress value={progreso} className="h-2 mt-2" />
                            )}
                          </div>
                          <Badge variant={completado ? 'default' : 'secondary'} className="ml-4">
                            <Gift className="h-3 w-3 mr-1" />
                            {desafio.recompensa} pts
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== COMPONENTES DE ESTADÍSTICAS ====================

function PanelEstadisticas({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [stats, setStats] = useState({
    recetasVistas: 0,
    recetasCocinadas: 0,
    busquedasRealizadas: 0,
    listasCreadas: 0,
    tiempoTotalCocina: 0,
    favoritos: 0,
    logrosDesbloqueados: 0,
    puntos: 0,
  });

  useEffect(() => {
    if (abierto) {
      fetch('/api/estadisticas')
        .then(res => res.json())
        .then(setStats)
        .catch(console.error);
    }
  }, [abierto]);

  const statCards = [
    { label: 'Recetas vistas', value: stats.recetasVistas, icon: Eye, color: 'text-blue-500' },
    { label: 'Recetas cocinadas', value: stats.recetasCocinadas, icon: ChefHat, color: 'text-orange-500' },
    { label: 'Búsquedas', value: stats.busquedasRealizadas, icon: Search, color: 'text-purple-500' },
    { label: 'Listas creadas', value: stats.listasCreadas, icon: ShoppingCart, color: 'text-emerald-500' },
    { label: 'Tiempo cocina', value: `${Math.round(stats.tiempoTotalCocina / 60)}h`, icon: Clock, color: 'text-amber-500' },
    { label: 'Favoritos', value: stats.favoritos, icon: Heart, color: 'text-rose-500' },
    { label: 'Logros', value: stats.logrosDesbloqueados, icon: Trophy, color: 'text-yellow-500' },
    { label: 'Puntos totales', value: stats.puntos, icon: Zap, color: 'text-cyan-500' },
  ];

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <BarChart3 className="h-5 w-5 text-blue-500" />
            Mis Estadísticas
          </DialogTitle>
          <DialogDescription>
            Tu actividad en CocinaViva
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          {statCards.map((stat, i) => (
            <Card key={i} className="text-center">
              <CardContent className="pt-4 pb-3">
                <stat.icon className={`h-6 w-6 mx-auto mb-2 ${stat.color}`} />
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Progreso semanal */}
        <Card className="mt-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Actividad esta semana</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end gap-1 h-20">
              {[40, 60, 30, 80, 50, 90, 45].map((h, i) => (
                <div
                  key={i}
                  className="flex-1 bg-gradient-to-t from-orange-500 to-amber-400 rounded-t"
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>
            <div className="flex justify-between mt-2 text-xs text-muted-foreground">
              {['L', 'M', 'X', 'J', 'V', 'S', 'D'].map((d, i) => (
                <span key={i}>{d}</span>
              ))}
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}

// ==================== CHEF IA (NUEVA FUNCIONALIDAD 1) ====================

function PanelChefIA({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [ingredientes, setIngredientes] = useState<string[]>(['', '']);
  const [herramienta, setHerramienta] = useState<'tradicional' | 'thermomix'>('tradicional');
  const [generando, setGenerando] = useState(false);
  const [recetaGenerada, setRecetaGenerada] = useState<{
    nombre: string;
    descripcion: string;
    ingredientes: { nombre: string; cantidad: string }[];
    pasos: string[];
    tiempo: string;
    dificultad: string;
    consejos: string;
  } | null>(null);

  const agregarIngrediente = () => {
    setIngredientes([...ingredientes, '']);
  };

  const actualizarIngrediente = (index: number, valor: string) => {
    const nuevos = [...ingredientes];
    nuevos[index] = valor;
    setIngredientes(nuevos);
  };

  const eliminarIngrediente = (index: number) => {
    if (ingredientes.length > 2) {
      setIngredientes(ingredientes.filter((_, i) => i !== index));
    }
  };

  const generarReceta = async () => {
    const ingredientesValidos = ingredientes.filter(i => i.trim() !== '');
    if (ingredientesValidos.length < 2) {
      toast.error('Añade al menos 2 ingredientes');
      return;
    }

    setGenerando(true);
    setRecetaGenerada(null);

    try {
      const response = await fetch('/api/chef-ia', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ingredientes: ingredientesValidos,
          herramienta
        })
      });

      if (!response.ok) throw new Error('Error al generar receta');

      const data = await response.json();
      setRecetaGenerada(data.receta);
      toast.success('¡Receta generada con éxito!');
    } catch (error) {
      console.error(error);
      toast.error('Error al generar la receta. Inténtalo de nuevo.');
    } finally {
      setGenerando(false);
    }
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Bot className="h-6 w-6 text-violet-500" />
            Chef IA
            <Badge className="bg-gradient-to-r from-violet-500 to-purple-600 text-white">IA</Badge>
          </DialogTitle>
          <DialogDescription>
            Introduce al menos 2 ingredientes y te crearé una receta personalizada
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-6 p-1">
            {/* Ingredientes */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Ingredientes disponibles</Label>
              {ingredientes.map((ing, index) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder={`Ingrediente ${index + 1}`}
                    value={ing}
                    onChange={(e) => actualizarIngrediente(index, e.target.value)}
                    className="flex-1"
                  />
                  {ingredientes.length > 2 && (
                    <Button variant="ghost" size="icon" onClick={() => eliminarIngrediente(index)}>
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={agregarIngrediente} className="w-full">
                <Plus className="h-4 w-4 mr-2" /> Añadir ingrediente
              </Button>
            </div>

            {/* Herramienta */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Herramienta de cocina</Label>
              <div className="flex gap-2">
                <Button
                  variant={herramienta === 'tradicional' ? 'default' : 'outline'}
                  onClick={() => setHerramienta('tradicional')}
                  className="flex-1"
                >
                  <Utensils className="h-4 w-4 mr-2" />
                  Tradicional
                </Button>
                <Button
                  variant={herramienta === 'thermomix' ? 'default' : 'outline'}
                  onClick={() => setHerramienta('thermomix')}
                  className={`flex-1 ${herramienta === 'thermomix' ? 'bg-violet-600 hover:bg-violet-700' : ''}`}
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Thermomix
                </Button>
              </div>
            </div>

            {/* Botón generar */}
            <Button
              onClick={generarReceta}
              disabled={generando || ingredientes.filter(i => i.trim()).length < 2}
              className="w-full bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700"
            >
              {generando ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generando receta...
                </>
              ) : (
                <>
                  <Wand2 className="h-4 w-4 mr-2" />
                  Generar receta con IA
                </>
              )}
            </Button>

            {/* Receta generada */}
            {recetaGenerada && (
              <Card className="border-violet-200 dark:border-violet-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{recetaGenerada.nombre}</CardTitle>
                  <CardDescription>{recetaGenerada.descripcion}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      {recetaGenerada.tiempo}
                    </div>
                    <div className="flex items-center gap-1">
                      <Flame className="h-4 w-4 text-muted-foreground" />
                      {recetaGenerada.dificultad}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">Ingredientes:</h4>
                    <ul className="text-sm space-y-1">
                      {recetaGenerada.ingredientes.map((ing, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <Check className="h-3 w-3 text-emerald-500" />
                          {ing.cantidad} {ing.nombre}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-sm mb-2">Preparación:</h4>
                    <ol className="text-sm space-y-2">
                      {recetaGenerada.pasos.map((paso, i) => (
                        <li key={i} className="flex gap-2">
                          <Badge variant="secondary" className="h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">{i + 1}</Badge>
                          {paso}
                        </li>
                      ))}
                    </ol>
                  </div>

                  {recetaGenerada.consejos && (
                    <div className="bg-yellow-50 dark:bg-yellow-950/30 p-3 rounded-lg">
                      <p className="text-sm"><strong>Consejo:</strong> {recetaGenerada.consejos}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== NEXUS AI (ASISTENTE INTELIGENTE) ====================

function PanelNexusAI({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [modo, setModo] = useState<'recomendar' | 'planificar' | 'consejos' | 'sustituir' | 'chat'>('recomendar');
  const [mensaje, setMensaje] = useState('');
  const [contexto, setContexto] = useState('');
  const [respuesta, setRespuesta] = useState('');
  const [cargando, setCargando] = useState(false);
  const [historial, setHistorial] = useState<{ tipo: string; pregunta: string; respuesta: string }[]>([]);

  const modos = [
    { id: 'recomendar', nombre: 'Recomendar', icono: '🍽️', descripcion: 'Recetas personalizadas', color: 'from-orange-500 to-amber-500' },
    { id: 'planificar', nombre: 'Planificar', icono: '📅', descripcion: 'Menú semanal', color: 'from-blue-500 to-cyan-500' },
    { id: 'consejos', nombre: 'Consejos', icono: '👨‍🍳', descripcion: 'Tips de cocina', color: 'from-green-500 to-emerald-500' },
    { id: 'sustituir', nombre: 'Sustituir', icono: '🔄', descripcion: 'Alternativas de ingredientes', color: 'from-purple-500 to-violet-500' },
    { id: 'chat', nombre: 'Chat', icono: '💬', descripcion: 'Pregúntame lo que quieras', color: 'from-pink-500 to-rose-500' },
  ];

  const enviarPeticion = async () => {
    if (!mensaje.trim()) return;

    setCargando(true);
    setRespuesta('');

    try {
      const res = await fetch('/api/nexus-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo: modo,
          mensaje,
          contexto
        })
      });

      const data = await res.json();

      if (data.success && data.respuesta) {
        setRespuesta(data.respuesta);
        setHistorial(prev => [...prev.slice(-4), { tipo: modo, pregunta: mensaje, respuesta: data.respuesta }]);
      } else {
        setRespuesta('Lo siento, no pude procesar tu solicitud. Por favor, intenta de nuevo.');
      }
    } catch (error) {
      console.error('Error:', error);
      setRespuesta('Error de conexión. Por favor, intenta de nuevo.');
    } finally {
      setCargando(false);
    }
  };

  const ejemplosRapidos: Record<string, string[]> = {
    recomendar: ['Receta rápida con pollo', 'Postre sin horno', 'Cena romántica', 'Plato vegetariano'],
    planificar: ['Menú para la semana', 'Comidas saludables', 'Para una familia de 4', 'Presupuesto bajo'],
    consejos: ['Cómo hacer arroz perfecto', 'Evitar que se pegue', 'Técnicas de cortes', 'Conservar alimentos'],
    sustituir: ['Huevos en repostería', 'Harina de trigo', 'Leche', 'Mantequilla'],
    chat: ['¿Qué es umami?', '¿Cómo sazonar?', 'Cocinar al vapor', 'Maridajes de vino']
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-xl">
            <div className="p-2 rounded-lg bg-gradient-to-r from-violet-600 to-purple-600">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <div>
              <span className="bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent font-bold">Nexus AI</span>
              <p className="text-sm font-normal text-muted-foreground">Tu asistente culinario inteligente</p>
            </div>
          </DialogTitle>
        </DialogHeader>

        {/* Modos */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {modos.map(m => (
            <Button
              key={m.id}
              variant={modo === m.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => { setModo(m.id as typeof modo); setRespuesta(''); }}
              className={`flex-shrink-0 ${modo === m.id ? `bg-gradient-to-r ${m.color} text-white border-0` : ''}`}
            >
              <span className="mr-1">{m.icono}</span>
              {m.nombre}
            </Button>
          ))}
        </div>

        {/* Contexto opcional */}
        {modo === 'recomendar' && (
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">Contexto (opcional): gustos, alergias, ocasión...</Label>
            <Input
              placeholder="Ej: Me gusta la comida italiana, soy alérgico al marisco..."
              value={contexto}
              onChange={(e) => setContexto(e.target.value)}
            />
          </div>
        )}

        {/* Input principal */}
        <div className="flex gap-2">
          <Input
            placeholder={modo === 'chat' ? 'Escribe tu pregunta...' : `Pide ${modos.find(m => m.id === modo)?.descripcion.toLowerCase()}...`}
            value={mensaje}
            onChange={(e) => setMensaje(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !cargando && enviarPeticion()}
            className="flex-1"
          />
          <Button
            onClick={enviarPeticion}
            disabled={cargando || !mensaje.trim()}
            className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700"
          >
            {cargando ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>

        {/* Ejemplos rápidos */}
        <div className="flex flex-wrap gap-1.5">
          {ejemplosRapidos[modo].map((ejemplo, i) => (
            <Button
              key={i}
              variant="ghost"
              size="sm"
              onClick={() => { setMensaje(ejemplo); setRespuesta(''); }}
              className="text-xs h-7 px-2"
            >
              {ejemplo}
            </Button>
          ))}
        </div>

        {/* Respuesta */}
        <ScrollArea className="flex-1 min-h-[200px]">
          {cargando ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin mb-3 text-violet-500" />
              <p className="text-sm">Pensando...</p>
            </div>
          ) : respuesta ? (
            <Card className="border-violet-200 dark:border-violet-800 bg-gradient-to-br from-violet-50 to-purple-50 dark:from-violet-950/30 dark:to-purple-950/30">
              <CardContent className="pt-4">
                <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                  {respuesta}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <div className="text-4xl mb-3">🤖</div>
              <p className="font-medium">¡Hola! Soy Nexus AI</p>
              <p className="text-sm mt-1">Selecciona un modo y escribe tu consulta</p>
            </div>
          )}
        </ScrollArea>

        {/* Historial reciente */}
        {historial.length > 0 && (
          <div className="border-t pt-3">
            <p className="text-xs text-muted-foreground mb-2">Consultas recientes:</p>
            <div className="flex gap-2 overflow-x-auto">
              {historial.map((h, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  onClick={() => { setModo(h.tipo as typeof modo); setMensaje(h.pregunta); setRespuesta(h.respuesta); }}
                  className="flex-shrink-0 text-xs max-w-[150px] truncate"
                >
                  {h.pregunta.slice(0, 20)}...
                </Button>
              ))}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// ==================== CALCULADORA DE ESCALADO (NUEVA FUNCIONALIDAD 2) ====================

function PanelEscalado({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [porcionesOriginales, setPorcionesOriginales] = useState(4);
  const [porcionesDeseadas, setPorcionesDeseadas] = useState(6);
  const [ingredientes, setIngredientes] = useState<{ nombre: string; cantidad: number; unidad: string }[]>([
    { nombre: 'Harina', cantidad: 200, unidad: 'g' },
    { nombre: 'Azúcar', cantidad: 100, unidad: 'g' },
    { nombre: 'Huevos', cantidad: 2, unidad: 'unidades' },
  ]);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevaCantidad, setNuevaCantidad] = useState('');
  const [nuevaUnidad, setNuevaUnidad] = useState('g');

  const factor = porcionesDeseadas / porcionesOriginales;

  const agregarIngrediente = () => {
    if (nuevoNombre && nuevaCantidad) {
      setIngredientes([...ingredientes, { 
        nombre: nuevoNombre, 
        cantidad: parseFloat(nuevaCantidad), 
        unidad: nuevaUnidad 
      }]);
      setNuevoNombre('');
      setNuevaCantidad('');
    }
  };

  const eliminarIngrediente = (index: number) => {
    setIngredientes(ingredientes.filter((_, i) => i !== index));
  };

  const escalarCantidad = (cantidad: number) => {
    const resultado = cantidad * factor;
    // Redondear a 2 decimales si es decimal
    return resultado % 1 === 0 ? resultado : Math.round(resultado * 100) / 100;
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Scale className="h-6 w-6 text-emerald-500" />
            Calculadora de Escalado
          </DialogTitle>
          <DialogDescription>
            Ajusta las cantidades de ingredientes según el número de porciones
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-6 p-1">
            {/* Configuración de porciones */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="pt-4">
                  <Label className="text-sm">Porciones originales</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Button variant="outline" size="icon" onClick={() => setPorcionesOriginales(p => Math.max(1, p - 1))}>
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Input type="number" value={porcionesOriginales} onChange={(e) => setPorcionesOriginales(Number(e.target.value))} className="text-center" />
                    <Button variant="outline" size="icon" onClick={() => setPorcionesOriginales(p => p + 1)}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-emerald-200 dark:border-emerald-800">
                <CardContent className="pt-4">
                  <Label className="text-sm">Porciones deseadas</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Button variant="outline" size="icon" onClick={() => setPorcionesDeseadas(p => Math.max(1, p - 1))}>
                      <Minus className="h-4 w-4" />
                    </Button>
                    <Input type="number" value={porcionesDeseadas} onChange={(e) => setPorcionesDeseadas(Number(e.target.value))} className="text-center font-bold" />
                    <Button variant="outline" size="icon" onClick={() => setPorcionesDeseadas(p => p + 1)}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Factor de escala */}
            <div className="text-center p-4 bg-muted rounded-lg">
              <p className="text-sm text-muted-foreground">Factor de escala</p>
              <p className="text-3xl font-bold text-emerald-600">×{factor.toFixed(2)}</p>
            </div>

            {/* Añadir ingrediente */}
            <div className="flex gap-2">
              <Input placeholder="Ingrediente" value={nuevoNombre} onChange={(e) => setNuevoNombre(e.target.value)} className="flex-1" />
              <Input placeholder="Cant." value={nuevaCantidad} onChange={(e) => setNuevaCantidad(e.target.value)} className="w-20" />
              <Select value={nuevaUnidad} onValueChange={setNuevaUnidad}>
                <SelectTrigger className="w-20"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="g">g</SelectItem>
                  <SelectItem value="kg">kg</SelectItem>
                  <SelectItem value="ml">ml</SelectItem>
                  <SelectItem value="l">l</SelectItem>
                  <SelectItem value="unidades">ud</SelectItem>
                  <SelectItem value="cucharadas">cdas</SelectItem>
                  <SelectItem value="cucharaditas">cdtas</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={agregarIngrediente}><Plus className="h-4 w-4" /></Button>
            </div>

            {/* Tabla de ingredientes */}
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left p-3 text-sm">Ingrediente</th>
                    <th className="text-center p-3 text-sm">Original</th>
                    <th className="text-center p-3 text-sm">Escalado</th>
                    <th className="w-10"></th>
                  </tr>
                </thead>
                <tbody>
                  {ingredientes.map((ing, i) => (
                    <tr key={i} className="border-t">
                      <td className="p-3">{ing.nombre}</td>
                      <td className="p-3 text-center text-muted-foreground">{ing.cantidad} {ing.unidad}</td>
                      <td className="p-3 text-center font-bold text-emerald-600">{escalarCantidad(ing.cantidad)} {ing.unidad}</td>
                      <td className="p-2">
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => eliminarIngrediente(i)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== CALCULADORA NUTRICIONAL (NUEVA FUNCIONALIDAD 3) ====================

function PanelNutricion({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [ingredientes, setIngredientes] = useState<{ nombre: string; cantidad: number }[]>([
    { nombre: 'Pollo', cantidad: 200 },
    { nombre: 'Arroz', cantidad: 150 },
  ]);
  const [nuevoIngrediente, setNuevoIngrediente] = useState('');
  const [nuevaCantidad, setNuevaCantidad] = useState('');

  // Valores nutricionales por 100g
  const valoresNutricionales: Record<string, { calorias: number; proteinas: number; carbs: number; grasas: number }> = {
    'pollo': { calorias: 165, proteinas: 31, carbs: 0, grasas: 3.6 },
    'ternera': { calorias: 250, proteinas: 26, carbs: 0, grasas: 15 },
    'cerdo': { calorias: 242, proteinas: 27, carbs: 0, grasas: 14 },
    'pescado': { calorias: 136, proteinas: 26, carbs: 0, grasas: 3 },
    'huevos': { calorias: 155, proteinas: 13, carbs: 1.1, grasas: 11 },
    'leche': { calorias: 42, proteinas: 3.4, carbs: 5, grasas: 1 },
    'queso': { calorias: 402, proteinas: 25, carbs: 1.3, grasas: 33 },
    'arroz': { calorias: 130, proteinas: 2.7, carbs: 28, grasas: 0.3 },
    'pasta': { calorias: 131, proteinas: 5, carbs: 25, grasas: 1.1 },
    'pan': { calorias: 265, proteinas: 9, carbs: 49, grasas: 3.2 },
    'patata': { calorias: 77, proteinas: 2, carbs: 17, grasas: 0.1 },
    'tomate': { calorias: 18, proteinas: 0.9, carbs: 3.9, grasas: 0.2 },
    'cebolla': { calorias: 40, proteinas: 1.1, carbs: 9.3, grasas: 0.1 },
    'zanahoria': { calorias: 41, proteinas: 0.9, carbs: 10, grasas: 0.2 },
    'aceite': { calorias: 884, proteinas: 0, carbs: 0, grasas: 100 },
    'mantequilla': { calorias: 717, proteinas: 0.9, carbs: 0.1, grasas: 81 },
    'azúcar': { calorias: 387, proteinas: 0, carbs: 100, grasas: 0 },
    'harina': { calorias: 364, proteinas: 10, carbs: 76, grasas: 1 },
    'yogur': { calorias: 59, proteinas: 10, carbs: 3.6, grasas: 0.7 },
    'plátano': { calorias: 89, proteinas: 1.1, carbs: 23, grasas: 0.3 },
    'manzana': { calorias: 52, proteinas: 0.3, carbs: 14, grasas: 0.2 },
    'naranja': { calorias: 47, proteinas: 0.9, carbs: 12, grasas: 0.1 },
    'espinacas': { calorias: 23, proteinas: 2.9, carbs: 3.6, grasas: 0.4 },
    'brócoli': { calorias: 34, proteinas: 2.8, carbs: 7, grasas: 0.4 },
    'aguacate': { calorias: 160, proteinas: 2, carbs: 9, grasas: 15 },
  };

  const agregarIngrediente = () => {
    if (nuevoIngrediente && nuevaCantidad) {
      setIngredientes([...ingredientes, { nombre: nuevoIngrediente.toLowerCase(), cantidad: parseFloat(nuevaCantidad) }]);
      setNuevoIngrediente('');
      setNuevaCantidad('');
    }
  };

  const eliminarIngrediente = (index: number) => {
    setIngredientes(ingredientes.filter((_, i) => i !== index));
  };

  const calcularTotal = () => {
    return ingredientes.reduce((acc, ing) => {
      const valores = valoresNutricionales[ing.nombre];
      if (valores) {
        const factor = ing.cantidad / 100;
        return {
          calorias: acc.calorias + valores.calorias * factor,
          proteinas: acc.proteinas + valores.proteinas * factor,
          carbs: acc.carbs + valores.carbs * factor,
          grasas: acc.grasas + valores.grasas * factor,
        };
      }
      return acc;
    }, { calorias: 0, proteinas: 0, carbs: 0, grasas: 0 });
  };

  const total = calcularTotal();

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <PieChart className="h-6 w-6 text-blue-500" />
            Calculadora Nutricional
          </DialogTitle>
          <DialogDescription>
            Calcula las calorías y macronutrientes de tus ingredientes
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-6 p-1">
            {/* Añadir ingrediente */}
            <div className="flex gap-2">
              <Input 
                placeholder="Ingrediente (ej: pollo, arroz...)" 
                value={nuevoIngrediente} 
                onChange={(e) => setNuevoIngrediente(e.target.value)} 
                className="flex-1" 
                list="ingredientes-list"
              />
              <datalist id="ingredientes-list">
                {Object.keys(valoresNutricionales).map(ing => (
                  <option key={ing} value={ing} />
                ))}
              </datalist>
              <Input 
                placeholder="Gramos" 
                type="number" 
                value={nuevaCantidad} 
                onChange={(e) => setNuevaCantidad(e.target.value)} 
                className="w-24" 
              />
              <Button onClick={agregarIngrediente}><Plus className="h-4 w-4" /></Button>
            </div>

            {/* Resumen nutricional */}
            <div className="grid grid-cols-4 gap-3">
              <Card className="bg-gradient-to-br from-orange-500 to-amber-500 text-white">
                <CardContent className="pt-4 pb-3 text-center">
                  <Flame className="h-5 w-5 mx-auto mb-1" />
                  <div className="text-2xl font-bold">{Math.round(total.calorias)}</div>
                  <div className="text-xs opacity-80">kcal</div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-red-500 to-rose-500 text-white">
                <CardContent className="pt-4 pb-3 text-center">
                  <div className="text-lg mb-1">🥩</div>
                  <div className="text-2xl font-bold">{Math.round(total.proteinas)}g</div>
                  <div className="text-xs opacity-80">Proteínas</div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-yellow-500 to-amber-500 text-white">
                <CardContent className="pt-4 pb-3 text-center">
                  <div className="text-lg mb-1">🍞</div>
                  <div className="text-2xl font-bold">{Math.round(total.carbs)}g</div>
                  <div className="text-xs opacity-80">Carbohidratos</div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-purple-500 to-violet-500 text-white">
                <CardContent className="pt-4 pb-3 text-center">
                  <div className="text-lg mb-1">🥑</div>
                  <div className="text-2xl font-bold">{Math.round(total.grasas)}g</div>
                  <div className="text-xs opacity-80">Grasas</div>
                </CardContent>
              </Card>
            </div>

            {/* Gráfico de proporciones */}
            <Card>
              <CardContent className="pt-4">
                <div className="flex h-6 rounded-full overflow-hidden">
                  {total.proteinas + total.carbs + total.grasas > 0 && (
                    <>
                      <div 
                        className="bg-red-500" 
                        style={{ width: `${(total.proteinas / (total.proteinas + total.carbs + total.grasas)) * 100}%` }} 
                      />
                      <div 
                        className="bg-yellow-500" 
                        style={{ width: `${(total.carbs / (total.proteinas + total.carbs + total.grasas)) * 100}%` }} 
                      />
                      <div 
                        className="bg-purple-500" 
                        style={{ width: `${(total.grasas / (total.proteinas + total.carbs + total.grasas)) * 100}%` }} 
                      />
                    </>
                  )}
                </div>
                <div className="flex justify-between mt-2 text-xs">
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-red-500 rounded" /> Proteínas</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-yellow-500 rounded" /> Carbs</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 bg-purple-500 rounded" /> Grasas</span>
                </div>
              </CardContent>
            </Card>

            {/* Lista de ingredientes */}
            <div className="space-y-2">
              {ingredientes.map((ing, i) => {
                const valores = valoresNutricionales[ing.nombre];
                const calorias = valores ? Math.round(valores.calorias * ing.cantidad / 100) : '?';
                return (
                  <div key={i} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-2">
                      <span className="capitalize">{ing.nombre}</span>
                      <Badge variant="secondary">{ing.cantidad}g</Badge>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-muted-foreground">{calorias} kcal</span>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => eliminarIngrediente(i)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== PLANIFICADOR SEMANAL (NUEVA FUNCIONALIDAD 4) ====================

function PanelPlanificador({ abierto, onCerrar, recetas }: { abierto: boolean; onCerrar: () => void; recetas: Receta[] }) {
  const [plan, setPlan] = useState<Record<string, Record<string, string | null>>>(() => {
    const saved = localStorage.getItem('cocinaviva-plan-semanal');
    return saved ? JSON.parse(saved) : {};
  });

  const dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];
  const comidas = ['Desayuno', 'Comida', 'Cena'];

  const actualizarPlan = (dia: string, comida: string, recetaId: string | null) => {
    const nuevoPlan = {
      ...plan,
      [dia]: {
        ...(plan[dia] || {}),
        [comida]: recetaId
      }
    };
    setPlan(nuevoPlan);
    localStorage.setItem('cocinaviva-plan-semanal', JSON.stringify(nuevoPlan));
  };

  const getReceta = (id: string | null | undefined) => recetas.find(r => r.id === id);

  const generarListaCompra = () => {
    const ingredientes: string[] = [];
    Object.values(plan).forEach(dia => {
      Object.values(dia).forEach(recetaId => {
        const receta = getReceta(recetaId);
        if (receta) {
          try {
            const ings = JSON.parse(receta.ingredientes);
            ings.forEach((i: { nombre: string }) => ingredientes.push(i.nombre));
          } catch {}
        }
      });
    });
    toast.success(`Lista generada: ${ingredientes.length} ingredientes`);
  };

  const limpiarPlan = () => {
    setPlan({});
    localStorage.removeItem('cocinaviva-plan-semanal');
    toast.success('Plan semanal limpiado');
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2 text-xl">
              <CalendarDays className="h-6 w-6 text-cyan-500" />
              Planificador Semanal
            </DialogTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={generarListaCompra}>
                <ShoppingCart className="h-4 w-4 mr-1" />
                Lista compra
              </Button>
              <Button variant="ghost" size="sm" onClick={limpiarPlan}>
                <Trash2 className="h-4 w-4 mr-1" />
                Limpiar
              </Button>
            </div>
          </div>
          <DialogDescription>
            Planifica tus comidas para toda la semana
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="p-2 text-left text-sm font-medium text-muted-foreground w-24"></th>
                  {dias.map(dia => (
                    <th key={dia} className="p-2 text-center text-sm font-medium border-l">{dia}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {comidas.map(comida => (
                  <tr key={comida}>
                    <td className="p-2 font-medium text-sm">{comida}</td>
                    {dias.map(dia => {
                      const recetaId = plan[dia]?.[comida];
                      const receta = getReceta(recetaId);
                      return (
                        <td key={dia} className="p-1 border-l">
                          <Select value={recetaId || '__none__'} onValueChange={(v) => actualizarPlan(dia, comida, v === '__none__' ? null : v)}>
                            <SelectTrigger className={`h-auto min-h-[60px] ${receta ? 'bg-muted' : ''}`}>
                              <SelectValue placeholder="+" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="__none__">Sin planificar</SelectItem>
                              {recetas.slice(0, 50).map(r => (
                                <SelectItem key={r.id} value={r.id}>{r.nombre}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== GUÍA DE VOZ EN MODO COCINA (NUEVA FUNCIONALIDAD 5) ====================

function PanelGuiaVoz({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [pasos, setPasos] = useState<string[]>([
    'Picar la cebolla en cubos pequeños',
    'Calentar aceite en una sartén grande',
    'Sofreír la cebolla hasta que esté transparente',
    'Añadir el ajo picado y cocinar 1 minuto',
    'Incorporar el arroz y tostar ligeramente',
    'Verter el caldo caliente gradualmente',
    'Cocinar a fuego medio durante 18 minutos',
    'Dejar reposar 5 minutos antes de servir'
  ]);
  const [pasoActual, setPasoActual] = useState(0);
  const [hablando, setHablando] = useState(false);
  const [nuevoPaso, setNuevoPaso] = useState('');

  const hablar = (texto: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(texto);
      utterance.lang = 'es-ES';
      utterance.rate = 0.9;
      utterance.onend = () => setHablando(false);
      window.speechSynthesis.speak(utterance);
      setHablando(true);
    }
  };

  const siguientePaso = () => {
    if (pasoActual < pasos.length - 1) {
      const nuevoPaso = pasoActual + 1;
      setPasoActual(nuevoPaso);
      hablar(pasos[nuevoPaso]);
    }
  };

  const pasoAnterior = () => {
    if (pasoActual > 0) {
      const nuevoPaso = pasoActual - 1;
      setPasoActual(nuevoPaso);
      hablar(pasos[nuevoPaso]);
    }
  };

  const repetirPaso = () => {
    hablar(pasos[pasoActual]);
  };

  const detener = () => {
    window.speechSynthesis.cancel();
    setHablando(false);
  };

  const agregarPaso = () => {
    if (nuevoPaso) {
      setPasos([...pasos, nuevoPaso]);
      setNuevoPaso('');
    }
  };

  const eliminarPaso = (index: number) => {
    setPasos(pasos.filter((_, i) => i !== index));
    if (pasoActual >= pasos.length - 1) {
      setPasoActual(Math.max(0, pasos.length - 2));
    }
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Headphones className="h-6 w-6 text-pink-500" />
            Guía de Voz en Cocina
          </DialogTitle>
          <DialogDescription>
            Escucha los pasos de la receta mientras cocinas
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 space-y-6">
          {/* Paso actual */}
          <Card className={`border-2 ${hablando ? 'border-pink-500 animate-pulse' : 'border-muted'}`}>
            <CardContent className="pt-6 pb-6">
              <div className="text-center">
                <Badge variant="secondary" className="mb-4">
                  Paso {pasoActual + 1} de {pasos.length}
                </Badge>
                <p className="text-xl font-medium">{pasos[pasoActual]}</p>
              </div>
            </CardContent>
          </Card>

          {/* Controles */}
          <div className="flex justify-center gap-4">
            <Button variant="outline" size="lg" onClick={pasoAnterior} disabled={pasoActual === 0}>
              <ChevronLeft className="h-5 w-5 mr-1" />
              Anterior
            </Button>
            <Button variant="outline" size="lg" onClick={repetirPaso}>
              <Volume2 className="h-5 w-5 mr-1" />
              Repetir
            </Button>
            {hablando ? (
              <Button variant="destructive" size="lg" onClick={detener}>
                <VolumeX className="h-5 w-5 mr-1" />
                Detener
              </Button>
            ) : (
              <Button size="lg" onClick={() => hablar(pasos[pasoActual])}>
                <Play className="h-5 w-5 mr-1" />
                Leer
              </Button>
            )}
            <Button variant="outline" size="lg" onClick={siguientePaso} disabled={pasoActual === pasos.length - 1}>
              Siguiente
              <ChevronRight className="h-5 w-5 ml-1" />
            </Button>
          </div>

          {/* Lista de pasos */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Todos los pasos</Label>
            <ScrollArea className="h-40">
              {pasos.map((paso, i) => (
                <div 
                  key={i} 
                  className={`flex items-center gap-2 p-2 rounded cursor-pointer ${i === pasoActual ? 'bg-pink-100 dark:bg-pink-950/30' : 'hover:bg-muted'}`}
                  onClick={() => { setPasoActual(i); hablar(paso); }}
                >
                  <Badge variant={i === pasoActual ? 'default' : 'secondary'} className="w-6 h-6 rounded-full p-0 flex items-center justify-center">
                    {i + 1}
                  </Badge>
                  <span className="flex-1 text-sm">{paso}</span>
                  <Button variant="ghost" size="icon" className="h-6 w-6" onClick={(e) => { e.stopPropagation(); eliminarPaso(i); }}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </ScrollArea>
          </div>

          {/* Añadir paso */}
          <div className="flex gap-2">
            <Input placeholder="Añadir nuevo paso..." value={nuevoPaso} onChange={(e) => setNuevoPaso(e.target.value)} className="flex-1" />
            <Button onClick={agregarPaso}><Plus className="h-4 w-4" /></Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== ESCÁNER DE RECETAS (FUNCIÓN BETA 1) ====================

function PanelEscanerRecetas({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [imagen, setImagen] = useState<string | null>(null);
  const [escaneando, setEscaneando] = useState(false);
  const [resultado, setResultado] = useState<{
    nombre: string;
    ingredientes: string[];
    pasos: string[];
    tiempo: string;
  } | null>(null);

  const manejarImagen = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setImagen(ev.target?.result as string);
        setResultado(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const escanearReceta = async () => {
    if (!imagen) return;

    setEscaneando(true);

    // Simular escaneo de IA
    await new Promise(resolve => setTimeout(resolve, 2000));

    setResultado({
      nombre: 'Receta Escaneada',
      ingredientes: [
        '2 tazas de harina',
        '1 taza de azúcar',
        '3 huevos',
        '1/2 taza de leche',
        '1 cucharadita de vainilla'
      ],
      pasos: [
        'Precalentar el horno a 180°C',
        'Mezclar ingredientes secos',
        'Añadir huevos y leche',
        'Hornear por 25-30 minutos'
      ],
      tiempo: '45 minutos'
    });

    setEscaneando(false);
    toast.success('¡Receta escaneada correctamente!');
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <ImageIcon className="h-6 w-6 text-green-500" />
            Escáner de Recetas
            <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300">BETA</Badge>
          </DialogTitle>
          <DialogDescription>
            Escanea recetas desde fotos usando inteligencia artificial
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-4 p-1">
            {/* Upload area */}
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center">
              {imagen ? (
                <div className="space-y-4">
                  <img src={imagen} alt="Receta escaneada" className="max-h-48 mx-auto rounded-lg" />
                  <div className="flex gap-2 justify-center">
                    <Button variant="outline" onClick={() => { setImagen(null); setResultado(null); }}>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Cambiar imagen
                    </Button>
                    <Button onClick={escanearReceta} disabled={escaneando} className="bg-gradient-to-r from-green-500 to-emerald-600">
                      {escaneando ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Escaneando...
                        </>
                      ) : (
                        <>
                          <Wand2 className="h-4 w-4 mr-2" />
                          Escanear receta
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              ) : (
                <label className="cursor-pointer">
                  <input type="file" accept="image/*" onChange={manejarImagen} className="hidden" />
                  <div className="space-y-2">
                    <ImageIcon className="h-12 w-12 mx-auto text-muted-foreground" />
                    <p className="text-muted-foreground">Haz clic para subir una foto de tu receta</p>
                    <p className="text-xs text-muted-foreground">Soporta: JPG, PNG, WEBP</p>
                  </div>
                </label>
              )}
            </div>

            {/* Resultado */}
            {resultado && (
              <Card className="border-green-200 dark:border-green-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-500" />
                    {resultado.nombre}
                  </CardTitle>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    {resultado.tiempo}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="font-medium text-sm mb-2">Ingredientes detectados:</h4>
                    <ul className="text-sm space-y-1">
                      {resultado.ingredientes.map((ing, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <Check className="h-3 w-3 text-emerald-500" />
                          {ing}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm mb-2">Pasos detectados:</h4>
                    <ol className="text-sm space-y-2">
                      {resultado.pasos.map((paso, i) => (
                        <li key={i} className="flex gap-2">
                          <Badge variant="secondary" className="h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">{i + 1}</Badge>
                          {paso}
                        </li>
                      ))}
                    </ol>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== MODO CHEF PRO (FUNCIÓN BETA 2) ====================

function PanelChefPro({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [temporizadores, setTemporizadores] = useState<{ id: number; nombre: string; segundos: number; restante: number; activo: boolean }[]>([]);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevoMinutos, setNuevoMinutos] = useState(5);
  const [notas, setNotas] = useState('');
  const [consejoActivo, setConsejoActivo] = useState(0);

  const consejos = [
    '💡 Precalienta siempre el horno antes de empezar',
    '💡 Usa cuchillos afilados para cortar de forma segura',
    '💡 Lee toda la receta antes de comenzar',
    '💡 Ten todos los ingredientes preparados (mise en place)',
    '💡 No abras el horno durante los primeros 20 minutos',
    '💡 Deja reposar la carne después de cocinarla',
    '💡 Sazona al final para ajustar el sabor',
  ];

  useEffect(() => {
    if (abierto) {
      const interval = setInterval(() => {
        setConsejoActivo(prev => (prev + 1) % consejos.length);
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [abierto, consejos.length]);

  useEffect(() => {
    if (temporizadores.some(t => t.activo)) {
      const interval = setInterval(() => {
        setTemporizadores(prev => prev.map(t => {
          if (t.activo && t.restante > 0) {
            const nuevoRestante = t.restante - 1;
            if (nuevoRestante === 0) {
              // Reproducir sonido y mostrar notificación
              if ('speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance(`¡El temporizador ${t.nombre} ha terminado!`);
                utterance.lang = 'es-ES';
                speechSynthesis.speak(utterance);
              }
              toast.success(`⏰ ¡${t.nombre} terminado!`);
              return { ...t, restante: 0, activo: false };
            }
            return { ...t, restante: nuevoRestante };
          }
          return t;
        }));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [temporizadores]);

  const agregarTemporizador = () => {
    if (nuevoNombre && nuevoMinutos > 0) {
      const nuevo = {
        id: Date.now(),
        nombre: nuevoNombre,
        segundos: nuevoMinutos * 60,
        restante: nuevoMinutos * 60,
        activo: false
      };
      setTemporizadores([...temporizadores, nuevo]);
      setNuevoNombre('');
      setNuevoMinutos(5);
      toast.success('Temporizador añadido');
    }
  };

  const toggleTemporizador = (id: number) => {
    setTemporizadores(prev => prev.map(t =>
      t.id === id ? { ...t, activo: !t.activo } : t
    ));
  };

  const reiniciarTemporizador = (id: number) => {
    setTemporizadores(prev => prev.map(t =>
      t.id === id ? { ...t, restante: t.segundos, activo: false } : t
    ));
  };

  const eliminarTemporizador = (id: number) => {
    setTemporizadores(prev => prev.filter(t => t.id !== id));
  };

  const formatearTiempo = (segundos: number) => {
    const mins = Math.floor(segundos / 60);
    const secs = segundos % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Zap className="h-6 w-6 text-rose-500" />
            Modo Chef Pro
            <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300">BETA</Badge>
          </DialogTitle>
          <DialogDescription>
            Herramientas avanzadas para cocinar como un profesional
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-6 p-1">
            {/* Consejo del día */}
            <div className="bg-gradient-to-r from-rose-50 to-amber-50 dark:from-rose-950/30 dark:to-amber-950/30 p-4 rounded-lg border border-rose-200 dark:border-rose-800">
              <p className="text-sm text-center transition-all duration-300">{consejos[consejoActivo]}</p>
            </div>

            {/* Temporizadores */}
            <div className="space-y-3">
              <h3 className="font-semibold flex items-center gap-2">
                <Timer className="h-4 w-4 text-rose-500" />
                Temporizadores
              </h3>

              {temporizadores.length > 0 && (
                <div className="space-y-2">
                  {temporizadores.map(t => (
                    <Card key={t.id} className={`${t.restante === 0 ? 'bg-green-50 dark:bg-green-950/30 border-green-300' : ''}`}>
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">{t.nombre}</div>
                            <div className={`text-2xl font-mono ${t.restante < 60 ? 'text-red-500' : ''}`}>
                              {formatearTiempo(t.restante)}
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant={t.activo ? 'destructive' : 'default'}
                              size="sm"
                              onClick={() => toggleTemporizador(t.id)}
                              disabled={t.restante === 0}
                            >
                              {t.activo ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                            </Button>
                            <Button variant="outline" size="sm" onClick={() => reiniciarTemporizador(t.id)}>
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => eliminarTemporizador(t.id)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <Input
                  placeholder="Nombre (ej: Arroz)"
                  value={nuevoNombre}
                  onChange={(e) => setNuevoNombre(e.target.value)}
                  className="flex-1"
                />
                <Select value={nuevoMinutos.toString()} onValueChange={(v) => setNuevoMinutos(parseInt(v))}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 5, 10, 15, 20, 30, 45, 60].map(m => (
                      <SelectItem key={m} value={m.toString()}>{m} min</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={agregarTemporizador} className="bg-gradient-to-r from-rose-500 to-amber-500">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Notas rápidas */}
            <div className="space-y-3">
              <h3 className="font-semibold flex items-center gap-2">
                <StickyNote className="h-4 w-4 text-amber-500" />
                Notas rápidas
              </h3>
              <textarea
                className="w-full h-24 p-3 border rounded-lg resize-none bg-background"
                placeholder="Escribe tus notas de cocina aquí..."
                value={notas}
                onChange={(e) => setNotas(e.target.value)}
              />
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== CONVERSOR DE UNIDADES (NUEVA FUNCIÓN 1) ====================

function PanelConversorUnidades({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [categoria, setCategoria] = useState<'peso' | 'volumen' | 'temperatura' | 'cucharas'>('peso');
  const [valor, setValor] = useState('');
  const [unidadOrigen, setUnidadOrigen] = useState('g');
  const [unidadDestino, setUnidadDestino] = useState('kg');

  const unidades: Record<string, { nombre: string; factor: number }[]> = {
    peso: [
      { nombre: 'Gramos (g)', factor: 1 },
      { nombre: 'Kilogramos (kg)', factor: 1000 },
      { nombre: 'Onzas (oz)', factor: 28.3495 },
      { nombre: 'Libras (lb)', factor: 453.592 },
    ],
    volumen: [
      { nombre: 'Mililitros (ml)', factor: 1 },
      { nombre: 'Litros (l)', factor: 1000 },
      { nombre: 'Tazas', factor: 236.588 },
      { nombre: 'Cucharadas', factor: 14.787 },
      { nombre: 'Cucharaditas', factor: 4.929 },
      { nombre: 'Onzas líquidas (fl oz)', factor: 29.5735 },
    ],
    temperatura: [
      { nombre: 'Celsius (°C)', factor: 1 },
      { nombre: 'Fahrenheit (°F)', factor: 1 },
    ],
    cucharas: [
      { nombre: 'Cucharadita (cdta)', factor: 1 },
      { nombre: 'Cucharada (cda)', factor: 3 },
      { nombre: 'Taza', factor: 48 },
    ],
  };

  const convertir = () => {
    const val = parseFloat(valor);
    if (isNaN(val)) return '0';

    if (categoria === 'temperatura') {
      if (unidadOrigen === 'C' && unidadDestino === 'F') {
        return ((val * 9/5) + 32).toFixed(2);
      } else if (unidadOrigen === 'F' && unidadDestino === 'C') {
        return ((val - 32) * 5/9).toFixed(2);
      }
      return val.toFixed(2);
    }

    const factorOrigen = unidades[categoria].find(u => u.nombre.includes(unidadOrigen))?.factor || 1;
    const factorDestino = unidades[categoria].find(u => u.nombre.includes(unidadDestino))?.factor || 1;
    
    const gramos = val * factorOrigen;
    return (gramos / factorDestino).toFixed(2);
  };

  const conversionesRapidas = [
    { de: '1 taza', a: '240 ml' },
    { de: '1 cucharada', a: '15 ml' },
    { de: '1 cucharadita', a: '5 ml' },
    { de: '1 onza', a: '28 g' },
    { de: '1 libra', a: '454 g' },
    { de: '180°C', a: '350°F' },
    { de: '200°C', a: '400°F' },
    { de: '220°C', a: '425°F' },
  ];

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Scale className="h-6 w-6 text-cyan-500" />
            Conversor de Unidades
          </DialogTitle>
          <DialogDescription>
            Convierte medidas de cocina fácilmente
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Categorías */}
          <div className="flex gap-1 flex-wrap">
            {(['peso', 'volumen', 'temperatura', 'cucharas'] as const).map(cat => (
              <Button
                key={cat}
                variant={categoria === cat ? 'default' : 'outline'}
                size="sm"
                onClick={() => setCategoria(cat)}
                className={categoria === cat ? 'bg-cyan-500 hover:bg-cyan-600' : ''}
              >
                {cat === 'peso' ? '⚖️ Peso' : cat === 'volumen' ? '🥛 Volumen' : cat === 'temperatura' ? '🌡️ Temp.' : '🥄 Cucharas'}
              </Button>
            ))}
          </div>

          {/* Conversor */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Cantidad</Label>
              <Input
                type="number"
                value={valor}
                onChange={(e) => setValor(e.target.value)}
                placeholder="Ej: 500"
              />
            </div>
            <div className="space-y-2">
              <Label>De</Label>
              <Select value={unidadOrigen} onValueChange={setUnidadOrigen}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {unidades[categoria].map(u => (
                    <SelectItem key={u.nombre} value={u.nombre.split(' ')[0]}>
                      {u.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center justify-center">
            <Button variant="ghost" size="icon">
              <ArrowUpDown className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2">
            <Label>A</Label>
            <Select value={unidadDestino} onValueChange={setUnidadDestino}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {unidades[categoria].map(u => (
                  <SelectItem key={u.nombre} value={u.nombre.split(' ')[0]}>
                    {u.nombre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Resultado */}
          {valor && (
            <Card className="bg-cyan-50 dark:bg-cyan-950/30 border-cyan-200 dark:border-cyan-800">
              <CardContent className="pt-4 text-center">
                <p className="text-sm text-muted-foreground">Resultado</p>
                <p className="text-3xl font-bold text-cyan-600">{convertir()}</p>
              </CardContent>
            </Card>
          )}

          {/* Conversiones rápidas */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Conversiones rápidas</Label>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {conversionesRapidas.map((conv, i) => (
                <div key={i} className="flex justify-between p-2 bg-muted/50 rounded">
                  <span>{conv.de}</span>
                  <span className="font-medium">= {conv.a}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== CALCULADORA DE PRECIOS (NUEVA FUNCIÓN 2) ====================

function PanelCalculadoraPrecios({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [ingredientes, setIngredientes] = useState<{ nombre: string; cantidad: number; unidad: string; precio: number }[]>([]);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevaCantidad, setNuevaCantidad] = useState('');
  const [nuevaUnidad, setNuevaUnidad] = useState('g');
  const [nuevoPrecio, setNuevoPrecio] = useState('');

  const agregarIngrediente = () => {
    if (nuevoNombre && nuevaCantidad && nuevoPrecio) {
      setIngredientes([...ingredientes, {
        nombre: nuevoNombre,
        cantidad: parseFloat(nuevaCantidad),
        unidad: nuevaUnidad,
        precio: parseFloat(nuevoPrecio),
      }]);
      setNuevoNombre('');
      setNuevaCantidad('');
      setNuevoPrecio('');
    }
  };

  const eliminarIngrediente = (index: number) => {
    setIngredientes(ingredientes.filter((_, i) => i !== index));
  };

  const total = ingredientes.reduce((acc, ing) => acc + ing.precio, 0);
  const porciones = 4;
  const precioPorcion = total / porciones;

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <DollarSign className="h-6 w-6 text-emerald-500" />
            Calculadora de Precios
          </DialogTitle>
          <DialogDescription>
            Calcula el costo de tus recetas
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Añadir ingrediente */}
          <div className="space-y-3">
            <div className="flex gap-2">
              <Input
                placeholder="Ingrediente"
                value={nuevoNombre}
                onChange={(e) => setNuevoNombre(e.target.value)}
                className="flex-1"
              />
              <Input
                type="number"
                placeholder="Cant."
                value={nuevaCantidad}
                onChange={(e) => setNuevaCantidad(e.target.value)}
                className="w-16"
              />
              <Select value={nuevaUnidad} onValueChange={setNuevaUnidad}>
                <SelectTrigger className="w-16">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="g">g</SelectItem>
                  <SelectItem value="kg">kg</SelectItem>
                  <SelectItem value="ml">ml</SelectItem>
                  <SelectItem value="l">l</SelectItem>
                  <SelectItem value="ud">ud</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="Precio (€)"
                value={nuevoPrecio}
                onChange={(e) => setNuevoPrecio(e.target.value)}
                className="flex-1"
              />
              <Button onClick={agregarIngrediente} className="bg-emerald-500 hover:bg-emerald-600">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Lista de ingredientes */}
          {ingredientes.length > 0 && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Ingredientes</Label>
              <ScrollArea className="h-40">
                {ingredientes.map((ing, i) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-muted/50 rounded mb-2">
                    <div>
                      <span className="font-medium">{ing.nombre}</span>
                      <span className="text-sm text-muted-foreground ml-2">
                        {ing.cantidad}{ing.unidad}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-600">{ing.precio.toFixed(2)}€</span>
                      <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => eliminarIngrediente(i)}>
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </ScrollArea>
            </div>
          )}

          {/* Resumen de costos */}
          <Card className="bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800">
            <CardContent className="pt-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Costo Total</span>
                <span className="text-2xl font-bold text-emerald-600">{total.toFixed(2)}€</span>
              </div>
              <Separator />
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Por porción (4 pers.)</span>
                <span className="font-bold">{precioPorcion.toFixed(2)}€</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Por 100g aprox.</span>
                <span className="font-bold">{(total / 10).toFixed(2)}€</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== GESTOR DE DESPENSA (NUEVA FUNCIÓN 3) ====================

function PanelGestorDespensa({ abierto, onCerrar }: { abierto: boolean; onCerrar: () => void }) {
  const [ingredientes, setIngredientes] = useState<{ id: string; nombre: string; cantidad: number; unidad: string; caducidad: string; categoria: string }[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('cocinaviva-despensa');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch {}
      }
    }
    return [];
  });
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevaCantidad, setNuevaCantidad] = useState('');
  const [nuevaUnidad, setNuevaUnidad] = useState('ud');
  const [nuevaCaducidad, setNuevaCaducidad] = useState('');
  const [nuevaCategoria, setNuevaCategoria] = useState('otros');
  const [filtroCategoria, setFiltroCategoria] = useState('todas');

  const guardarDespensa = (items: typeof ingredientes) => {
    setIngredientes(items);
    localStorage.setItem('cocinaviva-despensa', JSON.stringify(items));
  };

  const agregarIngrediente = () => {
    if (nuevoNombre && nuevaCantidad) {
      const nuevo = {
        id: Date.now().toString(),
        nombre: nuevoNombre,
        cantidad: parseFloat(nuevaCantidad),
        unidad: nuevaUnidad,
        caducidad: nuevaCaducidad,
        categoria: nuevaCategoria,
      };
      guardarDespensa([...ingredientes, nuevo]);
      setNuevoNombre('');
      setNuevaCantidad('');
      setNuevaCaducidad('');
    }
  };

  const eliminarIngrediente = (id: string) => {
    guardarDespensa(ingredientes.filter(i => i.id !== id));
  };

  const actualizarCantidad = (id: string, delta: number) => {
    guardarDespensa(ingredientes.map(i => 
      i.id === id ? { ...i, cantidad: Math.max(0, i.cantidad + delta) } : i
    ));
  };

  const categorias = [
    { id: 'todas', nombre: 'Todas', icon: '📦' },
    { id: 'lacteos', nombre: 'Lácteos', icon: '🥛' },
    { id: 'carnes', nombre: 'Carnes', icon: '🥩' },
    { id: 'verduras', nombre: 'Verduras', icon: '🥬' },
    { id: 'frutas', nombre: 'Frutas', icon: '🍎' },
    { id: 'cereales', nombre: 'Cereales', icon: '🌾' },
    { id: 'condimentos', nombre: 'Condimentos', icon: '🧂' },
    { id: 'otros', nombre: 'Otros', icon: '🥫' },
  ];

  const ingredientesFiltrados = filtroCategoria === 'todas' 
    ? ingredientes 
    : ingredientes.filter(i => i.categoria === filtroCategoria);

  const proximosCaducar = ingredientes.filter(i => {
    if (!i.caducidad) return false;
    const fecha = new Date(i.caducidad);
    const hoy = new Date();
    const diff = (fecha.getTime() - hoy.getTime()) / (1000 * 60 * 60 * 24);
    return diff <= 7 && diff >= 0;
  });

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Refrigerator className="h-6 w-6 text-sky-500" />
            Gestor de Despensa
          </DialogTitle>
          <DialogDescription>
            Controla los ingredientes que tienes en casa
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-4 mt-4 pr-2">
            {/* Alerta de caducidad */}
            {proximosCaducar.length > 0 && (
              <Card className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800">
                <CardContent className="pt-3 pb-3">
                  <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300">
                    <AlertCircle className="h-4 w-4" />
                    <span className="text-sm font-medium">{proximosCaducar.length} productos próximos a caducar</span>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Añadir ingrediente */}
            <div className="space-y-3">
              <div className="flex gap-2">
                <Input
                  placeholder="Ingrediente"
                  value={nuevoNombre}
                  onChange={(e) => setNuevoNombre(e.target.value)}
                  className="flex-1"
                />
                <Select value={nuevaCategoria} onValueChange={setNuevaCategoria}>
                  <SelectTrigger className="w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categorias.filter(c => c.id !== 'todas').map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>
                        {cat.icon} {cat.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-2">
                <Input
                  type="number"
                  placeholder="Cant."
                  value={nuevaCantidad}
                  onChange={(e) => setNuevaCantidad(e.target.value)}
                  className="w-20"
                />
                <Select value={nuevaUnidad} onValueChange={setNuevaUnidad}>
                  <SelectTrigger className="w-16">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ud">ud</SelectItem>
                    <SelectItem value="g">g</SelectItem>
                    <SelectItem value="kg">kg</SelectItem>
                    <SelectItem value="ml">ml</SelectItem>
                    <SelectItem value="l">l</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  type="date"
                  value={nuevaCaducidad}
                  onChange={(e) => setNuevaCaducidad(e.target.value)}
                  className="flex-1"
                  placeholder="Caducidad"
                />
                <Button onClick={agregarIngrediente} className="bg-sky-500 hover:bg-sky-600">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Filtros */}
            <div className="flex gap-1 flex-wrap">
              {categorias.map(cat => (
                <Button
                  key={cat.id}
                  variant={filtroCategoria === cat.id ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFiltroCategoria(cat.id)}
                  className={filtroCategoria === cat.id ? 'bg-sky-500 hover:bg-sky-600' : ''}
                >
                  {cat.icon} {cat.nombre}
                </Button>
              ))}
            </div>

            {/* Lista de ingredientes */}
            {ingredientesFiltrados.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Refrigerator className="h-12 w-12 mx-auto mb-2 opacity-30" />
                <p>No hay ingredientes en esta categoría</p>
              </div>
            ) : (
              <div className="space-y-2">
                {ingredientesFiltrados.map(ing => {
                  const proximoCaducar = ing.caducidad && 
                    (new Date(ing.caducidad).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24) <= 7;
                  
                  return (
                    <div 
                      key={ing.id} 
                      className={`flex items-center justify-between p-3 rounded-lg border ${
                        proximoCaducar ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-200' : 'bg-muted/50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="text-xl">{categorias.find(c => c.id === ing.categoria)?.icon || '📦'}</span>
                        <div>
                          <p className="font-medium">{ing.nombre}</p>
                          {ing.caducidad && (
                            <p className={`text-xs ${proximoCaducar ? 'text-amber-600' : 'text-muted-foreground'}`}>
                              Cad: {new Date(ing.caducidad).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => actualizarCantidad(ing.id, -1)}>
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="font-bold w-12 text-center">{ing.cantidad}{ing.unidad}</span>
                        <Button variant="outline" size="icon" className="h-6 w-6" onClick={() => actualizarCantidad(ing.id, 1)}>
                          <Plus className="h-3 w-3" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500" onClick={() => eliminarIngrediente(ing.id)}>
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== TU BIBLIOTECA (NUEVA FUNCIONALIDAD) ====================

function PanelBiblioteca({ abierto, onCerrar, recetas, favoritos }: {
  abierto: boolean;
  onCerrar: () => void;
  recetas: Receta[];
  favoritos: string[];
}) {
  const [colecciones, setColecciones] = useState<{ id: string; nombre: string; recetas: string[] }[]>([]);
  const [nuevaColeccion, setNuevaColeccion] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined' && abierto) {
      const saved = localStorage.getItem('cocinaviva-colecciones');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          requestAnimationFrame(() => setColecciones(parsed));
        } catch {}
      }
    }
  }, [abierto]);

  const guardarColecciones = (cols: typeof colecciones) => {
    setColecciones(cols);
    localStorage.setItem('cocinaviva-colecciones', JSON.stringify(cols));
  };

  const crearColeccion = () => {
    if (nuevaColeccion.trim()) {
      const nueva = {
        id: Date.now().toString(),
        nombre: nuevaColeccion.trim(),
        recetas: []
      };
      guardarColecciones([...colecciones, nueva]);
      setNuevaColeccion('');
      toast.success('Colección creada');
    }
  };

  const eliminarColeccion = (id: string) => {
    guardarColecciones(colecciones.filter(c => c.id !== id));
    toast.success('Colección eliminada');
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <BookOpen className="h-6 w-6 text-amber-500" />
            Tu Biblioteca
          </DialogTitle>
          <DialogDescription>
            Organiza tus recetas en colecciones personalizadas
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1">
          <div className="space-y-4 p-1">
            {/* Crear nueva colección */}
            <div className="flex gap-2">
              <Input
                placeholder="Nueva colección..."
                value={nuevaColeccion}
                onChange={(e) => setNuevaColeccion(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && crearColeccion()}
                className="flex-1"
              />
              <Button onClick={crearColeccion}>
                <FolderPlus className="h-4 w-4 mr-2" />
                Crear
              </Button>
            </div>

            {/* Favoritos */}
            <Card className="border-rose-200 dark:border-rose-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Heart className="h-4 w-4 text-rose-500" />
                  Favoritos
                  <Badge variant="secondary">{favoritos.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {favoritos.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No tienes recetas favoritas</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {favoritos.slice(0, 5).map(id => {
                      const receta = recetas.find(r => r.id === id);
                      return receta ? (
                        <Badge key={id} variant="outline">{receta.nombre}</Badge>
                      ) : null;
                    })}
                    {favoritos.length > 5 && (
                      <Badge variant="secondary">+{favoritos.length - 5} más</Badge>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Colecciones */}
            <div className="space-y-2">
              <h3 className="font-medium text-sm">Mis Colecciones</h3>
              {colecciones.length === 0 ? (
                <Card className="border-dashed">
                  <CardContent className="pt-4 text-center text-muted-foreground text-sm">
                    <FolderPlus className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    Crea tu primera colección para organizar recetas
                  </CardContent>
                </Card>
              ) : (
                colecciones.map(col => (
                  <Card key={col.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{col.nombre}</h4>
                          <p className="text-xs text-muted-foreground">{col.recetas.length} recetas</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => eliminarColeccion(col.id)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

// ==================== BUSCADOR NEVERA (NUEVA FUNCIONALIDAD) ====================

function PanelNevera({ abierto, onCerrar }: {
  abierto: boolean;
  onCerrar: () => void;
}) {
  const [ingredientes, setIngredientes] = useState<string[]>([]);
  const [nuevoIngrediente, setNuevoIngrediente] = useState('');
  const [resultados, setResultados] = useState<Receta[]>([]);
  const [buscando, setBuscando] = useState(false);

  const agregarIngrediente = () => {
    if (nuevoIngrediente.trim() && !ingredientes.includes(nuevoIngrediente.trim().toLowerCase())) {
      setIngredientes([...ingredientes, nuevoIngrediente.trim().toLowerCase()]);
      setNuevoIngrediente('');
    }
  };

  const eliminarIngrediente = (ing: string) => {
    setIngredientes(ingredientes.filter(i => i !== ing));
  };

  const buscarRecetas = async () => {
    if (ingredientes.length === 0) {
      toast.error('Añade al menos un ingrediente');
      return;
    }

    setBuscando(true);
    try {
      const response = await fetch('/api/buscar-por-ingredientes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ingredientes })
      });
      const data = await response.json();
      setResultados(data.recetas || []);
    } catch (error) {
      console.error(error);
      toast.error('Error al buscar recetas');
    } finally {
      setBuscando(false);
    }
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Refrigerator className="h-6 w-6 text-sky-500" />
            Buscador de Nevera
          </DialogTitle>
          <DialogDescription>
            ¿Qué tienes en la nevera? Te sugerimos recetas
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Input de ingredientes */}
          <div className="flex gap-2">
            <Input
              placeholder="Ej: tomate, cebolla, pollo..."
              value={nuevoIngrediente}
              onChange={(e) => setNuevoIngrediente(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && agregarIngrediente()}
              className="flex-1"
            />
            <Button onClick={agregarIngrediente}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Tags de ingredientes */}
          <div className="flex flex-wrap gap-2">
            {ingredientes.map(ing => (
              <Badge key={ing} variant="secondary" className="gap-1">
                {ing}
                <X className="h-3 w-3 cursor-pointer" onClick={() => eliminarIngrediente(ing)} />
              </Badge>
            ))}
          </div>

          {/* Botón buscar */}
          <Button
            onClick={buscarRecetas}
            disabled={buscando || ingredientes.length === 0}
            className="w-full bg-sky-600 hover:bg-sky-700"
          >
            {buscando ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Buscando...
              </>
            ) : (
              <>
                <Search className="h-4 w-4 mr-2" />
                Buscar recetas ({ingredientes.length} ingredientes)
              </>
            )}
          </Button>

          {/* Resultados */}
          {resultados.length > 0 && (
            <ScrollArea className="h-64">
              <div className="space-y-2">
                {resultados.map(receta => (
                  <Card key={receta.id}>
                    <CardContent className="pt-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={receta.imagen}
                          alt={receta.nombre}
                          className="w-12 h-12 rounded object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{receta.nombre}</h4>
                          <p className="text-xs text-muted-foreground">{receta.tiempoTotal} min • {receta.dificultad}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== LISTA DE COMPRA (NUEVA FUNCIONALIDAD) ====================

function PanelListaCompra({ abierto, onCerrar }: {
  abierto: boolean;
  onCerrar: () => void;
}) {
  interface ItemCompra {
    id: string;
    nombre: string;
    cantidad: string;
    comprado: boolean;
  }

  const [items, setItems] = useState<ItemCompra[]>([]);
  const [nuevoNombre, setNuevoNombre] = useState('');
  const [nuevaCantidad, setNuevaCantidad] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined' && abierto) {
      const saved = localStorage.getItem('cocinaviva-lista-compra');
      if (saved) {
        try {
          const parsed = JSON.parse(saved);
          requestAnimationFrame(() => setItems(parsed));
        } catch {}
      }
    }
  }, [abierto]);

  const guardarItems = (newItems: ItemCompra[]) => {
    setItems(newItems);
    localStorage.setItem('cocinaviva-lista-compra', JSON.stringify(newItems));
  };

  const agregarItem = () => {
    if (nuevoNombre.trim()) {
      const nuevo: ItemCompra = {
        id: Date.now().toString(),
        nombre: nuevoNombre.trim(),
        cantidad: nuevaCantidad.trim() || '1',
        comprado: false
      };
      guardarItems([...items, nuevo]);
      setNuevoNombre('');
      setNuevaCantidad('');
    }
  };

  const toggleComprado = (id: string) => {
    guardarItems(items.map(item =>
      item.id === id ? { ...item, comprado: !item.comprado } : item
    ));
  };

  const eliminarItem = (id: string) => {
    guardarItems(items.filter(item => item.id !== id));
  };

  const limpiarComprados = () => {
    guardarItems(items.filter(item => !item.comprado));
  };

  const vaciarLista = () => {
    guardarItems([]);
  };

  const comprados = items.filter(i => i.comprado).length;
  const total = items.length;

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <ShoppingCart className="h-6 w-6 text-teal-500" />
            Lista de Compra
          </DialogTitle>
          <DialogDescription>
            Organiza tus compras de ingredientes
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Progreso */}
          {total > 0 && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progreso</span>
                <span>{comprados}/{total}</span>
              </div>
              <Progress value={(comprados / total) * 100} className="h-2" />
            </div>
          )}

          {/* Agregar item */}
          <div className="flex gap-2">
            <Input
              placeholder="Ingrediente..."
              value={nuevoNombre}
              onChange={(e) => setNuevoNombre(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && agregarItem()}
              className="flex-1"
            />
            <Input
              placeholder="Cant."
              value={nuevaCantidad}
              onChange={(e) => setNuevaCantidad(e.target.value)}
              className="w-20"
            />
            <Button onClick={agregarItem}>
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {/* Lista */}
          <ScrollArea className="flex-1" style={{ maxHeight: '300px' }}>
            {items.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <ShoppingCart className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>Lista vacía</p>
              </div>
            ) : (
              <div className="space-y-2">
                {items.map(item => (
                  <div
                    key={item.id}
                    className={`flex items-center gap-2 p-2 rounded-lg border ${
                      item.comprado ? 'bg-teal-50 dark:bg-teal-950/30 border-teal-200' : 'bg-card'
                    }`}
                  >
                    <Check
                      className={`h-4 w-4 cursor-pointer ${item.comprado ? 'text-teal-500' : 'text-muted-foreground'}`}
                      onClick={() => toggleComprado(item.id)}
                    />
                    <span className={`flex-1 ${item.comprado ? 'line-through text-muted-foreground' : ''}`}>
                      {item.nombre}
                    </span>
                    <Badge variant="secondary" className="text-xs">{item.cantidad}</Badge>
                    <X
                      className="h-4 w-4 text-muted-foreground cursor-pointer hover:text-destructive"
                      onClick={() => eliminarItem(item.id)}
                    />
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>

          {/* Acciones */}
          {items.length > 0 && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={limpiarComprados} className="flex-1">
                <Check className="h-4 w-4 mr-1" />
                Limpiar comprados
              </Button>
              <Button variant="destructive" size="sm" onClick={vaciarLista} className="flex-1">
                <Trash2 className="h-4 w-4 mr-1" />
                Vaciar
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== PANEL COMPARTIR ====================

function PanelCompartir({ abierto, onCerrar }: {
  abierto: boolean;
  onCerrar: () => void;
}) {
  const [copiado, setCopiado] = useState(false);

  const compartirUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const copiarEnlace = async () => {
    try {
      await navigator.clipboard.writeText(compartirUrl);
      setCopiado(true);
      toast.success('Enlace copiado al portapapeles');
      setTimeout(() => setCopiado(false), 2000);
    } catch {
      toast.error('No se pudo copiar el enlace');
    }
  };

  const compartirTwitter = () => {
    const text = encodeURIComponent('¡Descubre CocinaViva! Tu cocina, tu estilo, tu sabor. 🍳👨‍🍳');
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${encodeURIComponent(compartirUrl)}`, '_blank');
  };

  const compartirFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(compartirUrl)}`, '_blank');
  };

  const compartirWhatsApp = () => {
    const text = encodeURIComponent(`¡Mira esta app de recetas! ${compartirUrl}`);
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  const compartirTelegram = () => {
    const text = encodeURIComponent(`¡Mira esta app de recetas! ${compartirUrl}`);
    window.open(`https://t.me/share/url?url=${encodeURIComponent(compartirUrl)}&text=${text}`, '_blank');
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Share2 className="h-6 w-6 text-emerald-500" />
            Compartir CocinaViva
          </DialogTitle>
          <DialogDescription>
            Comparte nuestra app con amigos y familiares
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Enlace para copiar */}
          <div className="flex gap-2">
            <Input value={compartirUrl} readOnly className="flex-1" />
            <Button onClick={copiarEnlace} variant={copiado ? 'default' : 'outline'}>
              {copiado ? <Check className="h-4 w-4" /> : <Download className="h-4 w-4" />}
            </Button>
          </div>

          {/* Redes sociales */}
          <div className="grid grid-cols-2 gap-3">
            <Button onClick={compartirWhatsApp} className="bg-green-500 hover:bg-green-600 text-white">
              <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
              </svg>
              WhatsApp
            </Button>
            <Button onClick={compartirTelegram} className="bg-blue-500 hover:bg-blue-600 text-white">
              <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
              </svg>
              Telegram
            </Button>
            <Button onClick={compartirTwitter} variant="outline" className="border-sky-500 text-sky-600 hover:bg-sky-50">
              <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
              </svg>
              Twitter/X
            </Button>
            <Button onClick={compartirFacebook} variant="outline" className="border-blue-600 text-blue-700 hover:bg-blue-50">
              <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              Facebook
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== PANEL SUGERENCIAS/BUGS ====================

function PanelSugerencias({ abierto, onCerrar }: {
  abierto: boolean;
  onCerrar: () => void;
}) {
  const [tipo, setTipo] = useState<'sugerencia' | 'bug'>('sugerencia');
  const [asunto, setAsunto] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [enviado, setEnviado] = useState(false);

  const enviarSugerencia = async () => {
    if (!asunto.trim() || !mensaje.trim()) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    setEnviando(true);
    try {
      const response = await fetch('/api/contacto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tipo,
          asunto,
          mensaje,
          email: 'iiribasu2010@gmail.com'
        })
      });

      if (!response.ok) throw new Error('Error al enviar');

      setEnviado(true);
      toast.success('¡Mensaje enviado correctamente!');
      setAsunto('');
      setMensaje('');
      setTimeout(() => {
        setEnviado(false);
        onCerrar();
      }, 2000);
    } catch (error) {
      console.error(error);
      toast.error('Error al enviar el mensaje. Inténtalo de nuevo.');
    } finally {
      setEnviando(false);
    }
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <AlertCircle className="h-6 w-6 text-blue-500" />
            Sugerencias y Bugs
          </DialogTitle>
          <DialogDescription>
            Ayúdanos a mejorar CocinaViva
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Tipo */}
          <div className="flex gap-2">
            <Button
              variant={tipo === 'sugerencia' ? 'default' : 'outline'}
              onClick={() => setTipo('sugerencia')}
              className="flex-1"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Sugerencia
            </Button>
            <Button
              variant={tipo === 'bug' ? 'destructive' : 'outline'}
              onClick={() => setTipo('bug')}
              className="flex-1"
            >
              <AlertCircle className="h-4 w-4 mr-2" />
              Reportar Bug
            </Button>
          </div>

          {/* Asunto */}
          <div className="space-y-2">
            <Label>Asunto</Label>
            <Input
              placeholder={tipo === 'sugerencia' ? 'Ej: Añadir recetas veganas' : 'Ej: Error al cargar recetas'}
              value={asunto}
              onChange={(e) => setAsunto(e.target.value)}
            />
          </div>

          {/* Mensaje */}
          <div className="space-y-2">
            <Label>Descripción</Label>
            <textarea
              className="w-full min-h-[120px] p-3 rounded-md border border-input bg-background text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder={tipo === 'sugerencia' ? 'Describe tu sugerencia con detalle...' : 'Describe el error encontrado y cómo reproducirlo...'}
              value={mensaje}
              onChange={(e) => setMensaje(e.target.value)}
            />
          </div>

          {/* Botón enviar */}
          <Button
            onClick={enviarSugerencia}
            disabled={enviando || enviado}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {enviando ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Enviando...
              </>
            ) : enviado ? (
              <>
                <Check className="h-4 w-4 mr-2" />
                ¡Enviado!
              </>
            ) : (
              <>
                <Send className="h-4 w-4 mr-2" />
                Enviar mensaje
              </>
            )}
          </Button>

          <p className="text-xs text-muted-foreground text-center">
            Tu mensaje será enviado a iiribasu2010@gmail.com
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== CAPTCHA MATEMÁTICO ====================

function generarCaptchaInicial() {
  const n1 = Math.floor(Math.random() * 10) + 1;
  const n2 = Math.floor(Math.random() * 10) + 1;
  const operadores = ['+', '-', '×'];
  const op = operadores[Math.floor(Math.random() * operadores.length)];
  return { n1, n2: op === '-' && n1 < n2 ? n1 : n2, op };
}

function CaptchaMatematico({ onValidado }: { onValidado: (valido: boolean) => void }) {
  const inicial = useMemo(() => generarCaptchaInicial(), []);
  const [num1, setNum1] = useState(inicial.n1);
  const [num2, setNum2] = useState(inicial.n2);
  const [operador, setOperador] = useState(inicial.op);
  const [respuesta, setRespuesta] = useState('');
  const [validado, setValidado] = useState(false);
  const [error, setError] = useState(false);

  const generarCaptcha = useCallback(() => {
    const { n1, n2, op } = generarCaptchaInicial();
    setNum1(n1);
    setNum2(n2);
    setOperador(op);
    setRespuesta('');
    setValidado(false);
    setError(false);
    onValidado(false);
  }, [onValidado]);

  const verificar = useCallback(() => {
    let resultadoCorrecto = 0;
    const n1 = operador === '-' && num1 < num2 ? num2 : num1;
    const n2 = operador === '-' && num1 < num2 ? num1 : num2;

    switch (operador) {
      case '+': resultadoCorrecto = num1 + num2; break;
      case '-': resultadoCorrecto = n1 - n2; break;
      case '×': resultadoCorrecto = num1 * num2; break;
    }

    const esCorrecto = parseInt(respuesta) === resultadoCorrecto;
    setValidado(esCorrecto);
    setError(!esCorrecto);
    onValidado(esCorrecto);

    if (!esCorrecto) {
      setTimeout(generarCaptcha, 1500);
    }
  }, [operador, num1, num2, respuesta, onValidado, generarCaptcha]);

  return (
    <div className="space-y-3">
      <Label className="text-sm font-medium flex items-center gap-2">
        <Shield className="h-4 w-4 text-emerald-500" />
        Verificación de seguridad
      </Label>

      <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
        <div className="flex items-center gap-2 text-lg font-mono font-bold">
          <span className="bg-gradient-to-r from-orange-500 to-rose-500 bg-clip-text text-transparent">{num1}</span>
          <span className="text-muted-foreground">{operador}</span>
          <span className="bg-gradient-to-r from-violet-500 to-purple-500 bg-clip-text text-transparent">{num2}</span>
          <span className="text-muted-foreground">=</span>
        </div>

        <Input
          type="number"
          value={respuesta}
          onChange={(e) => { setRespuesta(e.target.value); setError(false); }}
          onKeyDown={(e) => e.key === 'Enter' && verificar()}
          placeholder="?"
          className={`w-20 text-center ${error ? 'border-red-500 bg-red-50' : validado ? 'border-emerald-500 bg-emerald-50' : ''}`}
          disabled={validado}
        />

        <Button
          variant={validado ? 'default' : 'outline'}
          size="icon"
          onClick={validado ? generarCaptcha : verificar}
          className={validado ? 'bg-emerald-500 hover:bg-emerald-600' : ''}
        >
          {validado ? <Check className="h-4 w-4" /> : <Shield className="h-4 w-4" />}
        </Button>
      </div>

      {validado && (
        <div className="flex items-center gap-2 text-emerald-600 text-sm">
          <Check className="h-4 w-4" />
          Verificación correcta
        </div>
      )}
      {error && (
        <div className="flex items-center gap-2 text-red-600 text-sm">
          <X className="h-4 w-4" />
          Respuesta incorrecta, intenta de nuevo
        </div>
      )}
    </div>
  );
}

// ==================== PANEL DE LOGIN ====================

function PanelLogin({ abierto, onCerrar, onLogin }: {
  abierto: boolean;
  onCerrar: () => void;
  onLogin: (usuario: { nombre: string; email: string; avatar: string }) => void;
}) {
  const [modo, setModo] = useState<'login' | 'registro'>('login');
  const [captchaValido, setCaptchaValido] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [nombre, setNombre] = useState('');

  const redesSociales = [
    { id: 'google', nombre: 'Google', icono: '🔵', color: 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50' },
    { id: 'facebook', nombre: 'Facebook', icono: '📘', color: 'bg-blue-600 text-white hover:bg-blue-700' },
    { id: 'twitter', nombre: 'X (Twitter)', icono: '🐦', color: 'bg-black text-white hover:bg-gray-900' },
    { id: 'github', nombre: 'GitHub', icono: '🐙', color: 'bg-gray-800 text-white hover:bg-gray-900' },
  ];

  const loginConRedSocial = async (red: string) => {
    if (!captchaValido) {
      toast.error('Por favor completa la verificación de seguridad');
      return;
    }

    setCargando(true);

    // Simular login con red social
    await new Promise(resolve => setTimeout(resolve, 1500));

    const usuariosSimulados: Record<string, { nombre: string; email: string; avatar: string }> = {
      google: { nombre: 'Usuario Google', email: 'usuario@google.com', avatar: '🔵' },
      facebook: { nombre: 'Usuario Facebook', email: 'usuario@facebook.com', avatar: '📘' },
      twitter: { nombre: 'Usuario X', email: 'usuario@x.com', avatar: '🐦' },
      github: { nombre: 'Usuario GitHub', email: 'usuario@github.com', avatar: '🐙' },
    };

    onLogin(usuariosSimulados[red]);
    setCargando(false);
    toast.success(`¡Bienvenido! Sesión iniciada con ${red}`);

    // Guardar en localStorage
    localStorage.setItem('cocinaviva-usuario', JSON.stringify(usuariosSimulados[red]));

    onCerrar();
  };

  const loginConEmail = async () => {
    if (!captchaValido) {
      toast.error('Por favor completa la verificación de seguridad');
      return;
    }

    if (!email || !password || (modo === 'registro' && !nombre)) {
      toast.error('Por favor completa todos los campos');
      return;
    }

    setCargando(true);
    await new Promise(resolve => setTimeout(resolve, 1000));

    const usuario = {
      nombre: modo === 'registro' ? nombre : email.split('@')[0],
      email,
      avatar: '👤'
    };

    onLogin(usuario);
    localStorage.setItem('cocinaviva-usuario', JSON.stringify(usuario));
    setCargando(false);
    toast.success(modo === 'registro' ? '¡Cuenta creada correctamente!' : '¡Bienvenido de vuelta!');

    onCerrar();
  };

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <User className="h-6 w-6 text-orange-500" />
            {modo === 'login' ? 'Iniciar Sesión' : 'Crear Cuenta'}
          </DialogTitle>
          <DialogDescription>
            Accede a tu cuenta para guardar tus recetas favoritas
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Redes Sociales */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Continuar con</Label>
            <div className="grid grid-cols-2 gap-2">
              {redesSociales.map((red) => (
                <Button
                  key={red.id}
                  variant="outline"
                  onClick={() => loginConRedSocial(red.id)}
                  disabled={cargando || !captchaValido}
                  className={`h-11 ${red.color} border`}
                >
                  <span className="mr-2 text-lg">{red.icono}</span>
                  {red.nombre}
                </Button>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">o continúa con email</span>
            </div>
          </div>

          {/* Formulario Email */}
          <div className="space-y-3">
            {modo === 'registro' && (
              <div className="space-y-2">
                <Label>Nombre</Label>
                <Input
                  placeholder="Tu nombre"
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label>Email</Label>
              <Input
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Contraseña</Label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <Button
              onClick={loginConEmail}
              disabled={cargando || !captchaValido}
              className="w-full bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600"
            >
              {cargando ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Procesando...
                </>
              ) : modo === 'login' ? 'Iniciar Sesión' : 'Crear Cuenta'}
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              {modo === 'login' ? '¿No tienes cuenta?' : '¿Ya tienes cuenta?'}{' '}
              <button
                className="text-orange-500 hover:underline font-medium"
                onClick={() => setModo(modo === 'login' ? 'registro' : 'login')}
              >
                {modo === 'login' ? 'Regístrate' : 'Inicia sesión'}
              </button>
            </p>
          </div>

          {/* Captcha */}
          <CaptchaMatematico onValidado={setCaptchaValido} />
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== TARJETA DE RECETA ====================

function RecetaCard({ receta, onSelect, esFavorito, onToggleFavorito }: {
  receta: Receta;
  onSelect: () => void;
  esFavorito: boolean;
  onToggleFavorito: () => void;
}) {
  const dificultadConfig: Record<string, { color: string; label: string }> = {
    facil: { color: 'bg-emerald-500', label: 'Fácil' },
    medio: { color: 'bg-amber-500', label: 'Medio' },
    dificil: { color: 'bg-rose-500', label: 'Difícil' },
  };

  const config = dificultadConfig[receta.dificultad] || dificultadConfig.medio;

  return (
    <div className="group transition-transform duration-200 hover:-translate-y-1">
      <Card 
        className="overflow-hidden cursor-pointer border-0 shadow-lg hover:shadow-2xl transition-all duration-300 bg-card"
        onClick={onSelect}
      >
        <div className="relative aspect-[4/3] overflow-hidden">
          <img
            src={receta.imagen}
            alt={receta.nombre}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
          
          <div className="absolute top-3 left-3 flex gap-2">
            <Badge className={`${receta.tipo === 'thermomix' ? 'bg-violet-600 hover:bg-violet-700' : 'bg-orange-600 hover:bg-orange-700'} text-white border-0 font-medium`}>
              {receta.tipo === 'thermomix' ? (
                <><Sparkles className="h-3 w-3 mr-1" />Thermomix</>
              ) : (
                <><Utensils className="h-3 w-3 mr-1" />Tradicional</>
              )}
            </Badge>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            className={`absolute top-3 right-3 h-9 w-9 rounded-full backdrop-blur-sm transition-all ${
              esFavorito 
                ? 'bg-rose-500 text-white hover:bg-rose-600' 
                : 'bg-white/20 text-white hover:bg-white/40'
            }`}
            onClick={(e) => { e.stopPropagation(); onToggleFavorito(); }}
          >
            <Heart className={`h-5 w-5 ${esFavorito ? 'fill-current' : ''}`} />
          </Button>
          
          <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
            <h3 className="font-bold text-lg line-clamp-2 mb-2">{receta.nombre}</h3>
            <div className="flex items-center gap-3 text-sm">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                <span>{receta.tiempoTotal} min</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="h-4 w-4" />
                <span>{receta.porciones}</span>
              </div>
              <div className="flex items-center gap-1">
                <Flame className="h-4 w-4" />
                <span>{receta.calorias} kcal</span>
              </div>
            </div>
          </div>
        </div>
        
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{receta.descripcion}</p>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`h-4 w-4 ${
                      star <= Math.round(receta.valoracion)
                        ? 'text-yellow-400 fill-yellow-400'
                        : 'text-gray-200'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">({receta.numValoraciones})</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-xs capitalize">
                {receta.categoria}
              </Badge>
              <div className={`w-2.5 h-2.5 rounded-full ${config.color}`} title={config.label} />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== VISTA DETALLE DE RECETA ====================

function RecetaDetalle({ receta, onVolver, onModoCocina }: {
  receta: Receta;
  onVolver: () => void;
  onModoCocina: () => void;
}) {
  const { favoritos, toggleFavorito, agregarALista } = useAppStore();
  const [porciones, setPorciones] = useState(receta.porciones);
  const ingredientes = JSON.parse(receta.ingredientes);
  const pasos = JSON.parse(receta.pasos);
  const imagenes = JSON.parse(receta.imagenes);
  const esFavorito = favoritos.includes(receta.id);
  
  const factorPorciones = porciones / receta.porciones;
  
  const handleCompartir = async () => {
    if (navigator.share) {
      await navigator.share({
        title: receta.nombre,
        text: receta.descripcion,
        url: window.location.href,
      });
    } else {
      await navigator.clipboard.writeText(window.location.href);
      toast.success('Enlace copiado al portapapeles');
    }
  };
  
  const handleAgregarALista = () => {
    const items = ingredientes.map((ing: { nombre: string; cantidad: number; unidad: string }) => ({
      ingrediente: ing.nombre,
      cantidad: Math.round(ing.cantidad * factorPorciones),
      unidad: ing.unidad,
    }));
    agregarALista(items, receta.id);
    toast.success('Ingredientes añadidos a la lista de compra');
  };
  
  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onVolver} className="gap-2">
          <ChevronLeft className="h-4 w-4" />
          Volver
        </Button>
      </div>
      
      <div className="relative rounded-3xl overflow-hidden aspect-[21/9] shadow-2xl">
        <img src={receta.imagen} alt={receta.nombre} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
          <div className="flex flex-wrap items-center gap-2 mb-3">
            <Badge className={`${receta.tipo === 'thermomix' ? 'bg-violet-600' : 'bg-orange-600'} text-white border-0`}>
              {receta.tipo === 'thermomix' ? 'Thermomix' : 'Tradicional'}
            </Badge>
            <Badge variant="outline" className="text-white border-white/40 capitalize">{receta.categoria}</Badge>
          </div>
          <h1 className="text-3xl md:text-5xl font-bold mb-2">{receta.nombre}</h1>
          <p className="text-white/80 text-lg max-w-2xl">{receta.descripcion}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {[
          { icon: Clock, label: 'Tiempo', value: `${receta.tiempoTotal}`, suffix: 'min' },
          { icon: Users, label: 'Porciones', value: `${porciones}`, suffix: '' },
          { icon: Flame, label: 'Calorías', value: `${Math.round(receta.calorias * factorPorciones)}`, suffix: 'kcal' },
          { icon: Star, label: 'Valoración', value: receta.valoracion.toFixed(1), suffix: '/5' },
          { icon: ChefHat, label: 'Dificultad', value: receta.dificultad, suffix: '', capitalize: true },
        ].map((stat, i) => (
          <Card key={i} className="text-center border-0 shadow-md">
            <CardContent className="pt-5 pb-4">
              <stat.icon className="h-6 w-6 mx-auto mb-2 text-primary" />
              <div className="text-2xl font-bold">{stat.value}{stat.suffix && <span className="text-sm font-normal text-muted-foreground ml-1">{stat.suffix}</span>}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="flex flex-wrap gap-3">
        <Button onClick={() => toggleFavorito(receta.id)} variant={esFavorito ? 'default' : 'outline'} className={esFavorito ? 'bg-rose-500 hover:bg-rose-600' : ''}>
          <Heart className={`h-4 w-4 mr-2 ${esFavorito ? 'fill-current' : ''}`} />
          {esFavorito ? 'En favoritos' : 'Añadir a favoritos'}
        </Button>
        <Button onClick={onModoCocina} className="bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white border-0">
          <ChefHat className="h-4 w-4 mr-2" />
          Modo Cocina
        </Button>
        <Button onClick={handleAgregarALista} variant="outline">
          <ShoppingCart className="h-4 w-4 mr-2" />
          Añadir a lista
        </Button>
        <Button onClick={handleCompartir} variant="outline">
          <Share2 className="h-4 w-4 mr-2" />
          Compartir
        </Button>
      </div>
      
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            Calculadora de Porciones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => setPorciones(Math.max(1, porciones - 1))}>
              <Minus className="h-4 w-4" />
            </Button>
            <div className="text-3xl font-bold w-16 text-center">{porciones}</div>
            <Button variant="outline" size="icon" onClick={() => setPorciones(porciones + 1)}>
              <Plus className="h-4 w-4" />
            </Button>
            <span className="text-muted-foreground">personas</span>
          </div>
        </CardContent>
      </Card>
      
      <div className="grid md:grid-cols-3 gap-8">
        <Card className="md:col-span-1 border-0 shadow-md h-fit">
          <CardHeader>
            <CardTitle className="text-lg">Ingredientes</CardTitle>
            <CardDescription>Para {porciones} {porciones === 1 ? 'persona' : 'personas'}</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {ingredientes.map((ing: { nombre: string; cantidad: number; unidad: string }, i: number) => (
                <li key={i} className="flex items-start gap-3 py-2 border-b last:border-0">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                  <div className="flex-1">
                    <span className="font-medium">{Math.round(ing.cantidad * factorPorciones)}</span>
                    <span className="text-muted-foreground ml-1">{ing.unidad}</span>
                    <span className="capitalize ml-1">{ing.nombre}</span>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2 border-0 shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Preparación</CardTitle>
            <CardDescription>Prep: {receta.tiempoPreparacion} min • Cocción: {receta.tiempoCoccion} min</CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="space-y-6">
              {pasos.map((paso: { paso: number; descripcion: string; tiempo?: number }, i: number) => (
                <li key={i} className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-rose-500 text-white flex items-center justify-center font-bold text-lg shadow-lg">
                    {paso.paso}
                  </div>
                  <div className="flex-1 pt-1.5">
                    <p className="text-foreground leading-relaxed">{paso.descripcion}</p>
                    {paso.tiempo && paso.tiempo > 0 && (
                      <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{paso.tiempo} minutos</span>
                      </div>
                    )}
                  </div>
                </li>
              ))}
            </ol>
            {receta.consejos && (
              <div className="mt-8 p-5 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/30 dark:to-orange-950/30 rounded-xl border border-amber-200 dark:border-amber-800">
                <h4 className="font-semibold mb-2 flex items-center gap-2 text-amber-700 dark:text-amber-400">
                  <Sparkles className="h-4 w-4" />
                  Consejos del chef
                </h4>
                <p className="text-sm text-muted-foreground">{receta.consejos}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// ==================== MODO COCINA ====================

function ModoCocina({ receta, onSalir }: { receta: Receta; onSalir: () => void }) {
  const [pasoActual, setPasoActual] = useState(0);
  const [temporizador, setTemporizador] = useState<number | null>(null);
  const [tiempoRestante, setTiempoRestante] = useState(0);
  const pasos = JSON.parse(receta.pasos);
  
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (temporizador !== null && tiempoRestante > 0) {
      interval = setInterval(() => {
        setTiempoRestante(t => t - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [temporizador, tiempoRestante]);
  
  const iniciarTemporizador = (minutos: number) => {
    setTemporizador(minutos * 60);
    setTiempoRestante(minutos * 60);
  };
  
  const formatTiempo = (segundos: number) => {
    const min = Math.floor(segundos / 60);
    const seg = segundos % 60;
    return `${min.toString().padStart(2, '0')}:${seg.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="fixed inset-0 bg-gradient-to-b from-gray-900 to-black z-50 flex flex-col">
      <div className="flex items-center justify-between p-4 md:p-6 bg-gradient-to-r from-orange-600 to-rose-600 text-white">
        <div>
          <h1 className="text-xl md:text-2xl font-bold">{receta.nombre}</h1>
          <p className="text-sm opacity-80">Paso {pasoActual + 1} de {pasos.length}</p>
        </div>
        <Button variant="secondary" size="lg" onClick={onSalir} className="gap-2">
          <X className="h-5 w-5" />
          Salir
        </Button>
      </div>
      
      <div className="h-1.5 bg-white/10">
        <div 
          className="h-full bg-white transition-all duration-300 ease-out" 
          style={{ width: `${((pasoActual + 1) / pasos.length) * 100}%` }} 
        />
      </div>
      
      <div className="flex-1 flex items-center justify-center p-4 md:p-12">
        <div className="max-w-4xl w-full text-center">
          <div key={pasoActual} className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
            <div className="text-7xl md:text-9xl font-bold text-white/90">{pasoActual + 1}</div>
            <p className="text-2xl md:text-4xl text-white/80 leading-relaxed max-w-2xl mx-auto">{pasos[pasoActual].descripcion}</p>
            
            {pasos[pasoActual].tiempo && pasos[pasoActual].tiempo > 0 && (
              <div className="mt-8">
                {temporizador === null ? (
                  <Button size="lg" variant="secondary" onClick={() => iniciarTemporizador(pasos[pasoActual].tiempo)} className="text-lg px-8 py-6">
                    <Clock className="h-5 w-5 mr-2" />
                    Iniciar ({pasos[pasoActual].tiempo} min)
                  </Button>
                ) : (
                  <div className="font-mono text-7xl md:text-8xl text-white">{formatTiempo(tiempoRestante)}</div>
                )}
              </div>
            )}
            
            {tiempoRestante === 0 && temporizador !== null && (
              <div className="text-3xl text-emerald-400 animate-in zoom-in duration-200">
                ¡Tiempo completado!
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center justify-center gap-4 p-6 md:p-8">
        <Button size="lg" variant="secondary" disabled={pasoActual === 0} onClick={() => { setPasoActual(p => p - 1); setTemporizador(null); }} className="px-8">
          <ChevronLeft className="h-6 w-6 mr-2" />
          Anterior
        </Button>
        {pasoActual < pasos.length - 1 ? (
          <Button size="lg" className="bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white px-8" onClick={() => { setPasoActual(p => p + 1); setTemporizador(null); }}>
            Siguiente
            <ChevronRight className="h-6 w-6 ml-2" />
          </Button>
        ) : (
          <Button size="lg" className="bg-emerald-500 hover:bg-emerald-600 text-white px-8" onClick={onSalir}>
            <Check className="h-6 w-6 mr-2" />
            ¡Completado!
          </Button>
        )}
      </div>
    </div>
  );
}

// ==================== PANEL DE AJUSTES ====================

function PanelAjustes({ abierto, onCerrar, usuario, onActualizarUsuario }: {
  abierto: boolean;
  onCerrar: () => void;
  usuario: { nombre: string; email: string; avatar: string } | null;
  onActualizarUsuario: (user: { nombre: string; email: string; avatar: string }) => void;
}) {
  const { theme, setTheme } = useTheme();
  const { config, setConfig, exportarDatos, importarDatos, mounted } = useLocalConfig();

  // Estado para edición de perfil
  const [editandoNombre, setEditandoNombre] = useState(false);
  const [nuevoNombre, setNuevoNombre] = useState(usuario?.nombre || '');

  // Sincronizar nuevoNombre con usuario cuando se abre el panel
  const handleOpenChange = (open: boolean) => {
    if (open && usuario) {
      setNuevoNombre(usuario.nombre);
    }
    if (!open) {
      onCerrar();
    }
  };

  const AVATARES = ['👤', '👨‍🍳', '👩‍🍳', '🧑‍🍳', '🍳', '🥘', '🍕', '🍔', '🥗', '🍜', '🥐', '🍰', '🍷', '☕', '🧁', '🌮'];
  const NIVELES_COCINA = [
    { id: 'principiante', label: 'Principiante', icon: '🌱' },
    { id: 'aficionado', label: 'Aficionado', icon: '🍳' },
    { id: 'intermedio', label: 'Intermedio', icon: '👨‍🍳' },
    { id: 'avanzado', label: 'Avanzado', icon: '⭐' },
    { id: 'experto', label: 'Experto', icon: '👑' },
  ];

  const guardarNombre = () => {
    if (nuevoNombre.trim() && usuario) {
      const usuarioActualizado = { ...usuario, nombre: nuevoNombre.trim() };
      onActualizarUsuario(usuarioActualizado);
      localStorage.setItem('cocinaviva-usuario', JSON.stringify(usuarioActualizado));
      toast.success('Nombre actualizado');
      setEditandoNombre(false);
    }
  };

  const cambiarAvatar = (avatar: string) => {
    if (usuario) {
      const usuarioActualizado = { ...usuario, avatar };
      onActualizarUsuario(usuarioActualizado);
      localStorage.setItem('cocinaviva-usuario', JSON.stringify(usuarioActualizado));
      toast.success('Avatar actualizado');
    }
  };

  const RESTRICCIONES = [
    { id: 'vegetariano', label: 'Vegetariano' },
    { id: 'vegano', label: 'Vegano' },
    { id: 'sinGluten', label: 'Sin Gluten' },
    { id: 'sinLactosa', label: 'Sin Lactosa' },
    { id: 'bajoSodio', label: 'Bajo en Sodio' },
    { id: 'bajoAzucar', label: 'Bajo en Azúcar' },
  ];
  
  const COCINAS = ['espanola', 'italiana', 'mexicana', 'francesa', 'china', 'japonesa', 'india', 'arabe', 'griega', 'peruana'];
  
  const TAMAÑOS_FUENTE = [
    { id: 'pequeno', label: 'S', desc: 'Pequeño' },
    { id: 'mediano', label: 'M', desc: 'Mediano' },
    { id: 'grande', label: 'L', desc: 'Grande' },
    { id: 'xl', label: 'XL', desc: 'Extra Grande' },
  ];
  
  const ORDENES = [
    { id: 'alfabetico', label: 'Alfabético', icon: SortAsc },
    { id: 'mejorValoradas', label: 'Mejor Valoradas', icon: Star },
    { id: 'masRecientes', label: 'Más Recientes', icon: Clock },
    { id: 'tiempoCoccion', label: 'Tiempo de Cocción', icon: Flame },
  ];
  
  if (!mounted) return null;

  return (
    <Dialog open={abierto} onOpenChange={onCerrar}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Settings className="h-5 w-5" />
            Ajustes de CocinaViva
          </DialogTitle>
          <DialogDescription>Personaliza tu experiencia culinaria</DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="max-h-[70vh]">
        <div className="space-y-6 mt-6 pr-4">
          {/* === MI PERFIL === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <User className="h-4 w-4" />
              👤 Mi Perfil
            </h3>

            {usuario ? (
              <Card className="border-orange-200 dark:border-orange-800 bg-gradient-to-r from-orange-50 to-rose-50 dark:from-orange-950/30 dark:to-rose-950/30">
                <CardContent className="pt-4 space-y-4">
                  {/* Avatar y Nombre */}
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <div className="text-5xl">{usuario.avatar}</div>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" size="icon" className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full">
                            <Edit className="h-3 w-3" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-64">
                          <div className="space-y-3">
                            <Label className="text-sm font-medium">Elige tu avatar</Label>
                            <div className="grid grid-cols-4 gap-2">
                              {AVATARES.map(av => (
                                <Button
                                  key={av}
                                  variant={usuario.avatar === av ? 'default' : 'outline'}
                                  size="icon"
                                  onClick={() => cambiarAvatar(av)}
                                  className="text-2xl h-10 w-10"
                                >
                                  {av}
                                </Button>
                              ))}
                            </div>
                          </div>
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="flex-1">
                      {editandoNombre ? (
                        <div className="flex gap-2">
                          <Input
                            value={nuevoNombre}
                            onChange={(e) => setNuevoNombre(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && guardarNombre()}
                            className="flex-1"
                            autoFocus
                          />
                          <Button size="sm" onClick={guardarNombre}>
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditandoNombre(false)}>
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-lg">{usuario.nombre}</h4>
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setEditandoNombre(true)}>
                            <Edit className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                      <p className="text-sm text-muted-foreground">{usuario.email}</p>
                    </div>
                  </div>

                  {/* 10 Ajustes de Usuario */}
                  <Separator />

                  {/* 1. Nivel de Cocina */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <ChefHat className="h-4 w-4 text-orange-500" />
                      1. Nivel de Cocina
                    </Label>
                    <div className="flex flex-wrap gap-2">
                      {NIVELES_COCINA.map(nivel => (
                        <Button
                          key={nivel.id}
                          variant={config.nivelCocina === nivel.id ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setConfig({ nivelCocina: nivel.id as any })}
                          className="gap-1"
                        >
                          <span>{nivel.icon}</span>
                          {nivel.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* 2. Biografía */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <FileText className="h-4 w-4 text-blue-500" />
                      2. Biografía
                    </Label>
                    <textarea
                      className="w-full min-h-[60px] p-2 text-sm border rounded-md bg-background resize-none"
                      placeholder="Cuéntanos sobre ti y tu pasión por la cocina..."
                      value={config.biografia || ''}
                      onChange={(e) => setConfig({ biografia: e.target.value })}
                    />
                  </div>

                  {/* 3. Ubicación */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      📍 3. Ubicación
                    </Label>
                    <Input
                      placeholder="¿Dónde cocinas?"
                      value={config.ubicacion || ''}
                      onChange={(e) => setConfig({ ubicacion: e.target.value })}
                    />
                  </div>

                  {/* 4. Mostrar logros en perfil */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium flex items-center gap-2">
                        <Trophy className="h-4 w-4 text-yellow-500" />
                        4. Mostrar Logros en Perfil
                      </Label>
                      <p className="text-xs text-muted-foreground">Muestra tus logros desbloqueados públicamente</p>
                    </div>
                    <Switch checked={config.mostrarLogros ?? true} onCheckedChange={(v) => setConfig({ mostrarLogros: v })} />
                  </div>

                  {/* 5. Recibir sugerencias semanales */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium flex items-center gap-2">
                        📧 5. Sugerencias Semanales
                      </Label>
                      <p className="text-xs text-muted-foreground">Recibe recetas recomendadas cada semana</p>
                    </div>
                    <Switch checked={config.sugerenciasSemanales ?? true} onCheckedChange={(v) => setConfig({ sugerenciasSemanales: v })} />
                  </div>

                  {/* 6. Unidades de medida */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <Scale className="h-4 w-4 text-emerald-500" />
                      6. Unidades de Medida
                    </Label>
                    <div className="flex gap-2">
                      <Button
                        variant={config.sistemaUnidades === 'metrico' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setConfig({ sistemaUnidades: 'metrico' })}
                      >
                        Métrico (g, ml)
                      </Button>
                      <Button
                        variant={config.sistemaUnidades === 'imperial' ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setConfig({ sistemaUnidades: 'imperial' })}
                      >
                        Imperial (oz, cups)
                      </Button>
                    </div>
                  </div>

                  {/* 7. Idioma preferido para recetas */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      🌍 7. Idioma de Recetas
                    </Label>
                    <Select value={config.idiomaRecetas || 'es'} onValueChange={(v) => setConfig({ idiomaRecetas: v })}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="es">🇪🇸 Español</SelectItem>
                        <SelectItem value="en">🇬🇧 English</SelectItem>
                        <SelectItem value="fr">🇫🇷 Français</SelectItem>
                        <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                        <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                        <SelectItem value="pt">🇵🇹 Português</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* 8. Tipo de cocina favorito */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <Utensils className="h-4 w-4 text-violet-500" />
                      8. Tipo de Cocina Favorito
                    </Label>
                    <Select value={config.cocinaFavorita || 'espanola'} onValueChange={(v) => setConfig({ cocinaFavorita: v })}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="espanola">🇪🇸 Española</SelectItem>
                        <SelectItem value="italiana">🇮🇹 Italiana</SelectItem>
                        <SelectItem value="mexicana">🇲🇽 Mexicana</SelectItem>
                        <SelectItem value="china">🇨🇳 China</SelectItem>
                        <SelectItem value="japonesa">🇯🇵 Japonesa</SelectItem>
                        <SelectItem value="india">🇮🇳 India</SelectItem>
                        <SelectItem value="francesa">🇫🇷 Francesa</SelectItem>
                        <SelectItem value="tailandesa">🇹🇭 Tailandesa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* 9. Recetas por página */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium flex items-center gap-2">
                      <Layout className="h-4 w-4 text-cyan-500" />
                      9. Recetas por Página
                    </Label>
                    <div className="flex items-center gap-3">
                      {[6, 9, 12, 18, 24].map(num => (
                        <Button
                          key={num}
                          variant={(config.recetasPorPagina || 12) === num ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setConfig({ recetasPorPagina: num })}
                          className="w-10"
                        >
                          {num}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* 10. Confirmar antes de eliminar */}
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm font-medium flex items-center gap-2">
                        <AlertCircle className="h-4 w-4 text-amber-500" />
                        10. Confirmar Eliminaciones
                      </Label>
                      <p className="text-xs text-muted-foreground">Pide confirmación antes de eliminar favoritos o listas</p>
                    </div>
                    <Switch checked={config.confirmarEliminar ?? true} onCheckedChange={(v) => setConfig({ confirmarEliminar: v })} />
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-dashed">
                <CardContent className="pt-4 text-center">
                  <User className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground mb-3">Inicia sesión para personalizar tu perfil</p>
                  <Button onClick={onCerrar}>Iniciar Sesión</Button>
                </CardContent>
              </Card>
            )}
          </div>

          <Separator />

          {/* === APARIENCIA === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Apariencia
            </h3>
            
            <div className="space-y-3">
              <Label className="text-sm">Tema</Label>
              <div className="flex gap-2">
                {(['light', 'dark', 'system'] as const).map(t => (
                  <Button key={t} variant={theme === t ? 'default' : 'outline'} size="sm" onClick={() => setTheme(t)}>
                    {t === 'light' ? '☀️ Claro' : t === 'dark' ? '🌙 Oscuro' : '💻 Sistema'}
                  </Button>
                ))}
              </div>
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Idioma</Label>
              <Select value={config.idioma} onValueChange={(v) => setConfig({ idioma: v as LocalConfig['idioma'] })}>
                <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-80">
                  {/* Idiomas oficiales España */}
                  <SelectItem value="es">🇪🇸 Español</SelectItem>
                  <SelectItem value="ca">🏴 Català</SelectItem>
                  <SelectItem value="gl">🏴 Galego</SelectItem>
                  <SelectItem value="eu">🏴 Euskera</SelectItem>
                  <SelectItem value="en">🇬🇧 English</SelectItem>
                  {/* Europa */}
                  <SelectItem value="fr">🇫🇷 Français</SelectItem>
                  <SelectItem value="de">🇩🇪 Deutsch</SelectItem>
                  <SelectItem value="it">🇮🇹 Italiano</SelectItem>
                  <SelectItem value="pt">🇵🇹 Português</SelectItem>
                  <SelectItem value="ru">🇷🇺 Русский</SelectItem>
                  <SelectItem value="nl">🇳🇱 Nederlands</SelectItem>
                  <SelectItem value="pl">🇵🇱 Polski</SelectItem>
                  <SelectItem value="tr">🇹🇷 Türkçe</SelectItem>
                  <SelectItem value="el">🇬🇷 Ελληνικά</SelectItem>
                  <SelectItem value="sv">🇸🇪 Svenska</SelectItem>
                  <SelectItem value="da">🇩🇰 Dansk</SelectItem>
                  <SelectItem value="no">🇳🇴 Norsk</SelectItem>
                  <SelectItem value="fi">🇫🇮 Suomi</SelectItem>
                  {/* Asia */}
                  <SelectItem value="zh">🇨🇳 中文</SelectItem>
                  <SelectItem value="ja">🇯🇵 日本語</SelectItem>
                  <SelectItem value="ko">🇰🇷 한국어</SelectItem>
                  <SelectItem value="vi">🇻🇳 Tiếng Việt</SelectItem>
                  <SelectItem value="th">🇹🇭 ไทย</SelectItem>
                  <SelectItem value="hi">🇮🇳 हिन्दी</SelectItem>
                  {/* Otros */}
                  <SelectItem value="ar">🇸🇦 العربية</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Separator />
          
          {/* === VISUALIZACIÓN Y LECTURA === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Type className="h-4 w-4" />
              📖 Visualización y Lectura
            </h3>
            
            <div className="space-y-3">
              <Label className="text-sm">Tamaño de Fuente</Label>
              <div className="flex gap-2">
                {TAMAÑOS_FUENTE.map(t => (
                  <Button 
                    key={t.id} 
                    variant={config.tamanoFuente === t.id ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setConfig({ tamanoFuente: t.id as LocalConfig['tamanoFuente'] })}
                    className="w-12 h-10"
                  >
                    <span className="text-lg font-bold">{t.label}</span>
                  </Button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">Control deslizable para aumentar la legibilidad</p>
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Vista de Pasos</Label>
              <div className="flex gap-2">
                <Button 
                  variant={config.vistaPasos === 'lista' ? 'default' : 'outline'} 
                  size="sm" 
                  onClick={() => setConfig({ vistaPasos: 'lista' })}
                  className="gap-2"
                >
                  <List className="h-4 w-4" />
                  Lista continua
                </Button>
                <Button 
                  variant={config.vistaPasos === 'tarjetas' ? 'default' : 'outline'} 
                  size="sm" 
                  onClick={() => setConfig({ vistaPasos: 'tarjetas' })}
                  className="gap-2"
                >
                  <Layout className="h-4 w-4" />
                  Tarjetas paso a paso
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Alternar entre vista de scroll vertical o un paso por pantalla</p>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm">Ocultar Fotos en Recetas</Label>
                <p className="text-xs text-muted-foreground">Ahorra datos móviles y acelera la navegación</p>
              </div>
              <Switch checked={config.ocultarFotos} onCheckedChange={(v) => setConfig({ ocultarFotos: v })} />
            </div>
          </div>
          
          <Separator />
          
          {/* === ORDEN PREDETERMINADO === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <SortAsc className="h-4 w-4" />
              Orden Predeterminado
            </h3>
            
            <div className="grid grid-cols-2 gap-2">
              {ORDENES.map(o => {
                const Icon = o.icon;
                return (
                  <Button 
                    key={o.id} 
                    variant={config.ordenRecetas === o.id ? 'default' : 'outline'} 
                    size="sm" 
                    onClick={() => setConfig({ ordenRecetas: o.id as LocalConfig['ordenRecetas'] })}
                    className="justify-start gap-2"
                  >
                    <Icon className="h-4 w-4" />
                    {o.label}
                  </Button>
                );
              })}
            </div>
          </div>
          
          <Separator />
          
          {/* === DIETA Y PREFERENCIAS === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Utensils className="h-4 w-4" />
              Dieta y Preferencias
            </h3>
            
            <div className="space-y-3">
              <Label className="text-sm">Restricciones Alimentarias</Label>
              <div className="flex flex-wrap gap-2">
                {RESTRICCIONES.map(r => (
                  <Badge key={r.id} variant={config.restricciones.includes(r.id) ? 'default' : 'outline'} className="cursor-pointer px-3 py-1.5" onClick={() => {
                    const nuevas = config.restricciones.includes(r.id) ? config.restricciones.filter(x => x !== r.id) : [...config.restricciones, r.id];
                    setConfig({ restricciones: nuevas });
                  }}>
                    {r.label}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Número de Comensales</Label>
              <div className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => setConfig({ numeroComensales: Math.max(1, config.numeroComensales - 1) })}>
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="text-2xl font-bold w-12 text-center">{config.numeroComensales}</span>
                <Button variant="outline" size="icon" onClick={() => setConfig({ numeroComensales: config.numeroComensales + 1 })}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Región Gastronómica</Label>
              <Select value={config.regionGastronomica} onValueChange={(v) => setConfig({ regionGastronomica: v })}>
                <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {COCINAS.map(c => (
                    <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Separator />
          
          {/* === PRIVACIDAD Y CUENTA === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Shield className="h-4 w-4" />
              🔒 Privacidad y Cuenta
            </h3>
            
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm">Perfil Público</Label>
                <p className="text-xs text-muted-foreground">Otros usuarios pueden ver tus recetas y actividad</p>
              </div>
              <Switch checked={config.perfilPublico} onCheckedChange={(v) => setConfig({ perfilPublico: v })} />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm">Ocultar Historial de Búsqueda</Label>
                <p className="text-xs text-muted-foreground">Las búsquedas no se guardan</p>
              </div>
              <Switch checked={config.ocultarHistorial} onCheckedChange={(v) => setConfig({ ocultarHistorial: v })} />
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Exportar Mis Datos</Label>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => {
                  const data = {
                    config,
                    exportDate: new Date().toISOString(),
                    version: '1.0'
                  };
                  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `cocinaviva-data-${new Date().toISOString().split('T')[0]}.json`;
                  a.click();
                  toast.success('Datos exportados correctamente');
                }}>
                  <FileText className="h-4 w-4 mr-2" />
                  JSON
                </Button>
                <Button variant="outline" size="sm" onClick={() => {
                  const csvContent = 'Campo,Valor\n' + 
                    Object.entries(config).map(([k, v]) => `${k},"${typeof v === 'object' ? JSON.stringify(v) : v}"`).join('\n');
                  const blob = new Blob([csvContent], { type: 'text/csv' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `cocinaviva-data-${new Date().toISOString().split('T')[0]}.csv`;
                  a.click();
                  toast.success('Datos exportados en CSV');
                }}>
                  <Download className="h-4 w-4 mr-2" />
                  CSV
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Descarga tu información por transparencia y portabilidad</p>
            </div>
          </div>
          
          <Separator />
          
          {/* === ACCESIBILIDAD === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Accessibility className="h-4 w-4" />
              ♿ Accesibilidad
            </h3>
            
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm flex items-center gap-2">
                  <Contrast className="h-4 w-4" />
                  Modo Alto Contraste
                </Label>
                <p className="text-xs text-muted-foreground">Texto negro sobre fondo blanco para mayor visibilidad</p>
              </div>
              <Switch checked={config.altoContraste} onCheckedChange={(v) => setConfig({ altoContraste: v })} />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm flex items-center gap-2">
                  <Sparkles className="h-4 w-4" />
                  Reducir Movimiento
                </Label>
                <p className="text-xs text-muted-foreground">Desactiva animaciones y transiciones</p>
              </div>
              <Switch checked={config.reducirMovimiento} onCheckedChange={(v) => setConfig({ reducirMovimiento: v })} />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm flex items-center gap-2">
                  <Volume1 className="h-4 w-4" />
                  Lectura de Pasos (TTS)
                </Label>
                <p className="text-xs text-muted-foreground">Lee los pasos en voz alta usando síntesis de voz del sistema</p>
              </div>
              <Switch checked={config.ttsActivo} onCheckedChange={(v) => setConfig({ ttsActivo: v })} />
            </div>
          </div>
          
          <Separator />
          
          {/* === NOTIFICACIONES === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Volume2 className="h-4 w-4" />
              Notificaciones
            </h3>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm">Activar notificaciones</Label>
              <Switch checked={config.notificaciones} onCheckedChange={(v) => setConfig({ notificaciones: v })} />
            </div>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm">Sonidos</Label>
              <Switch checked={config.sonidos} onCheckedChange={(v) => setConfig({ sonidos: v })} />
            </div>
          </div>
          
          <Separator />
          
          {/* === AVANZADO === */}
          <div className="space-y-4">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Avanzado
            </h3>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm">Animaciones</Label>
              <Switch checked={config.animaciones} onCheckedChange={(v) => setConfig({ animaciones: v })} />
            </div>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm">Autoguardado</Label>
              <Switch checked={config.autoguardado} onCheckedChange={(v) => setConfig({ autoguardado: v })} />
            </div>
            
            <div className="flex items-center justify-between">
              <Label className="text-sm">Vista Compacta</Label>
              <Switch checked={config.vistaCompacta} onCheckedChange={(v) => setConfig({ vistaCompacta: v })} />
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Calidad de Imágenes</Label>
              <Select value={config.calidadImagenes} onValueChange={(v) => setConfig({ calidadImagenes: v as LocalConfig['calidadImagenes'] })}>
                <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="alta">Alta</SelectItem>
                  <SelectItem value="media">Media</SelectItem>
                  <SelectItem value="baja">Baja</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Sistema de Unidades</Label>
              <Select value={config.sistemaUnidades} onValueChange={(v) => setConfig({ sistemaUnidades: v as LocalConfig['sistemaUnidades'] })}>
                <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="metrico">Métrico (g, ml)</SelectItem>
                  <SelectItem value="imperial">Imperial (oz, cups)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-3">
              <Label className="text-sm">Importar/Exportar Configuración</Label>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={exportarDatos}>
                  <Download className="h-4 w-4 mr-2" />
                  Exportar
                </Button>
                <Button variant="outline" size="sm" onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = '.json';
                  input.onchange = async (e) => {
                    const file = (e.target as HTMLInputElement).files?.[0];
                    if (file) {
                      const text = await file.text();
                      importarDatos(text);
                    }
                  };
                  input.click();
                }}>
                  <Upload className="h-4 w-4 mr-2" />
                  Importar
                </Button>
              </div>
            </div>
          </div>
        </div>
        </ScrollArea>
        
        {/* === SECCIÓN OCULTA DE ADMINISTRADOR === */}
        <AdminSettings />
        
        <div className="flex justify-end mt-6 pt-4 border-t">
          <Button onClick={() => { toast.success('Ajustes guardados'); onCerrar(); }}>Guardar y cerrar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ==================== PANEL DE AJUSTES OCULTOS DE ADMINISTRADOR ====================

function AdminSettings() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [codigoAdmin, setCodigoAdmin] = useState('');
  const [intentos, setIntentos] = useState(0);
  
  // Los 12 ajustes ocultos de administrador
  const [adminSettings, setAdminSettings] = useState({
    // 1. Modo desarrollador
    modoDesarrollador: false,
    // 2. Ver logs detallados
    verLogsDetallados: false,
    // 3. Acceso a API directamente
    accesoDirectoAPI: false,
    // 4. Editar recetas del sistema
    editarRecetasSistema: false,
    // 5. Exportar base de datos completa
    exportarBDCompleta: false,
    // 6. Ver estadísticas detalladas
    verEstadisticasDetalladas: false,
    // 7. Modo mantenimiento
    modoMantenimiento: false,
    // 8. Limpiar cache del sistema
    limpiarCache: false,
    // 9. Resetear logros usuarios
    resetearLogros: false,
    // 10. Ver errores del sistema
    verErroresSistema: false,
    // 11. Cambiar tema global
    temaGlobalForzado: 'auto',
    // 12. Activar funcionalidades beta
    funcionalidadesBeta: false,
  });

  // Código secreto para administrador (en producción usar autenticación real)
  const CODIGO_SECRETO = 'cocinaviva2026admin';

  const verificarAdmin = () => {
    if (codigoAdmin === CODIGO_SECRETO) {
      setIsAdmin(true);
      toast.success('✅ Acceso de administrador activado');
    } else {
      setIntentos(prev => prev + 1);
      toast.error('❌ Código incorrecto');
      if (intentos >= 2) {
        toast.error('Demasiados intentos. Espera 30 segundos.');
        setTimeout(() => setIntentos(0), 30000);
      }
    }
  };

  const toggleAdminSetting = (key: keyof typeof adminSettings) => {
    setAdminSettings(prev => ({ ...prev, [key]: !prev[key] }));
    toast.success(`Ajuste actualizado`);
  };

  // Si ya es admin, mostrar los 12 ajustes
  if (isAdmin) {
    return (
      <div className="mt-6 p-4 border-2 border-dashed border-red-300 dark:border-red-800 rounded-lg bg-red-50/50 dark:bg-red-950/20">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg text-red-600 dark:text-red-400 flex items-center gap-2">
            🔐 Panel de Administrador
          </h3>
          <Button variant="ghost" size="sm" onClick={() => setIsAdmin(false)} className="text-red-600">
            Cerrar sesión admin
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* 1. Modo desarrollador */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Code className="h-4 w-4 text-purple-500" />
              <span className="text-sm">1. Modo Desarrollador</span>
            </div>
            <Switch checked={adminSettings.modoDesarrollador} onCheckedChange={() => toggleAdminSetting('modoDesarrollador')} />
          </div>
          
          {/* 2. Ver logs detallados */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-blue-500" />
              <span className="text-sm">2. Ver Logs Detallados</span>
            </div>
            <Switch checked={adminSettings.verLogsDetallados} onCheckedChange={() => toggleAdminSetting('verLogsDetallados')} />
          </div>
          
          {/* 3. Acceso directo API */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-yellow-500" />
              <span className="text-sm">3. Acceso Directo API</span>
            </div>
            <Switch checked={adminSettings.accesoDirectoAPI} onCheckedChange={() => toggleAdminSetting('accesoDirectoAPI')} />
          </div>
          
          {/* 4. Editar recetas del sistema */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Edit className="h-4 w-4 text-green-500" />
              <span className="text-sm">4. Editar Recetas Sistema</span>
            </div>
            <Switch checked={adminSettings.editarRecetasSistema} onCheckedChange={() => toggleAdminSetting('editarRecetasSistema')} />
          </div>
          
          {/* 5. Exportar BD completa */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-cyan-500" />
              <span className="text-sm">5. Exportar BD Completa</span>
            </div>
            <Button variant="outline" size="sm" onClick={() => toast.success('Exportando base de datos...')}>
              <Download className="h-3 w-3 mr-1" />
              Exportar
            </Button>
          </div>
          
          {/* 6. Ver estadísticas detalladas */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-indigo-500" />
              <span className="text-sm">6. Estadísticas Detalladas</span>
            </div>
            <Switch checked={adminSettings.verEstadisticasDetalladas} onCheckedChange={() => toggleAdminSetting('verEstadisticasDetalladas')} />
          </div>
          
          {/* 7. Modo mantenimiento */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Wrench className="h-4 w-4 text-orange-500" />
              <span className="text-sm">7. Modo Mantenimiento</span>
            </div>
            <Switch checked={adminSettings.modoMantenimiento} onCheckedChange={() => toggleAdminSetting('modoMantenimiento')} />
          </div>
          
          {/* 8. Limpiar cache */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Trash2 className="h-4 w-4 text-red-500" />
              <span className="text-sm">8. Limpiar Cache Sistema</span>
            </div>
            <Button variant="outline" size="sm" onClick={() => { localStorage.clear(); toast.success('Cache limpiado'); }}>
              Limpiar
            </Button>
          </div>
          
          {/* 9. Resetear logros */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-amber-500" />
              <span className="text-sm">9. Resetear Logros Usuarios</span>
            </div>
            <Button variant="outline" size="sm" onClick={() => toast.success('Logros reseteados')}>
              Resetear
            </Button>
          </div>
          
          {/* 10. Ver errores del sistema */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-rose-500" />
              <span className="text-sm">10. Ver Errores Sistema</span>
            </div>
            <Switch checked={adminSettings.verErroresSistema} onCheckedChange={() => toggleAdminSetting('verErroresSistema')} />
          </div>
          
          {/* 11. Tema global forzado */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Palette className="h-4 w-4 text-pink-500" />
              <span className="text-sm">11. Tema Global Forzado</span>
            </div>
            <Select value={adminSettings.temaGlobalForzado} onValueChange={(v) => setAdminSettings(prev => ({ ...prev, temaGlobalForzado: v }))}>
              <SelectTrigger className="w-24 h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="auto">Auto</SelectItem>
                <SelectItem value="light">Claro</SelectItem>
                <SelectItem value="dark">Oscuro</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          {/* 12. Funcionalidades beta */}
          <div className="flex items-center justify-between p-3 bg-background rounded border">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-violet-500" />
              <span className="text-sm">12. Funcionalidades Beta</span>
            </div>
            <Switch checked={adminSettings.funcionalidadesBeta} onCheckedChange={() => toggleAdminSetting('funcionalidadesBeta')} />
          </div>
        </div>
        
        <p className="text-xs text-muted-foreground mt-4 text-center">
          ⚠️ Estos ajustes solo son visibles para administradores autorizados
        </p>
      </div>
    );
  }

  // Si no es admin, mostrar input para código
  return (
    <div className="mt-6 pt-4 border-t">
      <div className="text-center">
        <p className="text-xs text-muted-foreground mb-2">¿Eres administrador?</p>
        <div className="flex gap-2 max-w-xs mx-auto">
          <Input
            type="password"
            placeholder="Código de administrador"
            value={codigoAdmin}
            onChange={(e) => setCodigoAdmin(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && verificarAdmin()}
            className="text-center"
          />
          <Button variant="ghost" size="sm" onClick={verificarAdmin}>
            <Lock className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

// ==================== COMPONENTE PRINCIPAL ====================

export default function CocinaViva() {
  const [recetas, setRecetas] = useState<Receta[]>([]);
  const [stats, setStats] = useState({ totalRecetas: 2000, tradicionales: 1000, thermomix: 1000 });
  const [cargando, setCargando] = useState(true);
  const [pagina, setPagina] = useState(1);
  const [totalPaginas, setTotalPaginas] = useState(1);
  const [mounted, setMounted] = useState(false);
  
  // Estados de modales agrupados para mejor rendimiento
  const [modales, setModales] = useState({
    ajustes: false, logros: false, desafios: false, estadisticas: false,
    chefIa: false, escalado: false, nutricion: false, planificador: false, guiaVoz: false,
    escanerRecetas: false, chefPro: false, nexusAi: false,
    conversorUnidades: false, calculadoraPrecios: false, gestorDespensa: false,
    biblioteca: false, nevera: false, listaCompra: false, menuFunciones: false,
    compartir: false, sugerencias: false, login: false, crearReceta: false, compartirLista: false
  });
  
  const openModal = (name: keyof typeof modales) => setModales(prev => ({ ...prev, [name]: true }));
  const closeModal = (name: keyof typeof modales) => setModales(prev => ({ ...prev, [name]: false }));
  const openModalAndCloseMenu = (name: keyof typeof modales) => {
    setModales(prev => ({ ...prev, [name]: true, menuFunciones: false }));
  };
  
  const { vistaActual, setVistaActual, busqueda, setBusqueda, filtros, setFiltros, resetFiltros, favoritos, toggleFavorito, recetaSeleccionada, setRecetaSeleccionada, modoCocina, setModoCocina } = useAppStore();
  
  const [usuario, setUsuario] = useState<{ nombre: string; email: string; avatar: string } | null>(null);

  // Inicialización
  useEffect(() => {
    const savedUser = localStorage.getItem('cocinaviva-usuario');
    if (savedUser) setUsuario(JSON.parse(savedUser));
    
    const savedConfig = localStorage.getItem('cocinaviva-local-config');
    if (savedConfig) {
      const config = JSON.parse(savedConfig);
      document.body.classList.add(`font-size-${config.tamanoFuente || 'mediano'}`);
    }
    
    setMounted(true);
  }, []);
  
  // Cargar datos
  useEffect(() => {
    if (!mounted) return;
    
    const cargarDatos = async () => {
      setCargando(true);
      try {
        const params = new URLSearchParams({
          page: pagina.toString(),
          limit: '12',
          busqueda,
          ...(filtros.tipo && { tipo: filtros.tipo }),
          ...(filtros.categoria && { categoria: filtros.categoria }),
          ...(filtros.dificultad && { dificultad: filtros.dificultad }),
        });
        const [recetasRes, statsRes] = await Promise.all([
          fetch(`/api/recetas?${params}`),
          fetch('/api/stats')
        ]);
        const recetasData = await recetasRes.json();
        const statsData = await statsRes.json();
        setRecetas(recetasData.recetas || []);
        setTotalPaginas(recetasData.paginacion?.totalPages || 1);
        setStats(statsData);
      } catch (e) {
        console.error('Error cargando datos');
      } finally {
        setCargando(false);
      }
    };
    cargarDatos();
  }, [mounted, pagina, busqueda, filtros.tipo, filtros.categoria, filtros.dificultad]);
  
  const recetasFavoritas = recetas.filter(r => favoritos.includes(r.id));
  
  if (!mounted) return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="animate-pulse text-center">
        <ChefHat className="h-16 w-16 mx-auto mb-4 text-primary" />
        <p className="text-muted-foreground">Cargando CocinaViva...</p>
      </div>
    </div>
  );
  
  if (modoCocina && recetaSeleccionada) {
    return <ModoCocina receta={recetaSeleccionada} onSalir={() => setModoCocina(false)} />;
  }
  
  const renderVistaPrincipal = () => {
    if (recetaSeleccionada) {
      return <RecetaDetalle receta={recetaSeleccionada} onVolver={() => setRecetaSeleccionada(null)} onModoCocina={() => setModoCocina(true)} />;
    }
    
    switch (vistaActual) {
      case 'favoritos':
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Mis Favoritos</h2>
              <Badge variant="secondary">{recetasFavoritas.length} recetas</Badge>
            </div>
            {recetasFavoritas.length === 0 ? (
              <div className="text-center py-20 text-muted-foreground">
                <Heart className="h-20 w-20 mx-auto mb-6 opacity-30" />
                <p className="text-lg font-medium">No tienes recetas favoritas</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {recetasFavoritas.map(receta => (
                  <RecetaCard key={receta.id} receta={receta} onSelect={() => setRecetaSeleccionada(receta)} esFavorito={true} onToggleFavorito={() => toggleFavorito(receta.id)} />
                ))}
              </div>
            )}
          </div>
        );
      
      default:
        return (
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="relative flex-1 max-w-2xl">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input placeholder="Buscar recetas por nombre o ingrediente..." className="pl-12 h-12 text-base border-0 shadow-md" value={busqueda} onChange={(e) => setBusqueda(e.target.value)} />
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Button variant={!filtros.tipo ? 'default' : 'outline'} size="sm" onClick={() => setFiltros({ tipo: '' })}>Todas</Button>
                <Button variant={filtros.tipo === 'tradicional' ? 'default' : 'outline'} size="sm" onClick={() => setFiltros({ tipo: 'tradicional' })} className={filtros.tipo === 'tradicional' ? 'bg-orange-500 hover:bg-orange-600' : ''}>
                  <Utensils className="h-4 w-4 mr-1" />Tradicionales
                </Button>
                <Button variant={filtros.tipo === 'thermomix' ? 'default' : 'outline'} size="sm" onClick={() => setFiltros({ tipo: 'thermomix' })} className={filtros.tipo === 'thermomix' ? 'bg-violet-600 hover:bg-violet-700' : ''}>
                  <Sparkles className="h-4 w-4 mr-1" />Thermomix
                </Button>
                {(filtros.tipo || filtros.categoria) && (
                  <Button variant="ghost" size="sm" onClick={resetFiltros}>
                    <RefreshCw className="h-4 w-4 mr-1" />Limpiar
                  </Button>
                )}
              </div>
            </div>
            
            {cargando ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="overflow-hidden border-0 shadow-lg">
                    <div className="aspect-[4/3] bg-muted animate-pulse" />
                    <CardContent className="p-4 space-y-3">
                      <div className="h-4 bg-muted rounded animate-pulse w-3/4" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recetas.map(receta => (
                    <RecetaCard key={receta.id} receta={receta} onSelect={() => setRecetaSeleccionada(receta)} esFavorito={favoritos.includes(receta.id)} onToggleFavorito={() => toggleFavorito(receta.id)} />
                  ))}
                </div>
                
                {totalPaginas > 1 && (
                  <div className="flex items-center justify-center gap-4 py-4">
                    <Button variant="outline" disabled={pagina === 1} onClick={() => setPagina(p => p - 1)}>
                      <ChevronLeft className="h-4 w-4 mr-1" />Anterior
                    </Button>
                    <span className="text-sm font-medium px-4">{pagina} / {totalPaginas}</span>
                    <Button variant="outline" disabled={pagina === totalPaginas} onClick={() => setPagina(p => p + 1)}>
                      Siguiente<ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        );
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-lg">
        <div className="container flex items-center justify-between h-16">
          <button onClick={() => { setVistaActual('inicio'); setRecetaSeleccionada(null); }} className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-rose-500 flex items-center justify-center shadow-lg">
              <ChefHat className="h-6 w-6 text-white" />
            </div>
            <div className="hidden sm:block">
              <h1 className="font-bold text-lg">CocinaViva</h1>
              <p className="text-xs text-muted-foreground">cocinavivafazeurru.com</p>
            </div>
          </button>
          
          <nav className="hidden md:flex items-center gap-1">
            <Button variant={vistaActual === 'inicio' ? 'secondary' : 'ghost'} size="sm" onClick={() => { setVistaActual('inicio'); setRecetaSeleccionada(null); }}>
              <Home className="h-4 w-4 mr-2" />Inicio
            </Button>
            <Button variant={vistaActual === 'favoritos' ? 'secondary' : 'ghost'} size="sm" onClick={() => { setVistaActual('favoritos'); setRecetaSeleccionada(null); }}>
              <Heart className="h-4 w-4 mr-2" />Favoritos
              {favoritos.length > 0 && <Badge className="ml-1 h-5 px-1.5 bg-rose-500">{favoritos.length}</Badge>}
            </Button>
          </nav>
          
          {/* Botones de acceso rápido */}
          <div className="flex items-center gap-2">
            {/* Nexus AI - Botón Principal */}
            <Button variant="default" size="sm" onClick={() => openModal('nexusAi')} className="gap-1.5 relative bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700 text-white border-0 shadow-md">
              <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-amber-500 text-violet-900 text-[10px] px-1 font-bold">NUEVO</Badge>
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">Nexus AI</span>
            </Button>

            <Separator orientation="vertical" className="h-6" />

            {/* Botones NUEVO */}
            <Button variant="outline" size="sm" onClick={() => openModal('escanerRecetas')} className="gap-1.5 relative bg-green-50 border-green-300 text-green-700 hover:bg-green-100 dark:bg-green-950 dark:border-green-800 dark:text-green-300">
              <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-[10px] px-1">NUEVO</Badge>
              <ImageIcon className="h-4 w-4" />
              <span className="hidden sm:inline">Escáner</span>
            </Button>

            <Button variant="outline" size="sm" onClick={() => openModal('chefPro')} className="gap-1.5 relative bg-rose-50 border-rose-300 text-rose-700 hover:bg-rose-100 dark:bg-rose-950 dark:border-rose-800 dark:text-rose-300">
              <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-[10px] px-1">NUEVO</Badge>
              <Zap className="h-4 w-4" />
              <span className="hidden sm:inline">Chef Pro</span>
            </Button>

            <Button variant="outline" size="sm" onClick={() => openModal('conversorUnidades')} className="gap-1.5 relative bg-cyan-50 border-cyan-300 text-cyan-700 hover:bg-cyan-100 dark:bg-cyan-950 dark:border-cyan-800 dark:text-cyan-300">
              <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-[10px] px-1">NUEVO</Badge>
              <Scale className="h-4 w-4" />
              <span className="hidden sm:inline">Conversor</span>
            </Button>

            <Button variant="outline" size="sm" onClick={() => openModal('calculadoraPrecios')} className="gap-1.5 relative bg-emerald-50 border-emerald-300 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950 dark:border-emerald-800 dark:text-emerald-300">
              <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-[10px] px-1">NUEVO</Badge>
              <DollarSign className="h-4 w-4" />
              <span className="hidden sm:inline">Precios</span>
            </Button>

            <Button variant="outline" size="sm" onClick={() => openModal('gestorDespensa')} className="gap-1.5 relative bg-sky-50 border-sky-300 text-sky-700 hover:bg-sky-100 dark:bg-sky-950 dark:border-sky-800 dark:text-sky-300">
              <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-[10px] px-1">NUEVO</Badge>
              <Refrigerator className="h-4 w-4" />
              <span className="hidden sm:inline">Despensa</span>
            </Button>

            <Separator orientation="vertical" className="h-6" />

            <Button variant="ghost" size="sm" onClick={() => openModal('logros')} className="gap-1.5 text-yellow-600 hover:text-yellow-700 hover:bg-yellow-50 dark:hover:bg-yellow-950">
              <Trophy className="h-4 w-4" />
              <span className="hidden sm:inline">Logros</span>
            </Button>

            <Button variant="ghost" size="sm" onClick={() => openModal('ajustes')} className="gap-1.5 text-gray-600 hover:text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-800">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Ajustes</span>
            </Button>

            <Separator orientation="vertical" className="h-6" />

            <Button variant="ghost" size="sm" onClick={() => openModal('compartir')} className="gap-1.5 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950">
              <Share2 className="h-4 w-4" />
              <span className="hidden sm:inline">Compartir</span>
            </Button>

            <Button variant="ghost" size="sm" onClick={() => openModal('sugerencias')} className="gap-1.5 text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:hover:bg-blue-950">
              <AlertCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Sugerencias</span>
            </Button>

            <Separator orientation="vertical" className="h-6" />

            {/* Botón de Usuario/Login */}
            {usuario ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setUsuario(null);
                  localStorage.removeItem('cocinaviva-usuario');
                  toast.success('Sesión cerrada');
                }}
                className="gap-1.5"
              >
                <span className="text-lg">{usuario.avatar}</span>
                <span className="hidden sm:inline">{usuario.nombre}</span>
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={() => openModal('login')}
                className="gap-1.5 bg-gradient-to-r from-orange-50 to-rose-50 border-orange-200 text-orange-700 hover:bg-orange-100 dark:from-orange-950 dark:border-orange-800 dark:text-orange-300"
              >
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">Entrar</span>
              </Button>
            )}

            <Separator orientation="vertical" className="h-6" />

            <Sheet open={modales.menuFunciones} onOpenChange={(v) => setModales(prev => ({ ...prev, menuFunciones: v }))}>
              <SheetTrigger asChild>
                <Button variant="default" size="sm" className="gap-1.5 bg-gradient-to-r from-orange-500 to-rose-500 hover:from-orange-600 hover:to-rose-600 text-white">
                  <Sparkles className="h-4 w-4" />
                  <span>Funciones</span>
                  <ChevronRight className="h-3 w-3" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 flex flex-col h-full">
                <SheetHeader>
                  <SheetTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-orange-500" />
                    Todas las Funciones
                  </SheetTitle>
                </SheetHeader>
                <ScrollArea className="flex-1 mt-4 h-[calc(100vh-8rem)] overflow-y-auto">
                <div className="space-y-6 pr-4">
                  {/* Herramientas de Cocina */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                      <ChefHat className="h-4 w-4" />
                      Herramientas de Cocina
                    </h3>
                    <div className="grid grid-cols-1 gap-2">
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('chefIa')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-violet-100 dark:bg-violet-950">
                          <Bot className="h-5 w-5 text-violet-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Chef IA</div>
                          <div className="text-xs text-muted-foreground">Genera recetas con IA</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('escalado')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-emerald-100 dark:bg-emerald-950">
                          <Scale className="h-5 w-5 text-emerald-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Calculadora Escalado</div>
                          <div className="text-xs text-muted-foreground">Ajusta porciones</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('nutricion')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-950">
                          <PieChart className="h-5 w-5 text-blue-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Calculadora Nutricional</div>
                          <div className="text-xs text-muted-foreground">Calorías y macros</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('planificador')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-cyan-100 dark:bg-cyan-950">
                          <CalendarDays className="h-5 w-5 text-cyan-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Planificador Semanal</div>
                          <div className="text-xs text-muted-foreground">Organiza tus menús</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('guiaVoz')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-pink-100 dark:bg-pink-950">
                          <Headphones className="h-5 w-5 text-pink-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Guía de Voz</div>
                          <div className="text-xs text-muted-foreground">Cocina sin manos</div>
                        </div>
                      </Button>
                      {/* Funciones Beta */}
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('escanerRecetas')} className="justify-start gap-3 h-auto py-3 relative">
                        <Badge className="absolute -top-1 -right-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs px-1.5">NUEVO</Badge>
                        <div className="p-2 rounded-lg bg-green-100 dark:bg-green-950">
                          <ImageIcon className="h-5 w-5 text-green-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium flex items-center gap-2">
                            Escáner de Recetas
                            <Badge variant="outline" className="text-xs bg-yellow-50 text-yellow-700 border-yellow-300">BETA</Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">Escanea recetas con la cámara</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('chefPro')} className="justify-start gap-3 h-auto py-3 relative">
                        <Badge className="absolute -top-1 -right-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs px-1.5">NUEVO</Badge>
                        <div className="p-2 rounded-lg bg-rose-100 dark:bg-rose-950">
                          <Zap className="h-5 w-5 text-rose-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium flex items-center gap-2">
                            Modo Chef Pro
                            <Badge variant="outline" className="text-xs bg-yellow-50 text-yellow-700 border-yellow-300">BETA</Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">Modo avanzado con temporizadores</div>
                        </div>
                      </Button>
                    </div>
                  </div>

                  {/* Utilidades (NUEVO) */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                      <Wrench className="h-4 w-4" />
                      Utilidades
                      <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white text-[10px]">NUEVO</Badge>
                    </h3>
                    <div className="grid grid-cols-1 gap-2">
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('conversorUnidades')} className="justify-start gap-3 h-auto py-3 relative">
                        <Badge className="absolute -top-1 -right-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs px-1.5">NUEVO</Badge>
                        <div className="p-2 rounded-lg bg-cyan-100 dark:bg-cyan-950">
                          <Scale className="h-5 w-5 text-cyan-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Conversor de Unidades</div>
                          <div className="text-xs text-muted-foreground">Convierte medidas de cocina</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('calculadoraPrecios')} className="justify-start gap-3 h-auto py-3 relative">
                        <Badge className="absolute -top-1 -right-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs px-1.5">NUEVO</Badge>
                        <div className="p-2 rounded-lg bg-emerald-100 dark:bg-emerald-950">
                          <DollarSign className="h-5 w-5 text-emerald-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Calculadora de Precios</div>
                          <div className="text-xs text-muted-foreground">Calcula el costo de recetas</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('gestorDespensa')} className="justify-start gap-3 h-auto py-3 relative">
                        <Badge className="absolute -top-1 -right-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white text-xs px-1.5">NUEVO</Badge>
                        <div className="p-2 rounded-lg bg-sky-100 dark:bg-sky-950">
                          <Refrigerator className="h-5 w-5 text-sky-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Gestor de Despensa</div>
                          <div className="text-xs text-muted-foreground">Controla tus ingredientes</div>
                        </div>
                      </Button>
                    </div>
                  </div>

                  {/* Organización y Listas */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                      <FolderPlus className="h-4 w-4" />
                      Organización y Listas
                    </h3>
                    <div className="grid grid-cols-1 gap-2">
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('biblioteca')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-950">
                          <BookOpen className="h-5 w-5 text-amber-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Tu Biblioteca</div>
                          <div className="text-xs text-muted-foreground">Colecciones de recetas</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('nevera')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-sky-100 dark:bg-sky-950">
                          <Refrigerator className="h-5 w-5 text-sky-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Buscador de Nevera</div>
                          <div className="text-xs text-muted-foreground">¿Qué tienes en casa?</div>
                        </div>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('listaCompra')} className="justify-start gap-3 h-auto py-3">
                        <div className="p-2 rounded-lg bg-teal-100 dark:bg-teal-950">
                          <ShoppingCart className="h-5 w-5 text-teal-600" />
                        </div>
                        <div className="text-left">
                          <div className="font-medium">Lista de Compra</div>
                          <div className="text-xs text-muted-foreground">Tu lista de ingredientes</div>
                        </div>
                      </Button>
                    </div>
                  </div>

                  {/* Gamificación */}
                  <div className="space-y-2">
                    <h3 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                      <Trophy className="h-4 w-4" />
                      Gamificación
                    </h3>
                    <div className="grid grid-cols-3 gap-2">
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('logros')} className="flex-col h-auto py-3 gap-1">
                        <Trophy className="h-5 w-5 text-yellow-500" />
                        <span className="text-xs">Logros</span>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('desafios')} className="flex-col h-auto py-3 gap-1">
                        <Target className="h-5 w-5 text-orange-500" />
                        <span className="text-xs">Desafíos</span>
                      </Button>
                      <Button variant="outline" onClick={() => openModalAndCloseMenu('estadisticas')} className="flex-col h-auto py-3 gap-1">
                        <BarChart3 className="h-5 w-5 text-indigo-500" />
                        <span className="text-xs">Stats</span>
                      </Button>
                    </div>
                  </div>

                  {/* Ajustes */}
                  <Button variant="outline" onClick={() => openModalAndCloseMenu('ajustes')} className="w-full justify-start gap-3 h-auto py-3">
                    <div className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800">
                      <Settings className="h-5 w-5 text-gray-600" />
                    </div>
                    <div className="text-left">
                      <div className="font-medium">Ajustes</div>
                      <div className="text-xs text-muted-foreground">Configuración de la app</div>
                    </div>
                  </Button>
                </div>
                </ScrollArea>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
      
      <main className="flex-1 container py-6">
        <div className="grid grid-cols-3 gap-3 md:gap-4 mb-8">
          <Card className="bg-gradient-to-br from-orange-500 to-amber-600 text-white border-0 shadow-lg">
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl md:text-3xl font-bold">{stats.totalRecetas.toLocaleString()}</div>
              <div className="text-xs md:text-sm opacity-80">Total Recetas</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-amber-500 to-yellow-600 text-white border-0 shadow-lg">
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl md:text-3xl font-bold">{stats.tradicionales.toLocaleString()}</div>
              <div className="text-xs md:text-sm opacity-80">Tradicionales</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-violet-500 to-purple-600 text-white border-0 shadow-lg">
            <CardContent className="pt-4 pb-3 text-center">
              <div className="text-2xl md:text-3xl font-bold">{stats.thermomix.toLocaleString()}</div>
              <div className="text-xs md:text-sm opacity-80">Thermomix</div>
            </CardContent>
          </Card>
        </div>
        
        {renderVistaPrincipal()}
      </main>
      
      <footer className="border-t mt-auto bg-muted/30">
        <div className="container py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-500 to-rose-500 flex items-center justify-center">
                <ChefHat className="h-5 w-5 text-white" />
              </div>
              <div>
                <span className="font-bold">CocinaViva</span>
                <span className="text-muted-foreground text-sm ml-2">cocinavivafazeurru.com</span>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Badge variant="outline" className="border-orange-400 text-orange-600"><Utensils className="h-3 w-3 mr-1" />1000 Tradicionales</Badge>
              <Badge variant="outline" className="border-violet-400 text-violet-600"><Sparkles className="h-3 w-3 mr-1" />1000 Thermomix</Badge>
              <Badge variant="outline" className="border-yellow-400 text-yellow-600"><Trophy className="h-3 w-3 mr-1" />350 Logros</Badge>
            </div>
          </div>
          <Separator className="my-4" />
          <div className="text-center text-xs text-muted-foreground">
            © 2026 CocinaViva. Todos los derechos reservados. | Tu cocina, tu estilo, tu sabor.
          </div>
        </div>
      </footer>
      
      <PanelAjustes
        abierto={modales.ajustes}
        onCerrar={() => closeModal('ajustes')}
        usuario={usuario}
        onActualizarUsuario={(user) => {
          setUsuario(user);
          localStorage.setItem('cocinaviva-usuario', JSON.stringify(user));
        }}
      />
      <PanelLogros abierto={modales.logros} onCerrar={() => closeModal('logros')} />
      <PanelDesafios abierto={modales.desafios} onCerrar={() => closeModal('desafios')} />
      <PanelEstadisticas abierto={modales.estadisticas} onCerrar={() => closeModal('estadisticas')} />
      
      {/* Nexus AI */}
      <PanelNexusAI abierto={modales.nexusAi} onCerrar={() => closeModal('nexusAi')} />
      
      {/* 5 nuevas funcionalidades */}
      <PanelChefIA abierto={modales.chefIa} onCerrar={() => closeModal('chefIa')} />
      <PanelEscalado abierto={modales.escalado} onCerrar={() => closeModal('escalado')} />
      <PanelNutricion abierto={modales.nutricion} onCerrar={() => closeModal('nutricion')} />
      <PanelPlanificador abierto={modales.planificador} onCerrar={() => closeModal('planificador')} recetas={recetas} />
      <PanelGuiaVoz abierto={modales.guiaVoz} onCerrar={() => closeModal('guiaVoz')} />

      {/* Funciones Beta */}
      <PanelEscanerRecetas abierto={modales.escanerRecetas} onCerrar={() => closeModal('escanerRecetas')} />
      <PanelChefPro abierto={modales.chefPro} onCerrar={() => closeModal('chefPro')} />

      {/* Nuevas funciones útiles (sin IA) */}
      <PanelConversorUnidades abierto={modales.conversorUnidades} onCerrar={() => closeModal('conversorUnidades')} />
      <PanelCalculadoraPrecios abierto={modales.calculadoraPrecios} onCerrar={() => closeModal('calculadoraPrecios')} />
      <PanelGestorDespensa abierto={modales.gestorDespensa} onCerrar={() => closeModal('gestorDespensa')} />

      {/* Organización y listas */}
      <PanelBiblioteca abierto={modales.biblioteca} onCerrar={() => closeModal('biblioteca')} recetas={recetas} favoritos={favoritos} />
      <PanelNevera abierto={modales.nevera} onCerrar={() => closeModal('nevera')} />
      <PanelListaCompra abierto={modales.listaCompra} onCerrar={() => closeModal('listaCompra')} />

      {/* Compartir y Sugerencias */}
      <PanelCompartir abierto={modales.compartir} onCerrar={() => closeModal('compartir')} />
      <PanelSugerencias abierto={modales.sugerencias} onCerrar={() => closeModal('sugerencias')} />

      {/* Login */}
      <PanelLogin
        abierto={modales.login}
        onCerrar={() => closeModal('login')}
        onLogin={(user) => {
          setUsuario(user);
          localStorage.setItem('cocinaviva-usuario', JSON.stringify(user));
        }}
      />
    </div>
  );
}
