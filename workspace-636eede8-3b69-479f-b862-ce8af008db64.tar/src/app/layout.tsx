import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "next-themes";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CocinaViva | Tu cocina, tu estilo, tu sabor",
  description: "Descubre más de 2000 recetas tradicionales y Thermomix. Organiza tus menús semanales, crea listas de compra y disfruta cocinando.",
  keywords: ["recetas", "cocina", "thermomix", "tradicional", "española", "menús", "lista de compra", "planificador"],
  authors: [{ name: "CocinaViva Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "CocinaViva - 2000 Recetas Tradicionales y Thermomix",
    description: "Tu cocina, tu estilo, tu sabor. Más de 2000 recetas con 7 funciones y 17 ajustes personalizados.",
    url: "https://cocinavivafazeurru.com",
    siteName: "CocinaViva",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CocinaViva - Tu cocina, tu estilo, tu sabor",
    description: "2000 recetas tradicionales y Thermomix con planificador de menús y lista de compra",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
          storageKey="cocinaviva-theme"
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
