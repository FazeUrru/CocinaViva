import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';
import crypto from 'crypto';

// Estilos de imagen predefinidos
const ESTILOS_IMAGEN: Record<string, string> = {
  realista: 'professional food photography, high-end restaurant presentation, natural lighting, appetizing, photorealistic, 4k quality',
  artistico: 'artistic food illustration, beautiful plating, gourmet magazine style, elegant composition, warm tones',
  minimalista: 'minimalist food photography, clean white background, simple plating, modern aesthetic, soft shadows',
  rustico: 'rustic farmhouse style, wooden table, natural ingredients scattered, cozy atmosphere, warm lighting',
  elegante: 'fine dining presentation, elegant tableware, sophisticated plating, luxurious atmosphere, dramatic lighting',
};

// Mapeo de tipos de cocina a estilos visuales
const ESTILOS_COCINA: Record<string, string> = {
  espanola: 'Spanish cuisine, traditional earthenware, rustic presentation',
  italiana: 'Italian cuisine, beautiful pasta dishes, rustic Italian setting',
  mexicana: 'Mexican cuisine, colorful presentation, vibrant colors, traditional pottery',
  francesa: 'French cuisine, elegant plating, fine dining style, sophisticated',
  china: 'Chinese cuisine, elegant porcelain, bamboo elements, traditional presentation',
  japonesa: 'Japanese cuisine, minimalist presentation, beautiful ceramics, zen aesthetic',
  india: 'Indian cuisine, colorful spices, traditional metal serving dishes',
  arabe: 'Arabic cuisine, ornate plates, rich colors, Middle Eastern setting',
  tailandesa: 'Thai cuisine, vibrant colors, beautiful garnish, tropical elements',
  griega: 'Greek cuisine, white and blue elements, Mediterranean style, olive oil',
  coreana: 'Korean cuisine, colorful banchan, traditional bowls, modern presentation',
  peruana: 'Peruvian cuisine, colorful native ingredients, traditional pottery',
  argentina: 'Argentine cuisine, rustic grilling, wooden boards, gaucho style',
  colombiana: 'Colombian cuisine, tropical fruits, colorful traditional dishes',
  venezolana: 'Venezuelan cuisine, arepas, tropical colors, Caribbean style',
  turca: 'Turkish cuisine, ornate ceramics, rich colors, Ottoman style',
  rusa: 'Russian cuisine, hearty presentation, wooden serving, cozy atmosphere',
  vietnamita: 'Vietnamese cuisine, fresh herbs, bamboo elements, elegant bowls',
  britanica: 'British cuisine, traditional plates, cozy pub atmosphere',
  alemana: 'German cuisine, hearty portions, wooden boards, beer garden style',
};

// Mapeo de categorías a elementos visuales
const ELEMENTOS_CATEGORIA: Record<string, string> = {
  entrantes: 'appetizer, starter dish, small portion, elegant presentation',
  primeros: 'first course, main plate, generous portion, beautiful plating',
  segundos: 'main course, substantial dish, center of plate focus',
  postres: 'dessert, sweet presentation, artistic plating, tempting',
  bebidas: 'beverage, drink presentation, glassware, refreshing',
  salsas: 'sauce, dipping bowl, accompaniment, rich texture',
};

// Generar hash único basado en el contenido de la receta
function generarHashReceta(
  nombre: string,
  categoria: string,
  cocina: string,
  ingredientes: string[],
  estilo: string
): string {
  const contenido = `${nombre}|${categoria}|${cocina}|${ingredientes.slice(0, 5).join(',')}|${estilo}`;
  return crypto.createHash('md5').update(contenido).digest('hex');
}

// Generar prompt único y variado para cada receta
function generarPromptReceta(
  nombre: string,
  categoria: string,
  cocina: string,
  ingredientes: string[],
  estilo: string = 'realista',
  uniqueSeed: number = 0
): string {
  const estiloBase = ESTILOS_IMAGEN[estilo] || ESTILOS_IMAGEN.realista;
  const estiloCocina = ESTILOS_COCINA[cocina] || '';
  const elementosCategoria = ELEMENTOS_CATEGORIA[categoria] || '';
  
  // Ingredientes principales (máximo 3)
  const ingredientesPrincipales = ingredientes.slice(0, 3).join(', ');
  
  // Añadir variación única basada en el seed
  const variaciones = [
    'beautifully arranged',
    'garnished with fresh herbs',
    'served on elegant dish',
    'perfectly plated',
    'chef style presentation',
    'restaurant quality',
    'gourmet style',
    'home style cooking',
  ];
  
  const variacionSeleccionada = variaciones[uniqueSeed % variaciones.length];
  
  // Prompt único y detallado
  const prompt = `${nombre}, ${elementosCategoria}, ${estiloCocina}, ${estiloBase}, ${ingredientesPrincipales}, ${variacionSeleccionada}, mouth-watering, delicious, freshly prepared, high quality, detailed, unique seed ${uniqueSeed}`;

  return prompt;
}

// GET - Obtener imagen de una receta (de cache o generar)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const recetaId = searchParams.get('recetaId');
    const forzarRegenerar = searchParams.get('regenerar') === 'true';
    const estilo = searchParams.get('estilo') || 'realista';
    const stats = searchParams.get('stats') === 'true';

    // Si piden estadísticas
    if (stats) {
      const totalRecetas = await db.receta.count();
      const cacheadas = await db.imagenReceta.count();
      return NextResponse.json({
        stats: {
          total: totalRecetas,
          cacheadas
        }
      });
    }

    if (!recetaId) {
      return NextResponse.json({ error: 'recetaId es requerido' }, { status: 400 });
    }

    // Obtener datos de la receta primero
    const receta = await db.receta.findUnique({
      where: { id: recetaId }
    });

    if (!receta) {
      return NextResponse.json({ error: 'Receta no encontrada' }, { status: 404 });
    }

    // Parsear ingredientes
    let ingredientes: string[] = [];
    try {
      const ingredientesData = JSON.parse(receta.ingredientes);
      ingredientes = ingredientesData.map((ing: { nombre: string }) => ing.nombre);
    } catch {
      ingredientes = ['ingredientes frescos'];
    }

    // Generar hash único para esta combinación de receta + estilo
    const contenidoHash = generarHashReceta(
      receta.nombre,
      receta.categoria,
      receta.cocina,
      ingredientes,
      estilo
    );

    // Verificar si ya existe en cache usando el contenido hash
    if (!forzarRegenerar) {
      const imagenCache = await db.imagenReceta.findFirst({
        where: { 
          recetaId,
          estilo 
        }
      });

      if (imagenCache) {
        return NextResponse.json({
          success: true,
          imagen: imagenCache.imagenBase64,
          cached: true,
          prompt: imagenCache.prompt,
          estilo: imagenCache.estilo,
          hash: contenidoHash
        });
      }
    }

    // Generar seed único basado en el hash
    const uniqueSeed = parseInt(contenidoHash.substring(0, 8), 16);
    
    // Generar prompt único
    const prompt = generarPromptReceta(
      receta.nombre,
      receta.categoria,
      receta.cocina,
      ingredientes,
      estilo,
      uniqueSeed
    );

    // Generar imagen con IA
    const zai = await ZAI.create();
    const response = await zai.images.generations.create({
      prompt,
      size: '1024x1024'
    });

    const imagenBase64 = response.data[0]?.base64;

    if (!imagenBase64) {
      throw new Error('No se pudo generar la imagen');
    }

    // Eliminar imágenes anteriores de la misma receta con el mismo estilo
    await db.imagenReceta.deleteMany({
      where: {
        recetaId,
        estilo
      }
    });

    // Guardar en cache
    await db.imagenReceta.create({
      data: {
        recetaId,
        imagenBase64,
        prompt,
        estilo
      }
    });

    return NextResponse.json({
      success: true,
      imagen: imagenBase64,
      cached: false,
      prompt,
      estilo,
      hash: contenidoHash
    });

  } catch (error) {
    console.error('Error generando imagen:', error);
    return NextResponse.json(
      { error: 'Error al generar la imagen', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

// POST - Generar imágenes en batch para múltiples recetas
export async function POST(request: NextRequest) {
  try {
    const { recetaIds, estilo = 'realista' } = await request.json();

    if (!recetaIds || !Array.isArray(recetaIds) || recetaIds.length === 0) {
      return NextResponse.json({ error: 'recetaIds es requerido y debe ser un array' }, { status: 400 });
    }

    const resultados: Array<{
      recetaId: string;
      success: boolean;
      cached?: boolean;
      error?: string;
    }> = [];

    for (const recetaId of recetaIds.slice(0, 10)) { // Máximo 10 por batch
      try {
        // Verificar cache
        const imagenCache = await db.imagenReceta.findUnique({
          where: { recetaId }
        });

        if (imagenCache) {
          resultados.push({ recetaId, success: true, cached: true });
          continue;
        }

        // Obtener receta
        const receta = await db.receta.findUnique({
          where: { id: recetaId }
        });

        if (!receta) {
          resultados.push({ recetaId, success: false, error: 'Receta no encontrada' });
          continue;
        }

        // Parsear ingredientes
        let ingredientes: string[] = [];
        try {
          const ingredientesData = JSON.parse(receta.ingredientes);
          ingredientes = ingredientesData.map((ing: { nombre: string }) => ing.nombre);
        } catch {
          ingredientes = ['ingredientes frescos'];
        }

        // Generar hash y seed único
        const contenidoHash = generarHashReceta(
          receta.nombre,
          receta.categoria,
          receta.cocina,
          ingredientes,
          estilo
        );
        const uniqueSeed = parseInt(contenidoHash.substring(0, 8), 16);

        // Generar prompt
        const prompt = generarPromptReceta(
          receta.nombre,
          receta.categoria,
          receta.cocina,
          ingredientes,
          estilo,
          uniqueSeed
        );

        // Generar imagen
        const zai = await ZAI.create();
        const response = await zai.images.generations.create({
          prompt,
          size: '1024x1024'
        });

        const imagenBase64 = response.data[0]?.base64;

        if (!imagenBase64) {
          throw new Error('No se generó imagen');
        }

        // Guardar en cache
        await db.imagenReceta.create({
          data: {
            recetaId,
            imagenBase64,
            prompt,
            estilo
          }
        });

        resultados.push({ recetaId, success: true, cached: false });

        // Pequeña pausa entre generaciones
        await new Promise(resolve => setTimeout(resolve, 500));

      } catch (error) {
        resultados.push({
          recetaId,
          success: false,
          error: error instanceof Error ? error.message : 'Error desconocido'
        });
      }
    }

    const exitosos = resultados.filter(r => r.success).length;
    const cacheados = resultados.filter(r => r.cached).length;

    return NextResponse.json({
      success: true,
      procesados: resultados.length,
      exitosos,
      cacheados,
      resultados
    });

  } catch (error) {
    console.error('Error en batch de imágenes:', error);
    return NextResponse.json(
      { error: 'Error al procesar imágenes' },
      { status: 500 }
    );
  }
}

// DELETE - Eliminar imagen de cache
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const recetaId = searchParams.get('recetaId');

    if (!recetaId) {
      return NextResponse.json({ error: 'recetaId es requerido' }, { status: 400 });
    }

    await db.imagenReceta.delete({
      where: { recetaId }
    });

    return NextResponse.json({ success: true, message: 'Imagen eliminada del cache' });

  } catch (error) {
    console.error('Error eliminando imagen:', error);
    return NextResponse.json(
      { error: 'Error al eliminar la imagen' },
      { status: 500 }
    );
  }
}
