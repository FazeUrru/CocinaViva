import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

// Fresh PrismaClient instance
const prisma = new PrismaClient();

export async function GET() {
  try {
    const logros = await prisma.logro.findMany({
      orderBy: [
        { categoria: 'asc' },
        { orden: 'asc' },
      ],
    });
    
    const logrosUsuario = await prisma.logroUsuario.findMany({
      include: { logro: true },
    });
    
    // Create sample user achievements if none exist
    if (logrosUsuario.length === 0 && logros.length > 0) {
      // Unlock first 5 achievements
      const toUnlock = logros.slice(0, 5);
      for (const logro of toUnlock) {
        try {
          const nuevo = await prisma.logroUsuario.create({
            data: {
              logroId: logro.id,
              desbloqueado: true,
              fechaDesbloqueo: new Date(),
              progreso: 100,
            },
            include: { logro: true },
          });
          logrosUsuario.push(nuevo);
        } catch {}
      }
      
      // Add progress to others
      const withProgress = logros.slice(5, 15);
      for (const logro of withProgress) {
        try {
          const nuevo = await prisma.logroUsuario.create({
            data: {
              logroId: logro.id,
              desbloqueado: false,
              progreso: Math.floor(Math.random() * 80) + 10,
            },
            include: { logro: true },
          });
          logrosUsuario.push(nuevo);
        } catch {}
      }
    }
    
    // Calculate rarity stats
    const statsRareza = {
      comun: { total: 0, desbloqueados: 0 },
      poco_comun: { total: 0, desbloqueados: 0 },
      raro: { total: 0, desbloqueados: 0 },
      epico: { total: 0, desbloqueados: 0 },
      legendario: { total: 0, desbloqueados: 0 },
    };
    
    for (const logro of logros) {
      const rareza = logro.rareza as keyof typeof statsRareza;
      if (statsRareza[rareza]) {
        statsRareza[rareza].total++;
        const desbloqueado = logrosUsuario.some(lu => lu.logroId === logro.id && lu.desbloqueado);
        if (desbloqueado) {
          statsRareza[rareza].desbloqueados++;
        }
      }
    }
    
    return NextResponse.json({ 
      logros, 
      logrosUsuario,
      statsRareza,
      totalDesbloqueados: logrosUsuario.filter(lu => lu.desbloqueado).length,
      totalPuntos: logrosUsuario.reduce((acc, lu) => lu.desbloqueado ? acc + (lu.logro?.puntos || 0) : acc, 0),
    });
  } catch (error) {
    console.error('Error fetching achievements:', error);
    return NextResponse.json({ logros: [], logrosUsuario: [], statsRareza: {}, totalDesbloqueados: 0, totalPuntos: 0 }, { status: 500 });
  }
}
