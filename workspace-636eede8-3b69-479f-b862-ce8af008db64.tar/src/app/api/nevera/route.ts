import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

/**
 * API de búsqueda por ingredientes exactos
 * Busca recetas que contengan TODOS los ingredientes seleccionados
 * Lógica: Filtro SQL con cláusulas AND estrictas. Sin ranking, sin predicción.
 */
export async function POST(request: NextRequest) {
  try {
    const { ingredientes } = await request.json();

    if (!ingredientes || !Array.isArray(ingredientes) || ingredientes.length < 2) {
      return NextResponse.json(
        { error: 'Se requieren al menos 2 ingredientes' },
        { status: 400 }
      );
    }

    // Normalizar ingredientes
    const ingredientesNormalizados = ingredientes.map((ing: string) =>
      ing.toLowerCase().trim()
    );

    // Buscar recetas en la base de datos
    // Usamos SQLite con LIKE para buscar coincidencias en el campo ingredientes (JSON)
    const recetas = await db.receta.findMany({
      where: {
        AND: ingredientesNormalizados.map((ing: string) => ({
          ingredientes: {
            contains: ing,
          },
        })),
      },
      take: 50,
      orderBy: {
        valoracion: 'desc',
      },
    });

    // Filtrar para asegurarnos que los ingredientes están realmente en el JSON
    // (el LIKE puede dar falsos positivos parciales)
    const recetasFiltradas = recetas.filter(receta => {
      try {
        const ingredientesReceta = JSON.parse(receta.ingredientes) as Array<{ nombre: string }>;
        const nombresIngredientes = ingredientesReceta.map(i =>
          i.nombre.toLowerCase().trim()
        );

        // Verificar que TODOS los ingredientes buscados están en la receta
        return ingredientesNormalizados.every(ingBuscado =>
          nombresIngredientes.some(ingReceta =>
            ingReceta.includes(ingBuscado) || ingBuscado.includes(ingReceta)
          )
        );
      } catch {
        return false;
      }
    });

    return NextResponse.json({
      recetas: recetasFiltradas,
      total: recetasFiltradas.length,
      ingredientes: ingredientesNormalizados,
    });
  } catch (error) {
    console.error('Error en búsqueda de nevera:', error);
    return NextResponse.json(
      { error: 'Error al buscar recetas' },
      { status: 500 }
    );
  }
}
