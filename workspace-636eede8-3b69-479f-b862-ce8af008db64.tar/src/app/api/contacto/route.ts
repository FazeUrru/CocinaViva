import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { tipo, asunto, mensaje, email } = await request.json();

    if (!asunto || !mensaje || !email) {
      return NextResponse.json(
        { error: 'Faltan campos requeridos' },
        { status: 400 }
      );
    }

    // En producción, aquí se enviaría el email usando un servicio como:
    // - Resend
    // - SendGrid
    // - Nodemailer
    // - Amazon SES
    
    // Por ahora, registramos el mensaje en la consola del servidor
    console.log('========================================');
    console.log('📩 NUEVO MENSAJE DE CONTACTO');
    console.log('========================================');
    console.log(`Tipo: ${tipo === 'sugerencia' ? '💡 Sugerencia' : '🐛 Bug'}`);
    console.log(`Para: ${email}`);
    console.log(`Asunto: ${asunto}`);
    console.log(`Mensaje: ${mensaje}`);
    console.log(`Fecha: ${new Date().toLocaleString('es-ES')}`);
    console.log('========================================');

    // Simular envío exitoso
    // En producción, descomentar el siguiente código y configurar el servicio de email:
    
    /*
    // Ejemplo con Resend:
    import Resend from 'resend';
    const resend = new Resend(process.env.RESEND_API_KEY);
    
    await resend.emails.send({
      from: 'noreply@cocinaviva.com',
      to: email,
      subject: `[CocinaViva] ${tipo === 'sugerencia' ? 'Sugerencia' : 'Bug'}: ${asunto}`,
      html: `
        <h2>Nuevo mensaje de CocinaViva</h2>
        <p><strong>Tipo:</strong> ${tipo}</p>
        <p><strong>Asunto:</strong> ${asunto}</p>
        <p><strong>Mensaje:</strong></p>
        <p>${mensaje}</p>
      `
    });
    */

    return NextResponse.json({ 
      success: true, 
      message: 'Mensaje enviado correctamente' 
    });
  } catch (error) {
    console.error('Error al procesar mensaje de contacto:', error);
    return NextResponse.json(
      { error: 'Error al enviar el mensaje' },
      { status: 500 }
    );
  }
}
