import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = Math.min(parseInt(searchParams.get('limit') || '12'), 24);
    const skip = (page - 1) * limit;
    
    const busqueda = searchParams.get('busqueda') || '';
    const tipo = searchParams.get('tipo') || '';
    const categoria = searchParams.get('categoria') || '';
    const dificultad = searchParams.get('dificultad') || '';
    
    const where: Record<string, unknown> = {};
    
    if (busqueda) {
      where.OR = [
        { nombre: { contains: busqueda } },
        { descripcion: { contains: busqueda } },
      ];
    }
    if (tipo) where.tipo = tipo;
    if (categoria) where.categoria = categoria;
    if (dificultad) where.dificultad = dificultad;
    
    const [total, recetas] = await Promise.all([
      db.receta.count({ where }),
      db.receta.findMany({
        where,
        skip,
        take: limit,
        orderBy: { valoracion: 'desc' },
        select: {
          id: true,
          nombre: true,
          descripcion: true,
          tiempoTotal: true,
          dificultad: true,
          porciones: true,
          calorias: true,
          tipo: true,
          categoria: true,
          imagen: true,
          valoracion: true,
          numValoraciones: true,
        }
      }),
    ]);
    
    return NextResponse.json({
      recetas,
      paginacion: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch {
    return NextResponse.json({ recetas: [], paginacion: { page: 1, limit: 12, total: 0, totalPages: 0 } });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const receta = await db.receta.create({
      data: {
        nombre: body.nombre,
        descripcion: body.descripcion || '',
        tiempoPreparacion: body.tiempoPreparacion || 15,
        tiempoCoccion: body.tiempoCoccion || 15,
        tiempoTotal: body.tiempoTotal || 30,
        dificultad: body.dificultad || 'facil',
        porciones: body.porciones || 4,
        calorias: body.calorias || 300,
        tipo: body.tipo || 'tradicional',
        categoria: body.categoria || 'primeros',
        cocina: body.cocina || 'espanola',
        imagen: body.imagen || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800',
        ingredientes: body.ingredientes || '[]',
        pasos: body.pasos || '[]',
      },
    });
    return NextResponse.json(receta);
  } catch {
    return NextResponse.json({ error: 'Error al crear receta' }, { status: 500 });
  }
}
