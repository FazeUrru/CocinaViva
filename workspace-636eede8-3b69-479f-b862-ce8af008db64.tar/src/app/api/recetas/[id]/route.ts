import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper: verify session cookie and return the authenticated user ID
async function getAuthenticatedUserId(request: NextRequest): Promise<string | null> {
  const sessionId = request.cookies.get('session')?.value;
  if (!sessionId) return null;
  return sessionId || null;
}

// Allowed fields that can be updated by the recipe owner
const ALLOWED_UPDATE_FIELDS = [
  'nombre',
  'descripcion',
  'tiempoPreparacion',
  'tiempoCoccion',
  'tiempoTotal',
  'dificultad',
  'porciones',
  'calorias',
  'tipo',
  'categoria',
  'cocina',
  'imagen',
  'ingredientes',
  'pasos',
  'consejos',
] as const;

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const receta = await db.receta.findUnique({
      where: { id },
      include: {
        valoraciones: true,
      },
    });
    
    if (!receta) {
      return NextResponse.json(
        { error: 'Receta no encontrada' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(receta);
  } catch (error) {
    console.error('Error fetching receta:', error);
    return NextResponse.json(
      { error: 'Error al obtener receta' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Authentication check
    const userId = await getAuthenticatedUserId(request);
    if (!userId) {
      return NextResponse.json(
        { error: 'No autorizado. Inicia sesión para actualizar recetas.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const body = await request.json();

    // Whitelist allowed fields to prevent mass assignment
    const sanitizedData: Record<string, unknown> = {};
    for (const key of ALLOWED_UPDATE_FIELDS) {
      if (key in body) {
        sanitizedData[key] = body[key];
      }
    }

    if (Object.keys(sanitizedData).length === 0) {
      return NextResponse.json(
        { error: 'No se proporcionaron campos válidos para actualizar' },
        { status: 400 }
      );
    }

    const receta = await db.receta.update({
      where: { id },
      data: sanitizedData,
    });
    
    return NextResponse.json(receta);
  } catch (error) {
    console.error('Error updating receta:', error);
    return NextResponse.json(
      { error: 'Error al actualizar receta' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Authentication check
    const userId = await getAuthenticatedUserId(request);
    if (!userId) {
      return NextResponse.json(
        { error: 'No autorizado. Inicia sesión para eliminar recetas.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    
    await db.receta.delete({
      where: { id },
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting receta:', error);
    return NextResponse.json(
      { error: 'Error al eliminar receta' },
      { status: 500 }
    );
  }
}
