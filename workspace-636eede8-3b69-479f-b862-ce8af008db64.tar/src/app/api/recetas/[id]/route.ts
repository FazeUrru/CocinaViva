import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const receta = await db.receta.findUnique({
      where: { id },
      include: {
        valoraciones: true,
      },
    });
    
    if (!receta) {
      return NextResponse.json(
        { error: 'Receta no encontrada' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(receta);
  } catch (error) {
    console.error('Error fetching receta:', error);
    return NextResponse.json(
      { error: 'Error al obtener receta' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const receta = await db.receta.update({
      where: { id },
      data: body,
    });
    
    return NextResponse.json(receta);
  } catch (error) {
    console.error('Error updating receta:', error);
    return NextResponse.json(
      { error: 'Error al actualizar receta' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    await db.receta.delete({
      where: { id },
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting receta:', error);
    return NextResponse.json(
      { error: 'Error al eliminar receta' },
      { status: 500 }
    );
  }
}
