import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    // Crear desafíos de ejemplo si no existen
    let desafios = await db.desafio.findMany({
      where: { activo: true },
      orderBy: [{ tipo: 'asc' }, { createdAt: 'desc' }],
    });
    
    if (desafios.length === 0) {
      const ahora = new Date();
      const finDia = new Date(ahora);
      finDia.setHours(23, 59, 59, 999);
      
      const finSemana = new Date(ahora);
      finSemana.setDate(finSemana.getDate() + 7);
      
      // Crear desafíos diarios
      const desafiosDiarios = [
        { nombre: 'Chef del Día', descripcion: 'Cocina 3 recetas diferentes hoy', tipo: 'diario', recompensa: 20 },
        { nombre: 'Explorador', descripcion: 'Busca 5 recetas nuevas', tipo: 'diario', recompensa: 15 },
        { nombre: 'Favoritismo', descripcion: 'Añade 2 recetas a favoritos', tipo: 'diario', recompensa: 10 },
      ];
      
      for (const d of desafiosDiarios) {
        await db.desafio.create({
          data: {
            ...d,
            fechaInicio: ahora,
            fechaFin: finDia,
          },
        });
      }
      
      // Crear desafíos semanales
      const desafiosSemanales = [
        { nombre: 'Maratón de Cocina', descripcion: 'Cocina 10 recetas esta semana', tipo: 'semanal', recompensa: 50 },
        { nombre: 'Viajero Culinario', descripcion: 'Prueba recetas de 5 cocinas diferentes', tipo: 'semanal', recompensa: 40 },
        { nombre: 'Planificador', descripcion: 'Organiza todas las comidas de una semana', tipo: 'semanal', recompensa: 30 },
      ];
      
      for (const d of desafiosSemanales) {
        await db.desafio.create({
          data: {
            ...d,
            fechaInicio: ahora,
            fechaFin: finSemana,
          },
        });
      }
      
      desafios = await db.desafio.findMany({
        where: { activo: true },
        orderBy: [{ tipo: 'asc' }, { createdAt: 'desc' }],
      });
    }
    
    // Obtener progreso del usuario
    let desafiosUsuario = await db.desafioUsuario.findMany({
      include: { desafio: true },
    });
    
    // Si no hay progreso, crear algunos de ejemplo
    if (desafiosUsuario.length === 0) {
      for (const desafio of desafios.slice(0, 2)) {
        try {
          await db.desafioUsuario.create({
            data: {
              desafioId: desafio.id,
              completado: false,
              progreso: Math.floor(Math.random() * 60) + 20,
            },
          });
        } catch {
          // Ignorar errores
        }
      }
      desafiosUsuario = await db.desafioUsuario.findMany({
        include: { desafio: true },
      });
    }
    
    return NextResponse.json({ desafios, desafiosUsuario });
  } catch (error) {
    console.error('Error fetching desafios:', error);
    return NextResponse.json({ desafios: [], desafiosUsuario: [] }, { status: 500 });
  }
}
