import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(request: NextRequest) {
  try {
    const { ingredientes, herramienta } = await request.json();

    if (!ingredientes || ingredientes.length < 2) {
      return NextResponse.json(
        { error: 'Se necesitan al menos 2 ingredientes' },
        { status: 400 }
      );
    }

    const herramientaTexto = herramienta === 'thermomix' 
      ? 'Thermomix (robot de cocina)' 
      : 'cocina tradicional (sartén, olla, horno)';

    const prompt = `Eres un chef experto en cocina ${herramienta === 'thermomix' ? 'con Thermomix' : 'tradicional'}. 
    Crea una receta deliciosa usando estos ingredientes principales: ${ingredientes.join(', ')}.
    
    La receta debe ser para ${herramientaTexto}.
    
    Responde SOLO en formato JSON válido (sin texto adicional) con esta estructura exacta:
    {
      "nombre": "Nombre de la receta",
      "descripcion": "Breve descripción de la receta (máx 2 líneas)",
      "ingredientes": [
        {"nombre": "ingrediente", "cantidad": "cantidad"}
      ],
      "pasos": [
        "Paso 1 detallado",
        "Paso 2 detallado"
      ],
      "tiempo": "XX min",
      "dificultad": "Fácil/Medio/Difícil",
      "consejos": "Un consejo útil para esta receta"
    }
    
    Incluye todos los ingredientes mencionados más los básicos necesarios (sal, aceite, etc.).
    Los pasos deben ser claros y detallados, específicos para ${herramientaTexto}.`;

    const zai = await getZAI();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: 'Eres un chef experto que responde solo en JSON válido.' },
        { role: 'user', content: prompt }
      ],
      thinking: { type: 'disabled' }
    });

    // Extract content from response
    const content = completion.choices?.[0]?.message?.content || '';
    
    // Try to parse JSON from the response
    let receta;
    try {
      // Try to find JSON in the response
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        receta = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in response');
      }
    } catch (parseError) {
      console.error('Error parsing JSON:', parseError, 'Content:', content);
      // Return a default recipe structure
      receta = {
        nombre: `Receta con ${ingredientes.slice(0, 2).join(' y ')}`,
        descripcion: `Una deliciosa receta preparada con ${ingredientes.join(', ')}`,
        ingredientes: ingredientes.map(ing => ({ nombre: ing, cantidad: 'al gusto' })),
        pasos: [
          `Preparar los ingredientes: ${ingredientes.join(', ')}`,
          'Calentar el aceite en una sartén u olla según corresponda',
          'Añadir los ingredientes principales y cocinar a fuego medio',
          'Sazonar al gusto y remover bien',
          'Cocinar hasta que esté listo',
          'Servir caliente'
        ],
        tiempo: '30 min',
        dificultad: 'Medio',
        consejos: 'Ajusta las cantidades según tu gusto personal'
      };
    }

    return NextResponse.json({ receta });
  } catch (error) {
    console.error('Error en Chef IA:', error);
    return NextResponse.json(
      { error: 'Error al generar la receta' },
      { status: 500 }
    );
  }
}
