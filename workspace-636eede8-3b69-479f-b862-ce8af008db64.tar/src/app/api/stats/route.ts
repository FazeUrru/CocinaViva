import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const [totalRecetas, tradicionales, thermomix, categorias, cocinas, dificultades] = await Promise.all([
      db.receta.count(),
      db.receta.count({ where: { tipo: 'tradicional' } }),
      db.receta.count({ where: { tipo: 'thermomix' } }),
      db.receta.groupBy({
        by: ['categoria'],
        _count: true,
      }),
      db.receta.groupBy({
        by: ['cocina'],
        _count: true,
      }),
      db.receta.groupBy({
        by: ['dificultad'],
        _count: true,
      }),
    ]);
    
    return NextResponse.json({
      totalRecetas,
      tradicionales,
      thermomix,
      categorias: categorias.map(c => ({ nombre: c.categoria, count: c._count })),
      cocinas: cocinas.map(c => ({ nombre: c.cocina, count: c._count })),
      dificultades: dificultades.map(d => ({ nombre: d.dificultad, count: d._count })),
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    return NextResponse.json(
      { error: 'Error al obtener estadísticas' },
      { status: 500 }
    );
  }
}
