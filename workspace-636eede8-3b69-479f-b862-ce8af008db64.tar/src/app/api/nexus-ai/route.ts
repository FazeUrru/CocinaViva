import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { tipo, mensaje, contexto } = body;

    const zai = await getZAI();

    let systemPrompt = '';
    let userMessage = '';

    switch (tipo) {
      case 'recomendar':
        systemPrompt = `Eres Nexus AI, un asistente culinario experto de CocinaViva. Tu personalidad es amigable, creativa y servicial.
        
Recomiendas recetas deliciosas basándote en los gustos, ingredientes disponibles, ocasión y preferencias del usuario.
Responde SIEMPRE en español con un tono cálido y entusiasta.

Formato de respuesta para recomendaciones:
🍽️ **[Nombre de la receta]**
⏱️ Tiempo: X min | 🍳 Dificultad: Fácil/Medio/Difícil | 👥 Porciones: X

📝 **Descripción breve:**
[1-2 frases describiendo la receta]

🥘 **Ingredientes principales:**
• Ingrediente 1
• Ingrediente 2
• ...

💡 **Por qué te recomiendo esta receta:**
[Razón personalizada basada en lo que el usuario mencionó]`;
        userMessage = contexto 
          ? `Contexto del usuario: ${contexto}\n\nSolicitud: ${mensaje}`
          : mensaje;
        break;

      case 'planificar':
        systemPrompt = `Eres Nexus AI, experto en planificación de menús semanales. 
Creas planes de comidas equilibrados, variados y adaptados a las necesidades del usuario.
Responde SIEMPRE en español con un formato claro y organizado.

Formato:
📅 **Plan Semanal Sugerido**

🎯 **Objetivo:** [Dieta/balance mencionado]

**Lunes:**
🥐 Desayuno: [receta]
🍽️ Comida: [receta]
🌙 Cena: [receta]

[Continuar para cada día...]

🛒 **Lista de compra resumida:**
[Ingredientes clave agrupados]`;
        userMessage = `Planifica un menú semanal: ${mensaje}`;
        break;

      case 'consejos':
        systemPrompt = `Eres Nexus AI, un chef experto que comparte consejos de cocina prácticos.
Tus consejos son fáciles de seguir, útiles y cubren técnicas, trucos, sustituciones y secretos de cocina.
Responde SIEMPRE en español con un tono cercano y experto.

Formato:
👨‍🍳 **Consejo de Nexus AI**

[Título del consejo]

📝 **Explicación:**
[Detalles del consejo]

⚡ **Truco rápido:**
[Un tip adicional relacionado]`;
        userMessage = `Dame consejos sobre: ${mensaje}`;
        break;

      case 'sustituir':
        systemPrompt = `Eres Nexus AI, experto en sustituciones de ingredientes.
Ayudas a encontrar alternativas cuando falta un ingrediente o para adaptar recetas a dietas especiales.
Responde SIEMPRE en español.

Formato:
🔄 **Sustitutos para [ingrediente]**

✅ **Mejores opciones:**
1. [Sustituto] - Proporción: [cantidad] - Nota: [cuándo usarlo]

✅ **Alternativas adicionales:**
• [Sustituto] - [nota breve]

⚠️ **Evita:**
[Qué no funciona como sustituto y por qué]`;
        userMessage = `Necesito sustitutos para: ${mensaje}`;
        break;

      case 'chat':
      default:
        systemPrompt = `Eres Nexus AI, el asistente de cocina inteligente de CocinaViva.
Eres amigable, conocedor y siempre dispuesto a ayudar con cualquier pregunta sobre cocina, recetas, técnicas culinarias, ingredientes, nutrición y más.
Responde SIEMPRE en español con un tono cálido y útil.
Usa emojis apropiados para hacer las respuestas más engaging.`;
        userMessage = mensaje;
    }

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: userMessage }
      ],
      thinking: { type: 'disabled' }
    });

    const response = completion.choices[0]?.message?.content;

    if (!response) {
      throw new Error('No se recibió respuesta del asistente');
    }

    return NextResponse.json({ 
      success: true, 
      respuesta: response 
    });

  } catch (error) {
    console.error('Error en Nexus AI:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'No pude procesar tu solicitud. Por favor, intenta de nuevo.',
      respuesta: null 
    }, { status: 500 });
  }
}
