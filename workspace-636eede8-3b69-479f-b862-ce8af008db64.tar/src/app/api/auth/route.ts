import { NextRequest, NextResponse } from 'next/server';
import crypto from 'crypto';

// Modelo de usuario en memoria (en producción usar base de datos)
interface Usuario {
  id: string;
  email: string;
  nombre: string;
  avatar?: string;
  proveedor: 'google' | 'facebook' | 'apple' | 'twitter' | 'manual';
  createdAt: Date;
}

// Almacenamiento temporal de sesiones
const sesiones = new Map<string, { usuarioId: string; expira: Date }>();
const usuarios = new Map<string, Usuario>();

// POST - Login/Registro
export async function POST(request: NextRequest) {
  try {
    const { email, password, proveedor, nombre, avatar, tokenId } = await request.json();

    // Validación básica
    if (!email) {
      return NextResponse.json({ error: 'Email es requerido' }, { status: 400 });
    }

    // Si es login manual, verificar password
    if (proveedor === 'manual' && !password) {
      return NextResponse.json({ error: 'Contraseña es requerida' }, { status: 400 });
    }

    // Verificar reCAPTCHA si se proporciona tokenId
    if (tokenId) {
      // En producción, verificar con Google reCAPTCHA API
      // Por ahora, simulamos verificación
      const recaptchaValid = tokenId.length > 10;
      if (!recaptchaValid) {
        return NextResponse.json({ error: 'reCAPTCHA inválido' }, { status: 400 });
      }
    }

    // Buscar o crear usuario
    let usuario = Array.from(usuarios.values()).find(u => u.email === email);
    
    if (!usuario) {
      // Crear nuevo usuario
      const nuevoUsuario: Usuario = {
        id: crypto.randomUUID(),
        email,
        nombre: nombre || email.split('@')[0],
        avatar: avatar || undefined,
        proveedor: proveedor || 'manual',
        createdAt: new Date()
      };
      
      usuarios.set(nuevoUsuario.id, nuevoUsuario);
      usuario = nuevoUsuario;
    }

    // Crear sesión
    const sessionId = crypto.randomBytes(32).toString('hex');
    const expira = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 días
    
    sesiones.set(sessionId, {
      usuarioId: usuario.id,
      expira
    });

    // Crear respuesta con cookie
    const response = NextResponse.json({
      success: true,
      usuario: {
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre,
        avatar: usuario.avatar,
        proveedor: usuario.proveedor
      }
    });

    // Establecer cookie de sesión
    response.cookies.set('session', sessionId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      expires: expira,
      path: '/'
    });

    return response;

  } catch (error) {
    console.error('Error en autenticación:', error);
    return NextResponse.json({ error: 'Error en autenticación' }, { status: 500 });
  }
}

// GET - Verificar sesión
export async function GET(request: NextRequest) {
  try {
    const sessionId = request.cookies.get('session')?.value;

    if (!sessionId) {
      return NextResponse.json({ autenticado: false });
    }

    const sesion = sesiones.get(sessionId);

    if (!sesion || sesion.expira < new Date()) {
      sesiones.delete(sessionId);
      return NextResponse.json({ autenticado: false });
    }

    const usuario = usuarios.get(sesion.usuarioId);

    if (!usuario) {
      return NextResponse.json({ autenticado: false });
    }

    return NextResponse.json({
      autenticado: true,
      usuario: {
        id: usuario.id,
        email: usuario.email,
        nombre: usuario.nombre,
        avatar: usuario.avatar,
        proveedor: usuario.proveedor
      }
    });

  } catch (error) {
    console.error('Error verificando sesión:', error);
    return NextResponse.json({ autenticado: false });
  }
}

// DELETE - Logout
export async function DELETE(request: NextRequest) {
  try {
    const sessionId = request.cookies.get('session')?.value;

    if (sessionId) {
      sesiones.delete(sessionId);
    }

    const response = NextResponse.json({ success: true });
    response.cookies.delete('session');

    return response;

  } catch (error) {
    console.error('Error en logout:', error);
    return NextResponse.json({ error: 'Error en logout' }, { status: 500 });
  }
}
