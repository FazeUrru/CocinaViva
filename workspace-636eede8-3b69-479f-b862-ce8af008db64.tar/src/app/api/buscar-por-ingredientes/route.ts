import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { ingredientes } = await request.json();

    if (!ingredientes || !Array.isArray(ingredientes) || ingredientes.length === 0) {
      return NextResponse.json({ recetas: [] });
    }

    // Get all recipes
    const recetas = await db.receta.findMany({
      take: 100,
      orderBy: { valoracion: 'desc' }
    });

    // Filter recipes that contain any of the specified ingredients
    const recetasConIngredientes = recetas.filter(receta => {
      try {
        const ingredientesReceta = JSON.parse(receta.ingredientes) as Array<{ nombre: string }>;
        const nombresIngredientes = ingredientesReceta.map(i => i.nombre.toLowerCase());
        
        // Check if any of the searched ingredients match
        return ingredientes.some((ing: string) => 
          nombresIngredientes.some(nombre => 
            nombre.includes(ing.toLowerCase()) || ing.toLowerCase().includes(nombre)
          )
        );
      } catch {
        return false;
      }
    });

    // Sort by number of matching ingredients (most matches first)
    const recetasOrdenadas = recetasConIngredientes.sort((a, b) => {
      const matchesA = countMatches(a, ingredientes);
      const matchesB = countMatches(b, ingredientes);
      return matchesB - matchesA;
    });

    return NextResponse.json({ recetas: recetasOrdenadas.slice(0, 20) });
  } catch (error) {
    console.error('Error searching recipes by ingredients:', error);
    return NextResponse.json({ recetas: [], error: 'Error al buscar recetas' }, { status: 500 });
  }
}

function countMatches(receta: { ingredientes: string }, ingredientesBuscados: string[]): number {
  try {
    const ingredientesReceta = JSON.parse(receta.ingredientes) as Array<{ nombre: string }>;
    const nombresIngredientes = ingredientesReceta.map(i => i.nombre.toLowerCase());
    
    return ingredientesBuscados.filter(ing => 
      nombresIngredientes.some(nombre => 
        nombre.includes(ing.toLowerCase()) || ing.toLowerCase().includes(nombre)
      )
    ).length;
  } catch {
    return 0;
  }
}
