import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

// Tipos
export interface Ingrediente {
  nombre: string;
  cantidad: number;
  unidad: string;
}

export interface Paso {
  paso: number;
  descripcion: string;
  tiempo?: number;
}

export interface Receta {
  id: string;
  nombre: string;
  descripcion: string;
  tiempoPreparacion: number;
  tiempoCoccion: number;
  tiempoTotal: number;
  dificultad: string;
  porciones: number;
  calorias: number;
  tipo: string;
  categoria: string;
  cocina: string;
  imagen: string;
  imagenes: string;
  videoUrl: string | null;
  ingredientes: string;
  pasos: string;
  consejos: string | null;
  valoracion: number;
  numValoraciones: number;
  esFavorita: boolean;
  vecesCocinada: number;
  ultimaVezCocinada: string | null;
}

// Store de configuración (17 ajustes)
interface ConfigState {
  // 1. Tema
  tema: 'light' | 'dark' | 'system';
  setTema: (tema: 'light' | 'dark' | 'system') => void;
  
  // 2. Idioma
  idioma: 'es' | 'en' | 'ca' | 'gl' | 'eu';
  setIdioma: (idioma: 'es' | 'en' | 'ca' | 'gl' | 'eu') => void;
  
  // 3. Sistema de unidades
  sistemaUnidades: 'metrico' | 'imperial';
  setSistemaUnidades: (sistema: 'metrico' | 'imperial') => void;
  
  // 4. Tamaño de fuente
  tamanoFuente: 'pequeno' | 'mediano' | 'grande';
  setTamanoFuente: (tamano: 'pequeno' | 'mediano' | 'grande') => void;
  
  // 5. Notificaciones
  notificaciones: boolean;
  setNotificaciones: (value: boolean) => void;
  
  // 6. Restricciones alimentarias
  restricciones: string[];
  setRestricciones: (restricciones: string[]) => void;
  
  // 7. Número de comensales por defecto
  numeroComensales: number;
  setNumeroComensales: (num: number) => void;
  
  // 8. Unidad de tiempo preferida
  unidadTiempo: 'minutos' | 'horas';
  setUnidadTiempo: (unidad: 'minutos' | 'horas') => void;
  
  // 9. Región gastronómica preferida
  regionGastronomica: string;
  setRegionGastronomica: (region: string) => void;
  
  // 10. Animaciones
  animaciones: boolean;
  setAnimaciones: (value: boolean) => void;
  
  // 11. Sonidos
  sonidos: boolean;
  setSonidos: (value: boolean) => void;
  
  // 12. Autoguardado
  autoguardado: boolean;
  setAutoguardado: (value: boolean) => void;
  
  // 13. Vista compacta
  vistaCompacta: boolean;
  setVistaCompacta: (value: boolean) => void;
  
  // 14. Calidad de imágenes
  calidadImagenes: 'alta' | 'media' | 'baja';
  setCalidadImagenes: (calidad: 'alta' | 'media' | 'baja') => void;
  
  // 15. Exportar datos
  exportarDatos: () => void;
  
  // 16. Importar datos
  importarDatos: (datos: string) => void;
  
  // 17. Ayuda/Acerca de
  mostrarAyuda: boolean;
  setMostrarAyuda: (value: boolean) => void;
}

export const useConfigStore = create<ConfigState>()(
  persist(
    (set, get) => ({
      tema: 'system',
      setTema: (tema) => set({ tema }),
      
      idioma: 'es',
      setIdioma: (idioma) => set({ idioma }),
      
      sistemaUnidades: 'metrico',
      setSistemaUnidades: (sistemaUnidades) => set({ sistemaUnidades }),
      
      tamanoFuente: 'mediano',
      setTamanoFuente: (tamanoFuente) => set({ tamanoFuente }),
      
      notificaciones: true,
      setNotificaciones: (notificaciones) => set({ notificaciones }),
      
      restricciones: [],
      setRestricciones: (restricciones) => set({ restricciones }),
      
      numeroComensales: 4,
      setNumeroComensales: (numeroComensales) => set({ numeroComensales }),
      
      unidadTiempo: 'minutos',
      setUnidadTiempo: (unidadTiempo) => set({ unidadTiempo }),
      
      regionGastronomica: 'espanola',
      setRegionGastronomica: (regionGastronomica) => set({ regionGastronomica }),
      
      animaciones: true,
      setAnimaciones: (animaciones) => set({ animaciones }),
      
      sonidos: true,
      setSonidos: (sonidos) => set({ sonidos }),
      
      autoguardado: true,
      setAutoguardado: (autoguardado) => set({ autoguardado }),
      
      vistaCompacta: false,
      setVistaCompacta: (vistaCompacta) => set({ vistaCompacta }),
      
      calidadImagenes: 'alta',
      setCalidadImagenes: (calidadImagenes) => set({ calidadImagenes }),
      
      exportarDatos: () => {
        const state = get();
        const datos = JSON.stringify({
          tema: state.tema,
          idioma: state.idioma,
          sistemaUnidades: state.sistemaUnidades,
          tamanoFuente: state.tamanoFuente,
          notificaciones: state.notificaciones,
          restricciones: state.restricciones,
          numeroComensales: state.numeroComensales,
          unidadTiempo: state.unidadTiempo,
          regionGastronomica: state.regionGastronomica,
          animaciones: state.animaciones,
          sonidos: state.sonidos,
          autoguardado: state.autoguardado,
          vistaCompacta: state.vistaCompacta,
          calidadImagenes: state.calidadImagenes,
        }, null, 2);
        const blob = new Blob([datos], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'cocinaviva-config.json';
        a.click();
        URL.revokeObjectURL(url);
      },
      
      importarDatos: (datos) => {
        try {
          const parsed = JSON.parse(datos);
          set(parsed);
        } catch (e) {
          console.error('Error importing data:', e);
        }
      },
      
      mostrarAyuda: false,
      setMostrarAyuda: (mostrarAyuda) => set({ mostrarAyuda }),
    }),
    {
      name: 'cocinaviva-config',
      storage: createJSONStorage(() => localStorage),
    }
  )
);

// Store de la aplicación
interface AppState {
  // Vista actual
  vistaActual: 'inicio' | 'receta' | 'busqueda' | 'favoritos' | 'lista-compra' | 'planificador' | 'menus' | 'ajustes';
  setVistaActual: (vista: AppState['vistaActual']) => void;
  
  // Receta seleccionada
  recetaSeleccionada: Receta | null;
  setRecetaSeleccionada: (receta: Receta | null) => void;
  
  // Búsqueda
  busqueda: string;
  setBusqueda: (busqueda: string) => void;
  
  // Filtros
  filtros: {
    tipo: string;
    categoria: string;
    cocina: string;
    dificultad: string;
    tiempoMax: number;
  };
  setFiltros: (filtros: Partial<AppState['filtros']>) => void;
  resetFiltros: () => void;
  
  // Favoritos
  favoritos: string[];
  toggleFavorito: (id: string) => void;
  
  // Lista de compra
  listaCompra: { ingrediente: string; cantidad: number; unidad: string; comprado: boolean; recetaId?: string }[];
  agregarALista: (items: { ingrediente: string; cantidad: number; unidad: string }[], recetaId?: string) => void;
  toggleComprado: (index: number) => void;
  eliminarDeLista: (index: number) => void;
  vaciarLista: () => void;
  
  // Planificador
  planificador: { fecha: string; tipo: string; recetaId: string }[];
  agregarAlPlanificador: (fecha: string, tipo: string, recetaId: string) => void;
  eliminarDelPlanificador: (fecha: string, tipo: string) => void;
  
  // Modo cocina
  modoCocina: boolean;
  setModoCocina: (value: boolean) => void;
  pasoActual: number;
  setPasoActual: (paso: number) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      vistaActual: 'inicio',
      setVistaActual: (vistaActual) => set({ vistaActual }),
      
      recetaSeleccionada: null,
      setRecetaSeleccionada: (recetaSeleccionada) => set({ recetaSeleccionada }),
      
      busqueda: '',
      setBusqueda: (busqueda) => set({ busqueda }),
      
      filtros: {
        tipo: '',
        categoria: '',
        cocina: '',
        dificultad: '',
        tiempoMax: 0,
      },
      setFiltros: (nuevosFiltros) => set((state) => ({
        filtros: { ...state.filtros, ...nuevosFiltros }
      })),
      resetFiltros: () => set({
        filtros: { tipo: '', categoria: '', cocina: '', dificultad: '', tiempoMax: 0 }
      }),
      
      favoritos: [],
      toggleFavorito: (id) => set((state) => ({
        favoritos: state.favoritos.includes(id)
          ? state.favoritos.filter(f => f !== id)
          : [...state.favoritos, id]
      })),
      
      listaCompra: [],
      agregarALista: (items, recetaId) => set((state) => {
        const nuevosItems = items.map(item => ({ ...item, comprado: false, recetaId }));
        return { listaCompra: [...state.listaCompra, ...nuevosItems] };
      }),
      toggleComprado: (index) => set((state) => {
        const lista = [...state.listaCompra];
        if (lista[index]) {
          lista[index] = { ...lista[index], comprado: !lista[index].comprado };
        }
        return { listaCompra: lista };
      }),
      eliminarDeLista: (index) => set((state) => ({
        listaCompra: state.listaCompra.filter((_, i) => i !== index)
      })),
      vaciarLista: () => set({ listaCompra: [] }),
      
      planificador: [],
      agregarAlPlanificador: (fecha, tipo, recetaId) => set((state) => {
        const filtrado = state.planificador.filter(p => !(p.fecha === fecha && p.tipo === tipo));
        return { planificador: [...filtrado, { fecha, tipo, recetaId }] };
      }),
      eliminarDelPlanificador: (fecha, tipo) => set((state) => ({
        planificador: state.planificador.filter(p => !(p.fecha === fecha && p.tipo === tipo))
      })),
      
      modoCocina: false,
      setModoCocina: (modoCocina) => set({ modoCocina }),
      pasoActual: 0,
      setPasoActual: (pasoActual) => set({ pasoActual }),
    }),
    {
      name: 'cocinaviva-app',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
