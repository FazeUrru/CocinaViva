import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Configuración para mayor estabilidad
  experimental: {
    // Desactivar características experimentales que puedan causar inestabilidad
  },
  // Configuración de errores más permisiva
  onDemandEntries: {
    maxInactiveAge: 60 * 60 * 1000, // 1 hora
    pagesBufferLength: 5,
  },
  // Evitar errores de hidratación
  compiler: {
    emotion: false,
  },
};

export default nextConfig;
