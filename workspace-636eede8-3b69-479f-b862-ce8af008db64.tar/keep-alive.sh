#!/bin/bash

# Script para mantener el servidor siempre activo
# Este script verifica cada 10 segundos si el servidor está corriendo
# y lo reinicia si es necesario

LOG_FILE="/home/z/my-project/server.log"
PID_FILE="/home/z/my-project/server.pid"

start_server() {
    echo "[$(date)] Iniciando servidor..." >> "$LOG_FILE"
    cd /home/z/my-project
    nohup bun run dev >> "$LOG_FILE" 2>&1 &
    echo $! > "$PID_FILE"
    sleep 5
}

check_server() {
    if pgrep -f "next dev" > /dev/null 2>&1; then
        return 0  # Servidor corriendo
    else
        return 1  # Servidor caído
    fi
}

# Bucle principal
while true; do
    if ! check_server; then
        echo "[$(date)] ⚠️ Servidor caído, reiniciando..." >> "$LOG_FILE"
        start_server
        echo "[$(date)] ✅ Servidor reiniciado" >> "$LOG_FILE"
    fi
    sleep 10
done
