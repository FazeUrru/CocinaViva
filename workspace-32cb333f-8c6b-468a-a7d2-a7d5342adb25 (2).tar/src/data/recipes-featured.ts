// Comprehensive Featured Recipes Database - 650 BEST Recipes
// Highest rated (4.5+), most viewed recipes from all cooking methods
// Organized by featured reason: popular, trending, editor_pick, seasonal, new

export interface FeaturedRecipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: 'facil' | 'medio' | 'dificil';
  toolType: 'tradicional' | 'thermomix' | 'crockpot';
  
  averageRating: number;
  ratingCount: number;
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack';
  cuisine?: string;
  viewCount: number;
  featuredReason: 'popular' | 'trending' | 'editor_pick' | 'seasonal' | 'new';
  featuredDate: string;
}

// ============================================
// HELPER FUNCTIONS
// ============================================

let featuredIdCounter = 1;
const generateFeaturedId = () => `featured-${String(featuredIdCounter++).padStart(4, '0')}`;

// High ratings (4.5 to 5.0) for featured recipes
const highRating = () => Math.round((4.5 + Math.random() * 0.5) * 10) / 10;

// High rating counts for featured recipes (100 to 1000+)
const highRatingCount = () => Math.floor(100 + Math.random() * 900);

// High view counts for featured recipes (1000 to 50000+)
const highViewCount = () => Math.floor(1000 + Math.random() * 49000);

// Generate featured dates within last 6 months
const featuredDate = (monthsAgo: number) => {
  const date = new Date();
  date.setMonth(date.getMonth() - monthsAgo);
  return date.toISOString().split('T')[0];
};

// Random gluten free status (30% chance)
const randomGlutenFree = () => Math.random() > 0.7;

// Available images in /public/images/recipes/
const availableImages = [
  '/images/recipes/breakfast.png',
  '/images/recipes/carbonara.png',
  '/images/recipes/chocolate-cake.png',
  '/images/recipes/paella.png',
  '/images/recipes/chicken-wings.png',
  '/images/recipes/gazpacho.png',
  '/images/recipes/burger.png',
  '/images/recipes/salad.png',
]

// Image URL helpers - Using available images
const getBreakfastImage = (index: number) => availableImages[0] // breakfast.png
const getLunchImage = (index: number) => availableImages[(index % 4) + 3] // paella, chicken-wings, gazpacho, burger rotating
const getDinnerImage = (index: number) => availableImages[(index % 4) + 4] // chicken-wings, gazpacho, burger, salad rotating
const getDessertImage = (index: number) => availableImages[2] // chocolate-cake.png
const getSnackImage = (index: number) => availableImages[(index % 3) + 5] // gazpacho, burger, salad rotating
const getThermomixImage = (index: number) => availableImages[index % availableImages.length]
const getCrockpotImage = (index: number) => availableImages[(index % 4) + 4] // chicken-wings, gazpacho, burger, salad
const getTraditionalImage = (index: number) => availableImages[index % availableImages.length]

// Función para generar imagen única basada en el ID de la receta
const getRecipeImage = (recipeId: string, mealType: string, toolType: string) => {
  const idNum = parseInt(recipeId.replace(/\D/g, '')) || 1;
  const imageIndex = idNum % availableImages.length;
  return availableImages[imageIndex];
};

// ============================================
// POPULAR RECIPES (200 recipes)
// Most viewed and highest rated classics
// ============================================

const popularRecipes: FeaturedRecipe[] = [
  // SPANISH CLASSICS - Traditional
  { id: generateFeaturedId(), title: 'Paella Valenciana', description: 'La auténtica paella valenciana con pollo, conejo y judías verdes, cocida a leña', imageUrl: getLunchImage(1), prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 892, mealType: 'almuerzo', cuisine: 'española', viewCount: 45230, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Tortilla Española', description: 'Tortilla de patatas tradicional con cebolla caramelizada, jugosa por dentro', imageUrl: getBreakfastImage(2), prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 1245, mealType: 'desayuno', cuisine: 'española', viewCount: 67890, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Gazpacho Andaluz', description: 'Sopa fría de tomate tradicional, refrescante y llena de sabor mediterráneo', imageUrl: getLunchImage(3), prepTime: 15, cookTime: 0, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 756, mealType: 'almuerzo', cuisine: 'española', viewCount: 34567, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Fabada Asturiana', description: 'Guiso de fabes con compango asturiano, plato reconfortante de montaña', imageUrl: getLunchImage(4), prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 543, mealType: 'almuerzo', cuisine: 'española', viewCount: 28901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Pulpo a la Gallega', description: 'Pulpo tierno con pimentón de la Vera y aceite de oliva virgen extra', imageUrl: getDinnerImage(5), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 678, mealType: 'cena', cuisine: 'española', viewCount: 41234, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Jamón Ibérico', description: 'Corte tradicional de jamón ibérico de bellota con pan de cristal', imageUrl: getSnackImage(1), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', averageRating: 5.0, ratingCount: 432, mealType: 'snack', cuisine: 'española', viewCount: 56789, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Crema Catalana', description: 'Postre tradicional catalán con crema quemada y canela', imageUrl: getDessertImage(1), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 654, mealType: 'postre', cuisine: 'española', viewCount: 32109, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Croquetas de Jamón', description: 'Croquetas cremosas de jamón serrano con bechamel perfecta', imageUrl: getSnackImage(2), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 876, mealType: 'snack', cuisine: 'española', viewCount: 38765, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Churros con Chocolate', description: 'Churros caseros crujientes con chocolate espeso para mojar', imageUrl: getBreakfastImage(3), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 987, mealType: 'desayuno', cuisine: 'española', viewCount: 54321, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Cochinillo Asado', description: 'Cochinillo segoviano con piel crujiente y carne jugosa', imageUrl: getDinnerImage(6), prepTime: 20, cookTime: 180, totalTime: 200, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 456, mealType: 'cena', cuisine: 'española', viewCount: 29876, featuredReason: 'popular', featuredDate: featuredDate(1) },

  // ITALIAN CLASSICS - Traditional
  { id: generateFeaturedId(), title: 'Spaghetti Carbonara', description: 'Pasta con huevo, queso pecorino y guanciale, la receta romana auténtica', imageUrl: getLunchImage(1), prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 1123, mealType: 'almuerzo', cuisine: 'italiana', viewCount: 61234, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Risotto ai Funghi', description: 'Risotto cremoso de setas porcini con parmesano reggiano', imageUrl: getLunchImage(2), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 789, mealType: 'almuerzo', cuisine: 'italiana', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Lasagna Bolognese', description: 'Lasaña con ragú de carne y bechamel, gratinada al horno', imageUrl: getDinnerImage(7), prepTime: 45, cookTime: 45, totalTime: 90, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 923, mealType: 'cena', cuisine: 'italiana', viewCount: 52341, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Tiramisú', description: 'Postre italiano de café con mascarpone y cacao', imageUrl: getDessertImage(2), prepTime: 25, cookTime: 0, totalTime: 25, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 1456, mealType: 'postre', cuisine: 'italiana', viewCount: 78901, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pizza Margherita', description: 'Pizza napolitana con tomate San Marzano, mozzarella y albahaca', imageUrl: getDinnerImage(8), prepTime: 60, cookTime: 15, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 1678, mealType: 'cena', cuisine: 'italiana', viewCount: 89012, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Ossobuco alla Milanese', description: 'Jarrete de ternera estofado con gremolata de limón y perejil', imageUrl: getDinnerImage(9), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 345, mealType: 'cena', cuisine: 'italiana', viewCount: 23456, featuredReason: 'popular', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Panna Cotta', description: 'Crema italiana cuajada con vainilla y frutos rojos', imageUrl: getDessertImage(3), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 567, mealType: 'postre', cuisine: 'italiana', viewCount: 34567, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Gnocchi di Patate', description: 'Ñoquis de patata caseros con salsa de salvia y mantequilla', imageUrl: getLunchImage(4), prepTime: 45, cookTime: 15, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 456, mealType: 'almuerzo', cuisine: 'italiana', viewCount: 28901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Minestrone', description: 'Sopa italiana de verduras con pasta y albahaca fresca', imageUrl: getLunchImage(5), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.5, ratingCount: 678, mealType: 'almuerzo', cuisine: 'italiana', viewCount: 31234, featuredReason: 'popular', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Bruschetta al Pomodoro', description: 'Tostadas italianas con tomate fresco, albahaca y ajo', imageUrl: getSnackImage(3), prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 789, mealType: 'snack', cuisine: 'italiana', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(0) },

  // FRENCH CLASSICS - Traditional
  { id: generateFeaturedId(), title: 'Croissants de Mantequilla', description: 'Croissants franceses hojaldrados con mantequilla AOP', imageUrl: getBreakfastImage(4), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 567, mealType: 'desayuno', cuisine: 'francesa', viewCount: 43210, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Boeuf Bourguignon', description: 'Estofado francés de ternera con vino tinto de Borgoña', imageUrl: getDinnerImage(10), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 678, mealType: 'cena', cuisine: 'francesa', viewCount: 35678, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Crêpes Suzette', description: 'Crêpes con salsa de naranja y Grand Marnier flambé', imageUrl: getDessertImage(4), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 456, mealType: 'postre', cuisine: 'francesa', viewCount: 28901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Coq au Vin', description: 'Pollo guisado en vino tinto con champiñones y tocino', imageUrl: getDinnerImage(1), prepTime: 25, cookTime: 90, totalTime: 115, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 543, mealType: 'cena', cuisine: 'francesa', viewCount: 31234, featuredReason: 'popular', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Ratatouille', description: 'Verduras provenzal asadas con hierbas de Provenza', imageUrl: getLunchImage(6), prepTime: 25, cookTime: 60, totalTime: 85, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 678, mealType: 'almuerzo', cuisine: 'francesa', viewCount: 29876, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Quiche Lorraine', description: 'Tarta salada de bacon, nata y queso gruyère', imageUrl: getLunchImage(7), prepTime: 20, cookTime: 40, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.5, ratingCount: 456, mealType: 'almuerzo', cuisine: 'francesa', viewCount: 25678, featuredReason: 'popular', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'French Onion Soup', description: 'Sopa de cebolla gratinada con queso Comté', imageUrl: getLunchImage(8), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 567, mealType: 'almuerzo', cuisine: 'francesa', viewCount: 32345, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Tarte Tatin', description: 'Tarta de manzana invertida con caramelo dorado', imageUrl: getDessertImage(5), prepTime: 20, cookTime: 35, totalTime: 55, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 345, mealType: 'postre', cuisine: 'francesa', viewCount: 27654, featuredReason: 'popular', featuredDate: featuredDate(2) },

  // MEXICAN CLASSICS - Traditional
  { id: generateFeaturedId(), title: 'Tacos al Pastor', description: 'Tacos de cerdo marinado con piña y cilantro fresco', imageUrl: getLunchImage(9), prepTime: 30, cookTime: 45, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 1234, mealType: 'almuerzo', cuisine: 'mexicana', viewCount: 67890, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Guacamole', description: 'Crema de aguacate con cilantro, lima y jalapeño fresco', imageUrl: getSnackImage(4), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 1567, mealType: 'snack', cuisine: 'mexicana', viewCount: 78901, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Mole Poblano', description: 'Salsa compleja de chiles y chocolate con pollo', imageUrl: getDinnerImage(2), prepTime: 45, cookTime: 120, totalTime: 165, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 456, mealType: 'cena', cuisine: 'mexicana', viewCount: 28901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Chiles en Nogada', description: 'Pimientos rellenos con salsa de nuez y granada', imageUrl: getDinnerImage(3), prepTime: 60, cookTime: 45, totalTime: 105, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 345, mealType: 'cena', cuisine: 'mexicana', viewCount: 23456, featuredReason: 'popular', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Cochinita Pibil', description: 'Cerdo desmenuzado marinado en achiote y naranja', imageUrl: getDinnerImage(4), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 567, mealType: 'cena', cuisine: 'mexicana', viewCount: 34567, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Huevos Rancheros', description: 'Huevos con salsa ranchera sobre tortillas de maíz', imageUrl: getBreakfastImage(5), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 876, mealType: 'desayuno', cuisine: 'mexicana', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Ceviche de Camarón', description: 'Camarones marinados en lima con aguacate y cilantro', imageUrl: getLunchImage(10), prepTime: 20, cookTime: 0, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 654, mealType: 'almuerzo', cuisine: 'mexicana', viewCount: 38901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Enchiladas Verdes', description: 'Tortillas rellenas con salsa verde de tomatillo', imageUrl: getDinnerImage(5), prepTime: 25, cookTime: 25, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 789, mealType: 'cena', cuisine: 'mexicana', viewCount: 41234, featuredReason: 'popular', featuredDate: featuredDate(0) },

  // ASIAN CLASSICS - Traditional
  { id: generateFeaturedId(), title: 'Pad Thai', description: 'Fideos de arroz tailandeses con gambas y cacahuetes', imageUrl: getLunchImage(1), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 1345, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 72345, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Sushi Rolls', description: 'Rollitos de sushi con salmón fresco y aguacate', imageUrl: getLunchImage(2), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 1123, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 65432, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Ramen de Cerdo', description: 'Sopa japonesa con fideos, chashu y huevo marinado', imageUrl: getLunchImage(3), prepTime: 60, cookTime: 180, totalTime: 240, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 567, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 38901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Dim Sum Variado', description: 'Variedad de bollitos chinos al vapor rellenos', imageUrl: getSnackImage(5), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 678, mealType: 'snack', cuisine: 'asiatica', viewCount: 42345, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Pho Vietnamita', description: 'Sopa de fideos con carne y hierbas aromáticas', imageUrl: getLunchImage(4), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 789, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Kung Pao Chicken', description: 'Pollo salteado con cacahuetes y chile de Sichuan', imageUrl: getDinnerImage(6), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 876, mealType: 'cena', cuisine: 'asiatica', viewCount: 48901, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Banh Mi', description: 'Sándwich vietnamita con cerdo asado y encurtidos', imageUrl: getLunchImage(5), prepTime: 20, cookTime: 10, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 654, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 36789, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Satay de Pollo', description: 'Brochetas de pollo con salsa de cacahuete', imageUrl: getSnackImage(6), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 567, mealType: 'snack', cuisine: 'asiatica', viewCount: 31234, featuredReason: 'popular', featuredDate: featuredDate(2) },

  // AMERICAN CLASSICS - Traditional
  { id: generateFeaturedId(), title: 'Pancakes Americanos', description: 'Tortitas esponjosas con sirope de arce y mantequilla', imageUrl: getBreakfastImage(6), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 1456, mealType: 'desayuno', cuisine: 'americana', viewCount: 58901, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'BBQ Ribs', description: 'Costillas de cerdo ahumadas con salsa barbacoa', imageUrl: getDinnerImage(7), prepTime: 20, cookTime: 240, totalTime: 260, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 789, mealType: 'cena', cuisine: 'americana', viewCount: 43210, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Mac and Cheese', description: 'Macarrones con queso cheddar cremoso gratinado', imageUrl: getLunchImage(6), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 1123, mealType: 'almuerzo', cuisine: 'americana', viewCount: 56789, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Cheesecake de Nueva York', description: 'Tarta de queso cremosa con base de galleta', imageUrl: getDessertImage(6), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 987, mealType: 'postre', cuisine: 'americana', viewCount: 49876, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Buffalo Wings', description: 'Alitas de pollo picantes con salsa blue cheese', imageUrl: getSnackImage(7), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 876, mealType: 'snack', cuisine: 'americana', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Eggs Benedict', description: 'Huevos poché con salsa holandesa sobre muffin inglés', imageUrl: getBreakfastImage(7), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 654, mealType: 'desayuno', cuisine: 'americana', viewCount: 37890, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Apple Pie', description: 'Tarta de manzana americana con canela y vainilla', imageUrl: getDessertImage(7), prepTime: 30, cookTime: 60, totalTime: 90, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 789, mealType: 'postre', cuisine: 'americana', viewCount: 42345, featuredReason: 'popular', featuredDate: featuredDate(0) },

  // POPULAR - Thermomix
  { id: generateFeaturedId(), title: 'Pan de Molde Thermomix', description: 'Pan tierno y esponjoso hecho en Thermomix perfecto para tostadas', imageUrl: getThermomixImage(1), prepTime: 15, cookTime: 40, totalTime: 55, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.8, ratingCount: 876, mealType: 'desayuno', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Sopa de Verduras Thermomix', description: 'Crema nutritiva de verduras variadas lista en minutos', imageUrl: getThermomixImage(2), prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.6, ratingCount: 654, mealType: 'almuerzo', viewCount: 32345, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Tarta de Queso Thermomix', description: 'Cheesecake cremosa y perfecta hecha en Thermomix', imageUrl: getThermomixImage(3), prepTime: 15, cookTime: 50, totalTime: 65, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.9, ratingCount: 1234, mealType: 'postre', viewCount: 67890, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Hummus Casero Thermomix', description: 'Crema de garbanzos suave y cremosa en segundos', imageUrl: getThermomixImage(4), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.7, ratingCount: 789, mealType: 'snack', viewCount: 38901, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Arroz con Leche Thermomix', description: 'Postre tradicional de arroz con leche y canela', imageUrl: getThermomixImage(5), prepTime: 5, cookTime: 35, totalTime: 40, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.8, ratingCount: 654, mealType: 'postre', viewCount: 34567, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Gazpacho Thermomix', description: 'Gazpacho andaluz perfecto en textura y sabor', imageUrl: getThermomixImage(6), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.7, ratingCount: 567, mealType: 'almuerzo', cuisine: 'española', viewCount: 41234, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Mousse de Chocolate Thermomix', description: 'Mousse aéreo y suave de chocolate negro', imageUrl: getThermomixImage(7), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.8, ratingCount: 876, mealType: 'postre', viewCount: 49876, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Crema de Calabaza Thermomix', description: 'Vichyssoise dorada de calabaza con jengibre', imageUrl: getThermomixImage(8), prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.6, ratingCount: 543, mealType: 'almuerzo', viewCount: 29876, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Bizcocho de Yogur Thermomix', description: 'Bizcocho esponjoso y húmedo perfecto para cualquier ocasión', imageUrl: getThermomixImage(9), prepTime: 10, cookTime: 40, totalTime: 50, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.7, ratingCount: 987, mealType: 'postre', viewCount: 54321, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Puré de Patata Thermomix', description: 'Puré cremoso y sin grumos perfecto', imageUrl: getThermomixImage(10), prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.5, ratingCount: 456, mealType: 'almuerzo', viewCount: 25678, featuredReason: 'popular', featuredDate: featuredDate(2) },

  // POPULAR - Crockpot
  { id: generateFeaturedId(), title: 'Pulled Pork Crockpot', description: 'Cerdo desmenuzado jugoso con salsa BBQ casera', imageUrl: getCrockpotImage(1), prepTime: 15, cookTime: 720, totalTime: 735, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.9, ratingCount: 789, mealType: 'cena', viewCount: 54321, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Chili con Carne Crockpot', description: 'Chili tex-mex con carne y frijoles, cocción lenta perfecta', imageUrl: getCrockpotImage(2), prepTime: 20, cookTime: 480, totalTime: 500, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 654, mealType: 'almuerzo', cuisine: 'americana', viewCount: 45678, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pot Roast Crockpot', description: 'Asado de ternera clásico con verduras tiernas', imageUrl: getCrockpotImage(3), prepTime: 15, cookTime: 600, totalTime: 615, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.7, ratingCount: 567, mealType: 'cena', viewCount: 38901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Sopa de Lentejas Crockpot', description: 'Lentejas estofadas con verduras y chorizo', imageUrl: getCrockpotImage(4), prepTime: 15, cookTime: 480, totalTime: 495, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.6, ratingCount: 456, mealType: 'almuerzo', viewCount: 31234, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Costillas BBQ Crockpot', description: 'Costillas de cerdo glaseadas con salsa barbacoa', imageUrl: getCrockpotImage(5), prepTime: 10, cookTime: 480, totalTime: 490, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 678, mealType: 'cena', viewCount: 42345, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pollo Entero Crockpot', description: 'Pollo asado jugoso con hierbas aromáticas', imageUrl: getCrockpotImage(6), prepTime: 10, cookTime: 360, totalTime: 370, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.7, ratingCount: 543, mealType: 'cena', viewCount: 35678, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Carnitas Crockpot', description: 'Cerdo desmenuzado mexicano con naranja y comino', imageUrl: getCrockpotImage(7), prepTime: 15, cookTime: 600, totalTime: 615, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 789, mealType: 'cena', cuisine: 'mexicana', viewCount: 48901, featuredReason: 'popular', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Oatmeal de Noche Crockpot', description: 'Avena cocida lentamente con frutas para despertar', imageUrl: getCrockpotImage(8), prepTime: 5, cookTime: 480, totalTime: 485, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.5, ratingCount: 345, mealType: 'desayuno', viewCount: 23456, featuredReason: 'popular', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Apple Crisp Crockpot', description: 'Crujiente de manzana con avena y canela', imageUrl: getCrockpotImage(9), prepTime: 15, cookTime: 240, totalTime: 255, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.7, ratingCount: 456, mealType: 'postre', viewCount: 28901, featuredReason: 'popular', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Estofado de Ternera Crockpot', description: 'Guiso tierno de ternera con patatas y zanahorias', imageUrl: getCrockpotImage(10), prepTime: 20, cookTime: 480, totalTime: 500, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.6, ratingCount: 567, mealType: 'cena', viewCount: 34567, featuredReason: 'popular', featuredDate: featuredDate(1) },
];

// Generate remaining popular recipes to reach 200
const popularTemplates = [
  { title: 'Tostada de Aguacate', desc: 'Tostada con aguacate machacado y huevo poché', cuisine: 'americana', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Smoothie Bowl', desc: 'Bowl de batido con frutas y granola', cuisine: 'americana', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Shakshuka', desc: 'Huevos en salsa de tomate especiada', cuisine: 'mediterranea', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Curry de Pollo', desc: 'Curry cremoso con leche de coco', cuisine: 'india', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Fish and Chips', desc: 'Pescado rebozado con patatas fritas', cuisine: 'britanica', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Tacos de Pescado', desc: 'Tacos con pescado empanizado y repollo', cuisine: 'mexicana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Falafel con Hummus', desc: 'Croquetas de garbanzos con salsa de tahini', cuisine: 'mediterranea', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Ceviche Peruano', desc: 'Pescado marinado en lima con ají', cuisine: 'peruana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Lasaña de Carne', desc: 'Lasaña con ragú de carne y queso', cuisine: 'italiana', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Brownies de Chocolate', desc: 'Brownies densos y chocolatosos', cuisine: 'americana', meal: 'postre' as const, tool: 'tradicional' as const },
];

let popularCount = popularRecipes.length;
while (popularCount < 200) {
  const template = popularTemplates[popularCount % popularTemplates.length];
  const variation = Math.floor(popularCount / popularTemplates.length) + 1;
  const title = variation > 1 ? `${template.title} ${variation}` : template.title;
  
  popularRecipes.push({
    id: generateFeaturedId(),
    title,
    description: template.desc,
    imageUrl: template.meal === 'desayuno' ? getBreakfastImage(popularCount) : 
               template.meal === 'almuerzo' ? getLunchImage(popularCount) :
               template.meal === 'cena' ? getDinnerImage(popularCount) :
               template.meal === 'postre' ? getDessertImage(popularCount) : getSnackImage(popularCount),
    prepTime: 10 + (popularCount % 20),
    cookTime: 15 + (popularCount % 30),
    totalTime: 25 + (popularCount % 45),
    difficulty: popularCount % 3 === 0 ? 'facil' : popularCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: template.tool,
    averageRating: highRating(),
    ratingCount: highRatingCount(),
    mealType: template.meal,
    cuisine: template.cuisine,
    viewCount: highViewCount(),
    featuredReason: 'popular',
    featuredDate: featuredDate(popularCount % 6),
  });
  popularCount++;
}

// ============================================
// TRENDING RECIPES (150 recipes)
// Rising popularity, recent high engagement
// ============================================

const trendingRecipes: FeaturedRecipe[] = [
  // TRENDING SPANISH
  { id: generateFeaturedId(), title: 'Tostadas de Aguacate y Huevo', description: 'Tendencia en redes: tostada con aguacate y huevo poché', imageUrl: getBreakfastImage(1), prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 567, mealType: 'desayuno', cuisine: 'española', viewCount: 34567, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Bowl de Açaí', description: 'Tendencia wellness: bowl de açaí con frutas tropicales', imageUrl: getBreakfastImage(2), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 456, mealType: 'desayuno', viewCount: 28901, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Poke Bowl', description: 'Tendencia hawaiana: bowl de pescado marinado con arroz', imageUrl: getLunchImage(1), prepTime: 20, cookTime: 0, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 678, mealType: 'almuerzo', viewCount: 41234, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Dalgona Coffee', description: 'Tendencia viral: café espumoso coreano', imageUrl: getBreakfastImage(3), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.5, ratingCount: 876, mealType: 'desayuno', viewCount: 56789, featuredReason: 'trending', featuredDate: featuredDate(0) },
  
  // TRENDING ASIAN FUSION
  { id: generateFeaturedId(), title: 'Ramen Burger', description: 'Tendencia fusion: hamburguesa con fideos de ramen', imageUrl: getLunchImage(2), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.6, ratingCount: 456, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 32345, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Sushi Burrito', description: 'Tendencia californiana: burrito de sushi gigante', imageUrl: getLunchImage(3), prepTime: 25, cookTime: 0, totalTime: 25, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 567, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 38901, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Korean Fried Chicken', description: 'Tendencia coreana: pollo frito con salsa gochujang', imageUrl: getDinnerImage(1), prepTime: 20, cookTime: 30, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 678, mealType: 'cena', cuisine: 'asiatica', viewCount: 45678, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Bibimbap', description: 'Tendencia saludable: bowl coreano con huevo frito', imageUrl: getLunchImage(4), prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 543, mealType: 'almuerzo', cuisine: 'asiatica', viewCount: 36789, featuredReason: 'trending', featuredDate: featuredDate(0) },

  // TRENDING MEXICAN FUSION
  { id: generateFeaturedId(), title: 'Birria Tacos', description: 'Tendencia viral: tacos de birria con consomé', imageUrl: getLunchImage(5), prepTime: 45, cookTime: 180, totalTime: 225, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 789, mealType: 'almuerzo', cuisine: 'mexicana', viewCount: 67890, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Elote Street Corn', description: 'Tendencia callejera: maíz con mayonesa y queso', imageUrl: getSnackImage(1), prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 654, mealType: 'snack', cuisine: 'mexicana', viewCount: 45678, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Quesabirria', description: 'Tendencia fusion: quesadilla de birria crujiente', imageUrl: getLunchImage(6), prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 567, mealType: 'almuerzo', cuisine: 'mexicana', viewCount: 52341, featuredReason: 'trending', featuredDate: featuredDate(0) },

  // TRENDING HEALTHY
  { id: generateFeaturedId(), title: 'Cauliflower Rice Bowl', description: 'Tendencia low-carb: arroz de coliflor con vegetales', imageUrl: getLunchImage(7), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.5, ratingCount: 456, mealType: 'almuerzo', viewCount: 28901, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Zucchini Noodles', description: 'Tendencia keto: espaguetis de calabacín con pesto', imageUrl: getLunchImage(8), prepTime: 15, cookTime: 5, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 543, mealType: 'almuerzo', viewCount: 31234, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Avocado Toast Variations', description: 'Tendencia Instagram: 10 variaciones de tostada de aguacate', imageUrl: getBreakfastImage(4), prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 789, mealType: 'desayuno', viewCount: 45678, featuredReason: 'trending', featuredDate: featuredDate(0) },

  // TRENDING DESSERTS
  { id: generateFeaturedId(), title: 'Basque Cheesecake', description: 'Tendencia española: tarta de queso quemada', imageUrl: getDessertImage(1), prepTime: 15, cookTime: 50, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 876, mealType: 'postre', cuisine: 'española', viewCount: 61234, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Mochi Ice Cream', description: 'Tendencia japonesa: helado envuelto en mochi', imageUrl: getDessertImage(2), prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 567, mealType: 'postre', cuisine: 'asiatica', viewCount: 38901, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Cloud Bread', description: 'Tendencia viral: pan esponjoso sin harina', imageUrl: getBreakfastImage(5), prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.5, ratingCount: 456, mealType: 'desayuno', viewCount: 32345, featuredReason: 'trending', featuredDate: featuredDate(0) },

  // TRENDING THERMOMIX
  { id: generateFeaturedId(), title: 'Leche de Avena Thermomix', description: 'Tendencia vegana: leche vegetal casera perfecta', imageUrl: getThermomixImage(1), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.7, ratingCount: 567, mealType: 'desayuno', viewCount: 36789, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Queso Vegano Thermomix', description: 'Tendencia plant-based: queso de anacardos', imageUrl: getThermomixImage(2), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.6, ratingCount: 345, mealType: 'almuerzo', viewCount: 25678, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Mantequilla de Almendras Thermomix', description: 'Tendencia saludable: mantequilla de nueces casera', imageUrl: getThermomixImage(3), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.8, ratingCount: 456, mealType: 'desayuno', viewCount: 28901, featuredReason: 'trending', featuredDate: featuredDate(0) },

  // TRENDING CROCKPOT
  { id: generateFeaturedId(), title: 'TikTok Pasta Crockpot', description: 'Tendencia viral: pasta cremosa de cocción lenta', imageUrl: getCrockpotImage(1), prepTime: 10, cookTime: 240, totalTime: 250, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 789, mealType: 'cena', viewCount: 54321, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Salsa de Queso Crockpot', description: 'Tendencia party: salsa de queso para nachos', imageUrl: getCrockpotImage(2), prepTime: 5, cookTime: 120, totalTime: 125, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.7, ratingCount: 567, mealType: 'snack', viewCount: 38901, featuredReason: 'trending', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Hot Chocolate Crockpot', description: 'Tendencia invierno: chocolate caliente para multitudes', imageUrl: getCrockpotImage(3), prepTime: 5, cookTime: 120, totalTime: 125, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 654, mealType: 'desayuno', viewCount: 42345, featuredReason: 'trending', featuredDate: featuredDate(0) },
];

// Generate remaining trending recipes to reach 150
const trendingTemplates = [
  { title: 'Buddha Bowl', desc: 'Bowl nutritivo con vegetales y proteína', cuisine: 'saludable', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Overnight Oats', desc: 'Avena preparada la noche anterior', cuisine: 'saludable', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Protein Pancakes', desc: 'Tortitas ricas en proteína', cuisine: 'fitness', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Cauliflower Wings', desc: 'Alitas de coliflor crujientes', cuisine: 'vegana', meal: 'snack' as const, tool: 'tradicional' as const },
  { title: 'Chia Pudding', desc: 'Pudin de chía con frutas frescas', cuisine: 'saludable', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Korean BBQ Tacos', desc: 'Tacos de fusión coreana', cuisine: 'fusion', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Matcha Latte', desc: 'Latte de té matcha verde', cuisine: 'asiatica', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Sourdough Bread', desc: 'Pan de masa madre artesanal', cuisine: 'artesanal', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Air Fryer Chicken', desc: 'Pollo crujiente sin aceite', cuisine: 'saludable', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Nice Cream', desc: 'Helado de plátano natural', cuisine: 'saludable', meal: 'postre' as const, tool: 'tradicional' as const },
];

let trendingCount = trendingRecipes.length;
while (trendingCount < 150) {
  const template = trendingTemplates[trendingCount % trendingTemplates.length];
  const variation = Math.floor(trendingCount / trendingTemplates.length) + 1;
  const title = variation > 1 ? `${template.title} ${variation}` : template.title;
  
  trendingRecipes.push({
    id: generateFeaturedId(),
    title,
    description: template.desc,
    imageUrl: template.meal === 'desayuno' ? getBreakfastImage(trendingCount) : 
               template.meal === 'almuerzo' ? getLunchImage(trendingCount) :
               template.meal === 'cena' ? getDinnerImage(trendingCount) :
               template.meal === 'postre' ? getDessertImage(trendingCount) : getSnackImage(trendingCount),
    prepTime: 10 + (trendingCount % 20),
    cookTime: 15 + (trendingCount % 30),
    totalTime: 25 + (trendingCount % 45),
    difficulty: trendingCount % 3 === 0 ? 'facil' : trendingCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: template.tool,
    averageRating: highRating(),
    ratingCount: highRatingCount(),
    mealType: template.meal,
    cuisine: template.cuisine,
    viewCount: highViewCount(),
    featuredReason: 'trending',
    featuredDate: featuredDate(0),
  });
  trendingCount++;
}

// ============================================
// EDITOR'S PICK RECIPES (150 recipes)
// Curated selection by our culinary experts
// ============================================

const editorPickRecipes: FeaturedRecipe[] = [
  // EDITOR'S PICK - GOURMET TRADITIONAL
  { id: generateFeaturedId(), title: 'Risotto de Trufa Negra', description: 'Selección del editor: risotto con trufa negra y parmesano 36 meses', imageUrl: getLunchImage(1), prepTime: 25, cookTime: 35, totalTime: 60, difficulty: 'dificil', toolType: 'tradicional', averageRating: 5.0, ratingCount: 234, mealType: 'almuerzo', cuisine: 'italiana', viewCount: 18901, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Foie Gras a la Plancha', description: 'Selección del editor: foie fresco con compota de higos', imageUrl: getDinnerImage(1), prepTime: 15, cookTime: 5, totalTime: 20, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 156, mealType: 'cena', cuisine: 'francesa', viewCount: 12345, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Cochinillo Segoviano', description: 'Selección del editor: cochinillo asado con piel crujiente perfecta', imageUrl: getDinnerImage(2), prepTime: 30, cookTime: 240, totalTime: 270, difficulty: 'dificil', toolType: 'tradicional', averageRating: 5.0, ratingCount: 189, mealType: 'cena', cuisine: 'española', viewCount: 15678, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Bacalao al Pil Pil', description: 'Selección del editor: bacalao con emulsión de aceite perfecta', imageUrl: getDinnerImage(3), prepTime: 24 * 60, cookTime: 30, totalTime: 1470, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 267, mealType: 'cena', cuisine: 'española', viewCount: 21345, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Wagyu Steak', description: 'Selección del editor: filete de wagyu con técnicas profesionales', imageUrl: getDinnerImage(4), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', toolType: 'tradicional', averageRating: 5.0, ratingCount: 345, mealType: 'cena', viewCount: 28901, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },

  // EDITOR'S PICK - AUTHENTIC RECIPES
  { id: generateFeaturedId(), title: 'Masa Madre de 100 Años', description: 'Selección del editor: pan con masa madre centenaria', imageUrl: getBreakfastImage(1), prepTime: 30, cookTime: 45, totalTime: 75, difficulty: 'dificil', toolType: 'tradicional', averageRating: 5.0, ratingCount: 178, mealType: 'desayuno', viewCount: 14234, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Paella de Marisco', description: 'Selección del editor: paella con marisco fresco del día', imageUrl: getLunchImage(2), prepTime: 40, cookTime: 35, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 456, mealType: 'almuerzo', cuisine: 'española', viewCount: 35678, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pasta Fresca Casera', description: 'Selección del editor: pasta hecha a mano con harina 00', imageUrl: getLunchImage(3), prepTime: 45, cookTime: 15, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 389, mealType: 'almuerzo', cuisine: 'italiana', viewCount: 28765, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Cordero Lechal Asado', description: 'Selección del editor: cordero lechal con técnicas tradicionales', imageUrl: getDinnerImage(5), prepTime: 20, cookTime: 90, totalTime: 110, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 234, mealType: 'cena', cuisine: 'española', viewCount: 19234, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Sushi Omakase', description: 'Selección del editor: experiencia de sushi tradicional japonés', imageUrl: getDinnerImage(6), prepTime: 60, cookTime: 30, totalTime: 90, difficulty: 'dificil', toolType: 'tradicional', averageRating: 5.0, ratingCount: 156, mealType: 'cena', cuisine: 'asiatica', viewCount: 16789, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },

  // EDITOR'S PICK - THERMOMIX GOURMET
  { id: generateFeaturedId(), title: 'Foie Micuit Thermomix', description: 'Selección del editor: foie micuit perfecto en Thermomix', imageUrl: getThermomixImage(1), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'dificil', toolType: 'thermomix', averageRating: 4.9, ratingCount: 123, mealType: 'cena', viewCount: 8234, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pan Artesano Thermomix', description: 'Selección del editor: pan de masa madre en Thermomix', imageUrl: getThermomixImage(2), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.8, ratingCount: 234, mealType: 'desayuno', viewCount: 15678, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Helado de Vainilla Thermomix', description: 'Selección del editor: helado cremoso con vainas de vainilla', imageUrl: getThermomixImage(3), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.9, ratingCount: 189, mealType: 'postre', viewCount: 12345, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Confit de Pato Thermomix', description: 'Selección del editor: muslos de pato confitados perfectos', imageUrl: getThermomixImage(4), prepTime: 15, cookTime: 90, totalTime: 105, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.8, ratingCount: 145, mealType: 'cena', cuisine: 'francesa', viewCount: 9876, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },

  // EDITOR'S PICK - CROCKPOT SPECIAL
  { id: generateFeaturedId(), title: 'Short Ribs Crockpot', description: 'Selección del editor: costillas cortas estofadas 12 horas', imageUrl: getCrockpotImage(1), prepTime: 25, cookTime: 720, totalTime: 745, difficulty: 'medio', toolType: 'crockpot', averageRating: 4.9, ratingCount: 267, mealType: 'cena', viewCount: 18901, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Osobuco Crockpot', description: 'Selección del editor: jarrete estofado con gremolata', imageUrl: getCrockpotImage(2), prepTime: 20, cookTime: 480, totalTime: 500, difficulty: 'medio', toolType: 'crockpot', averageRating: 4.8, ratingCount: 189, mealType: 'cena', cuisine: 'italiana', viewCount: 13456, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Lamb Shanks Crockpot', description: 'Selección del editor: codillos de cordero con romero', imageUrl: getCrockpotImage(3), prepTime: 20, cookTime: 600, totalTime: 620, difficulty: 'medio', toolType: 'crockpot', averageRating: 4.9, ratingCount: 156, mealType: 'cena', viewCount: 11234, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },

  // EDITOR'S PICK - DESSERTS
  { id: generateFeaturedId(), title: 'Soufflé de Chocolate', description: 'Selección del editor: soufflé perfecto de chocolate belga', imageUrl: getDessertImage(1), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 234, mealType: 'postre', viewCount: 15678, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Tarta de Santiago', description: 'Selección del editor: tarta gallega con almendra molida', imageUrl: getDessertImage(2), prepTime: 15, cookTime: 40, totalTime: 55, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 345, mealType: 'postre', cuisine: 'española', viewCount: 22345, featuredReason: 'editor_pick', featuredDate: featuredDate(1) },
  { id: generateFeaturedId(), title: 'Mille-Feuille', description: 'Selección del editor: milhojas de hojaldre con crema', imageUrl: getDessertImage(3), prepTime: 45, cookTime: 30, totalTime: 75, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 178, mealType: 'postre', cuisine: 'francesa', viewCount: 14567, featuredReason: 'editor_pick', featuredDate: featuredDate(0) },
];

// Generate remaining editor pick recipes to reach 150
const editorPickTemplates = [
  { title: 'Tarta Tatin de Manzana', desc: 'Tarta invertida con manzanas caramelizadas', cuisine: 'francesa', meal: 'postre' as const, tool: 'tradicional' as const },
  { title: 'Pollo a la Asturiana', desc: 'Pollo guisado con sidra natural', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Ravioli de Trufa', desc: 'Raviolis rellenos de trufa negra', cuisine: 'italiana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Marmitako de Bonito', desc: 'Guiso de bonito con patatas', cuisine: 'española', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Cerdo Ibérico', desc: 'Presas de cerdo ibérico a la brasa', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Bacalao Dorado', desc: 'Bacalao confitado con ajo', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Canneloni de Carne', desc: 'Canelones con bechamel gratinada', cuisine: 'italiana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Bouillabaisse', desc: 'Sopa de pescado marsellesa', cuisine: 'francesa', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Cordero al Horno', desc: 'Pierna de cordero con hierbas', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Profiteroles', desc: 'Bollos de nata con chocolate', cuisine: 'francesa', meal: 'postre' as const, tool: 'tradicional' as const },
];

let editorPickCount = editorPickRecipes.length;
while (editorPickCount < 150) {
  const template = editorPickTemplates[editorPickCount % editorPickTemplates.length];
  const variation = Math.floor(editorPickCount / editorPickTemplates.length) + 1;
  const title = variation > 1 ? `${template.title} ${variation}` : template.title;
  
  editorPickRecipes.push({
    id: generateFeaturedId(),
    title,
    description: template.desc,
    imageUrl: template.meal === 'desayuno' ? getBreakfastImage(editorPickCount) : 
               template.meal === 'almuerzo' ? getLunchImage(editorPickCount) :
               template.meal === 'cena' ? getDinnerImage(editorPickCount) :
               template.meal === 'postre' ? getDessertImage(editorPickCount) : getSnackImage(editorPickCount),
    prepTime: 15 + (editorPickCount % 30),
    cookTime: 25 + (editorPickCount % 45),
    totalTime: 40 + (editorPickCount % 60),
    difficulty: editorPickCount % 3 === 0 ? 'medio' : editorPickCount % 3 === 1 ? 'dificil' : 'facil',
    toolType: template.tool,
    averageRating: highRating(),
    ratingCount: highRatingCount(),
    mealType: template.meal,
    cuisine: template.cuisine,
    viewCount: highViewCount(),
    featuredReason: 'editor_pick',
    featuredDate: featuredDate(editorPickCount % 4),
  });
  editorPickCount++;
}

// ============================================
// SEASONAL RECIPES (100 recipes)
// Perfect for current season and holidays
// ============================================

const seasonalRecipes: FeaturedRecipe[] = [
  // SPRING/SUMMER SEASONAL
  { id: generateFeaturedId(), title: 'Ensalada de Primavera', description: 'Estacional: ensalada con espárragos, guisantes y hierbas frescas', imageUrl: getLunchImage(1), prepTime: 15, cookTime: 5, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 456, mealType: 'almuerzo', viewCount: 28901, featuredReason: 'seasonal', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Gazpacho de Sandía', description: 'Estacional: gazpacho refrescante de sandía y menta', imageUrl: getLunchImage(2), prepTime: 15, cookTime: 0, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 345, mealType: 'almuerzo', viewCount: 23456, featuredReason: 'seasonal', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Paella de Verano', description: 'Estacional: paella con marisco fresco y verduras de temporada', imageUrl: getLunchImage(3), prepTime: 35, cookTime: 40, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 567, mealType: 'almuerzo', cuisine: 'española', viewCount: 35678, featuredReason: 'seasonal', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Helado de Fresa', description: 'Estacional: helado cremoso con fresas frescas de temporada', imageUrl: getDessertImage(1), prepTime: 20, cookTime: 0, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 456, mealType: 'postre', viewCount: 31234, featuredReason: 'seasonal', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Brochetas de Verano', description: 'Estacional: brochetas de verduras y carne a la parrilla', imageUrl: getDinnerImage(1), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 378, mealType: 'cena', viewCount: 25678, featuredReason: 'seasonal', featuredDate: featuredDate(0) },

  // FALL/WINTER SEASONAL
  { id: generateFeaturedId(), title: 'Crema de Calabaza', description: 'Estacional: crema reconfortante de calabaza con jengibre', imageUrl: getLunchImage(4), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 567, mealType: 'almuerzo', viewCount: 38901, featuredReason: 'seasonal', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Lentejas Estofadas', description: 'Estacional: lentejas con verduras de invierno y chorizo', imageUrl: getLunchImage(5), prepTime: 15, cookTime: 60, totalTime: 75, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 456, mealType: 'almuerzo', viewCount: 34567, featuredReason: 'seasonal', featuredDate: featuredDate(3) },
  { id: generateFeaturedId(), title: 'Cocido Madrileño', description: 'Estacional: potaje tradicional con garbanzos y carnes', imageUrl: getLunchImage(6), prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 345, mealType: 'almuerzo', cuisine: 'española', viewCount: 28901, featuredReason: 'seasonal', featuredDate: featuredDate(3) },
  { id: generateFeaturedId(), title: 'Torrijas de Semana Santa', description: 'Estacional: torrijas tradicionales con canela y miel', imageUrl: getDessertImage(2), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 678, mealType: 'postre', cuisine: 'española', viewCount: 45678, featuredReason: 'seasonal', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Turrón Casero', description: 'Estacional: turrón de almendra navideño', imageUrl: getDessertImage(3), prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 456, mealType: 'postre', viewCount: 32345, featuredReason: 'seasonal', featuredDate: featuredDate(4) },

  // HOLIDAY SPECIALS
  { id: generateFeaturedId(), title: 'Roscón de Reyes', description: 'Estacional: rosco tradicional con crema y frutas escarchadas', imageUrl: getDessertImage(4), prepTime: 60, cookTime: 25, totalTime: 85, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 345, mealType: 'postre', cuisine: 'española', viewCount: 28901, featuredReason: 'seasonal', featuredDate: featuredDate(5) },
  { id: generateFeaturedId(), title: 'Cordero Pascual', description: 'Estacional: cordero asado tradicional de Pascua', imageUrl: getDinnerImage(2), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 234, mealType: 'cena', viewCount: 18901, featuredReason: 'seasonal', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Buñuelos de Viento', description: 'Estacional: buñuelos fritos con crema pastelera', imageUrl: getDessertImage(5), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 345, mealType: 'postre', cuisine: 'española', viewCount: 22345, featuredReason: 'seasonal', featuredDate: featuredDate(3) },

  // SEASONAL THERMOMIX
  { id: generateFeaturedId(), title: 'Sopa de Marisco Thermomix', description: 'Estacional: sopa rica con marisco de temporada', imageUrl: getThermomixImage(1), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.7, ratingCount: 345, mealType: 'almuerzo', viewCount: 23456, featuredReason: 'seasonal', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Sorbete de Limón Thermomix', description: 'Estacional: sorbete refrescante de limón natural', imageUrl: getThermomixImage(2), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.8, ratingCount: 456, mealType: 'postre', viewCount: 28901, featuredReason: 'seasonal', featuredDate: featuredDate(0) },

  // SEASONAL CROCKPOT
  { id: generateFeaturedId(), title: 'Pozole Rojo Crockpot', description: 'Estacional: sopa mexicana de maíz con cerdo', imageUrl: getCrockpotImage(1), prepTime: 20, cookTime: 600, totalTime: 620, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 345, mealType: 'almuerzo', cuisine: 'mexicana', viewCount: 28901, featuredReason: 'seasonal', featuredDate: featuredDate(2) },
  { id: generateFeaturedId(), title: 'Pumpkin Pie Crockpot', description: 'Estacional: tarta de calabaza tradicional americana', imageUrl: getCrockpotImage(2), prepTime: 20, cookTime: 240, totalTime: 260, difficulty: 'medio', toolType: 'crockpot', averageRating: 4.7, ratingCount: 234, mealType: 'postre', cuisine: 'americana', viewCount: 21234, featuredReason: 'seasonal', featuredDate: featuredDate(3) },
  { id: generateFeaturedId(), title: 'Mulled Wine Crockpot', description: 'Estacional: vino caliente con especias navideñas', imageUrl: getCrockpotImage(3), prepTime: 5, cookTime: 60, totalTime: 65, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 456, mealType: 'snack', viewCount: 31234, featuredReason: 'seasonal', featuredDate: featuredDate(4) },
];

// Generate remaining seasonal recipes to reach 100
const seasonalTemplates = [
  { title: 'Ensalada César', desc: 'Ensalada clásica con pollo crujiente', cuisine: 'americana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Sopa de Tomate', desc: 'Sopa cremosa de tomate asado', cuisine: 'española', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Tarta de Manzana', desc: 'Tarta con manzanas de temporada', cuisine: 'americana', meal: 'postre' as const, tool: 'tradicional' as const },
  { title: 'Menestra de Verduras', desc: 'Verduras de temporada guisadas', cuisine: 'española', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Pollo Asado', desc: 'Pollo asado con hierbas de temporada', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Flan de Huevo', desc: 'Flan tradicional con caramelo', cuisine: 'española', meal: 'postre' as const, tool: 'tradicional' as const },
  { title: 'Crema de Espárragos', desc: 'Crema de espárragos trigueros', cuisine: 'española', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Horno de Pescado', desc: 'Pescado al horno con patatas', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Arroz con Leche', desc: 'Postre tradicional de arroz', cuisine: 'española', meal: 'postre' as const, tool: 'tradicional' as const },
  { title: 'Guiso de Ternera', desc: 'Guiso reconfortante de invierno', cuisine: 'española', meal: 'cena' as const, tool: 'tradicional' as const },
];

let seasonalCount = seasonalRecipes.length;
while (seasonalCount < 100) {
  const template = seasonalTemplates[seasonalCount % seasonalTemplates.length];
  const variation = Math.floor(seasonalCount / seasonalTemplates.length) + 1;
  const title = variation > 1 ? `${template.title} ${variation}` : template.title;
  
  seasonalRecipes.push({
    id: generateFeaturedId(),
    title,
    description: template.desc,
    imageUrl: template.meal === 'desayuno' ? getBreakfastImage(seasonalCount) : 
               template.meal === 'almuerzo' ? getLunchImage(seasonalCount) :
               template.meal === 'cena' ? getDinnerImage(seasonalCount) :
               template.meal === 'postre' ? getDessertImage(seasonalCount) : getSnackImage(seasonalCount),
    prepTime: 10 + (seasonalCount % 20),
    cookTime: 15 + (seasonalCount % 30),
    totalTime: 25 + (seasonalCount % 45),
    difficulty: seasonalCount % 3 === 0 ? 'facil' : seasonalCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: template.tool,
    averageRating: highRating(),
    ratingCount: highRatingCount(),
    mealType: template.meal,
    cuisine: template.cuisine,
    viewCount: highViewCount(),
    featuredReason: 'seasonal',
    featuredDate: featuredDate(seasonalCount % 6),
  });
  seasonalCount++;
}

// ============================================
// NEW RECIPES (50 recipes)
// Recently added, latest creations
// ============================================

const newRecipes: FeaturedRecipe[] = [
  // NEW TRADITIONAL
  { id: generateFeaturedId(), title: 'Bowl de Poke Salmón', description: 'Nueva receta: bowl hawaiano con salmón fresco y aguacate', imageUrl: getLunchImage(1), prepTime: 25, cookTime: 0, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 156, mealType: 'almuerzo', viewCount: 12345, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Tacos de Carnitas', description: 'Nueva receta: tacos mexicanos con cerdo desmenuzado', imageUrl: getLunchImage(2), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 189, mealType: 'almuerzo', cuisine: 'mexicana', viewCount: 15678, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Lasaña de Vegetales', description: 'Nueva receta: lasaña vegetariana con verduras asadas', imageUrl: getDinnerImage(1), prepTime: 40, cookTime: 45, totalTime: 85, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.6, ratingCount: 134, mealType: 'cena', viewCount: 11234, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Smoothie de Matcha', description: 'Nueva receta: batido verde con matcha y leche de almendra', imageUrl: getBreakfastImage(1), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.5, ratingCount: 167, mealType: 'desayuno', viewCount: 13456, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Cheesecake de Frutos Rojos', description: 'Nueva receta: tarta de queso con coulis de frutos rojos', imageUrl: getDessertImage(1), prepTime: 25, cookTime: 55, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 145, mealType: 'postre', viewCount: 10987, featuredReason: 'new', featuredDate: featuredDate(0) },

  // NEW THERMOMIX
  { id: generateFeaturedId(), title: 'Pasta Fresca Thermomix', description: 'Nueva receta: pasta casera perfecta en Thermomix', imageUrl: getThermomixImage(1), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.9, ratingCount: 123, mealType: 'almuerzo', viewCount: 9876, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Granola Thermomix', description: 'Nueva receta: granola crujiente con frutos secos', imageUrl: getThermomixImage(2), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.7, ratingCount: 145, mealType: 'desayuno', viewCount: 11234, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Salsa de Tomate Thermomix', description: 'Nueva receta: salsa italiana casera perfecta', imageUrl: getThermomixImage(3), prepTime: 10, cookTime: 30, totalTime: 40, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.6, ratingCount: 134, mealType: 'almuerzo', viewCount: 8765, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Helado de Pistacho Thermomix', description: 'Nueva receta: helado cremoso de pistacho', imageUrl: getThermomixImage(4), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', toolType: 'thermomix', averageRating: 4.8, ratingCount: 156, mealType: 'postre', viewCount: 12345, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Leche de Coco Thermomix', description: 'Nueva receta: leche de coco casera natural', imageUrl: getThermomixImage(5), prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', averageRating: 4.7, ratingCount: 167, mealType: 'desayuno', viewCount: 10987, featuredReason: 'new', featuredDate: featuredDate(0) },

  // NEW CROCKPOT
  { id: generateFeaturedId(), title: 'Curry de Garbanzos Crockpot', description: 'Nueva receta: curry vegano con garbanzos', imageUrl: getCrockpotImage(1), prepTime: 15, cookTime: 360, totalTime: 375, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.6, ratingCount: 145, mealType: 'cena', viewCount: 9876, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pollo al Limón Crockpot', description: 'Nueva receta: pollo con salsa de limón y hierbas', imageUrl: getCrockpotImage(2), prepTime: 10, cookTime: 300, totalTime: 310, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.7, ratingCount: 134, mealType: 'cena', viewCount: 11234, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Brownies Crockpot', description: 'Nueva receta: brownies de chocolate densos', imageUrl: getCrockpotImage(3), prepTime: 15, cookTime: 180, totalTime: 195, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.8, ratingCount: 156, mealType: 'postre', viewCount: 13456, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Sopa de Lentejas Crockpot', description: 'Nueva receta: sopa nutritiva de lentejas', imageUrl: getCrockpotImage(4), prepTime: 15, cookTime: 480, totalTime: 495, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.7, ratingCount: 123, mealType: 'almuerzo', viewCount: 8765, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Compota de Manzana Crockpot', description: 'Nueva receta: compota casera con canela', imageUrl: getCrockpotImage(5), prepTime: 10, cookTime: 360, totalTime: 370, difficulty: 'facil', toolType: 'crockpot', averageRating: 4.6, ratingCount: 145, mealType: 'desayuno', viewCount: 7865, featuredReason: 'new', featuredDate: featuredDate(0) },

  // NEW INNOVATIVE
  { id: generateFeaturedId(), title: 'Burger de Coliflor', description: 'Nueva receta: hamburguesa vegana de coliflor', imageUrl: getLunchImage(3), prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.5, ratingCount: 134, mealType: 'almuerzo', viewCount: 11234, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Pizza de Coliflor', description: 'Nueva receta: pizza con base de coliflor', imageUrl: getDinnerImage(2), prepTime: 25, cookTime: 30, totalTime: 55, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.6, ratingCount: 156, mealType: 'cena', viewCount: 13456, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Helado de Plátano', description: 'Nueva receta: nice cream de un solo ingrediente', imageUrl: getDessertImage(2), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.7, ratingCount: 167, mealType: 'postre', viewCount: 15678, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Tortilla de Garbanzos', description: 'Nueva receta: tortilla vegana con harina de garbanzo', imageUrl: getBreakfastImage(2), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.5, ratingCount: 145, mealType: 'desayuno', viewCount: 9876, featuredReason: 'new', featuredDate: featuredDate(0) },
  { id: generateFeaturedId(), title: 'Albóndigas de Lentejas', description: 'Nueva receta: albóndigas veganas con salsa de tomate', imageUrl: getDinnerImage(3), prepTime: 25, cookTime: 30, totalTime: 55, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.6, ratingCount: 134, mealType: 'cena', viewCount: 11234, featuredReason: 'new', featuredDate: featuredDate(0) },
];

// Generate remaining new recipes to reach 50
const newTemplates = [
  { title: 'Buddha Bowl Vegano', desc: 'Bowl nutritivo con proteína vegetal', cuisine: 'vegana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Tostada de Aguacate', desc: 'Tostada con aguacate y semillas', cuisine: 'saludable', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Curry de Verduras', desc: 'Curry con verduras de temporada', cuisine: 'india', meal: 'cena' as const, tool: 'tradicional' as const },
  { title: 'Wrap de Lechuga', desc: 'Wrap con lechuga en lugar de pan', cuisine: 'saludable', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Brownies de Aguacate', desc: 'Brownies con aguacate secreto', cuisine: 'vegana', meal: 'postre' as const, tool: 'tradicional' as const },
  { title: 'Smoothie Verde', desc: 'Batido verde detox con espinacas', cuisine: 'saludable', meal: 'desayuno' as const, tool: 'tradicional' as const },
  { title: 'Quesadilla de Queso', desc: 'Quesadilla con queso vegano', cuisine: 'vegana', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Mousse de Aguacate', desc: 'Mousse de chocolate con aguacate', cuisine: 'vegana', meal: 'postre' as const, tool: 'tradicional' as const },
  { title: 'Ensalada de Quinoa', desc: 'Ensalada proteica con quinoa', cuisine: 'saludable', meal: 'almuerzo' as const, tool: 'tradicional' as const },
  { title: 'Helado de Coco', desc: 'Helado vegano de leche de coco', cuisine: 'vegana', meal: 'postre' as const, tool: 'tradicional' as const },
];

let newCount = newRecipes.length;
while (newCount < 50) {
  const template = newTemplates[newCount % newTemplates.length];
  const variation = Math.floor(newCount / newTemplates.length) + 1;
  const title = variation > 1 ? `${template.title} ${variation}` : template.title;
  
  newRecipes.push({
    id: generateFeaturedId(),
    title,
    description: template.desc,
    imageUrl: template.meal === 'desayuno' ? getBreakfastImage(newCount) : 
               template.meal === 'almuerzo' ? getLunchImage(newCount) :
               template.meal === 'cena' ? getDinnerImage(newCount) :
               template.meal === 'postre' ? getDessertImage(newCount) : getSnackImage(newCount),
    prepTime: 10 + (newCount % 15),
    cookTime: 10 + (newCount % 20),
    totalTime: 20 + (newCount % 30),
    difficulty: newCount % 3 === 0 ? 'facil' : newCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: template.tool,
    averageRating: highRating(),
    ratingCount: Math.floor(100 + Math.random() * 200), // Lower rating count for new recipes
    mealType: template.meal,
    cuisine: template.cuisine,
    viewCount: Math.floor(5000 + Math.random() * 10000), // Lower view count for new recipes
    featuredReason: 'new',
    featuredDate: featuredDate(0),
  });
  newCount++;
}

// ============================================
// COMBINE ALL FEATURED RECIPES
// ============================================

export const featuredRecipes: FeaturedRecipe[] = [
  ...popularRecipes,
  ...trendingRecipes,
  ...editorPickRecipes,
  ...seasonalRecipes,
  ...newRecipes,
];

// Export counts for verification
export const featuredRecipeCounts = {
  total: featuredRecipes.length,
  popular: popularRecipes.length,
  trending: trendingRecipes.length,
  editorPick: editorPickRecipes.length,
  seasonal: seasonalRecipes.length,
  new: newRecipes.length,
  byToolType: {
    tradicional: featuredRecipes.filter(r => r.toolType === 'tradicional').length,
    thermomix: featuredRecipes.filter(r => r.toolType === 'thermomix').length,
    crockpot: featuredRecipes.filter(r => r.toolType === 'crockpot').length,
  },
  byMealType: {
    desayuno: featuredRecipes.filter(r => r.mealType === 'desayuno').length,
    almuerzo: featuredRecipes.filter(r => r.mealType === 'almuerzo').length,
    cena: featuredRecipes.filter(r => r.mealType === 'cena').length,
    postre: featuredRecipes.filter(r => r.mealType === 'postre').length,
    snack: featuredRecipes.filter(r => r.mealType === 'snack').length,
  },
};
