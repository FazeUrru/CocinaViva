// Achievement System - 125 Total Achievements for FREE Plan
// Premium achievements are hidden with PremiumGuard
// Premium plan gets 175+ additional achievements

export type AchievementCategory = 'recetas' | 'cocina' | 'social' | 'exploracion' | 'maestria' | 'thermomix' | 'coleccion' | 'tiempo' | 'especial' | 'retos'

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  category: AchievementCategory
  points: number
  unlocked: boolean
  unlockedAt?: string
  progress: number
  maxProgress: number
  isPremium?: boolean
  requiredPlan?: 'ultra' | 'masterchef'
  hidden?: boolean
}

const generateId = (prefix: string, index: number) => `${prefix}-${String(index).padStart(3, '0')}`

// ============================================
// RECETAS ACHIEVEMENTS (15) - Recipe creation/completion - FREE
// ============================================
const recetasAchievements: Achievement[] = [
  { id: generateId('rec', 1), title: 'Primer Plato', description: 'Crea tu primera receta', icon: '🍳', category: 'recetas', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('rec', 2), title: 'Cocinero Novato', description: 'Crea 5 recetas', icon: '👨‍🍳', category: 'recetas', points: 25, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('rec', 3), title: 'Cocinero Amateur', description: 'Crea 10 recetas', icon: '🥘', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 4), title: 'Primera Vez', description: 'Completa tu primera receta', icon: '✨', category: 'recetas', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('rec', 5), title: 'En Racha', description: 'Completa 10 recetas', icon: '🔥', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 6), title: 'Cocinero Activo', description: 'Completa 50 recetas', icon: '💪', category: 'recetas', points: 150, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('rec', 7), title: 'Fácil y Rápido', description: 'Completa 10 recetas fáciles', icon: '🟢', category: 'recetas', points: 30, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 8), title: 'Nivel Medio', description: 'Completa 10 recetas de dificultad media', icon: '🟡', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 9), title: 'Mañana Energético', description: 'Completa 20 desayunos', icon: '🥐', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 10), title: 'Chef de Mediodía', description: 'Completa 20 almuerzos', icon: '🍽️', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 11), title: 'Chef Nocturno', description: 'Completa 20 cenas', icon: '🌙', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 12), title: 'Dulce Tentación', description: 'Completa 20 postres', icon: '🍰', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 13), title: 'Snacker Pro', description: 'Completa 20 snacks', icon: '🍿', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 14), title: 'Internacional', description: 'Cocina recetas de 5 cocinas diferentes', icon: '🌍', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('rec', 15), title: 'Recetario Completo', description: 'Completa recetas de todas las categorías', icon: '📚', category: 'recetas', points: 200, unlocked: false, progress: 0, maxProgress: 6 },
]

// ============================================
// COCINA ACHIEVEMENTS (15) - Kitchen tools and techniques - FREE
// ============================================
const cocinaAchievements: Achievement[] = [
  { id: generateId('coc', 1), title: 'Sartén Maestra', description: 'Usa la sartén 50 veces', icon: '🍳', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('coc', 2), title: 'Horno Experto', description: 'Usa el horno 50 veces', icon: '🔥', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('coc', 3), title: 'Vapor Maestro', description: 'Cocina al vapor 25 veces', icon: '♨️', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('coc', 4), title: 'A la Parrilla', description: 'Cocina a la parrilla 30 veces', icon: '🍖', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 5), title: 'Técnicas Básicas', description: 'Aprende 10 técnicas de cocina', icon: '📖', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 6), title: 'Panadero', description: 'Hornea 20 panes', icon: '🍞', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 7), title: 'Pastelero', description: 'Prepara 15 pasteles', icon: '🎂', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 8), title: 'Pizzero', description: 'Prepara 15 pizzas caseras', icon: '🍕', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 9), title: 'Salsas Maestro', description: 'Prepara 20 salsas diferentes', icon: '🫙', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 10), title: 'Caldos y Sopas', description: 'Prepara 25 caldos o sopas', icon: '🍲', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('coc', 11), title: 'Arrocero', description: 'Prepara 20 arroces diferentes', icon: '🍚', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 12), title: 'Fritura Perfecta', description: 'Logra 10 frituras perfectas', icon: '🍤', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 13), title: 'Horneado Perfecto', description: 'Logra 15 horneados perfectos', icon: '🥧', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 14), title: 'Limpieza Pro', description: 'Mantén la cocina limpia 30 días', icon: '✨', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 15), title: 'Chef Completo', description: 'Usa todos los métodos de cocción', icon: '👨‍🍳', category: 'cocina', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
]

// ============================================
// SOCIAL ACHIEVEMENTS (15) - Community interaction - FREE
// ============================================
const socialAchievements: Achievement[] = [
  { id: generateId('soc', 1), title: 'Bienvenido', description: 'Crea tu cuenta', icon: '👋', category: 'social', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 2), title: 'Perfil Completo', description: 'Completa tu perfil al 100%', icon: '✅', category: 'social', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 3), title: 'Foto de Perfil', description: 'Añade una foto de perfil', icon: '📸', category: 'social', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 4), title: 'Primer Favorito', description: 'Guarda tu primera receta favorita', icon: '❤️', category: 'social', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 5), title: 'Coleccionista', description: 'Guarda 10 recetas favoritas', icon: '💖', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 6), title: 'Primer Comentario', description: 'Deja tu primer comentario', icon: '💬', category: 'social', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 7), title: 'Opinador', description: 'Deja 10 comentarios', icon: '🗣️', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 8), title: 'Primera Reseña', description: 'Escribe tu primera reseña', icon: '⭐', category: 'social', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 9), title: 'Reseñador', description: 'Escribe 10 reseñas', icon: '🌟', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 10), title: 'Compartidor', description: 'Comparte una receta', icon: '📤', category: 'social', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 11), title: 'Influencer', description: 'Comparte 20 recetas', icon: '📱', category: 'social', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('soc', 12), title: 'Seguidor', description: 'Sigue a 5 usuarios', icon: '👥', category: 'social', points: 25, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('soc', 13), title: 'Popular', description: 'Consigue 10 seguidores', icon: '🌟', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 14), title: 'Cooksnap', description: 'Comparte 10 fotos de tus platos', icon: '📸', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 15), title: 'Me Gusta', description: 'Recibe 50 me gusta en tus recetas', icon: '👍', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
]

// ============================================
// EXPLORACION ACHIEVEMENTS (15) - Discovering features - FREE
// ============================================
const exploracionAchievements: Achievement[] = [
  { id: generateId('exp', 1), title: 'Explorador', description: 'Visita 10 páginas diferentes', icon: '🧭', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('exp', 2), title: 'Navegante', description: 'Visita 50 páginas diferentes', icon: '🗺️', category: 'exploracion', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('exp', 3), title: 'Buscador', description: 'Realiza 10 búsquedas', icon: '🔍', category: 'exploracion', points: 25, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('exp', 4), title: 'Investigador', description: 'Realiza 50 búsquedas', icon: '🔎', category: 'exploracion', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('exp', 5), title: 'Galería', description: 'Visita la galería de fotos', icon: '🖼️', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 6), title: 'Historial', description: 'Revisa tu historial', icon: '📜', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 7), title: 'Destacados', description: 'Visita recetas destacadas', icon: '⭐', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 8), title: 'Comunidad', description: 'Visita la página de comunidad', icon: '👥', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 9), title: 'Ajustes', description: 'Personaliza tus ajustes', icon: '⚙️', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 10), title: 'Temporizador', description: 'Usa el temporizador por primera vez', icon: '⏱️', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 11), title: 'Lista de Compras', description: 'Crea tu primera lista de compras', icon: '🛒', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 12), title: 'Favoritos Explorador', description: 'Visita tu sección de favoritos', icon: '❤️', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 13), title: 'Categorías', description: 'Explora todas las categorías', icon: '🏷️', category: 'exploracion', points: 50, unlocked: false, progress: 0, maxProgress: 6 },
  { id: generateId('exp', 14), title: 'Herramientas', description: 'Explora todas las herramientas', icon: '🔧', category: 'exploracion', points: 50, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('exp', 15), title: 'Explorador Completo', description: 'Descubre todas las secciones', icon: '🗺️', category: 'exploracion', points: 200, unlocked: false, progress: 0, maxProgress: 20 },
]

// ============================================
// MAESTRIA ACHIEVEMENTS (15) - Mastery and expertise - FREE
// ============================================
const maestriaAchievements: Achievement[] = [
  { id: generateId('mae', 1), title: 'Aprendiz', description: 'Alcanza el nivel 5', icon: '📚', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 2), title: 'Novato Avanzado', description: 'Alcanza el nivel 10', icon: '🎯', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 3), title: 'Intermedio', description: 'Alcanza el nivel 25', icon: '⭐', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 4), title: 'Avanzado', description: 'Alcanza el nivel 50', icon: '🌟', category: 'maestria', points: 400, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 5), title: '100 Puntos', description: 'Acumula 100 puntos', icon: '💯', category: 'maestria', points: 25, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('mae', 6), title: '500 Puntos', description: 'Acumula 500 puntos', icon: '🎯', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 500 },
  { id: generateId('mae', 7), title: '1000 Puntos', description: 'Acumula 1000 puntos', icon: '⭐', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 1000 },
  { id: generateId('mae', 8), title: 'Primer Logro', description: 'Desbloquea tu primer logro', icon: '🏅', category: 'maestria', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 9), title: 'Coleccionista de Logros', description: 'Desbloquea 10 logros', icon: '🎖️', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('mae', 10), title: 'Cazador de Logros', description: 'Desbloquea 25 logros', icon: '🏆', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('mae', 11), title: 'Maestro de Logros', description: 'Desbloquea 50 logros', icon: '💎', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('mae', 12), title: 'Racha de 7 días', description: 'Usa la app 7 días seguidos', icon: '🔥', category: 'maestria', points: 75, unlocked: false, progress: 0, maxProgress: 7 },
  { id: generateId('mae', 13), title: 'Racha de 30 días', description: 'Usa la app 30 días seguidos', icon: '💪', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('mae', 14), title: 'Receta Perfecta', description: 'Completa una receta sin errores', icon: '✅', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 15), title: 'Variedad', description: 'Cocina de 10 cocinas diferentes', icon: '🌍', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
]

// ============================================
// THERMOMIX ACHIEVEMENTS (15) - Thermomix-specific - FREE
// ============================================
const thermomixAchievements: Achievement[] = [
  { id: generateId('thx', 1), title: 'Bienvenido a Thermomix', description: 'Usa Thermomix por primera vez', icon: '🤖', category: 'thermomix', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('thx', 2), title: 'Termo Novato', description: 'Completa 5 recetas Thermomix', icon: '⭐', category: 'thermomix', points: 30, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('thx', 3), title: 'Termo Amateur', description: 'Completa 15 recetas Thermomix', icon: '🌟', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 4), title: 'Termo Pro', description: 'Completa 30 recetas Thermomix', icon: '💫', category: 'thermomix', points: 150, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('thx', 5), title: 'Velocidad 1', description: 'Usa velocidad 1 en 10 recetas', icon: '1️⃣', category: 'thermomix', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 6), title: 'Velocidad 2', description: 'Usa velocidad 2 en 10 recetas', icon: '2️⃣', category: 'thermomix', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 7), title: 'Espiga', description: 'Usa la función espiga 10 veces', icon: '🌾', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 8), title: 'Amasador', description: 'Usa el modo amasar 10 veces', icon: '🥖', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 9), title: 'Varoma', description: 'Usa Varoma 15 veces', icon: '♨️', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 10), title: 'Cestillo', description: 'Usa el cestillo 15 veces', icon: '🧺', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 11), title: 'Mariposa', description: 'Usa la mariposa 10 veces', icon: '🦋', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 12), title: 'Sopas Thermomix', description: 'Prepara 20 sopas con Thermomix', icon: '🍲', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('thx', 13), title: 'Salsas Thermomix', description: 'Prepara 15 salsas con Thermomix', icon: '🫙', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 14), title: 'Pan Thermomix', description: 'Prepara 15 panes con Thermomix', icon: '🍞', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 15), title: 'Termo Master', description: 'Completa 50 recetas Thermomix', icon: '👑', category: 'thermomix', points: 300, unlocked: false, progress: 0, maxProgress: 50 },
]

// ============================================
// COLECCION ACHIEVEMENTS (15) - Collection achievements - FREE
// ============================================
const coleccionAchievements: Achievement[] = [
  { id: generateId('col', 1), title: 'Primer Ingrediente', description: 'Añade tu primer ingrediente', icon: '🥕', category: 'coleccion', points: 5, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 2), title: 'Despensa Básica', description: 'Añade 20 ingredientes', icon: '🥫', category: 'coleccion', points: 30, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 3), title: 'Despensa Completa', description: 'Añade 50 ingredientes', icon: '📦', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('col', 4), title: 'Especiero', description: 'Añade 10 especias diferentes', icon: '🧂', category: 'coleccion', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 5), title: 'Coleccionista de Utensilios', description: 'Registra 10 utensilios', icon: '🥄', category: 'coleccion', points: 30, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 6), title: 'Electrodomésticos', description: 'Registra 5 electrodomésticos', icon: '🔌', category: 'coleccion', points: 25, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('col', 7), title: 'Libro de Recetas', description: 'Guarda 10 recetas propias', icon: '📖', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 8), title: 'Bibliotecario', description: 'Guarda 25 recetas propias', icon: '📚', category: 'coleccion', points: 125, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 9), title: 'Primer Menú', description: 'Crea tu primer menú semanal', icon: '📋', category: 'coleccion', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 10), title: 'Planificador', description: 'Crea 5 menús semanales', icon: '📅', category: 'coleccion', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('col', 11), title: 'Organizado', description: 'Organiza tu nevera', icon: '❄️', category: 'coleccion', points: 30, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 12), title: 'Meal Prep', description: 'Prepara 10 comidas con antelación', icon: '🥘', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 13), title: 'Batch Cooking', description: 'Cocina 5 veces en batch', icon: '🍲', category: 'coleccion', points: 60, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('col', 14), title: 'Congelador Pro', description: 'Congela 10 preparaciones', icon: '🧊', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 15), title: 'Coleccionista Supremo', description: 'Completa todas las colecciones', icon: '🏆', category: 'coleccion', points: 300, unlocked: false, progress: 0, maxProgress: 14 },
]

// ============================================
// TIEMPO ACHIEVEMENTS (15) - Time-based achievements - FREE
// ============================================
const tiempoAchievements: Achievement[] = [
  { id: generateId('tmp', 1), title: 'Madrugador', description: 'Cocina antes de las 7am', icon: '🌅', category: 'tiempo', points: 30, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 2), title: 'Nocturno', description: 'Cocina después de las 10pm', icon: '🌙', category: 'tiempo', points: 30, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 3), title: 'Fin de Semana', description: 'Cocina 10 veces el fin de semana', icon: '🎉', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('tmp', 4), title: 'Navidad', description: 'Cocina en Navidad', icon: '🎄', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 5), title: 'Año Nuevo', description: 'Cocina en Año Nuevo', icon: '🎆', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 6), title: 'Verano', description: 'Cocina 20 recetas en verano', icon: '☀️', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('tmp', 7), title: 'Invierno', description: 'Cocina 20 recetas en invierno', icon: '❄️', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('tmp', 8), title: 'Primavera', description: 'Cocina 20 recetas en primavera', icon: '🌸', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('tmp', 9), title: 'Otoño', description: 'Cocina 20 recetas en otoño', icon: '🍂', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('tmp', 10), title: 'Rápido', description: 'Completa una receta en menos de 15 min', icon: '⚡', category: 'tiempo', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 11), title: 'Velocista', description: 'Completa 10 recetas en menos de 30 min', icon: '🏃', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('tmp', 12), title: 'Paciente', description: 'Completa una receta de más de 3 horas', icon: '⏳', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 13), title: 'Maratón', description: 'Cocina durante 4 horas seguidas', icon: '🏃‍♂️', category: 'tiempo', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tmp', 14), title: 'Productivo', description: 'Completa 5 recetas en un día', icon: '📈', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('tmp', 15), title: 'Estaciones', description: 'Cocina en las 4 estaciones', icon: '🌍', category: 'tiempo', points: 200, unlocked: false, progress: 0, maxProgress: 4 },
]

// ============================================
// ESPECIAL ACHIEVEMENTS (10) - Special achievements - FREE
// ============================================
const especialAchievements: Achievement[] = [
  { id: generateId('esp', 1), title: 'Pionero', description: 'Sé uno de los primeros 100 usuarios', icon: '🏅', category: 'especial', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 2), title: 'Beta Tester', description: 'Participa en la versión beta', icon: '🧪', category: 'especial', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 3), title: 'Feedback', description: 'Envía tu primer feedback', icon: '💭', category: 'especial', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 4), title: 'Colaborador', description: 'Envía 10 feedbacks', icon: '🤝', category: 'especial', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('esp', 5), title: 'Bug Hunter', description: 'Reporta un bug', icon: '🐛', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 6), title: 'Detective', description: 'Reporta 5 bugs', icon: '🔍', category: 'especial', points: 150, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('esp', 7), title: 'Sugerencia', description: 'Sugiere una nueva función', icon: '💡', category: 'especial', points: 30, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 8), title: 'Innovador', description: 'Tu sugerencia es implementada', icon: '✨', category: 'especial', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 9), title: 'Ambajador', description: 'Invita a 5 amigos', icon: '👥', category: 'especial', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('esp', 10), title: 'Leyenda', description: 'Completa todos los logros gratis', icon: '👑', category: 'especial', points: 1000, unlocked: false, progress: 0, maxProgress: 124 },
]

// ============================================
// RETOS ACHIEVEMENTS (10) - Challenge achievements - FREE
// ============================================
const retosAchievements: Achievement[] = [
  { id: generateId('ret', 1), title: 'Primer Reto', description: 'Completa tu primer reto', icon: '🎯', category: 'retos', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 2), title: 'Retador', description: 'Completa 5 retos', icon: '🏆', category: 'retos', points: 75, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('ret', 3), title: 'Campeón', description: 'Completa 10 retos', icon: '🥇', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('ret', 4), title: 'Retos Diarios', description: 'Completa 7 retos diarios', icon: '📅', category: 'retos', points: 50, unlocked: false, progress: 0, maxProgress: 7 },
  { id: generateId('ret', 5), title: 'Retos Semanales', description: 'Completa 4 retos semanales', icon: '📆', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 4 },
  { id: generateId('ret', 6), title: 'Reto Fácil', description: 'Completa un reto fácil', icon: '🟢', category: 'retos', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 7), title: 'Reto Medio', description: 'Completa un reto medio', icon: '🟡', category: 'retos', points: 30, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 8), title: 'Reto Difícil', description: 'Completa un reto difícil', icon: '🔴', category: 'retos', points: 60, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 9), title: 'Racha de Retos', description: 'Completa retos 7 días seguidos', icon: '🔥', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 7 },
  { id: generateId('ret', 10), title: 'Maestro de Retos', description: 'Completa 25 retos', icon: '👑', category: 'retos', points: 300, unlocked: false, progress: 0, maxProgress: 25 },
]

// Combine all achievements - 125 total for FREE plan
export const allAchievements: Achievement[] = [
  ...recetasAchievements,
  ...cocinaAchievements,
  ...socialAchievements,
  ...exploracionAchievements,
  ...maestriaAchievements,
  ...thermomixAchievements,
  ...coleccionAchievements,
  ...tiempoAchievements,
  ...especialAchievements,
  ...retosAchievements,
]

// Achievement categories
export const achievementCategories = [
  { id: 'recetas', name: 'Recetas', icon: '🍳', count: 15, color: 'from-orange-500 to-red-500' },
  { id: 'cocina', name: 'Cocina', icon: '👨‍🍳', count: 15, color: 'from-blue-500 to-cyan-500' },
  { id: 'social', name: 'Social', icon: '👥', count: 15, color: 'from-green-500 to-emerald-500' },
  { id: 'exploracion', name: 'Exploración', icon: '🧭', count: 15, color: 'from-purple-500 to-pink-500' },
  { id: 'maestria', name: 'Maestría', icon: '🏆', count: 15, color: 'from-yellow-500 to-orange-500' },
  { id: 'thermomix', name: 'Thermomix', icon: '🤖', count: 15, color: 'from-indigo-500 to-purple-500' },
  { id: 'coleccion', name: 'Colección', icon: '📦', count: 15, color: 'from-teal-500 to-cyan-500' },
  { id: 'tiempo', name: 'Tiempo', icon: '⏰', count: 15, color: 'from-rose-500 to-pink-500' },
  { id: 'especial', name: 'Especial', icon: '⭐', count: 10, color: 'from-amber-500 to-yellow-500' },
  { id: 'retos', name: 'Retos', icon: '🎯', count: 10, color: 'from-red-500 to-orange-500' },
]

// Get achievements by category
export function getAchievementsByCategory(category: AchievementCategory): Achievement[] {
  return allAchievements.filter(a => a.category === category)
}

// Get free achievements (not premium)
export function getFreeAchievements(): Achievement[] {
  return allAchievements.filter(a => !a.isPremium)
}

// Get premium achievements
export function getPremiumAchievements(): Achievement[] {
  return allAchievements.filter(a => a.isPremium)
}

// Total count
export const TOTAL_ACHIEVEMENTS = 125
export const FREE_ACHIEVEMENTS = 125
export const PREMIUM_ACHIEVEMENTS = 0 // Premium achievements are hidden for free plan
