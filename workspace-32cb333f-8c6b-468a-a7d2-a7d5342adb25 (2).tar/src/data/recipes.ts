// Comprehensive Recipe Database - 2700+ Recipes
// Categories: Desayuno (400), Almuerzo (400), Postre (500), Snack (500), Thermomix (300), Crockpot (300), Tradicional (300)

import { getRecipeImage } from '@/lib/recipe-images';

export interface Recipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: 'facil' | 'medio' | 'dificil';
  toolType: 'tradicional' | 'thermomix' | 'crockpot';
  
  averageRating: number;
  ratingCount: number;
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack';
  cuisine?: string;
}

// Helper to generate unique IDs
let recipeIdCounter = 1;
const generateId = () => `recipe-${recipeIdCounter++}`;

// Smart image function that matches recipe content to appropriate image
const getSmartImage = (title: string, description: string, mealType: string, toolType: string): string => {
  return getRecipeImage(title, description, mealType, toolType);
}

// Helper function to create a recipe with auto-generated imageUrl
const createRecipe = (config: {
  title: string;
  description: string;
  mealType: Recipe['mealType'];
  toolType: Recipe['toolType'];
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: Recipe['difficulty'];
  averageRating: number;
  ratingCount: number;
  cuisine?: string;
}): Recipe => {
  return {
    id: generateId(),
    title: config.title,
    description: config.description,
    imageUrl: getSmartImage(config.title, config.description, config.mealType, config.toolType),
    prepTime: config.prepTime,
    cookTime: config.cookTime,
    totalTime: config.totalTime,
    difficulty: config.difficulty,
    toolType: config.toolType,
    averageRating: config.averageRating,
    ratingCount: config.ratingCount,
    mealType: config.mealType,
    cuisine: config.cuisine,
  };
};

// Random helpers
const randomRating = () => Math.round((3.5 + Math.random() * 1.5) * 10) / 10;
const randomRatingCount = () => Math.floor(50 + Math.random() * 300);

// DESAYUNO RECIPES (400 recipes)
const desayunoRecipes: Recipe[] = [
  // Spanish Breakfasts
  createRecipe({ title: 'Tostadas con Tomate', description: 'Clásicas tostadas españolas con tomate rallado y aceite de oliva virgen extra', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 2, totalTime: 7, difficulty: 'facil', averageRating: 4.7, ratingCount: 234, cuisine: 'española' }),
  createRecipe({ title: 'Tortilla Española', description: 'Tortilla de patatas tradicional con cebolla caramelizada', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'medio', averageRating: 4.9, ratingCount: 567, cuisine: 'española' }),
  createRecipe({ title: 'Churros con Chocolate', description: 'Churros caseros crujientes con chocolate espeso para mojar', mealType: 'desayuno', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', averageRating: 4.8, ratingCount: 456, cuisine: 'española' }),
  createRecipe({ title: 'Torrijas', description: 'Torrijas tradicionales con canela y miel', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', averageRating: 4.6, ratingCount: 189, cuisine: 'española' }),
  createRecipe({ title: 'Huevos Rotos con Jamón', description: 'Huevos fritos sobre patatas con jamón ibérico', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.5, ratingCount: 321, cuisine: 'española' }),
  createRecipe({ title: 'Migas Extremeñas', description: 'Migas tradicionales con torreznos y pimientos', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'medio', averageRating: 4.4, ratingCount: 156, cuisine: 'española' }),
  createRecipe({ title: 'Pan con Aceite', description: 'Pan tostado con aceite de oliva y sal', mealType: 'desayuno', toolType: 'tradicional', prepTime: 2, cookTime: 3, totalTime: 5, difficulty: 'facil', averageRating: 4.3, ratingCount: 98, cuisine: 'española' }),
  createRecipe({ title: 'Huevos al Plato', description: 'Huevos al plato con guisantes y jamón', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', averageRating: 4.2, ratingCount: 145, cuisine: 'española' }),
  createRecipe({ title: 'Desayuno Andaluz', description: 'Pan cateto con aceite, tomate y jamón serrano', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.6, ratingCount: 234, cuisine: 'española' }),
  createRecipe({ title: 'Embutidos Ibéricos', description: 'Tabla de embutidos ibéricos con pan', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.8, ratingCount: 345, cuisine: 'española' }),

  // French Breakfasts
  createRecipe({ title: 'Croissants de Mantequilla', description: 'Croissants franceses hojaldrados y crujientes', mealType: 'desayuno', toolType: 'tradicional', prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'dificil', averageRating: 4.9, ratingCount: 456, cuisine: 'francesa' }),
  createRecipe({ title: 'Pain au Chocolat', description: 'Napolitanas de chocolate francesas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'dificil', averageRating: 4.8, ratingCount: 389, cuisine: 'francesa' }),
  createRecipe({ title: 'Crêpes Suzette', description: 'Crêpes con salsa de naranja y Grand Marnier', mealType: 'desayuno', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', averageRating: 4.7, ratingCount: 267, cuisine: 'francesa' }),
  createRecipe({ title: 'Omelette aux Fines Herbes', description: 'Tortilla francesa con hierbas frescas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', averageRating: 4.5, ratingCount: 198, cuisine: 'francesa' }),
  createRecipe({ title: 'Brioche', description: 'Pan brioche francés suave y esponjoso', mealType: 'desayuno', toolType: 'tradicional', prepTime: 30, cookTime: 35, totalTime: 65, difficulty: 'medio', averageRating: 4.6, ratingCount: 234, cuisine: 'francesa' }),
  createRecipe({ title: 'Pain Perdu', description: 'Torrijas francesas con vainilla', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', averageRating: 4.7, ratingCount: 287, cuisine: 'francesa' }),
  createRecipe({ title: 'Croissant aux Amandes', description: 'Croissant de almendra con crema', mealType: 'desayuno', toolType: 'tradicional', prepTime: 50, cookTime: 20, totalTime: 70, difficulty: 'dificil', averageRating: 4.8, ratingCount: 178, cuisine: 'francesa' }),
  createRecipe({ title: 'Galette de Sarrasin', description: 'Crêpe de trigo sarraceno con huevo', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.4, ratingCount: 156, cuisine: 'francesa' }),
  createRecipe({ title: 'Viennoiserie', description: 'Pastelería vienesa francesa variada', mealType: 'desayuno', toolType: 'tradicional', prepTime: 40, cookTime: 25, totalTime: 65, difficulty: 'dificil', averageRating: 4.6, ratingCount: 201, cuisine: 'francesa' }),
  createRecipe({ title: 'Madeleines', description: 'Pequeños bizcochos franceses con forma de concha', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', averageRating: 4.5, ratingCount: 189, cuisine: 'francesa' }),

  // American Breakfasts
  createRecipe({ title: 'Pancakes Americanos', description: 'Tortitas esponjosas con sirope de arce', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.6, ratingCount: 567, cuisine: 'americana' }),
  createRecipe({ title: 'Bacon and Eggs', description: 'Huevos fritos con bacon crujiente', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.5, ratingCount: 432, cuisine: 'americana' }),
  createRecipe({ title: 'Hash Browns', description: 'Tortitas de patata crujientes', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.4, ratingCount: 298, cuisine: 'americana' }),
  createRecipe({ title: 'French Toast', description: 'Pan francés con canela y sirope', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.7, ratingCount: 345, cuisine: 'americana' }),
  createRecipe({ title: 'Bagel con Queso Crema', description: 'Bagel tostado con queso crema y salmón', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.5, ratingCount: 267, cuisine: 'americana' }),
  createRecipe({ title: 'Waffles Belgas', description: 'Waffles crujientes con frutas frescas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.8, ratingCount: 389, cuisine: 'americana' }),
  createRecipe({ title: 'Eggs Benedict', description: 'Huevos benedictinos con salsa holandesa', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', averageRating: 4.9, ratingCount: 456, cuisine: 'americana' }),
  createRecipe({ title: 'Granola con Yogur', description: 'Granola casera con yogur griego y frutas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.4, ratingCount: 234, cuisine: 'americana' }),
  createRecipe({ title: 'Breakfast Burrito', description: 'Burrito de desayuno con huevos y bacon', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', averageRating: 4.6, ratingCount: 312, cuisine: 'americana' }),
  createRecipe({ title: 'Blueberry Muffins', description: 'Muffins de arándanos frescos', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'facil', averageRating: 4.5, ratingCount: 278, cuisine: 'americana' }),

  // Italian Breakfasts
  createRecipe({ title: 'Cappuccino e Cornetto', description: 'Desayuno italiano clásico con cappuccino y croissant', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', averageRating: 4.7, ratingCount: 456, cuisine: 'italiana' }),
  createRecipe({ title: 'Focaccia al Rosmarino', description: 'Focaccia italiana con romero', mealType: 'desayuno', toolType: 'tradicional', prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'medio', averageRating: 4.6, ratingCount: 234, cuisine: 'italiana' }),
  createRecipe({ title: 'Biscotti', description: 'Galletas italianas crujientes para mojar', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 35, totalTime: 50, difficulty: 'facil', averageRating: 4.4, ratingCount: 189, cuisine: 'italiana' }),
  createRecipe({ title: 'Panettone', description: 'Pan dulce milanés con frutas escarchadas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 45, cookTime: 50, totalTime: 95, difficulty: 'dificil', averageRating: 4.8, ratingCount: 345, cuisine: 'italiana' }),
  createRecipe({ title: 'Ciabatta con Prosciutto', description: 'Pan ciabatta con jamón italiano', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.5, ratingCount: 267, cuisine: 'italiana' }),
  createRecipe({ title: 'Bomboloni', description: 'Donuts italianos rellenos de crema', mealType: 'desayuno', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.7, ratingCount: 298, cuisine: 'italiana' }),
  createRecipe({ title: 'Frittata di Pasta', description: 'Tortilla italiana de pasta', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.3, ratingCount: 156, cuisine: 'italiana' }),
  createRecipe({ title: 'Panini alla Nutella', description: 'Sándwich de pan con Nutella', mealType: 'desayuno', toolType: 'tradicional', prepTime: 3, cookTime: 5, totalTime: 8, difficulty: 'facil', averageRating: 4.6, ratingCount: 389, cuisine: 'italiana' }),
  createRecipe({ title: 'Ricotta e Miele', description: 'Ricotta fresca con miel y frutos secos', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.4, ratingCount: 201, cuisine: 'italiana' }),
  createRecipe({ title: 'Brioscina', description: 'Pequeños bollos sicilianos', mealType: 'desayuno', toolType: 'tradicional', prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'medio', averageRating: 4.5, ratingCount: 178, cuisine: 'italiana' }),

  // Mexican Breakfasts
  createRecipe({ title: 'Huevos Rancheros', description: 'Huevos con salsa ranchera y tortillas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.7, ratingCount: 345, cuisine: 'mexicana' }),
  createRecipe({ title: 'Chilaquiles', description: 'Totopos con salsa verde y crema', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.8, ratingCount: 456, cuisine: 'mexicana' }),
  createRecipe({ title: 'Molletes', description: 'Pan con frijoles y queso gratinado', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', averageRating: 4.5, ratingCount: 234, cuisine: 'mexicana' }),
  createRecipe({ title: 'Enchiladas de Desayuno', description: 'Enchiladas con huevo y queso', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'medio', averageRating: 4.6, ratingCount: 289, cuisine: 'mexicana' }),
  createRecipe({ title: 'Tamales de Elote', description: 'Tamales dulces de maíz tierno', mealType: 'desayuno', toolType: 'tradicional', prepTime: 30, cookTime: 60, totalTime: 90, difficulty: 'medio', averageRating: 4.7, ratingCount: 312, cuisine: 'mexicana' }),
  createRecipe({ title: 'Huevos a la Mexicana', description: 'Huevos revueltos con tomate y chile', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.4, ratingCount: 267, cuisine: 'mexicana' }),
  createRecipe({ title: 'Quesadillas de Maíz', description: 'Quesadillas con queso Oaxaca', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', averageRating: 4.5, ratingCount: 298, cuisine: 'mexicana' }),
  createRecipe({ title: 'Atole de Chocolate', description: 'Bebida espesa de chocolate mexicano', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.6, ratingCount: 189, cuisine: 'mexicana' }),
  createRecipe({ title: 'Tostadas de Ceviche', description: 'Tostadas con ceviche de pescado', mealType: 'desayuno', toolType: 'tradicional', prepTime: 20, cookTime: 0, totalTime: 20, difficulty: 'facil', averageRating: 4.7, ratingCount: 234, cuisine: 'mexicana' }),
  createRecipe({ title: 'Conchas', description: 'Pan dulce mexicano típico', mealType: 'desayuno', toolType: 'tradicional', prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', averageRating: 4.5, ratingCount: 278, cuisine: 'mexicana' }),

  // Mediterranean Breakfasts
  createRecipe({ title: 'Shakshuka', description: 'Huevos en salsa de tomate especiada', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', averageRating: 4.8, ratingCount: 456, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Labneh con Zaatar', description: 'Queso fresco con hierbas mediterráneas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.5, ratingCount: 234, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Foul Medames', description: 'Habas con especias egipcias', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.4, ratingCount: 156, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Menemen', description: 'Huevos turcos con pimientos y tomate', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.6, ratingCount: 289, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Fatteh', description: 'Pan con garbanzos y yogur', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'medio', averageRating: 4.5, ratingCount: 178, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Borek', description: 'Pastel turco de phyllo con queso', mealType: 'desayuno', toolType: 'tradicional', prepTime: 30, cookTime: 35, totalTime: 65, difficulty: 'medio', averageRating: 4.7, ratingCount: 312, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Simit', description: 'Pan turco con semillas de sésamo', mealType: 'desayuno', toolType: 'tradicional', prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'medio', averageRating: 4.4, ratingCount: 201, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Ful Nabed', description: 'Sopa de habas egipcia', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', averageRating: 4.3, ratingCount: 145, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Halloumi a la Plancha', description: 'Queso chipriota a la plancha', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', averageRating: 4.6, ratingCount: 267, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Manaqeesh', description: 'Pan plano con zaatar y aceite', mealType: 'desayuno', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', averageRating: 4.5, ratingCount: 189, cuisine: 'mediterranea' }),

  // Asian Breakfasts
  createRecipe({ title: 'Congee', description: 'Gachas de arroz chinas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 45, totalTime: 55, difficulty: 'facil', averageRating: 4.5, ratingCount: 234, cuisine: 'asiatica' }),
  createRecipe({ title: 'Dim Sum', description: 'Variedad de bollitos chinos al vapor', mealType: 'desayuno', toolType: 'tradicional', prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', averageRating: 4.8, ratingCount: 456, cuisine: 'asiatica' }),
  createRecipe({ title: 'Tamagoyaki', description: 'Tortilla japonesa enrollada', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'medio', averageRating: 4.6, ratingCount: 289, cuisine: 'asiatica' }),
  createRecipe({ title: 'Onigiri', description: 'Bolas de arroz japonés rellenas', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', averageRating: 4.4, ratingCount: 267, cuisine: 'asiatica' }),
  createRecipe({ title: 'Miso Soup', description: 'Sopa japonesa de miso con tofu', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.5, ratingCount: 312, cuisine: 'asiatica' }),
  createRecipe({ title: 'Nasi Goreng', description: 'Arroz frito indonesio con huevo', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.7, ratingCount: 378, cuisine: 'asiatica' }),
  createRecipe({ title: 'Pho', description: 'Sopa vietnamita de fideos', mealType: 'desayuno', toolType: 'tradicional', prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', averageRating: 4.8, ratingCount: 423, cuisine: 'asiatica' }),
  createRecipe({ title: 'Banh Mi', description: 'Sándwich vietnamita con cerdo', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.6, ratingCount: 345, cuisine: 'asiatica' }),
  createRecipe({ title: 'Idli', description: 'Pasteles de arroz del sur de India', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.4, ratingCount: 189, cuisine: 'asiatica' }),
  createRecipe({ title: 'Dosa', description: 'Crepe india crujiente de arroz', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', averageRating: 4.7, ratingCount: 298, cuisine: 'asiatica' }),

  // Healthy Breakfasts
  createRecipe({ title: 'Smoothie Bowl', description: 'Bowl de batido con frutas y granola', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.6, ratingCount: 345 }),
  createRecipe({ title: 'Açaí Bowl', description: 'Bowl de açaí con frutas tropicales', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.7, ratingCount: 389 }),
  createRecipe({ title: 'Overnight Oats', description: 'Avena preparada la noche anterior', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.5, ratingCount: 267 }),
  createRecipe({ title: 'Chia Pudding', description: 'Pudin de chía con leche de almendras', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.4, ratingCount: 234 }),
  createRecipe({ title: 'Quinoa Breakfast Bowl', description: 'Bowl de quinoa con frutas y nueces', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', averageRating: 4.5, ratingCount: 198 }),
  createRecipe({ title: 'Avocado Toast', description: 'Tostada de aguacate con huevo', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', averageRating: 4.6, ratingCount: 456 }),
  createRecipe({ title: 'Greek Yogurt Parfait', description: 'Yogur griego en capas con granola', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.5, ratingCount: 289 }),
  createRecipe({ title: 'Egg White Omelette', description: 'Tortilla de claras con vegetales', mealType: 'desayuno', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.3, ratingCount: 178 }),
  createRecipe({ title: 'Protein Pancakes', description: 'Tortitas con proteína y avena', mealType: 'desayuno', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.4, ratingCount: 234 }),
  createRecipe({ title: 'Buddha Bowl', description: 'Bowl nutritivo con vegetales y legumbres', mealType: 'desayuno', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.5, ratingCount: 201 }),
];

// Generate remaining breakfast recipes to reach 400
const breakfastTemplates = [
  { prefix: 'Tostada de ', ingredients: ['Aguacate', 'Jamón', 'Queso', 'Tomate', 'Mermelada', 'Nocilla', 'Mantequilla', 'Miel', 'Frutas', 'Crema'] },
  { prefix: 'Bowl de ', ingredients: ['Frutas', 'Yogur', 'Avena', 'Quinoa', 'Chía', 'Granola', 'Smoothie', 'Proteína', 'Cacao', 'Coco'] },
  { prefix: 'Huevos ', suffix: ['', ' con Bacon', ' Revueltos', ' Fritos', ' Poché', ' al Plato', ' con Queso', ' con Jamón', ' a la Mexicana', ' Benedict'] },
  { prefix: 'Muffin de ', ingredients: ['Arándanos', 'Chocolate', 'Plátano', 'Nueces', 'Avena', 'Zanahoria', 'Limón', 'Vainilla', 'Mora', 'Manzana'] },
  { prefix: 'Smoothie de ', ingredients: ['Plátano', 'Fresa', 'Mango', 'Papaya', 'Kiwi', 'Pera', 'Manzana', 'Piña', 'Uva', 'Melón'] },
];

let breakfastCount = desayunoRecipes.length;
while (breakfastCount < 400) {
  const template = breakfastTemplates[breakfastCount % breakfastTemplates.length];
  let title: string;
  if (template.suffix) {
    title = template.prefix + template.suffix[breakfastCount % template.suffix.length];
  } else if (template.ingredients) {
    title = template.prefix + template.ingredients[breakfastCount % template.ingredients.length];
  } else {
    title = template.prefix;
  }
  
  desayunoRecipes.push(createRecipe({
    title,
    description: `Delicioso desayuno de ${title.toLowerCase()}`,
    mealType: 'desayuno',
    toolType: 'tradicional',
    prepTime: 5 + (breakfastCount % 20),
    cookTime: 5 + (breakfastCount % 15),
    totalTime: 10 + (breakfastCount % 30),
    difficulty: breakfastCount % 3 === 0 ? 'facil' : breakfastCount % 3 === 1 ? 'medio' : 'dificil',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
  }));
  breakfastCount++;
}

// ALMUERZO RECIPES (400 recipes)
const almuerzoRecipes: Recipe[] = [
  // Spanish Lunch
  createRecipe({ title: 'Paella Valenciana', description: 'La auténtica paella valenciana con pollo, conejo y judías verdes', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'medio', averageRating: 4.9, ratingCount: 567, cuisine: 'española' }),
  createRecipe({ title: 'Cocido Madrileño', description: 'Potaje tradicional con garbanzos y carnes', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'medio', averageRating: 4.7, ratingCount: 345, cuisine: 'española' }),
  createRecipe({ title: 'Gazpacho Andaluz', description: 'Sopa fría de tomate tradicional', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 0, totalTime: 15, difficulty: 'facil', averageRating: 4.6, ratingCount: 456, cuisine: 'española' }),
  createRecipe({ title: 'Fabada Asturiana', description: 'Guiso de fabes con compango', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 90, totalTime: 120, difficulty: 'medio', averageRating: 4.8, ratingCount: 389, cuisine: 'española' }),
  createRecipe({ title: 'Pulpo a la Gallega', description: 'Pulpo con pimentón y aceite de oliva', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', averageRating: 4.9, ratingCount: 423, cuisine: 'española' }),
  createRecipe({ title: 'Judiones a la Llanesca', description: 'Alubias con marisco', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', averageRating: 4.5, ratingCount: 234, cuisine: 'española' }),
  createRecipe({ title: 'Marmitako', description: 'Guiso de bonito con patatas', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', averageRating: 4.7, ratingCount: 298, cuisine: 'española' }),
  createRecipe({ title: 'Callos a la Madrileña', description: 'Guiso tradicional de callos', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'dificil', averageRating: 4.6, ratingCount: 267, cuisine: 'española' }),
  createRecipe({ title: 'Coque de Sant Jordi', description: 'Coca catalana con butifarra', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 45, cookTime: 30, totalTime: 75, difficulty: 'medio', averageRating: 4.5, ratingCount: 189, cuisine: 'española' }),
  createRecipe({ title: 'Escalivada', description: 'Verduras asadas catalanas', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 45, totalTime: 60, difficulty: 'facil', averageRating: 4.4, ratingCount: 201, cuisine: 'española' }),

  // Italian Lunch
  createRecipe({ title: 'Spaghetti Carbonara', description: 'Pasta con huevo, queso pecorino y guanciale', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'medio', averageRating: 4.8, ratingCount: 567, cuisine: 'italiana' }),
  createRecipe({ title: 'Risotto ai Funghi', description: 'Risotto de setas porcini', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'medio', averageRating: 4.7, ratingCount: 423, cuisine: 'italiana' }),
  createRecipe({ title: 'Lasagna Bolognese', description: 'Lasaña con ragú y bechamel', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 45, cookTime: 45, totalTime: 90, difficulty: 'dificil', averageRating: 4.9, ratingCount: 512, cuisine: 'italiana' }),
  createRecipe({ title: 'Ossobuco alla Milanese', description: 'Jarrete de ternera con gremolata', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', averageRating: 4.8, ratingCount: 345, cuisine: 'italiana' }),
  createRecipe({ title: 'Pasta al Pomodoro', description: 'Pasta con salsa de tomate fresco', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', averageRating: 4.5, ratingCount: 478, cuisine: 'italiana' }),
  createRecipe({ title: 'Cotoletta alla Milanese', description: 'Chuleta de ternera empanada', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', averageRating: 4.6, ratingCount: 298, cuisine: 'italiana' }),
  createRecipe({ title: 'Saltimbocca alla Romana', description: 'Ternera con jamón y salvia', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.7, ratingCount: 267, cuisine: 'italiana' }),
  createRecipe({ title: 'Minestrone', description: 'Sopa de verduras italiana', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'facil', averageRating: 4.4, ratingCount: 234, cuisine: 'italiana' }),
  createRecipe({ title: 'Gnocchi di Patate', description: 'Ñoquis de patata caseros', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 45, cookTime: 15, totalTime: 60, difficulty: 'medio', averageRating: 4.6, ratingCount: 312, cuisine: 'italiana' }),
  createRecipe({ title: 'Pollo alla Cacciatora', description: 'Pollo guisado estilo cazador', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', averageRating: 4.5, ratingCount: 289, cuisine: 'italiana' }),

  // Mexican Lunch
  createRecipe({ title: 'Tacos al Pastor', description: 'Tacos de cerdo con piña', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 45, totalTime: 75, difficulty: 'medio', averageRating: 4.9, ratingCount: 534, cuisine: 'mexicana' }),
  createRecipe({ title: 'Enchiladas Verdes', description: 'Enchiladas con salsa de tomatillo', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'medio', averageRating: 4.7, ratingCount: 389, cuisine: 'mexicana' }),
  createRecipe({ title: 'Pozole Rojo', description: 'Sopa de maíz con cerdo', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 90, totalTime: 120, difficulty: 'medio', averageRating: 4.6, ratingCount: 312, cuisine: 'mexicana' }),
  createRecipe({ title: 'Mole Poblano', description: 'Pollo con mole de chocolate', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 45, cookTime: 120, totalTime: 165, difficulty: 'dificil', averageRating: 4.8, ratingCount: 456, cuisine: 'mexicana' }),
  createRecipe({ title: 'Tamales de Cerdo', description: 'Tamales con salsa de chile', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 60, cookTime: 60, totalTime: 120, difficulty: 'medio', averageRating: 4.7, ratingCount: 378, cuisine: 'mexicana' }),
  createRecipe({ title: 'Cochinita Pibil', description: 'Cerdo desmenuzado achiote', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'medio', averageRating: 4.9, ratingCount: 423, cuisine: 'mexicana' }),
  createRecipe({ title: 'Carnitas', description: 'Cerdo confitado mexicano', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 150, totalTime: 170, difficulty: 'medio', averageRating: 4.8, ratingCount: 389, cuisine: 'mexicana' }),
  createRecipe({ title: 'Quesadillas de Flor de Calabaza', description: 'Quesadillas con flor de calabaza', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.5, ratingCount: 267, cuisine: 'mexicana' }),
  createRecipe({ title: 'Sopes con Frijoles', description: 'Antojitos con frijoles y queso', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'facil', averageRating: 4.4, ratingCount: 234, cuisine: 'mexicana' }),
  createRecipe({ title: 'Birria de Chivo', description: 'Guiso de chivo con chiles', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'dificil', averageRating: 4.7, ratingCount: 298, cuisine: 'mexicana' }),

  // Asian Lunch
  createRecipe({ title: 'Pad Thai', description: 'Fideos de arroz tailandeses con gambas', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', averageRating: 4.8, ratingCount: 534, cuisine: 'asiatica' }),
  createRecipe({ title: 'Kung Pao Chicken', description: 'Pollo con cacahuetes y chile', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', averageRating: 4.6, ratingCount: 423, cuisine: 'asiatica' }),
  createRecipe({ title: 'Sushi Rolls', description: 'Rollitos de sushi variados', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'medio', averageRating: 4.7, ratingCount: 489, cuisine: 'asiatica' }),
  createRecipe({ title: 'Ramen de Cerdo', description: 'Sopa de fideos con chashu', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'dificil', averageRating: 4.9, ratingCount: 567, cuisine: 'asiatica' }),
  createRecipe({ title: 'Bibimbap', description: 'Arroz coreano con verduras', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', averageRating: 4.7, ratingCount: 378, cuisine: 'asiatica' }),
  createRecipe({ title: 'Green Curry', description: 'Curry verde tailandés con pollo', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'facil', averageRating: 4.6, ratingCount: 345, cuisine: 'asiatica' }),
  createRecipe({ title: 'Mapo Tofu', description: 'Tofu con salsa picante sichuanesa', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', averageRating: 4.5, ratingCount: 289, cuisine: 'asiatica' }),
  createRecipe({ title: 'Tom Yum', description: 'Sopa tailandesa picante', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', averageRating: 4.7, ratingCount: 412, cuisine: 'asiatica' }),
  createRecipe({ title: 'Peking Duck', description: 'Pato laqueado pekinés', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 60, cookTime: 90, totalTime: 150, difficulty: 'dificil', averageRating: 4.9, ratingCount: 456, cuisine: 'asiatica' }),
  createRecipe({ title: 'Bulgogi', description: 'Ternera coreana marinada', mealType: 'almuerzo', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'facil', averageRating: 4.8, ratingCount: 389, cuisine: 'asiatica' }),
];

// Generate remaining lunch recipes to reach 400
let lunchCount = almuerzoRecipes.length;
while (lunchCount < 400) {
  const dishTypes = ['Arroz', 'Pasta', 'Pollo', 'Carne', 'Pescado', 'Sopa', 'Ensalada', 'Legumbres', 'Verduras', 'Marisco'];
  const styles = ['Mediterráneo', 'Criollo', 'Casero', 'Tradicional', 'Moderno', 'Fusión', 'Light', 'Especial', 'Gourmet', 'Regional'];
  
  const title = `${dishTypes[lunchCount % dishTypes.length]} ${styles[lunchCount % styles.length]}`;
  
  almuerzoRecipes.push(createRecipe({
    title,
    description: `Delicioso ${dishTypes[lunchCount % dishTypes.length].toLowerCase()} preparado al estilo ${styles[lunchCount % styles.length].toLowerCase()}`,
    mealType: 'almuerzo',
    toolType: 'tradicional',
    prepTime: 10 + (lunchCount % 30),
    cookTime: 15 + (lunchCount % 45),
    totalTime: 25 + (lunchCount % 60),
    difficulty: lunchCount % 3 === 0 ? 'facil' : lunchCount % 3 === 1 ? 'medio' : 'dificil',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
  }));
  lunchCount++;
}

// POSTRE RECIPES (500 recipes)
const postreRecipes: Recipe[] = [
  // Spanish Desserts
  createRecipe({ title: 'Tarta de Santiago', description: 'Tarta de almendras gallega', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 40, totalTime: 60, difficulty: 'medio', averageRating: 4.7, ratingCount: 345, cuisine: 'española' }),
  createRecipe({ title: 'Crema Catalana', description: 'Crema quemada tradicional', mealType: 'postre', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', averageRating: 4.8, ratingCount: 456, cuisine: 'española' }),
  createRecipe({ title: 'Flan de Huevo', description: 'Flan casero tradicional', mealType: 'postre', toolType: 'tradicional', prepTime: 15, cookTime: 45, totalTime: 60, difficulty: 'facil', averageRating: 4.6, ratingCount: 389, cuisine: 'española' }),
  createRecipe({ title: 'Arroz con Leche', description: 'Postre de arroz con canela', mealType: 'postre', toolType: 'tradicional', prepTime: 10, cookTime: 45, totalTime: 55, difficulty: 'facil', averageRating: 4.5, ratingCount: 312, cuisine: 'española' }),
  createRecipe({ title: 'Tocino de Cielo', description: 'Postre dulce de huevo', mealType: 'postre', toolType: 'tradicional', prepTime: 15, cookTime: 40, totalTime: 55, difficulty: 'medio', averageRating: 4.7, ratingCount: 278, cuisine: 'española' }),
  createRecipe({ title: 'Buñuelos de Viento', description: 'Buñuelos rellenos de crema', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.6, ratingCount: 234, cuisine: 'española' }),
  createRecipe({ title: 'Pestiños', description: 'Dulces fritos con miel', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.4, ratingCount: 189, cuisine: 'española' }),
  createRecipe({ title: 'Leche Frita', description: 'Postre cremoso frito', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', averageRating: 4.5, ratingCount: 267, cuisine: 'española' }),
  createRecipe({ title: 'Rosquillas', description: 'Donuts tradicionales españoles', mealType: 'postre', toolType: 'tradicional', prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'facil', averageRating: 4.3, ratingCount: 201, cuisine: 'española' }),
  createRecipe({ title: 'Yemas de Ávila', description: 'Dulces de yema de huevo', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 20, totalTime: 40, difficulty: 'medio', averageRating: 4.6, ratingCount: 178, cuisine: 'española' }),

  // French Desserts
  createRecipe({ title: 'Crème Brûlée', description: 'Crema quemada francesa', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', averageRating: 4.9, ratingCount: 512, cuisine: 'francesa' }),
  createRecipe({ title: 'Macarons', description: 'Pastelitos franceses de almendra', mealType: 'postre', toolType: 'tradicional', prepTime: 45, cookTime: 15, totalTime: 60, difficulty: 'dificil', averageRating: 4.8, ratingCount: 456, cuisine: 'francesa' }),
  createRecipe({ title: 'Mille-Feuille', description: 'Pastel de mil hojas', mealType: 'postre', toolType: 'tradicional', prepTime: 60, cookTime: 30, totalTime: 90, difficulty: 'dificil', averageRating: 4.7, ratingCount: 345, cuisine: 'francesa' }),
  createRecipe({ title: 'Éclair', description: 'Pastel alargado de crema', mealType: 'postre', toolType: 'tradicional', prepTime: 45, cookTime: 25, totalTime: 70, difficulty: 'dificil', averageRating: 4.6, ratingCount: 289, cuisine: 'francesa' }),
  createRecipe({ title: 'Opera Cake', description: 'Tarta de café y chocolate', mealType: 'postre', toolType: 'tradicional', prepTime: 90, cookTime: 30, totalTime: 120, difficulty: 'dificil', averageRating: 4.8, ratingCount: 312, cuisine: 'francesa' }),
  createRecipe({ title: 'Tarte Tatin', description: 'Tarta de manzana invertida', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'medio', averageRating: 4.7, ratingCount: 267, cuisine: 'francesa' }),
  createRecipe({ title: 'Profiteroles', description: 'Bollos de nata con chocolate', mealType: 'postre', toolType: 'tradicional', prepTime: 40, cookTime: 25, totalTime: 65, difficulty: 'medio', averageRating: 4.5, ratingCount: 234, cuisine: 'francesa' }),
  createRecipe({ title: 'Paris-Brest', description: 'Pastel circular de praliné', mealType: 'postre', toolType: 'tradicional', prepTime: 50, cookTime: 30, totalTime: 80, difficulty: 'dificil', averageRating: 4.7, ratingCount: 201, cuisine: 'francesa' }),
  createRecipe({ title: 'Ile Flottante', description: 'Islas flotantes de merengue', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', averageRating: 4.4, ratingCount: 178, cuisine: 'francesa' }),
  createRecipe({ title: 'Baba au Rhum', description: 'Pastel empapado de ron', mealType: 'postre', toolType: 'tradicional', prepTime: 40, cookTime: 35, totalTime: 75, difficulty: 'medio', averageRating: 4.5, ratingCount: 156, cuisine: 'francesa' }),

  // Italian Desserts
  createRecipe({ title: 'Tiramisú', description: 'Postre de café y mascarpone', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'facil', averageRating: 4.9, ratingCount: 567, cuisine: 'italiana' }),
  createRecipe({ title: 'Panna Cotta', description: 'Crema italiana cuajada', mealType: 'postre', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.7, ratingCount: 456, cuisine: 'italiana' }),
  createRecipe({ title: 'Cannoli', description: 'Tubos de masa rellenos de ricotta', mealType: 'postre', toolType: 'tradicional', prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'medio', averageRating: 4.8, ratingCount: 389, cuisine: 'italiana' }),
  createRecipe({ title: 'Gelato', description: 'Helado italiano cremoso', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'medio', averageRating: 4.9, ratingCount: 534, cuisine: 'italiana' }),
  createRecipe({ title: 'Cassata Siciliana', description: 'Tarta siciliana de ricotta', mealType: 'postre', toolType: 'tradicional', prepTime: 60, cookTime: 0, totalTime: 60, difficulty: 'dificil', averageRating: 4.6, ratingCount: 234, cuisine: 'italiana' }),
  createRecipe({ title: 'Semifreddo', description: 'Postre semicongelado italiano', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'medio', averageRating: 4.5, ratingCount: 201, cuisine: 'italiana' }),
  createRecipe({ title: 'Zuccotto', description: 'Postre con forma de cúpula', mealType: 'postre', toolType: 'tradicional', prepTime: 45, cookTime: 0, totalTime: 45, difficulty: 'medio', averageRating: 4.4, ratingCount: 178, cuisine: 'italiana' }),
  createRecipe({ title: 'Crostata di Marmellata', description: 'Tarta de mermelada italiana', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'facil', averageRating: 4.3, ratingCount: 234, cuisine: 'italiana' }),
  createRecipe({ title: 'Zabaglione', description: 'Crema de yemas con vino', mealType: 'postre', toolType: 'tradicional', prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', averageRating: 4.5, ratingCount: 189, cuisine: 'italiana' }),
  createRecipe({ title: 'Torta Caprese', description: 'Tarta de chocolate y almendra', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', averageRating: 4.7, ratingCount: 267, cuisine: 'italiana' }),

  // American Desserts
  createRecipe({ title: 'Cheesecake New York', description: 'Tarta de queso neoyorquina', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 60, totalTime: 90, difficulty: 'medio', averageRating: 4.8, ratingCount: 512, cuisine: 'americana' }),
  createRecipe({ title: 'Brownies', description: 'Pastelitos de chocolate densos', mealType: 'postre', toolType: 'tradicional', prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', averageRating: 4.7, ratingCount: 456, cuisine: 'americana' }),
  createRecipe({ title: 'Apple Pie', description: 'Tarta de manzana americana', mealType: 'postre', toolType: 'tradicional', prepTime: 45, cookTime: 50, totalTime: 95, difficulty: 'medio', averageRating: 4.6, ratingCount: 389, cuisine: 'americana' }),
  createRecipe({ title: 'Pumpkin Pie', description: 'Tarta de calabaza', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 55, totalTime: 85, difficulty: 'medio', averageRating: 4.5, ratingCount: 312, cuisine: 'americana' }),
  createRecipe({ title: 'Key Lime Pie', description: 'Tarta de lima de Key West', mealType: 'postre', toolType: 'tradicional', prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'facil', averageRating: 4.6, ratingCount: 267, cuisine: 'americana' }),
  createRecipe({ title: 'Pecan Pie', description: 'Tarta de nueces pecanas', mealType: 'postre', toolType: 'tradicional', prepTime: 20, cookTime: 50, totalTime: 70, difficulty: 'facil', averageRating: 4.5, ratingCount: 234, cuisine: 'americana' }),
  createRecipe({ title: 'Red Velvet Cake', description: 'Tarta de terciopelo rojo', mealType: 'postre', toolType: 'tradicional', prepTime: 40, cookTime: 35, totalTime: 75, difficulty: 'medio', averageRating: 4.7, ratingCount: 345, cuisine: 'americana' }),
  createRecipe({ title: 'Carrot Cake', description: 'Tarta de zanahoria con nueces', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 45, totalTime: 75, difficulty: 'medio', averageRating: 4.6, ratingCount: 298, cuisine: 'americana' }),
  createRecipe({ title: 'Doughnuts', description: 'Donuts glaseados americanos', mealType: 'postre', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.4, ratingCount: 278, cuisine: 'americana' }),
  createRecipe({ title: 'S\'mores', description: 'Postre de fuego con malvaviscos', mealType: 'postre', toolType: 'tradicional', prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', averageRating: 4.5, ratingCount: 201, cuisine: 'americana' }),
];

// Generate remaining dessert recipes to reach 500
let dessertCount = postreRecipes.length;
const dessertTypes = ['Tarta', 'Pastel', 'Galletas', 'Flan', 'Mousse', 'Helado', 'Crema', 'Pudin', 'Bizcocho', 'Cupcake'];
const dessertFlavors = ['Chocolate', 'Vainilla', 'Fresa', 'Limón', 'Caramelo', 'Frutos Rojos', 'Naranja', 'Café', 'Coco', 'Canela'];

while (dessertCount < 500) {
  const title = `${dessertTypes[dessertCount % dessertTypes.length]} de ${dessertFlavors[dessertCount % dessertFlavors.length]}`;
  
  postreRecipes.push(createRecipe({
    title,
    description: `Delicioso ${dessertTypes[dessertCount % dessertTypes.length].toLowerCase()} con sabor a ${dessertFlavors[dessertCount % dessertFlavors.length].toLowerCase()}`,
    mealType: 'postre',
    toolType: 'tradicional',
    prepTime: 10 + (dessertCount % 30),
    cookTime: 15 + (dessertCount % 40),
    totalTime: 25 + (dessertCount % 50),
    difficulty: dessertCount % 3 === 0 ? 'facil' : dessertCount % 3 === 1 ? 'medio' : 'dificil',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
  }));
  dessertCount++;
}

// SNACK RECIPES (500 recipes)
const snackRecipes: Recipe[] = [
  // Spanish Snacks
  createRecipe({ title: 'Patatas Bravas', description: 'Patatas con salsa brava picante', mealType: 'snack', toolType: 'tradicional', prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', averageRating: 4.7, ratingCount: 456, cuisine: 'española' }),
  createRecipe({ title: 'Croquetas de Jamón', description: 'Croquetas cremosas de jamón serrano', mealType: 'snack', toolType: 'tradicional', prepTime: 30, cookTime: 10, totalTime: 40, difficulty: 'medio', averageRating: 4.8, ratingCount: 512, cuisine: 'española' }),
  createRecipe({ title: 'Pinchos Morunos', description: 'Brochetas de cerdo especiadas', mealType: 'snack', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.6, ratingCount: 345, cuisine: 'española' }),
  createRecipe({ title: 'Gildas', description: 'Pincho de aceituna y anchoa', mealType: 'snack', toolType: 'tradicional', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.4, ratingCount: 234, cuisine: 'española' }),
  createRecipe({ title: 'Aceitunas Aliñadas', description: 'Aceitunas con hierbas y especias', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.3, ratingCount: 189, cuisine: 'española' }),
  createRecipe({ title: 'Empanadillas', description: 'Empanadillas de atún', mealType: 'snack', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.5, ratingCount: 298, cuisine: 'española' }),
  createRecipe({ title: 'Huevos Rellenos', description: 'Huevos rellenos de atún', mealType: 'snack', toolType: 'tradicional', prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'facil', averageRating: 4.4, ratingCount: 267, cuisine: 'española' }),
  createRecipe({ title: 'Pimientos de Padrón', description: 'Pimientos fritos con sal', mealType: 'snack', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.5, ratingCount: 312, cuisine: 'española' }),
  createRecipe({ title: 'Torreznos', description: 'Panceta de cerdo crujiente', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', averageRating: 4.6, ratingCount: 278, cuisine: 'española' }),
  createRecipe({ title: 'Gambas al Ajillo', description: 'Gambas con ajo y guindilla', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', averageRating: 4.7, ratingCount: 389, cuisine: 'española' }),

  // International Snacks
  createRecipe({ title: 'Nachos con Queso', description: 'Totopos con queso fundido', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', averageRating: 4.5, ratingCount: 423, cuisine: 'mexicana' }),
  createRecipe({ title: 'Guacamole', description: 'Pasta de aguacate con especias', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.7, ratingCount: 512, cuisine: 'mexicana' }),
  createRecipe({ title: 'Spring Rolls', description: 'Rollos primavera crujientes', mealType: 'snack', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.6, ratingCount: 345, cuisine: 'asiatica' }),
  createRecipe({ title: 'Edamame', description: 'Habas de soja al vapor', mealType: 'snack', toolType: 'tradicional', prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', averageRating: 4.4, ratingCount: 267, cuisine: 'asiatica' }),
  createRecipe({ title: 'Bruschetta', description: 'Tostadas con tomate y albahaca', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', averageRating: 4.5, ratingCount: 389, cuisine: 'italiana' }),
  createRecipe({ title: 'Caprese Skewers', description: 'Brochetas de mozzarella y tomate', mealType: 'snack', toolType: 'tradicional', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.4, ratingCount: 234, cuisine: 'italiana' }),
  createRecipe({ title: 'Buffalo Wings', description: 'Alitas de pollo picantes', mealType: 'snack', toolType: 'tradicional', prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'facil', averageRating: 4.7, ratingCount: 456, cuisine: 'americana' }),
  createRecipe({ title: 'Onion Rings', description: 'Aros de cebolla empanizados', mealType: 'snack', toolType: 'tradicional', prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', averageRating: 4.3, ratingCount: 298, cuisine: 'americana' }),
  createRecipe({ title: 'Falafel', description: 'Croquetas de garbanzos especiadas', mealType: 'snack', toolType: 'tradicional', prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', averageRating: 4.6, ratingCount: 378, cuisine: 'mediterranea' }),
  createRecipe({ title: 'Hummus con Pita', description: 'Crema de garbanzo con pan', mealType: 'snack', toolType: 'tradicional', prepTime: 15, cookTime: 0, totalTime: 15, difficulty: 'facil', averageRating: 4.5, ratingCount: 312, cuisine: 'mediterranea' }),
];

// Generate remaining snack recipes to reach 500
let snackCount = snackRecipes.length;
const snackTypes = ['Chips', 'Nachos', 'Dip', 'Rolls', 'Bites', 'Sticks', 'Balls', 'Wings', 'Fingers', 'Poppers'];
const snackFlavors = ['Queso', 'Picante', 'BBQ', 'Ajo', 'Hierbas', 'Ranch', 'Chili', 'Cebolla', 'Pimentón', 'Curry'];

while (snackCount < 500) {
  const title = `${snackTypes[snackCount % snackTypes.length]} ${snackFlavors[snackCount % snackFlavors.length]}`;
  
  snackRecipes.push(createRecipe({
    title,
    description: `Crujientes ${snackTypes[snackCount % snackTypes.length].toLowerCase()} con sabor ${snackFlavors[snackCount % snackFlavors.length].toLowerCase()}`,
    mealType: 'snack',
    toolType: 'tradicional',
    prepTime: 5 + (snackCount % 15),
    cookTime: 5 + (snackCount % 20),
    totalTime: 10 + (snackCount % 25),
    difficulty: snackCount % 3 === 0 ? 'facil' : snackCount % 3 === 1 ? 'medio' : 'dificil',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
  }));
  snackCount++;
}

// THERMOMIX RECIPES (300 recipes)
const thermomixRecipes: Recipe[] = [
  createRecipe({ title: 'Pan de Molde Thermomix', description: 'Pan de molde esponjoso en Thermomix', mealType: 'desayuno', toolType: 'thermomix', prepTime: 15, cookTime: 45, totalTime: 60, difficulty: 'facil', averageRating: 4.7, ratingCount: 456 }),
  createRecipe({ title: 'Sopa de Verduras Thermomix', description: 'Sopa cremosa de verduras', mealType: 'almuerzo', toolType: 'thermomix', prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', averageRating: 4.5, ratingCount: 345 }),
  createRecipe({ title: 'Sorbete de Limón Thermomix', description: 'Sorbete refrescante de limón', mealType: 'postre', toolType: 'thermomix', prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', averageRating: 4.6, ratingCount: 389 }),
  createRecipe({ title: 'Hummus Thermomix', description: 'Crema de garbanzos perfecta', mealType: 'snack', toolType: 'thermomix', prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', averageRating: 4.8, ratingCount: 512 }),
  createRecipe({ title: 'Bizcocho de Yogur Thermomix', description: 'Bizcocho esponjoso de yogur', mealType: 'postre', toolType: 'thermomix', prepTime: 10, cookTime: 40, totalTime: 50, difficulty: 'facil', averageRating: 4.6, ratingCount: 423 }),
  createRecipe({ title: 'Puré de Patata Thermomix', description: 'Puré de patata cremoso', mealType: 'almuerzo', toolType: 'thermomix', prepTime: 10, cookTime: 30, totalTime: 40, difficulty: 'facil', averageRating: 4.4, ratingCount: 267 }),
  createRecipe({ title: 'Helado de Vainilla Thermomix', description: 'Helado cremoso de vainilla', mealType: 'postre', toolType: 'thermomix', prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', averageRating: 4.7, ratingCount: 378 }),
  createRecipe({ title: 'Masa de Pizza Thermomix', description: 'Masa de pizza perfecta', mealType: 'almuerzo', toolType: 'thermomix', prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', averageRating: 4.5, ratingCount: 312 }),
  createRecipe({ title: 'Crema de Calabaza Thermomix', description: 'Crema suave de calabaza', mealType: 'almuerzo', toolType: 'thermomix', prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', averageRating: 4.6, ratingCount: 298 }),
  createRecipe({ title: 'Mermelada de Fresa Thermomix', description: 'Mermelada casera de fresa', mealType: 'desayuno', toolType: 'thermomix', prepTime: 10, cookTime: 30, totalTime: 40, difficulty: 'facil', averageRating: 4.8, ratingCount: 456 }),
];

// Generate remaining Thermomix recipes to reach 300
let thermomixCount = thermomixRecipes.length;
const thermomixDishes = ['Arroz', 'Pasta', 'Sopa', 'Crema', 'Puré', 'Salsa', 'Masa', 'Batido', 'Sorbete', 'Helado'];
const thermomixVariants = ['Clásico', 'Especial', 'Cremoso', 'Ligero', 'Intenso', 'Suave', 'Casero', 'Fácil', 'Rápido', 'Gourmet'];

while (thermomixCount < 300) {
  const title = `${thermomixDishes[thermomixCount % thermomixDishes.length]} ${thermomixVariants[thermomixCount % thermomixVariants.length]} Thermomix`;
  
  thermomixRecipes.push(createRecipe({
    title,
    description: `${thermomixDishes[thermomixCount % thermomixDishes.length]} preparado de forma ${thermomixVariants[thermomixCount % thermomixVariants.length].toLowerCase()} en Thermomix`,
    mealType: ['desayuno', 'almuerzo', 'cena', 'postre', 'snack'][thermomixCount % 5] as Recipe['mealType'],
    toolType: 'thermomix',
    prepTime: 5 + (thermomixCount % 15),
    cookTime: 10 + (thermomixCount % 25),
    totalTime: 15 + (thermomixCount % 35),
    difficulty: thermomixCount % 3 === 0 ? 'facil' : thermomixCount % 3 === 1 ? 'medio' : 'dificil',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
  }));
  thermomixCount++;
}

// CROCKPOT RECIPES (300 recipes)
const crockpotRecipes: Recipe[] = [
  createRecipe({ title: 'Pulled Pork Crockpot', description: 'Cerdo desmenuzado a fuego lento', mealType: 'almuerzo', toolType: 'crockpot', prepTime: 20, cookTime: 480, totalTime: 500, difficulty: 'facil', averageRating: 4.9, ratingCount: 534 }),
  createRecipe({ title: 'Chili con Carne Crockpot', description: 'Chili especiado de larga cocción', mealType: 'almuerzo', toolType: 'crockpot', prepTime: 15, cookTime: 360, totalTime: 375, difficulty: 'facil', averageRating: 4.7, ratingCount: 456 }),
  createRecipe({ title: 'Beef Stew Crockpot', description: 'Estofado de ternera con verduras', mealType: 'cena', toolType: 'crockpot', prepTime: 20, cookTime: 420, totalTime: 440, difficulty: 'facil', averageRating: 4.8, ratingCount: 489 }),
  createRecipe({ title: 'Pollo a la Cerveza Crockpot', description: 'Pollo guisado con cerveza', mealType: 'cena', toolType: 'crockpot', prepTime: 15, cookTime: 300, totalTime: 315, difficulty: 'facil', averageRating: 4.6, ratingCount: 378 }),
  createRecipe({ title: 'Ribs BBQ Crockpot', description: 'Costillas barbacoa tiernas', mealType: 'almuerzo', toolType: 'crockpot', prepTime: 15, cookTime: 360, totalTime: 375, difficulty: 'facil', averageRating: 4.9, ratingCount: 512 }),
  createRecipe({ title: 'Lentil Soup Crockpot', description: 'Sopa de lentejas casera', mealType: 'almuerzo', toolType: 'crockpot', prepTime: 15, cookTime: 300, totalTime: 315, difficulty: 'facil', averageRating: 4.5, ratingCount: 312 }),
  createRecipe({ title: 'Pot Roast Crockpot', description: 'Asado de ternera clásico', mealType: 'almuerzo', toolType: 'crockpot', prepTime: 15, cookTime: 480, totalTime: 495, difficulty: 'facil', averageRating: 4.8, ratingCount: 423 }),
  createRecipe({ title: 'Chicken Curry Crockpot', description: 'Curry de pollo especiado', mealType: 'cena', toolType: 'crockpot', prepTime: 15, cookTime: 300, totalTime: 315, difficulty: 'facil', averageRating: 4.6, ratingCount: 345 }),
  createRecipe({ title: 'Oatmeal Crockpot', description: 'Avena de cocción lenta', mealType: 'desayuno', toolType: 'crockpot', prepTime: 5, cookTime: 360, totalTime: 365, difficulty: 'facil', averageRating: 4.4, ratingCount: 234 }),
  createRecipe({ title: 'Apple Butter Crockpot', description: 'Mantequilla de manzana casera', mealType: 'desayuno', toolType: 'crockpot', prepTime: 15, cookTime: 600, totalTime: 615, difficulty: 'facil', averageRating: 4.7, ratingCount: 298 }),
];

// Generate remaining Crockpot recipes to reach 300
let crockpotCount = crockpotRecipes.length;
const crockpotDishes = ['Estofado', 'Guiso', 'Sopa', 'Asado', 'Curry', 'Chili', 'Ragú', 'Cocido', 'Puchero', 'Olla'];
const crockpotProteins = ['Ternera', 'Cerdo', 'Pollo', 'Cordero', 'Pavo', 'Legumbres', 'Verduras', 'Pescado', 'Marisco', 'Mixto'];

while (crockpotCount < 300) {
  const title = `${crockpotDishes[crockpotCount % crockpotDishes.length]} de ${crockpotProteins[crockpotCount % crockpotProteins.length]} Crockpot`;
  
  crockpotRecipes.push(createRecipe({
    title,
    description: `${crockpotDishes[crockpotCount % crockpotDishes.length]} de ${crockpotProteins[crockpotCount % crockpotProteins.length].toLowerCase()} cocinado lentamente`,
    mealType: ['almuerzo', 'cena'][crockpotCount % 2] as Recipe['mealType'],
    toolType: 'crockpot',
    prepTime: 10 + (crockpotCount % 20),
    cookTime: 180 + (crockpotCount % 300),
    totalTime: 190 + (crockpotCount % 320),
    difficulty: 'facil',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
  }));
  crockpotCount++;
}

// Helper function for traditional recipes (uses pre-defined images)
const getTraditionalImage = (index: number): string => {
  const traditionalImages = [
    'https://images.unsplash.com/photo-1544025162-d76694265947?w=400',
    'https://images.unsplash.com/photo-1432139555190-58524dae6a55?w=400',
    'https://images.unsplash.com/photo-1559847844-5315695dadae?w=400',
    'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?w=400',
    'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400',
    'https://images.unsplash.com/photo-1478057067332-46c79ca9e59c?w=400',
    'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400',
    'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400',
    'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400',
    'https://images.unsplash.com/photo-1558030006-450675393462?w=400',
  ];
  return traditionalImages[(index - 1) % traditionalImages.length];
};

// TRADITIONAL RECIPES (300 recipes)
const traditionalRecipes: Recipe[] = [
  { id: generateId(), title: 'Asado de Cordero', description: 'Cordero asado tradicional', imageUrl: getTraditionalImage(1), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 456, mealType: 'almuerzo' },
  { id: generateId(), title: 'Cochinillo Asado', description: 'Cochinillo crujiente tradicional', imageUrl: getTraditionalImage(2), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 512, mealType: 'almuerzo' },
  { id: generateId(), title: 'Bacalao al Pil Pil', description: 'Bacalao con salsa de ajo', imageUrl: getTraditionalImage(3), prepTime: 30, cookTime: 30, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 389, mealType: 'almuerzo' },
  { id: generateId(), title: 'Cordero Segoviano', description: 'Cordero asado estilo segoviano', imageUrl: getTraditionalImage(4), prepTime: 20, cookTime: 150, totalTime: 170, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.8, ratingCount: 345, mealType: 'almuerzo' },
  { id: generateId(), title: 'Pollo al Ajillo', description: 'Pollo con ajos fritos', imageUrl: getTraditionalImage(5), prepTime: 15, cookTime: 40, totalTime: 55, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.6, ratingCount: 378, mealType: 'cena' },
  { id: generateId(), title: 'Lomo de Orza', description: 'Lomo confitado tradicional', imageUrl: getTraditionalImage(6), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.7, ratingCount: 298, mealType: 'almuerzo' },
  { id: generateId(), title: 'Chuletillas de Cordero', description: 'Chuletillas a la brasa', imageUrl: getTraditionalImage(7), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', averageRating: 4.8, ratingCount: 423, mealType: 'cena' },
  { id: generateId(), title: 'Merluza a la Vasca', description: 'Merluza con salsa verde', imageUrl: getTraditionalImage(8), prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.6, ratingCount: 312, mealType: 'almuerzo' },
  { id: generateId(), title: 'Rabo de Toro', description: 'Rabo de toro estofado', imageUrl: getTraditionalImage(9), prepTime: 30, cookTime: 240, totalTime: 270, difficulty: 'dificil', toolType: 'tradicional', averageRating: 4.9, ratingCount: 389, mealType: 'almuerzo' },
  { id: generateId(), title: 'Lechazo Asado', description: 'Lechazo asado tradicional', imageUrl: getTraditionalImage(10), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', averageRating: 4.9, ratingCount: 456, mealType: 'almuerzo' },
];

// Generate remaining Traditional recipes to reach 300
let traditionalCount = traditionalRecipes.length;
const traditionalDishes = ['Asado', 'Guiso', 'Estofado', 'Frito', 'A la Plancha', 'Al Horno', 'En Salsa', 'Guisado', 'Salteado', 'Confitado'];
const traditionalIngredients = ['Ternera', 'Cerdo', 'Cordero', 'Pollo', 'Pescado', 'Marisco', 'Caza', 'Legumbres', 'Verduras', 'Arroz'];

while (traditionalCount < 300) {
  traditionalRecipes.push({
    id: generateId(),
    title: `${traditionalDishes[traditionalCount % traditionalDishes.length]} de ${traditionalIngredients[traditionalCount % traditionalIngredients.length]} Tradicional`,
    description: `${traditionalDishes[traditionalCount % traditionalDishes.length].toLowerCase()} de ${traditionalIngredients[traditionalCount % traditionalIngredients.length].toLowerCase()} preparado de forma tradicional`,
    imageUrl: getTraditionalImage(traditionalCount),
    prepTime: 15 + (traditionalCount % 25),
    cookTime: 30 + (traditionalCount % 90),
    totalTime: 45 + (traditionalCount % 100),
    difficulty: traditionalCount % 3 === 0 ? 'facil' : traditionalCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'tradicional',
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: ['almuerzo', 'cena'][traditionalCount % 2] as Recipe['mealType'],
  });
  traditionalCount++;
}

// Combine all recipes
export const allRecipes: Recipe[] = [
  ...desayunoRecipes,
  ...almuerzoRecipes,
  ...postreRecipes,
  ...snackRecipes,
  ...thermomixRecipes,
  ...crockpotRecipes,
  ...traditionalRecipes,
];

// Export counts
export const recipeCounts = {
  desayuno: desayunoRecipes.length,
  almuerzo: almuerzoRecipes.length,
  postre: postreRecipes.length,
  snack: snackRecipes.length,
  thermomix: thermomixRecipes.length,
  crockpot: crockpotRecipes.length,
  tradicional: traditionalRecipes.length,
  total: allRecipes.length,
};

export default allRecipes;
