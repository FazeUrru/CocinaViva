// 1000 Recetas Tradicionales - Cocina Clásica
import { getRecipeImage } from '@/lib/recipe-images';

export interface TraditionalRecipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: 'facil' | 'medio' | 'dificil';
  toolType: 'tradicional';
  
  averageRating: number;
  ratingCount: number;
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack';
  cuisine?: string;
}

const difficulties: ('facil' | 'medio' | 'dificil')[] = ['facil', 'medio', 'dificil'];
const cuisines = ['española', 'italiana', 'francesa', 'mexicana', 'asiatica', 'mediterranea', 'americana', 'india', 'griega', 'japonesa'];

// Plantillas de recetas tradicionales por categoría
const desayunoTemplates = [
  { title: 'Tostadas con Tomate', desc: 'Clásicas tostadas españolas con tomate rallado y aceite de oliva virgen extra', cuisine: 'española' },
  { title: 'Tortilla Española', desc: 'Tortilla de patatas tradicional con cebolla caramelizada', cuisine: 'española' },
  { title: 'Churros con Chocolate', desc: 'Churros caseros crujientes con chocolate espeso para mojar', cuisine: 'española' },
  { title: 'Torrijas', desc: 'Torrijas tradicionales con canela y miel', cuisine: 'española' },
  { title: 'Huevos Rotos con Jamón', desc: 'Huevos fritos sobre patatas con jamón ibérico', cuisine: 'española' },
  { title: 'Migas Extremeñas', desc: 'Migas tradicionales con torreznos y pimientos', cuisine: 'española' },
  { title: 'Croissants de Mantequilla', desc: 'Croissants franceses hojaldrados y crujientes', cuisine: 'francesa' },
  { title: 'Pain au Chocolat', desc: 'Napolitanas de chocolate francesas', cuisine: 'francesa' },
  { title: 'Crêpes Suzette', desc: 'Crêpes con salsa de naranja y Grand Marnier', cuisine: 'francesa' },
  { title: 'Omelette aux Fines Herbes', desc: 'Tortilla francesa con hierbas frescas', cuisine: 'francesa' },
  { title: 'Brioche', desc: 'Pan brioche francés suave y esponjoso', cuisine: 'francesa' },
  { title: 'Pain Perdu', desc: 'Torrijas francesas con vainilla', cuisine: 'francesa' },
  { title: 'Pancakes Americanos', desc: 'Tortitas esponjosas con sirope de arce', cuisine: 'americana' },
  { title: 'Bacon and Eggs', desc: 'Huevos fritos con bacon crujiente', cuisine: 'americana' },
  { title: 'Hash Browns', desc: 'Tortitas de patata crujientes', cuisine: 'americana' },
  { title: 'French Toast', desc: 'Pan francés con canela y sirope', cuisine: 'americana' },
  { title: 'Bagel con Queso Crema', desc: 'Bagel tostado con queso crema y salmón', cuisine: 'americana' },
  { title: 'Waffles Belgas', desc: 'Waffles crujientes con frutas frescas', cuisine: 'americana' },
  { title: 'Eggs Benedict', desc: 'Huevos benedictinos con salsa holandesa', cuisine: 'americana' },
  { title: 'Granola con Yogur', desc: 'Granola casera con yogur griego y frutas', cuisine: 'americana' },
  { title: 'Cappuccino e Cornetto', desc: 'Desayuno italiano clásico con cappuccino y croissant', cuisine: 'italiana' },
  { title: 'Focaccia al Rosmarino', desc: 'Focaccia italiana con romero', cuisine: 'italiana' },
  { title: 'Biscotti', desc: 'Galletas italianas crujientes para mojar', cuisine: 'italiana' },
  { title: 'Panettone', desc: 'Pan dulce milanés con frutas escarchadas', cuisine: 'italiana' },
  { title: 'Bomboloni', desc: 'Donuts italianos rellenos de crema', cuisine: 'italiana' },
  { title: 'Huevos Rancheros', desc: 'Huevos con salsa ranchera y tortillas', cuisine: 'mexicana' },
  { title: 'Chilaquiles', desc: 'Totopos con salsa verde y crema', cuisine: 'mexicana' },
  { title: 'Molletes', desc: 'Pan con frijoles y queso gratinado', cuisine: 'mexicana' },
  { title: 'Tamales de Elote', desc: 'Tamales dulces de maíz tierno', cuisine: 'mexicana' },
  { title: 'Conchas', desc: 'Pan dulce mexicano típico', cuisine: 'mexicana' },
  { title: 'Shakshuka', desc: 'Huevos en salsa de tomate especiada', cuisine: 'mediterranea' },
  { title: 'Labneh con Zaatar', desc: 'Queso fresco con hierbas mediterráneas', cuisine: 'mediterranea' },
  { title: 'Menemen', desc: 'Huevos turcos con pimientos y tomate', cuisine: 'mediterranea' },
  { title: 'Borek', desc: 'Pastel turco de phyllo con queso', cuisine: 'mediterranea' },
  { title: 'Halloumi a la Plancha', desc: 'Queso chipriota a la plancha', cuisine: 'mediterranea' },
  { title: 'Congee', desc: 'Gachas de arroz chinas', cuisine: 'asiatica' },
  { title: 'Dim Sum', desc: 'Variedad de bollitos chinos al vapor', cuisine: 'asiatica' },
  { title: 'Tamagoyaki', desc: 'Tortilla japonesa enrollada', cuisine: 'japonesa' },
  { title: 'Onigiri', desc: 'Bolas de arroz japonés rellenas', cuisine: 'japonesa' },
  { title: 'Miso Soup', desc: 'Sopa japonesa de miso con tofu', cuisine: 'japonesa' },
  { title: 'Nasi Goreng', desc: 'Arroz frito indonesio con huevo', cuisine: 'asiatica' },
  { title: 'Pho', desc: 'Sopa vietnamita de fideos', cuisine: 'asiatica' },
  { title: 'Idli', desc: 'Pasteles de arroz del sur de India', cuisine: 'india' },
  { title: 'Dosa', desc: 'Crepe india crujiente de arroz', cuisine: 'india' },
  { title: 'Smoothie Bowl', desc: 'Bowl de batido con frutas y granola', cuisine: 'americana' },
  { title: 'Açaí Bowl', desc: 'Bowl de açaí con frutas tropicales', cuisine: 'americana' },
  { title: 'Overnight Oats', desc: 'Avena preparada la noche anterior', cuisine: 'americana' },
  { title: 'Chia Pudding', desc: 'Pudin de chía con leche de almendras', cuisine: 'americana' },
  { title: 'Avocado Toast', desc: 'Tostada de aguacate con huevo', cuisine: 'americana' },
];

const almuerzoTemplates = [
  { title: 'Paella Valenciana', desc: 'La auténtica paella valenciana con pollo, conejo y judías verdes', cuisine: 'española' },
  { title: 'Cocido Madrileño', desc: 'Potaje tradicional con garbanzos y carnes', cuisine: 'española' },
  { title: 'Gazpacho Andaluz', desc: 'Sopa fría de tomate tradicional', cuisine: 'española' },
  { title: 'Fabada Asturiana', desc: 'Guiso de fabes con compango', cuisine: 'española' },
  { title: 'Pulpo a la Gallega', desc: 'Pulpo con pimentón y aceite de oliva', cuisine: 'española' },
  { title: 'Marmitako', desc: 'Guiso de bonito con patatas', cuisine: 'española' },
  { title: 'Callos a la Madrileña', desc: 'Guiso tradicional de callos', cuisine: 'española' },
  { title: 'Escalivada', desc: 'Verduras asadas catalanas', cuisine: 'española' },
  { title: 'Spaghetti Carbonara', desc: 'Pasta con huevo, queso pecorino y guanciale', cuisine: 'italiana' },
  { title: 'Risotto ai Funghi', desc: 'Risotto de setas porcini', cuisine: 'italiana' },
  { title: 'Lasagna Bolognese', desc: 'Lasaña con ragú y bechamel', cuisine: 'italiana' },
  { title: 'Ossobuco alla Milanese', desc: 'Jarrete de ternera con gremolata', cuisine: 'italiana' },
  { title: 'Pasta al Pomodoro', desc: 'Pasta con salsa de tomate fresco', cuisine: 'italiana' },
  { title: 'Gnocchi di Patate', desc: 'Ñoquis de patata caseros', cuisine: 'italiana' },
  { title: 'Pollo alla Cacciatora', desc: 'Pollo guisado estilo cazador', cuisine: 'italiana' },
  { title: 'Tacos al Pastor', desc: 'Tacos de cerdo con piña', cuisine: 'mexicana' },
  { title: 'Enchiladas Verdes', desc: 'Enchiladas con salsa de tomatillo', cuisine: 'mexicana' },
  { title: 'Pozole Rojo', desc: 'Sopa de maíz con cerdo', cuisine: 'mexicana' },
  { title: 'Mole Poblano', desc: 'Pollo con mole de chocolate', cuisine: 'mexicana' },
  { title: 'Cochinita Pibil', desc: 'Cerdo desmenuzado con achiote', cuisine: 'mexicana' },
  { title: 'Carnitas', desc: 'Cerdo confitado mexicano', cuisine: 'mexicana' },
  { title: 'Pad Thai', desc: 'Fideos de arroz tailandeses con gambas', cuisine: 'asiatica' },
  { title: 'Kung Pao Chicken', desc: 'Pollo con cacahuetes y chile', cuisine: 'asiatica' },
  { title: 'Sushi Rolls', desc: 'Rollitos de sushi variados', cuisine: 'japonesa' },
  { title: 'Ramen', desc: 'Sopa de fideos japonesa', cuisine: 'japonesa' },
  { title: 'Teriyaki Chicken', desc: 'Pollo con salsa teriyaki', cuisine: 'japonesa' },
  { title: 'Butter Chicken', desc: 'Pollo con salsa de mantequilla', cuisine: 'india' },
  { title: 'Chicken Tikka Masala', desc: 'Pollo tikka en salsa cremosa', cuisine: 'india' },
  { title: 'Biryani', desc: 'Arroz especiado con carne', cuisine: 'india' },
  { title: 'Moussaka', desc: 'Pastel griego de berenjena y carne', cuisine: 'griega' },
  { title: 'Souvlaki', desc: 'Brochetas griegas de cerdo', cuisine: 'griega' },
  { title: 'Gyro', desc: 'Sándwich griego de carne', cuisine: 'griega' },
  { title: 'Coq au Vin', desc: 'Gallo al vino tinto', cuisine: 'francesa' },
  { title: 'Boeuf Bourguignon', desc: 'Estofado de ternera borgoñón', cuisine: 'francesa' },
  { title: 'Ratatouille', desc: 'Verduras provenzal', cuisine: 'francesa' },
  { title: 'Bouillabaisse', desc: 'Sopa de pescado marsellesa', cuisine: 'francesa' },
  { title: 'Hamburger Classic', desc: 'Hamburguesa clásica con todos los ingredientes', cuisine: 'americana' },
  { title: 'BBQ Ribs', desc: 'Costillas barbacoa ahumadas', cuisine: 'americana' },
  { title: 'Mac and Cheese', desc: 'Macarrones con queso cremoso', cuisine: 'americana' },
  { title: 'Clam Chowder', desc: 'Sopa de almejas neoyorquina', cuisine: 'americana' },
];

const cenaTemplates = [
  { title: 'Pollo Asado', desc: 'Pollo asado al horno con hierbas', cuisine: 'española' },
  { title: 'Merluza a la Vasca', desc: 'Merluza en salsa verde', cuisine: 'española' },
  { title: 'Cordero Asado', desc: 'Cordero lechal asado tradicional', cuisine: 'española' },
  { title: 'Sepia a la Plancha', desc: 'Sepia con aceite de oliva y ajo', cuisine: 'española' },
  { title: 'Lomo de Orza', desc: 'Lomo adobado en manteca', cuisine: 'española' },
  { title: 'Rape a la Gallega', desc: 'Rape con patatas y pimentón', cuisine: 'española' },
  { title: 'Pollo al Ajillo', desc: 'Pollo frito con ajo', cuisine: 'española' },
  { title: 'Bacalao al Pil Pil', desc: 'Bacalao con salsa emulsionada', cuisine: 'española' },
  { title: 'Chipirones a la Andaluza', desc: 'Chipirones fritos con limón', cuisine: 'española' },
  { title: 'Estofado de Toro', desc: 'Guiso de toro de lidia', cuisine: 'española' },
  { title: 'Grilled Salmon', desc: 'Salmón a la plancha con hierbas', cuisine: 'americana' },
  { title: 'Steak Frites', desc: 'Filete con patatas fritas', cuisine: 'francesa' },
  { title: 'Duck Confit', desc: 'Muslo de pato confitado', cuisine: 'francesa' },
  { title: 'Beef Wellington', desc: 'Solomillo en hojaldre', cuisine: 'americana' },
  { title: 'Roast Chicken', desc: 'Pollo asado inglés', cuisine: 'americana' },
  { title: 'Fish and Chips', desc: 'Pescado rebozado con patatas', cuisine: 'americana' },
  { title: 'Pizza Margherita', desc: 'Pizza clásica de tomate y mozzarella', cuisine: 'italiana' },
  { title: 'Osso Buco', desc: 'Jarrete de ternera estofado', cuisine: 'italiana' },
  { title: 'Saltimbocca', desc: 'Ternera con jamón y salvia', cuisine: 'italiana' },
  { title: 'Branzino al Forno', desc: 'Lubrina al horno con hierbas', cuisine: 'italiana' },
  { title: 'Tacos de Pescado', desc: 'Tacos de pescado con repollo', cuisine: 'mexicana' },
  { title: 'Fajitas de Pollo', desc: 'Fajitas con pimientos y cebolla', cuisine: 'mexicana' },
  { title: 'Quesadillas', desc: 'Tortillas rellenas de queso', cuisine: 'mexicana' },
  { title: 'Burrito Bowl', desc: 'Bowl de arroz con ingredientes mexicanos', cuisine: 'mexicana' },
  { title: 'Tonkatsu', desc: 'Chuleta de cerdo empanizada', cuisine: 'japonesa' },
  { title: 'Tempura', desc: 'Verduras y marisco rebozados', cuisine: 'japonesa' },
  { title: 'Yakitori', desc: 'Brochetas de pollo japonesas', cuisine: 'japonesa' },
  { title: 'Katsu Curry', desc: 'Curry japonés con chuleta', cuisine: 'japonesa' },
  { title: 'Pad See Ew', desc: 'Fideos de arroz con soja', cuisine: 'asiatica' },
  { title: 'Green Curry', desc: 'Curry verde tailandés', cuisine: 'asiatica' },
  { title: 'Butter Naan', desc: 'Pan plano indio con mantequilla', cuisine: 'india' },
  { title: 'Tandoori Chicken', desc: 'Pollo al horno tandoor', cuisine: 'india' },
  { title: 'Lamb Korma', desc: 'Cordero en salsa cremosa', cuisine: 'india' },
  { title: 'Lamb Chops', desc: 'Chuletas de cordero a la parrilla', cuisine: 'griega' },
  { title: 'Grilled Octopus', desc: 'Pulpo a la parrilla con limón', cuisine: 'griega' },
  { title: 'Fasolada', desc: 'Sopa de judías griega', cuisine: 'griega' },
  { title: 'Pulled Pork', desc: 'Cerdo desmenuzado barbacoa', cuisine: 'americana' },
  { title: 'Meatloaf', desc: 'Pastel de carne tradicional', cuisine: 'americana' },
  { title: 'Jambalaya', desc: 'Arroz criollo con marisco', cuisine: 'americana' },
  { title: 'Shrimp Gumbo', desc: 'Guiso de gambas cajún', cuisine: 'americana' },
];

const postreTemplates = [
  { title: 'Flan de Huevo', desc: 'Flan tradicional cremoso con caramelo', cuisine: 'española' },
  { title: 'Tarta de Santiago', desc: 'Tarta de almendra gallega', cuisine: 'española' },
  { title: 'Crema Catalana', desc: 'Postre tradicional catalán con caramelo', cuisine: 'española' },
  { title: 'Arroz con Leche', desc: 'Postre de arroz con canela', cuisine: 'española' },
  { title: 'Tocino de Cielo', desc: 'Postre de yemas de huevo', cuisine: 'española' },
  { title: 'Natillas', desc: 'Crema de huevo con canela', cuisine: 'española' },
  { title: 'Pestiños', desc: 'Dulces fritos con miel', cuisine: 'española' },
  { title: 'Turron de Jijona', desc: 'Turrón blando de almendra', cuisine: 'española' },
  { title: 'Tiramisú', desc: 'Postre italiano de café y mascarpone', cuisine: 'italiana' },
  { title: 'Panna Cotta', desc: 'Postre italiano de nata', cuisine: 'italiana' },
  { title: 'Cannoli', desc: 'Tubos de masa rellenos de ricotta', cuisine: 'italiana' },
  { title: 'Gelato', desc: 'Helado italiano artesanal', cuisine: 'italiana' },
  { title: 'Biscotti', desc: 'Galletas italianas crujientes', cuisine: 'italiana' },
  { title: 'Zeppole', desc: 'Buñuelos italianos rellenos', cuisine: 'italiana' },
  { title: 'Crème Brûlée', desc: 'Crema quemada francesa', cuisine: 'francesa' },
  { title: 'Mille-Feuille', desc: 'Milhojas de crema y hojaldre', cuisine: 'francesa' },
  { title: 'Éclair', desc: 'Pastelillo de crema choux', cuisine: 'francesa' },
  { title: 'Macarons', desc: 'Pastelitos franceses de almendra', cuisine: 'francesa' },
  { title: 'Opera Cake', desc: 'Pastel francés de café y chocolate', cuisine: 'francesa' },
  { title: 'Chocolate Lava Cake', desc: 'Bizcocho de chocolate con corazón líquido', cuisine: 'americana' },
  { title: 'Cheesecake', desc: 'Tarta de queso cremosa', cuisine: 'americana' },
  { title: 'Brownies', desc: 'Pastelitos de chocolate densos', cuisine: 'americana' },
  { title: 'Apple Pie', desc: 'Tarta de manzana tradicional', cuisine: 'americana' },
  { title: 'Pecan Pie', desc: 'Tarta de nueces pecanas', cuisine: 'americana' },
  { title: 'Churros', desc: 'Masa frita con azúcar y canela', cuisine: 'mexicana' },
  { title: 'Tres Leches', desc: 'Pastel bañado en tres leches', cuisine: 'mexicana' },
  { title: 'Arroz con Leche Mexicano', desc: 'Arroz dulce con leche condensada', cuisine: 'mexicana' },
  { title: 'Cajeta', desc: 'Dulce de leche de cabra', cuisine: 'mexicana' },
  { title: 'Mochi', desc: 'Pastelitos de arroz glutinoso', cuisine: 'japonesa' },
  { title: 'Dorayaki', desc: 'Pastelitos rellenos de judía dulce', cuisine: 'japonesa' },
  { title: 'Matcha Ice Cream', desc: 'Helado de té verde', cuisine: 'japonesa' },
  { title: 'Mango Sticky Rice', desc: 'Arroz con mango y coco', cuisine: 'asiatica' },
  { title: 'Baklava', desc: 'Pastel de nueces y miel', cuisine: 'griega' },
  { title: 'Gulab Jamun', desc: 'Bolas de leche fritas en sirope', cuisine: 'india' },
  { title: 'Kheer', desc: 'Pudin de arroz indio', cuisine: 'india' },
  { title: 'Jalebi', desc: 'Dulce en espiral de sémola', cuisine: 'india' },
  { title: 'Bread Pudding', desc: 'Pudin de pan con pasas', cuisine: 'americana' },
  { title: 'Cobbler', desc: 'Pastel de frutas con masa', cuisine: 'americana' },
  { title: 'Key Lime Pie', desc: 'Tarta de lima key', cuisine: 'americana' },
  { title: 'Red Velvet Cake', desc: 'Pastel rojo con crema de queso', cuisine: 'americana' },
];

const snackTemplates = [
  { title: 'Patatas Bravas', desc: 'Patatas con salsa brava picante', cuisine: 'española' },
  { title: 'Croquetas de Jamón', desc: 'Croquetas cremosas de jamón', cuisine: 'española' },
  { title: 'Tortilla de Patatas', desc: 'Tortilla española de patatas', cuisine: 'española' },
  { title: 'Gildas', desc: 'Pincho de anchoa, aceituna y guindilla', cuisine: 'española' },
  { title: 'Pimientos de Padrón', desc: 'Pimientos fritos con sal', cuisine: 'española' },
  { title: 'Gambas al Ajillo', desc: 'Gambas fritas con ajo', cuisine: 'española' },
  { title: 'Boquerones en Vinagre', desc: 'Boquerones marinados', cuisine: 'española' },
  { title: 'Ensaladilla Rusa', desc: 'Ensalada de patata y mayonesa', cuisine: 'española' },
  { title: 'Bruschetta', desc: 'Pan tostado con tomate y albahaca', cuisine: 'italiana' },
  { title: 'Arancini', desc: 'Bolas de arroz rebozadas', cuisine: 'italiana' },
  { title: 'Focaccia', desc: 'Pan plano italiano con hierbas', cuisine: 'italiana' },
  { title: 'Antipasti', desc: 'Tabla de embutidos y quesos', cuisine: 'italiana' },
  { title: 'Nachos con Queso', desc: 'Nachos con salsa de queso', cuisine: 'mexicana' },
  { title: 'Guacamole', desc: 'Pasta de aguacate mexicana', cuisine: 'mexicana' },
  { title: 'Quesadillas', desc: 'Tortillas de queso dobladas', cuisine: 'mexicana' },
  { title: 'Elotes', desc: 'Maíz con mayonesa y queso', cuisine: 'mexicana' },
  { title: 'Ceviche', desc: 'Pescado marinado en limón', cuisine: 'mexicana' },
  { title: 'Edamame', desc: 'Habas de soja al vapor', cuisine: 'japonesa' },
  { title: 'Gyoza', desc: 'Empanadillas japonesas', cuisine: 'japonesa' },
  { title: 'Takoyaki', desc: 'Bolas de pulpo', cuisine: 'japonesa' },
  { title: 'Onigiri', desc: 'Triángulos de arroz rellenos', cuisine: 'japonesa' },
  { title: 'Spring Rolls', desc: 'Rollos primavera crujientes', cuisine: 'asiatica' },
  { title: 'Samosa', desc: 'Empanadillas de patata especiada', cuisine: 'india' },
  { title: 'Pakora', desc: 'Verduras rebozadas', cuisine: 'india' },
  { title: 'Naan', desc: 'Pan plano indio', cuisine: 'india' },
  { title: 'Hummus', desc: 'Crema de garbanzos', cuisine: 'mediterranea' },
  { title: 'Falafel', desc: 'Croquetas de garbanzos', cuisine: 'mediterranea' },
  { title: 'Tabbouleh', desc: 'Ensalada de perejil y bulgur', cuisine: 'mediterranea' },
  { title: 'Buffalo Wings', desc: 'Alitas de pollo picantes', cuisine: 'americana' },
  { title: 'Loaded Fries', desc: 'Patatas fritas cargadas', cuisine: 'americana' },
  { title: 'Onion Rings', desc: 'Aros de cebolla rebozados', cuisine: 'americana' },
  { title: 'Pigs in a Blanket', desc: 'Salchichas en hojaldre', cuisine: 'americana' },
  { title: 'Dolmades', desc: 'Hojas de parra rellenas', cuisine: 'griega' },
  { title: 'Spanakopita', desc: 'Pastel de espinacas y queso', cuisine: 'griega' },
  { title: 'Tzatziki', desc: 'Salsa de yogur y pepino', cuisine: 'griega' },
];

function generateTraditionalRecipes(): TraditionalRecipe[] {
  const recipes: TraditionalRecipe[] = [];
  let id = 1;

  // Generate desayuno recipes (200)
  for (let i = 0; i < 200; i++) {
    const template = desayunoTemplates[i % desayunoTemplates.length];
    const variation = Math.floor(i / desayunoTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `trad-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'tradicional'),
      prepTime: 5 + (i % 20),
      cookTime: 5 + (i % 15),
      totalTime: 10 + (i % 30),
      difficulty: difficulties[i % 3],
      toolType: 'tradicional',
      averageRating: Number((4.2 + (i % 8) / 10).toFixed(1)),
      ratingCount: 50 + (i * 3) % 400,
      mealType: 'desayuno',
      cuisine: template.cuisine,
    });
    id++;
  }

  // Generate almuerzo recipes (250)
  for (let i = 0; i < 250; i++) {
    const template = almuerzoTemplates[i % almuerzoTemplates.length];
    const variation = Math.floor(i / almuerzoTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `trad-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'almuerzo', 'tradicional'),
      prepTime: 15 + (i % 25),
      cookTime: 20 + (i % 40),
      totalTime: 35 + (i % 50),
      difficulty: difficulties[(i + 1) % 3],
      toolType: 'tradicional',
      averageRating: Number((4.3 + (i % 7) / 10).toFixed(1)),
      ratingCount: 80 + (i * 4) % 500,
      mealType: 'almuerzo',
      cuisine: template.cuisine,
    });
    id++;
  }

  // Generate cena recipes (250)
  for (let i = 0; i < 250; i++) {
    const template = cenaTemplates[i % cenaTemplates.length];
    const variation = Math.floor(i / cenaTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `trad-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'cena', 'tradicional'),
      prepTime: 10 + (i % 20),
      cookTime: 15 + (i % 35),
      totalTime: 25 + (i % 45),
      difficulty: difficulties[(i + 2) % 3],
      toolType: 'tradicional',
      averageRating: Number((4.4 + (i % 6) / 10).toFixed(1)),
      ratingCount: 70 + (i * 5) % 450,
      mealType: 'cena',
      cuisine: template.cuisine,
    });
    id++;
  }

  // Generate postre recipes (200)
  for (let i = 0; i < 200; i++) {
    const template = postreTemplates[i % postreTemplates.length];
    const variation = Math.floor(i / postreTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `trad-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'postre', 'tradicional'),
      prepTime: 15 + (i % 25),
      cookTime: 20 + (i % 30),
      totalTime: 35 + (i % 40),
      difficulty: difficulties[i % 3],
      toolType: 'tradicional',
      averageRating: Number((4.5 + (i % 5) / 10).toFixed(1)),
      ratingCount: 60 + (i * 4) % 350,
      mealType: 'postre',
      cuisine: template.cuisine,
    });
    id++;
  }

  // Generate snack recipes (100)
  for (let i = 0; i < 100; i++) {
    const template = snackTemplates[i % snackTemplates.length];
    const variation = Math.floor(i / snackTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `trad-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'snack', 'tradicional'),
      prepTime: 5 + (i % 15),
      cookTime: 10 + (i % 20),
      totalTime: 15 + (i % 25),
      difficulty: difficulties[i % 3],
      toolType: 'tradicional',
      averageRating: Number((4.2 + (i % 8) / 10).toFixed(1)),
      ratingCount: 40 + (i * 3) % 300,
      mealType: 'snack',
      cuisine: template.cuisine,
    });
    id++;
  }

  return recipes;
}

export const traditionalRecipes: TraditionalRecipe[] = generateTraditionalRecipes();
export const recipeCounts = {
  total: traditionalRecipes.length,
  desayuno: traditionalRecipes.filter(r => r.mealType === 'desayuno').length,
  almuerzo: traditionalRecipes.filter(r => r.mealType === 'almuerzo').length,
  cena: traditionalRecipes.filter(r => r.mealType === 'cena').length,
  postre: traditionalRecipes.filter(r => r.mealType === 'postre').length,
  snack: traditionalRecipes.filter(r => r.mealType === 'snack').length,
};
