// ============================================================
// CROCKPOT / SLOW COOKER RECIPES DATA FILE
// 1000 Recetas para Olla de Cocción Lenta
// ============================================================

import { getRecipeImage } from '@/lib/recipe-images';

export interface Recipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: 'facil' | 'medio' | 'dificil';
  toolType: 'crockpot';
  
  averageRating: number;
  ratingCount: number;
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack';
  cuisine?: string;
  slowCookerHours: number;
  slowCookerSetting: 'low' | 'high';
}

// ============================================================
// HELPER FUNCTIONS
// ============================================================

const generateId = (index: number): string => `crockpot-${String(index).padStart(4, '0')}`;

const randomRating = (base: number, variation: number): number => {
  const rating = base + (Math.random() * variation);
  return Math.round(rating * 10) / 10;
};

const randomCount = (min: number, max: number): number => 
  Math.floor(Math.random() * (max - min + 1)) + min;

const difficulties: ('facil' | 'medio' | 'dificil')[] = ['facil', 'medio', 'dificil'];
const settings: ('low' | 'high')[] = ['low', 'high'];

// ============================================================
// DESAYUNO RECIPES (80 recipes)
// Breakfast: Oatmeals, Egg Casseroles, Breads, Yogurts
// ============================================================

const desayunoRecipes: Recipe[] = [
  {
    id: generateId(1),
    title: 'Avena de Noche con Manzana y Canela',
    description: 'Avena cocida lentamente durante la noche con trozos de manzana fresca, canela y un toque de miel natural.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 480,
    totalTime: 490,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.7,
    ratingCount: 234,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 8,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(2),
    title: 'Casserole de Huevos con Tocino',
    description: 'Deliciosa tortilla al horno lento con tocino crujiente, queso cheddar y pimientos verdes.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15,
    cookTime: 240,
    totalTime: 255,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.5,
    ratingCount: 189,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 4,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(3),
    title: 'Pan de Plátano con Nueces',
    description: 'Esponjoso pan de plátano preparado en olla lenta con nueces tostadas y aroma de vainilla.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20,
    cookTime: 180,
    totalTime: 200,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.8,
    ratingCount: 312,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 3,
    slowCookerSetting: 'high',
  },
  {
    id: generateId(4),
    title: 'Yogur Natural Casero',
    description: 'Yogur cremoso fermentado en casa con leche entera y cultivos naturales, perfectamente suave.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 480,
    totalTime: 490,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.6,
    ratingCount: 156,
    mealType: 'desayuno',
    cuisine: 'Mediterránea',
    slowCookerHours: 8,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(5),
    title: 'Compota de Manzana con Canela',
    description: 'Apple butter casero con manzanas caramelizadas, canela y azúcar moreno, ideal para untar.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15,
    cookTime: 600,
    totalTime: 615,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.9,
    ratingCount: 278,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 10,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(6),
    title: 'Avena con Arándanos y Miel',
    description: 'Avena cremosa cocida con arándanos frescos, miel de abeja y un toque de vainilla.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 420,
    totalTime: 430,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.5,
    ratingCount: 145,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 7,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(7),
    title: 'Casserole de Espinaca y Queso Feta',
    description: 'Gratinado de huevos con espinacas frescas, queso feta griego y hierbas mediterráneas.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15,
    cookTime: 300,
    totalTime: 315,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.4,
    ratingCount: 98,
    mealType: 'desayuno',
    cuisine: 'Mediterránea',
    slowCookerHours: 5,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(8),
    title: 'Pan de Calabaza con Especias',
    description: 'Pan húmedo de calabaza con mezcla de especias de otoño, nueces y glaseado de queso crema.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 25,
    cookTime: 240,
    totalTime: 265,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.7,
    ratingCount: 203,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 4,
    slowCookerSetting: 'high',
  },
  {
    id: generateId(9),
    title: 'Granola Casera con Miel',
    description: 'Granola crujiente con avena, nueces, almendras y miel, perfecta para el desayuno.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 180,
    totalTime: 190,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.6,
    ratingCount: 167,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 3,
    slowCookerSetting: 'high',
  },
  {
    id: generateId(10),
    title: 'Huevos Benedict en Olla Lenta',
    description: 'Clásico desayuno con huevos pochados, jamón serrano y salsa holandesa cremosa.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20,
    cookTime: 150,
    totalTime: 170,
    difficulty: 'dificil',
    toolType: 'crockpot',
    averageRating: 4.3,
    ratingCount: 89,
    mealType: 'desayuno',
    cuisine: 'Francesa',
    slowCookerHours: 2.5,
    slowCookerSetting: 'high',
  },
  {
    id: generateId(11),
    title: 'Avena con Leche de Almendras',
    description: 'Avena vegana cocida con leche de almendras, canela, vainilla y frutos rojos.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 360,
    totalTime: 370,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.5,
    ratingCount: 134,
    mealType: 'desayuno',
    cuisine: 'Vegana',
    slowCookerHours: 6,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(12),
    title: 'Tortilla de Patatas en Slow Cooker',
    description: 'Tortilla española tradicional cocida lentamente con patatas, cebolla y huevos.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20,
    cookTime: 240,
    totalTime: 260,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.8,
    ratingCount: 245,
    mealType: 'desayuno',
    cuisine: 'Española',
    slowCookerHours: 4,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(13),
    title: 'Pan de Zanahoria con Nueces',
    description: 'Pan dulce de zanahoria rallada con nueces, canela y glaseado de naranja.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 25,
    cookTime: 210,
    totalTime: 235,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.6,
    ratingCount: 178,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 3.5,
    slowCookerSetting: 'high',
  },
  {
    id: generateId(14),
    title: 'Muesli de Noche con Yogur',
    description: 'Muesli cremoso preparado la noche anterior con yogur, frutas y semillas de chía.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 480,
    totalTime: 490,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.4,
    ratingCount: 112,
    mealType: 'desayuno',
    cuisine: 'Europea',
    slowCookerHours: 8,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(15),
    title: 'Casserole de Jamón y Queso',
    description: 'Gratinado de huevos con jamón york, queso gruyere y pan rallado crujiente.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15,
    cookTime: 270,
    totalTime: 285,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.5,
    ratingCount: 156,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 4.5,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(16),
    title: 'Avena con Mermelada de Fresa',
    description: 'Avena dulce cocida con mermelada de fresa casera y trozos de fruta fresca.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 390,
    totalTime: 400,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.6,
    ratingCount: 189,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 6.5,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(17),
    title: 'Hot Cakes de Avena en Olla',
    description: 'Panqueques esponjosos de avena cocidos en olla lenta con jarabe de arce.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15,
    cookTime: 120,
    totalTime: 135,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.3,
    ratingCount: 98,
    mealType: 'desayuno',
    cuisine: 'Americana',
    slowCookerHours: 2,
    slowCookerSetting: 'high',
  },
  {
    id: generateId(18),
    title: 'Strata de Espinaca y Hongos',
    description: 'Pastel de pan y huevos con espinacas, hongos portobello y queso mozzarella.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20,
    cookTime: 300,
    totalTime: 320,
    difficulty: 'medio',
    toolType: 'crockpot',
    averageRating: 4.5,
    ratingCount: 134,
    mealType: 'desayuno',
    cuisine: 'Italiana',
    slowCookerHours: 5,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(19),
    title: 'Compota de Pera con Cardamomo',
    description: 'Peras caramelizadas con cardamomo, jengibre y miel, perfectas para acompañar.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15,
    cookTime: 360,
    totalTime: 375,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.7,
    ratingCount: 89,
    mealType: 'desayuno',
    cuisine: 'Asiática',
    slowCookerHours: 6,
    slowCookerSetting: 'low',
  },
  {
    id: generateId(20),
    title: 'Avena con Mango y Coco',
    description: 'Avena tropical cocida con mango fresco, leche de coco y ralladura de lima.',
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10,
    cookTime: 420,
    totalTime: 430,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: 4.6,
    ratingCount: 145,
    mealType: 'desayuno',
    cuisine: 'Tropical',
    slowCookerHours: 7,
    slowCookerSetting: 'low',
  },
];

// Continue desayuno recipes (21-80)
for (let i = 21; i <= 80; i++) {
  const templates = [
    { title: 'Avena con Durazno y Almendras', desc: 'Avena cremosa con duraznos frescos y almendras tostadas.', hours: 7, setting: 'low' as const, cuisine: 'Americana' },
    { title: 'Casserole de Salchicha y Pimiento', desc: 'Gratinado de huevos con salchicha italiana y pimientos rojos.', hours: 4, setting: 'low' as const, cuisine: 'Italiana' },
    { title: 'Pan de Arándanos y Limón', desc: 'Pan dulce con arándanos frescos y glaseado de limón.', hours: 3, setting: 'high' as const, cuisine: 'Americana' },
    { title: 'Avena con Nueces y Miel', desc: 'Avena tradicional con nueces pecanas y miel de abeja.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
    { title: 'Tamales de Desayuno', desc: 'Tamales rellenos de huevo, chorizo y queso.', hours: 6, setting: 'low' as const, cuisine: 'Mexicana' },
    { title: 'Budín de Pan con Pasas', desc: 'Budín de pan con pasas, canela y salsa de vainilla.', hours: 4, setting: 'low' as const, cuisine: 'Inglesa' },
    { title: 'Avena con Mantequilla de Maní', desc: 'Avena proteica con mantequilla de maní y plátano.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
    { title: 'Frittata de Verduras', desc: 'Tortilla italiana con calabacín, tomate y queso parmesano.', hours: 3, setting: 'low' as const, cuisine: 'Italiana' },
    { title: 'Pan de Dátiles y Nueces', desc: 'Pan dulce con dátiles medjool y nueces picadas.', hours: 3.5, setting: 'high' as const, cuisine: 'Mediterránea' },
    { title: 'Avena con Canela y Azúcar Moreno', desc: 'Avena clásica con canela de Ceilán y azúcar moreno.', hours: 7, setting: 'low' as const, cuisine: 'Americana' },
  ];
  
  const template = templates[(i - 21) % templates.length];
  
  desayunoRecipes.push({
    id: generateId(i),
    title: template.title,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 10 + (i % 15),
    cookTime: template.hours * 60,
    totalTime: 10 + (i % 15) + template.hours * 60,
    difficulty: difficulties[i % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.2, 0.7),
    ratingCount: randomCount(80, 350),
    mealType: 'desayuno',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// ============================================================
// ALMUERZO RECIPES (300 recipes)
// Lunch: Soups, Stews, Chilis, Lighter Fare
// ============================================================

const almuerzoRecipes: Recipe[] = [];

// Sopas (Soups) - 100 recipes
const soupTemplates = [
  { title: 'Sopa de Lentejas Española', desc: 'Lentejas estofadas con chorizo, zanahoria y cebolla sofrita.', hours: 8, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Sopa de Tomate Asado', desc: 'Crema de tomates asados con albahaca fresca y queso cremoso.', hours: 6, setting: 'low' as const, cuisine: 'Italiana' },
  { title: 'Sopa Minestrone', desc: 'Minestrone italiano con judías, pasta y verduras de temporada.', hours: 8, setting: 'low' as const, cuisine: 'Italiana' },
  { title: 'Sopa de Cebolla Gratinada', desc: 'Sopa francesa con cebolla caramelizada y queso gruyere gratinado.', hours: 8, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Sopa de Pollo con Fideos', desc: 'Caldo reconfortante de pollo con fideos y verduras.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Crema de Calabaza', desc: 'Crema suave de calabaza con jengibre, nata y semillas de calabaza.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Gazpacho Andaluz', desc: 'Sopa fría de tomate, pepino y pimiento con aceite de oliva.', hours: 4, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Sopa de Frijoles Negros', desc: 'Sopa cubana de frijoles negros con comino y pimiento.', hours: 8, setting: 'low' as const, cuisine: 'Cubana' },
  { title: 'Sopa de Papa y Puerro', desc: 'Vichyssoise cremosa con patatas y puerros.', hours: 6, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Sopa de Mariscos', desc: 'Sopa de pescado con mejillones, gambas y almejas.', hours: 4, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Sopa de Misu', desc: 'Sopa japonesa con pasta de miso, tofu y algas wakame.', hours: 4, setting: 'low' as const, cuisine: 'Japonesa' },
  { title: 'Sopa de Tortilla Mexicana', desc: 'Sopa de tortilla con pollo, aguacate y queso fresco.', hours: 6, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Sopa de Remolacha', desc: 'Borscht ruso con remolacha, nata y eneldo fresco.', hours: 8, setting: 'low' as const, cuisine: 'Rusa' },
  { title: 'Sopa de Guisantes', desc: 'Crema de guisantes con menta y jamón serrano.', hours: 5, setting: 'low' as const, cuisine: 'Inglesa' },
  { title: 'Sopa de Espárragos', desc: 'Crema de espárragos verdes con queso parmesano.', hours: 5, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Sopa de Coliflor', desc: 'Crema de coliflor con curry y leche de coco.', hours: 5, setting: 'low' as const, cuisine: 'Asiática' },
  { title: 'Sopa de Zanahoria y Jengibre', desc: 'Crema de zanahoria con jengibre fresco y nata.', hours: 5, setting: 'low' as const, cuisine: 'Asiática' },
  { title: 'Sopa de Hongos', desc: 'Crema de hongos silvestres con trufa y nata.', hours: 6, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Sopa de Maíz', desc: 'Crema de maíz dulce con pimiento rojo y cilantro.', hours: 5, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Sopa de Ajo', desc: 'Sopa castellana con ajo, pan y huevo pochado.', hours: 4, setting: 'low' as const, cuisine: 'Española' },
];

for (let i = 0; i < 100; i++) {
  const template = soupTemplates[i % soupTemplates.length];
  const variation = Math.floor(i / soupTemplates.length) + 1;
  const titleSuffix = i >= soupTemplates.length ? ` (Variación ${variation})` : '';
  
  almuerzoRecipes.push({
    id: generateId(81 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15 + (i % 20),
    cookTime: template.hours * 60,
    totalTime: 15 + (i % 20) + template.hours * 60,
    difficulty: difficulties[(i + 1) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.2, 0.6),
    ratingCount: randomCount(100, 450),
    mealType: 'almuerzo',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Chilis - 80 recipes
const chiliTemplates = [
  { title: 'Chili con Carne Tradicional', desc: 'Chili texano con carne de res, frijoles y chile ancho.', hours: 8, setting: 'low' as const, cuisine: 'Tex-Mex' },
  { title: 'Chili Verde con Cerdo', desc: 'Chili verde con carne de cerdo y chiles verdes.', hours: 8, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Chili de Pavo', desc: 'Chili ligero con pavo molido y frijoles blancos.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Chili Vegetariano', desc: 'Chili con frijoles negros, maíz y pimientos variados.', hours: 6, setting: 'low' as const, cuisine: 'Vegetariana' },
  { title: 'Chili Cincinnati', desc: 'Chili con canela y chocolate sobre espagueti.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Chili Blanco de Pollo', desc: 'Chili cremoso con pollo, frijoles blancos y maíz.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Chili con Chorizo', desc: 'Chili picante con chorizo español y frijoles pintos.', hours: 7, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Chili de Bisonte', desc: 'Chili con carne de bisonte y chipotle ahumado.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
];

for (let i = 0; i < 80; i++) {
  const template = chiliTemplates[i % chiliTemplates.length];
  const variation = Math.floor(i / chiliTemplates.length) + 1;
  const titleSuffix = i >= chiliTemplates.length ? ` (Variación ${variation})` : '';
  
  almuerzoRecipes.push({
    id: generateId(181 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20 + (i % 15),
    cookTime: template.hours * 60,
    totalTime: 20 + (i % 15) + template.hours * 60,
    difficulty: difficulties[(i + 2) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.3, 0.6),
    ratingCount: randomCount(150, 500),
    mealType: 'almuerzo',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Estofados (Stews) - 120 recipes
const stewTemplates = [
  { title: 'Estofado Irlandés de Cordero', desc: 'Irish stew con cordero, patatas y cebolla.', hours: 10, setting: 'low' as const, cuisine: 'Irlandesa' },
  { title: 'Estofado de Ternera con Vino', desc: 'Estofado bourguignon con vino tinto y champiñones.', hours: 10, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Estofado de Pollo y Verduras', desc: 'Estofado casero con pollo, zanahoria y patata.', hours: 8, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Goulash Húngaro', desc: 'Goulash con ternera, paprika y pimientos.', hours: 10, setting: 'low' as const, cuisine: 'Húngara' },
  { title: 'Estofado de Mariscos', desc: 'Cioppino italiano con pescado, gambas y mejillones.', hours: 4, setting: 'low' as const, cuisine: 'Italiana' },
  { title: 'Tagine de Cordero', desc: 'Tagine marroquí con cordero, ciruelas y almendras.', hours: 8, setting: 'low' as const, cuisine: 'Marroquí' },
  { title: 'Estofado de Costillas', desc: 'Estofado de costillas de cerdo con salsa BBQ.', hours: 10, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Feijoada Brasileña', desc: 'Feijoada con cerdo, salchicha y frijoles negros.', hours: 12, setting: 'low' as const, cuisine: 'Brasileña' },
  { title: 'Estofado de Lentejas', desc: 'Lentejas estofadas con verduras y jamón.', hours: 8, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Cocido Madrileño', desc: 'Cocido tradicional con garbanzos, carne y verduras.', hours: 10, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Puchero Criollo', desc: 'Puchero argentino con carne, chorizo y verduras.', hours: 10, setting: 'low' as const, cuisine: 'Argentina' },
  { title: 'Estofado de Conejo', desc: 'Estofado de conejo con aceitunas y hierbas.', hours: 6, setting: 'low' as const, cuisine: 'Francesa' },
];

for (let i = 0; i < 120; i++) {
  const template = stewTemplates[i % stewTemplates.length];
  const variation = Math.floor(i / stewTemplates.length) + 1;
  const titleSuffix = i >= stewTemplates.length ? ` (Variación ${variation})` : '';
  
  almuerzoRecipes.push({
    id: generateId(261 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20 + (i % 25),
    cookTime: template.hours * 60,
    totalTime: 20 + (i % 25) + template.hours * 60,
    difficulty: difficulties[(i + 1) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.4, 0.5),
    ratingCount: randomCount(120, 550),
    mealType: 'almuerzo',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// ============================================================
// CENA RECIPES (480 recipes)
// Dinner: Roasts, Pulled Meats, Curries, Main Dishes
// ============================================================

const cenaRecipes: Recipe[] = [];

// Carnes Desmenuzadas (Pulled Meats) - 100 recipes
const pulledTemplates = [
  { title: 'Pulled Pork Carolina', desc: 'Cerdo desmenuzado estilo Carolina con salsa de vinagre.', hours: 12, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Pulled Pork BBQ', desc: 'Cerdo desmenuzado con salsa BBQ ahumada casera.', hours: 12, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Carnitas Mexicanas', desc: 'Cerdo desmenuzado con naranja, comino y cilantro.', hours: 10, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Pulled Chicken BBQ', desc: 'Pollo desmenuzado con salsa BBQ dulce y picante.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Ropa Vieja Cubana', desc: 'Ternera desmenuzada con pimientos, cebolla y tomate.', hours: 10, setting: 'low' as const, cuisine: 'Cubana' },
  { title: 'Pulled Beef Brisket', desc: 'Pecho de res desmenuzado con especias ahumadas.', hours: 12, setting: 'low' as const, cuisine: 'Tex-Mex' },
  { title: 'Pernil Puertorriqueño', desc: 'Jamón asado con mojo de ajo y orégano.', hours: 12, setting: 'low' as const, cuisine: 'Puertorriqueña' },
  { title: 'Pulled Lamb', desc: 'Cordero desmenuzado con hierbas mediterráneas.', hours: 10, setting: 'low' as const, cuisine: 'Mediterránea' },
  { title: 'Pulled Turkey', desc: 'Pavo desmenuzado con gravy de hierbas.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Machaca de Res', desc: 'Carne deshebrada mexicana con chile y tomate.', hours: 8, setting: 'low' as const, cuisine: 'Mexicana' },
];

for (let i = 0; i < 100; i++) {
  const template = pulledTemplates[i % pulledTemplates.length];
  const variation = Math.floor(i / pulledTemplates.length) + 1;
  const titleSuffix = i >= pulledTemplates.length ? ` (Variación ${variation})` : '';
  
  cenaRecipes.push({
    id: generateId(381 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20 + (i % 20),
    cookTime: template.hours * 60,
    totalTime: 20 + (i % 20) + template.hours * 60,
    difficulty: difficulties[(i + 2) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.5, 0.4),
    ratingCount: randomCount(200, 600),
    mealType: 'cena',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Asados (Roasts) - 100 recipes
const roastTemplates = [
  { title: 'Pot Roast Clásico', desc: 'Asado de ternera con patatas, zanahoria y gravy.', hours: 10, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Pollo Entero Asado', desc: 'Pollo jugoso con romero, limón y ajo.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Lomo de Cerdo Asado', desc: 'Lomo de cerdo con manzana y salvia.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Costillas BBQ', desc: 'Costillas de cerdo glaseadas con salsa BBQ.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Pierna de Cordero', desc: 'Pierna de cordero con ajo, romero y menta.', hours: 10, setting: 'low' as const, cuisine: 'Mediterránea' },
  { title: 'Beef Brisket', desc: 'Pecho de res ahumado con especias rub.', hours: 12, setting: 'low' as const, cuisine: 'Tex-Mex' },
  { title: 'Osobuco a la Milanesa', desc: 'Jarrete de ternera con gremolata tradicional.', hours: 8, setting: 'low' as const, cuisine: 'Italiana' },
  { title: 'Lamb Shanks', desc: 'Codillos de cordero con vino tinto y romero.', hours: 10, setting: 'low' as const, cuisine: 'Mediterránea' },
  { title: 'Pechuga de Pavo', desc: 'Pechuga de pavo con hierbas y limón.', hours: 6, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Lomo de Ternera', desc: 'Lomo de ternera con champiñones y vino.', hours: 6, setting: 'low' as const, cuisine: 'Francesa' },
];

for (let i = 0; i < 100; i++) {
  const template = roastTemplates[i % roastTemplates.length];
  const variation = Math.floor(i / roastTemplates.length) + 1;
  const titleSuffix = i >= roastTemplates.length ? ` (Variación ${variation})` : '';
  
  cenaRecipes.push({
    id: generateId(481 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 25 + (i % 20),
    cookTime: template.hours * 60,
    totalTime: 25 + (i % 20) + template.hours * 60,
    difficulty: difficulties[(i + 1) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.4, 0.5),
    ratingCount: randomCount(180, 550),
    mealType: 'cena',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Curries - 100 recipes
const curryTemplates = [
  { title: 'Curry de Ternera Indio', desc: 'Curry cremoso de ternera con garam masala y leche de coco.', hours: 8, setting: 'low' as const, cuisine: 'India' },
  { title: 'Pollo Tikka Masala', desc: 'Pollo en salsa de tomate con nata y especias.', hours: 6, setting: 'low' as const, cuisine: 'India' },
  { title: 'Curry de Cordero', desc: 'Curry de cordero con yogur y hierbas frescas.', hours: 8, setting: 'low' as const, cuisine: 'India' },
  { title: 'Curry Rojo Tailandés', desc: 'Curry rojo con pollo, bambú y albahaca tailandesa.', hours: 6, setting: 'low' as const, cuisine: 'Tailandesa' },
  { title: 'Curry Verde Tailandés', desc: 'Curry verde con pescado, berenjena y leche de coco.', hours: 4, setting: 'low' as const, cuisine: 'Tailandesa' },
  { title: 'Korma de Pollo', desc: 'Korma suave con almendras y pasas.', hours: 6, setting: 'low' as const, cuisine: 'India' },
  { title: 'Vindaloo de Cerdo', desc: 'Curry picante de cerdo con vinagre y ajo.', hours: 8, setting: 'low' as const, cuisine: 'India' },
  { title: 'Curry de Lentejas', desc: 'Dal indio con lentejas y especias tostadas.', hours: 6, setting: 'low' as const, cuisine: 'India' },
  { title: 'Curry de Camarones', desc: 'Curry de gambas con leche de coco y lima.', hours: 4, setting: 'low' as const, cuisine: 'Tailandesa' },
  { title: 'Butter Chicken', desc: 'Pollo con mantequilla y salsa de tomate cremosa.', hours: 6, setting: 'low' as const, cuisine: 'India' },
];

for (let i = 0; i < 100; i++) {
  const template = curryTemplates[i % curryTemplates.length];
  const variation = Math.floor(i / curryTemplates.length) + 1;
  const titleSuffix = i >= curryTemplates.length ? ` (Variación ${variation})` : '';
  
  cenaRecipes.push({
    id: generateId(581 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20 + (i % 15),
    cookTime: template.hours * 60,
    totalTime: 20 + (i % 15) + template.hours * 60,
    difficulty: difficulties[(i + 2) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.5, 0.5),
    ratingCount: randomCount(150, 500),
    mealType: 'cena',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Platos de Pollo - 80 recipes
const chickenTemplates = [
  { title: 'Pollo al Limón', desc: 'Pollo con salsa de limón, ajo y hierbas provenzales.', hours: 6, setting: 'low' as const, cuisine: 'Mediterránea' },
  { title: 'Pollo a la Mostaza', desc: 'Pollo en salsa de mostaza con miel y estragón.', hours: 6, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Pollo con Champiñones', desc: 'Pollo con salsa cremosa de champiñones.', hours: 6, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Pollo al Chipotle', desc: 'Pollo en salsa de chipotle con crema.', hours: 6, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Coq au Vin', desc: 'Pollo al vino tinto con champiñones y tocino.', hours: 8, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Pollo a la Cerveza', desc: 'Pollo braseado en cerveza con hierbas.', hours: 6, setting: 'low' as const, cuisine: 'Belga' },
  { title: 'Pollo con Aceitunas', desc: 'Pollo marroquí con aceitunas y limón preservado.', hours: 6, setting: 'low' as const, cuisine: 'Marroquí' },
  { title: 'Pollo a la Parmesana', desc: 'Pollo con salsa de tomate y queso parmesano.', hours: 4, setting: 'low' as const, cuisine: 'Italiana' },
];

for (let i = 0; i < 80; i++) {
  const template = chickenTemplates[i % chickenTemplates.length];
  const variation = Math.floor(i / chickenTemplates.length) + 1;
  const titleSuffix = i >= chickenTemplates.length ? ` (Variación ${variation})` : '';
  
  cenaRecipes.push({
    id: generateId(681 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15 + (i % 15),
    cookTime: template.hours * 60,
    totalTime: 15 + (i % 15) + template.hours * 60,
    difficulty: difficulties[i % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.3, 0.6),
    ratingCount: randomCount(130, 480),
    mealType: 'cena',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Platos de Ternera - 60 recipes
const beefTemplates = [
  { title: 'Estofado de Ternera', desc: 'Estofado clásico con zanahoria, patata y vino tinto.', hours: 10, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Ternera Stroganoff', desc: 'Ternera con setas y nata ácida.', hours: 6, setting: 'low' as const, cuisine: 'Rusa' },
  { title: 'Carne Guisada', desc: 'Carne guisada con patatas y guisantes.', hours: 8, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Ternera con Pimientos', desc: 'Ternera con pimientos rojos y cebolla.', hours: 8, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Bistec en Salsa', desc: 'Bistec en salsa de cebolla y vino.', hours: 6, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Carne con Chile', desc: 'Carne con chile colorado y frijoles.', hours: 8, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Ternera Bourguignon', desc: 'Ternera al vino de Borgoña con champiñones.', hours: 10, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Carne con Papa', desc: 'Carne con patatas en salsa de tomate.', hours: 8, setting: 'low' as const, cuisine: 'Mexicana' },
];

for (let i = 0; i < 60; i++) {
  const template = beefTemplates[i % beefTemplates.length];
  const variation = Math.floor(i / beefTemplates.length) + 1;
  const titleSuffix = i >= beefTemplates.length ? ` (Variación ${variation})` : '';
  
  cenaRecipes.push({
    id: generateId(761 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 20 + (i % 20),
    cookTime: template.hours * 60,
    totalTime: 20 + (i % 20) + template.hours * 60,
    difficulty: difficulties[(i + 1) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.4, 0.5),
    ratingCount: randomCount(140, 520),
    mealType: 'cena',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// Platos de Cerdo - 40 recipes
const porkTemplates = [
  { title: 'Cerdo con Manzana', desc: 'Lomo de cerdo con manzanas y cebolla caramelizada.', hours: 8, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Cerdo a la Cerveza', desc: 'Cerdo braseado en cerveza con mostaza.', hours: 8, setting: 'low' as const, cuisine: 'Alemana' },
  { title: 'Chuletas de Cerdo', desc: 'Chuletas en salsa de cebolla y hierbas.', hours: 6, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Cerdo con Naranja', desc: 'Cerdo con jugo de naranja y comino.', hours: 8, setting: 'low' as const, cuisine: 'Cubana' },
  { title: 'Cerdo Agrio-Dulce', desc: 'Cerdo con piña, pimiento y salsa agridulce.', hours: 6, setting: 'low' as const, cuisine: 'China' },
  { title: 'Cerdo con Col', desc: 'Cerdo estofado con col y patatas.', hours: 8, setting: 'low' as const, cuisine: 'Irlandesa' },
  { title: 'Secreto Ibérico', desc: 'Secreto de cerdo ibérico con pimentón.', hours: 6, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Cerdo con Ciruelas', desc: 'Cerdo con ciruelas pasas y vino blanco.', hours: 8, setting: 'low' as const, cuisine: 'Francesa' },
];

for (let i = 0; i < 40; i++) {
  const template = porkTemplates[i % porkTemplates.length];
  const variation = Math.floor(i / porkTemplates.length) + 1;
  const titleSuffix = i >= porkTemplates.length ? ` (Variación ${variation})` : '';
  
  cenaRecipes.push({
    id: generateId(821 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 18 + (i % 15),
    cookTime: template.hours * 60,
    totalTime: 18 + (i % 15) + template.hours * 60,
    difficulty: difficulties[(i + 2) % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.3, 0.6),
    ratingCount: randomCount(120, 450),
    mealType: 'cena',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// ============================================================
// POSTRE RECIPES (100 recipes)
// Desserts: Cakes, Puddings, Cobblers, etc.
// ============================================================

const postreRecipes: Recipe[] = [];

const dessertTemplates = [
  { title: 'Brownies de Chocolate', desc: 'Brownies densos de chocolate con nueces.', hours: 3, setting: 'high' as const, cuisine: 'Americana' },
  { title: 'Cobbler de Melocotón', desc: 'Pastel de melocotón con cobertura crujiente.', hours: 3, setting: 'high' as const, cuisine: 'Americana' },
  { title: 'Apple Crisp', desc: 'Crujiente de manzana con avena y canela.', hours: 4, setting: 'high' as const, cuisine: 'Americana' },
  { title: 'Pudin de Pan', desc: 'Bread pudding con pasas y salsa de caramelo.', hours: 4, setting: 'low' as const, cuisine: 'Inglesa' },
  { title: 'Lava Cake', desc: 'Pastel de chocolate con centro líquido.', hours: 2, setting: 'high' as const, cuisine: 'Francesa' },
  { title: 'Cheesecake de Nueva York', desc: 'Tarta de queso cremosa con base de galleta.', hours: 4, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Tiramisú', desc: 'Postre italiano con mascarpone y café.', hours: 3, setting: 'low' as const, cuisine: 'Italiana' },
  { title: 'Crumble de Fresas', desc: 'Crujiente de fresas con cobertura de avena.', hours: 3, setting: 'high' as const, cuisine: 'Inglesa' },
  { title: 'Flan de Huevo', desc: 'Flan tradicional con caramelo casero.', hours: 4, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Arroz con Leche', desc: 'Arroz dulce con canela y leche condensada.', hours: 4, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Mousse de Chocolate', desc: 'Mousse aireado de chocolate oscuro.', hours: 3, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Poached Pears', desc: 'Peras pochadas en vino tinto con especias.', hours: 4, setting: 'low' as const, cuisine: 'Francesa' },
  { title: 'Bread Pudding de Chocolate', desc: 'Budín de pan con chips de chocolate.', hours: 4, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Cobbler de Cereza', desc: 'Pastel de cerezas con cobertura dorada.', hours: 3, setting: 'high' as const, cuisine: 'Americana' },
  { title: 'Budín de Navidad', desc: 'Christmas pudding con frutas secas.', hours: 8, setting: 'low' as const, cuisine: 'Inglesa' },
  { title: 'Crema Catalana', desc: 'Crema quemada con caramelo crujiente.', hours: 3, setting: 'low' as const, cuisine: 'Española' },
  { title: 'Pastel de Zanahoria', desc: 'Cake de zanahoria con glaseado de queso.', hours: 4, setting: 'high' as const, cuisine: 'Americana' },
  { title: 'Soufflé de Chocolate', desc: 'Soufflé esponjoso de chocolate belga.', hours: 2, setting: 'high' as const, cuisine: 'Francesa' },
  { title: 'Trifle de Frutas', desc: 'Trifle en capas con bizcocho y nata.', hours: 4, setting: 'low' as const, cuisine: 'Inglesa' },
  { title: 'Pastel de Limón', desc: 'Cake de limón con glaseado de crema.', hours: 3, setting: 'high' as const, cuisine: 'Americana' },
];

for (let i = 0; i < 100; i++) {
  const template = dessertTemplates[i % dessertTemplates.length];
  const variation = Math.floor(i / dessertTemplates.length) + 1;
  const titleSuffix = i >= dessertTemplates.length ? ` (Variación ${variation})` : '';
  
  postreRecipes.push({
    id: generateId(861 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 15 + (i % 15),
    cookTime: template.hours * 60,
    totalTime: 15 + (i % 15) + template.hours * 60,
    difficulty: difficulties[i % 3],
    toolType: 'crockpot',
    averageRating: randomRating(4.5, 0.4),
    ratingCount: randomCount(90, 400),
    mealType: 'postre',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// ============================================================
// SNACK RECIPES (40 recipes)
// Snacks: Nuts, Dips, Party Foods
// ============================================================

const snackRecipes: Recipe[] = [];

const snackTemplates = [
  { title: 'Nueces de Mapache', desc: 'Nueces glaseadas con azúcar moreno y canela.', hours: 3, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Snack Mix Festivo', desc: 'Mezcla de pretzels, cereales y frutos secos.', hours: 2, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Dip de Queso Cheddar', desc: 'Queso fundido con cerveza y mostaza.', hours: 2, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Chex Party Mix', desc: 'Mezcla crujiente con salsa Worcestershire.', hours: 3, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Almendras Glaseadas', desc: 'Almendras dulces con canela y vainilla.', hours: 3, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Cacahuetes Picantes', desc: 'Cacahuetes con chile y limón.', hours: 2, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Dip de Espinaca', desc: 'Dip cremoso de espinaca y alcachofa.', hours: 2, setting: 'low' as const, cuisine: 'Americana' },
  { title: 'Pistachos Tostados', desc: 'Pistachos con sal marina y romero.', hours: 2, setting: 'low' as const, cuisine: 'Mediterránea' },
  { title: 'Queso Fundido con Chorizo', desc: 'Queso derretido con chorizo y pimientos.', hours: 2, setting: 'low' as const, cuisine: 'Mexicana' },
  { title: 'Mix de Semillas', desc: 'Semillas de calabaza y girasol tostadas.', hours: 2, setting: 'low' as const, cuisine: 'Americana' },
];

for (let i = 0; i < 40; i++) {
  const template = snackTemplates[i % snackTemplates.length];
  const variation = Math.floor(i / snackTemplates.length) + 1;
  const titleSuffix = i >= snackTemplates.length ? ` (Variación ${variation})` : '';
  
  snackRecipes.push({
    id: generateId(961 + i),
    title: template.title + titleSuffix,
    description: template.desc,
    imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'crockpot'),
    prepTime: 5 + (i % 10),
    cookTime: template.hours * 60,
    totalTime: 5 + (i % 10) + template.hours * 60,
    difficulty: 'facil',
    toolType: 'crockpot',
    averageRating: randomRating(4.2, 0.7),
    ratingCount: randomCount(50, 250),
    mealType: 'snack',
    cuisine: template.cuisine,
    slowCookerHours: template.hours,
    slowCookerSetting: template.setting,
  });
}

// ============================================================
// EXPORT ALL RECIPES
// ============================================================

export const crockpotRecipes: Recipe[] = [
  ...desayunoRecipes,
  ...almuerzoRecipes,
  ...cenaRecipes,
  ...postreRecipes,
  ...snackRecipes,
];

// Export counts for verification
export const recipeCounts = {
  total: crockpotRecipes.length,
  desayuno: desayunoRecipes.length,
  almuerzo: almuerzoRecipes.length,
  cena: cenaRecipes.length,
  postre: postreRecipes.length,
  snack: snackRecipes.length,
};
