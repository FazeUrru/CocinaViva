// 1000 Recetas Thermomix - Cocina Inteligente
import { getRecipeImage } from '@/lib/recipe-images';

export interface ThermomixRecipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: 'facil' | 'medio' | 'dificil';
  toolType: 'thermomix';
  
  averageRating: number;
  ratingCount: number;
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack';
  thermomixSpeed: string;
  thermomixTemp: string;
}

const difficulties: ('facil' | 'medio' | 'dificil')[] = ['facil', 'medio', 'dificil'];

const desayunoTemplates = [
  { title: 'Smoothie de Frutas', desc: 'Batido energético de frutas frescas', speed: '8-10', temp: '-' },
  { title: 'Pan de Molde', desc: 'Pan tierno para tostadas', speed: 'Espiga', temp: '37°C' },
  { title: 'Mermelada de Fresa', desc: 'Mermelada casera rápida', speed: '4-5', temp: '100°C' },
  { title: 'Granola Casera', desc: 'Granola crujiente de avena', speed: '2-3', temp: '-' },
  { title: 'Crema de Avena', desc: 'Porridge cremoso de avena', speed: '3-4', temp: '90°C' },
  { title: 'Bizcocho de Yogur', desc: 'Bizcocho esponjoso rápido', speed: '4-6', temp: '-' },
  { title: 'Leche de Almendras', desc: 'Leche vegetal casera', speed: '8-10', temp: '-' },
  { title: 'Tortitas Americanas', desc: 'Pancakes esponjosos', speed: '4-6', temp: '-' },
  { title: 'Batido Verde', desc: 'Smoothie detox verde', speed: '9-10', temp: '-' },
  { title: 'Bollos de Canela', desc: 'Rollos de canela glaseados', speed: 'Espiga', temp: '37°C' },
  { title: 'Zumo de Naranja', desc: 'Zumo natural exprimido', speed: '10', temp: '-' },
  { title: 'Batido de Plátano', desc: 'Batido cremoso de plátano', speed: '8-9', temp: '-' },
  { title: 'Muffins de Arándanos', desc: 'Muffins húmedos de frutas', speed: '4-5', temp: '-' },
  { title: 'Crema de Cacao', desc: 'Nocilla casera saludable', speed: '8', temp: '60°C' },
  { title: 'Tostadas Francesas', desc: 'French toast thermomix', speed: '4', temp: '-' },
  { title: 'Brownie de Desayuno', desc: 'Brownie saludable', speed: '5-6', temp: '-' },
  { title: 'Bowl de Açaí', desc: 'Açaí bowl con toppings', speed: '9-10', temp: '-' },
  { title: 'Wrap de Huevo', desc: 'Tortilla wrap de desayuno', speed: '4', temp: 'Varoma' },
  { title: 'Churros Thermomix', desc: 'Churros rápidos y crujientes', speed: '4', temp: '100°C' },
  { title: 'Magdalenas', desc: 'Magdalenas caseras esponjosas', speed: '5-6', temp: '-' },
];

const almuerzoTemplates = [
  { title: 'Sopa de Verduras', desc: 'Crema de verduras variadas', speed: '5-8', temp: '100°C' },
  { title: 'Puré de Patata', desc: 'Puré cremoso perfecto', speed: '4', temp: '100°C' },
  { title: 'Arroz con Pollo', desc: 'Arroz meloso con pollo', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Salsa de Tomate', desc: 'Salsa italiana casera', speed: '1-4', temp: '100°C' },
  { title: 'Ensalada de Quinoa', desc: 'Quinoa con verduras', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Gazpacho', desc: 'Gazpacho andaluz tradicional', speed: '5-10', temp: '-' },
  { title: 'Crema de Calabaza', desc: 'Vichyssoise de calabaza', speed: '4-8', temp: '100°C' },
  { title: 'Fideuá', desc: 'Fideos con marisco', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Lasaña de Verduras', desc: 'Lasaña vegetariana', speed: '4', temp: '100°C' },
  { title: 'Cous Cous', desc: 'Cous cous con verduras', speed: 'Giro Inverso', temp: '-' },
  { title: 'Paella Rápida', desc: 'Paella valenciana express', speed: 'Giro Inverso', temp: 'Varoma' },
  { title: 'Pasta al Pesto', desc: 'Pasta con pesto casero', speed: 'Giro Inverso', temp: '-' },
  { title: 'Ensalada César', desc: 'Con salsa césar casera', speed: '5', temp: '-' },
  { title: 'Crema de Espárragos', desc: 'Crema suave de espárragos', speed: '6-8', temp: '100°C' },
  { title: 'Sopa de Lentejas', desc: 'Lentejas estofadas', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Arroz a la Cubana', desc: 'Arroz con huevo y plátano', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Potaje de Garbanzos', desc: 'Potaje tradicional', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Sopa de Miso', desc: 'Sopa japonesa tradicional', speed: '3', temp: '80°C' },
  { title: 'Bowl de Poke', desc: 'Poke bowl hawaiano', speed: '4-5', temp: '-' },
  { title: 'Wrap de Pollo', desc: 'Wrap integral con pollo', speed: '4', temp: 'Varoma' },
];

const cenaTemplates = [
  { title: 'Pollo al Jengibre', desc: 'Pollo con salsa asiática', speed: 'Giro Inverso', temp: 'Varoma' },
  { title: 'Salmón al Vapor', desc: 'Salmón jugoso al varoma', speed: '1-2', temp: 'Varoma' },
  { title: 'Estofado de Ternera', desc: 'Guiso tierno de ternera', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Pasta Carbonara', desc: 'Carbonara italiana auténtica', speed: 'Giro Inverso', temp: '-' },
  { title: 'Curry de Pollo', desc: 'Curry cremoso de pollo', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Merluza en Salsa Verde', desc: 'Merluza tradicional vasca', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Lomo de Cerdo', desc: 'Lomo asado jugoso', speed: '1-2', temp: 'Varoma' },
  { title: 'Risotto de Setas', desc: 'Risotto cremoso de hongos', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Pollo al Limón', desc: 'Pollo con salsa cítrica', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Albóndigas en Salsa', desc: 'Albóndigas caseras', speed: '4-8', temp: '100°C' },
  { title: 'Bacalao al Pil Pil', desc: 'Bacalao emulsionado', speed: '3-4', temp: '80°C' },
  { title: 'Pulpo a la Gallega', desc: 'Pulpo tierno con pimentón', speed: 'Giro Inverso', temp: 'Varoma' },
  { title: 'Chipirones Rellenos', desc: 'Chipirones con relleno', speed: '4', temp: '100°C' },
  { title: 'Cordero Guisado', desc: 'Cordero en salsa', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Lasaña de Carne', desc: 'Lasaña bolognesa', speed: '4', temp: '100°C' },
  { title: 'Rape a la Americana', desc: 'Rape con gambas', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Pollo al Curry', desc: 'Curry indio de pollo', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Ternera con Pimientos', desc: 'Ternera guisada', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Pescado en Papillote', desc: 'Pescado al vapor', speed: '1', temp: 'Varoma' },
  { title: 'Jamón al Horno', desc: 'Jamón glaseado', speed: '2', temp: 'Varoma' },
];

const postreTemplates = [
  { title: 'Tarta de Queso', desc: 'Cheesecake cremosa', speed: '4-6', temp: '-' },
  { title: 'Mousse de Chocolate', desc: 'Mousse aireado de chocolate', speed: '3-4', temp: '-' },
  { title: 'Flan de Huevo', desc: 'Flan tradicional cremoso', speed: '4', temp: '100°C' },
  { title: 'Bizcocho de Chocolate', desc: 'Brownie esponjoso', speed: '4-6', temp: '-' },
  { title: 'Helado de Vainilla', desc: 'Helado cremoso casero', speed: '4', temp: '90°C' },
  { title: 'Tarta de Manzana', desc: 'Apple pie tradicional', speed: '4-6', temp: '-' },
  { title: 'Panna Cotta', desc: 'Postre italiano de nata', speed: '3-4', temp: '90°C' },
  { title: 'Trufas de Chocolate', desc: 'Bombones de chocolate', speed: '5-8', temp: '-' },
  { title: 'Crema Catalana', desc: 'Postre tradicional catalán', speed: '4', temp: '90°C' },
  { title: 'Sorbete de Limón', desc: 'Sorbete refrescante', speed: '8-10', temp: '-' },
  { title: 'Tiramisú Rápido', desc: 'Tiramisú express', speed: '4', temp: '-' },
  { title: 'Brownie Húmedo', desc: 'Brownie denso de chocolate', speed: '5-6', temp: '-' },
  { title: 'Arroz con Leche', desc: 'Postre cremoso de arroz', speed: 'Giro Inverso', temp: '100°C' },
  { title: 'Natillas', desc: 'Crema de huevo con canela', speed: '3-4', temp: '90°C' },
  { title: 'Galletas de Mantequilla', desc: 'Cookies caseras', speed: '5', temp: '-' },
  { title: 'Pastel de Zanahoria', desc: 'Carrot cake con frosting', speed: '5-6', temp: '-' },
  { title: 'Cheesecake de Fresa', desc: 'Tarta de queso con fresas', speed: '4', temp: '-' },
  { title: 'Mousse de Limón', desc: 'Mousse cítrico refrescante', speed: '4', temp: '-' },
  { title: 'Profiteroles', desc: 'Pasta choux con crema', speed: '5', temp: '-' },
  { title: 'Tarta de Limón', desc: 'Lemon pie merengada', speed: '4-5', temp: '-' },
];

const snackTemplates = [
  { title: 'Hummus Casero', desc: 'Crema de garbanzos', speed: '5-8', temp: '-' },
  { title: 'Guacamole', desc: 'Dip mexicano de aguacate', speed: '4-5', temp: '-' },
  { title: 'Patatas Chips', desc: 'Chips crujientes caseras', speed: '5-7', temp: '-' },
  { title: 'Dip de Queso', desc: 'Salsa de queso cremosa', speed: '3-4', temp: '-' },
  { title: 'Palomitas', desc: 'Popcorn de maíz', speed: '1', temp: 'Varoma' },
  { title: 'Salsa de Yogur', desc: 'Dip de yogur con hierbas', speed: '3-4', temp: '-' },
  { title: 'Bolas de Queso', desc: 'Cheese balls crujientes', speed: '5', temp: '-' },
  { title: 'Crackers de Semillas', desc: 'Galletas de semillas', speed: '5', temp: '-' },
  { title: 'Pinchos Morunos', desc: 'Brochetas especiadas', speed: '4', temp: 'Varoma' },
  { title: 'Empanadillas', desc: 'Empanadillas de atún', speed: '4-5', temp: '-' },
];

function generateThermomixRecipes(): ThermomixRecipe[] {
  const recipes: ThermomixRecipe[] = [];
  let id = 1;

  // Generate desayuno recipes (200)
  for (let i = 0; i < 200; i++) {
    const template = desayunoTemplates[i % desayunoTemplates.length];
    const variation = Math.floor(i / desayunoTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `thermo-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'desayuno', 'thermomix'),
      prepTime: 5 + (i % 15),
      cookTime: 10 + (i % 20),
      totalTime: 15 + (i % 30),
      difficulty: difficulties[i % 3],
      toolType: 'thermomix',
      averageRating: Number((4.3 + (i % 7) / 10).toFixed(1)),
      ratingCount: 70 + (i * 3) % 350,
      mealType: 'desayuno',
      thermomixSpeed: template.speed,
      thermomixTemp: template.temp,
    });
    id++;
  }

  // Generate almuerzo recipes (250)
  for (let i = 0; i < 250; i++) {
    const template = almuerzoTemplates[i % almuerzoTemplates.length];
    const variation = Math.floor(i / almuerzoTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `thermo-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'almuerzo', 'thermomix'),
      prepTime: 10 + (i % 20),
      cookTime: 20 + (i % 25),
      totalTime: 30 + (i % 40),
      difficulty: difficulties[(i + 1) % 3],
      toolType: 'thermomix',
      averageRating: Number((4.4 + (i % 6) / 10).toFixed(1)),
      ratingCount: 100 + (i * 4) % 450,
      mealType: 'almuerzo',
      thermomixSpeed: template.speed,
      thermomixTemp: template.temp,
    });
    id++;
  }

  // Generate cena recipes (300)
  for (let i = 0; i < 300; i++) {
    const template = cenaTemplates[i % cenaTemplates.length];
    const variation = Math.floor(i / cenaTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `thermo-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'cena', 'thermomix'),
      prepTime: 15 + (i % 25),
      cookTime: 25 + (i % 30),
      totalTime: 40 + (i % 50),
      difficulty: difficulties[(i + 2) % 3],
      toolType: 'thermomix',
      averageRating: Number((4.5 + (i % 5) / 10).toFixed(1)),
      ratingCount: 120 + (i * 5) % 550,
      mealType: 'cena',
      thermomixSpeed: template.speed,
      thermomixTemp: template.temp,
    });
    id++;
  }

  // Generate postre recipes (200)
  for (let i = 0; i < 200; i++) {
    const template = postreTemplates[i % postreTemplates.length];
    const variation = Math.floor(i / postreTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `thermo-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'postre', 'thermomix'),
      prepTime: 10 + (i % 20),
      cookTime: 20 + (i % 25),
      totalTime: 30 + (i % 40),
      difficulty: difficulties[i % 3],
      toolType: 'thermomix',
      averageRating: Number((4.6 + (i % 4) / 10).toFixed(1)),
      ratingCount: 90 + (i * 4) % 400,
      mealType: 'postre',
      thermomixSpeed: template.speed,
      thermomixTemp: template.temp,
    });
    id++;
  }

  // Generate snack recipes (50)
  for (let i = 0; i < 50; i++) {
    const template = snackTemplates[i % snackTemplates.length];
    const variation = Math.floor(i / snackTemplates.length);
    const title = variation > 0 ? `${template.title} ${variation + 1}` : template.title;
    
    recipes.push({
      id: `thermo-${String(id).padStart(4, '0')}`,
      title,
      description: template.desc,
      imageUrl: getRecipeImage(title, template.desc, 'snack', 'thermomix'),
      prepTime: 5 + (i % 10),
      cookTime: 10 + (i % 15),
      totalTime: 15 + (i % 20),
      difficulty: difficulties[i % 3],
      toolType: 'thermomix',
      averageRating: Number((4.3 + (i % 7) / 10).toFixed(1)),
      ratingCount: 50 + (i * 3) % 250,
      mealType: 'snack',
      thermomixSpeed: template.speed,
      thermomixTemp: template.temp,
    });
    id++;
  }

  return recipes;
}

export const thermomixRecipes: ThermomixRecipe[] = generateThermomixRecipes();
export const recipeCounts = {
  total: thermomixRecipes.length,
  desayuno: thermomixRecipes.filter(r => r.mealType === 'desayuno').length,
  almuerzo: thermomixRecipes.filter(r => r.mealType === 'almuerzo').length,
  cena: thermomixRecipes.filter(r => r.mealType === 'cena').length,
  postre: thermomixRecipes.filter(r => r.mealType === 'postre').length,
  snack: thermomixRecipes.filter(r => r.mealType === 'snack').length,
};
