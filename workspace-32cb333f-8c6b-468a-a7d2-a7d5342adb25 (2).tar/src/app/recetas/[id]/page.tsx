'use client'

import { useState, use, useMemo } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Clock,
  Users,
  Star,
  Heart,
  Share2,
  Bookmark,
  Printer,
  Timer,
  Play,
  MessageCircle,
  ChefHat,
  Check,
  ShoppingCart,
  Volume2,
  VolumeX,
  Sparkles,
  ShieldCheck,
  Lock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useShoppingListStore } from '@/store'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'
import { allRecipes, type Recipe } from '@/data/recipes'
import { PremiumGuard, PremiumHide } from '@/components/premium-guard'
import { Captcha } from '@/components/captcha'

// Helper function to generate recipe details from a recipe
function generateRecipeDetails(recipe: Recipe) {
  // Generate deterministic view count based on recipe ID (no random for SSR)
  const viewCount = parseInt(recipe.id.replace(/\D/g, '')) * 100 + 500
  
  return {
    ...recipe,
    servings: 4,
    viewCount,
    ingredients: [
      { id: '1', name: 'Ingrediente principal', quantity: 500, unit: 'g', notes: '' },
      { id: '2', name: 'Cebolla', quantity: 1, unit: 'unidad', notes: 'picada' },
      { id: '3', name: 'Ajo', quantity: 2, unit: 'dientes', notes: 'picados' },
      { id: '4', name: 'Aceite de oliva', quantity: 3, unit: 'cucharadas', notes: 'virgen extra' },
      { id: '5', name: 'Sal', quantity: 1, unit: 'cucharadita', notes: 'al gusto' },
      { id: '6', name: 'Pimienta', quantity: 0.5, unit: 'cucharadita', notes: 'recién molida' },
      { id: '7', name: 'Hierbas frescas', quantity: 1, unit: 'manojo', notes: '' },
    ],
    steps: [
      {
        id: '1',
        stepNumber: 1,
        instruction: `Prepara todos los ingredientes para ${recipe.title}. Lava y pica los vegetales necesarios.`,
        duration: 10,
        tip: 'Ten todo preparado antes de empezar a cocinar.'
      },
      {
        id: '2',
        stepNumber: 2,
        instruction: 'Calienta el aceite en una sartén grande a fuego medio. Añade la cebolla y el ajo, sofríe hasta que estén dorados.',
        duration: 5,
        tip: 'No dejes que el ajo se queme, puede amargar el plato.'
      },
      {
        id: '3',
        stepNumber: 3,
        instruction: 'Añade el ingrediente principal y cocina según las indicaciones de la receta.',
        duration: recipe.cookTime / 2,
        tip: 'Cocina a fuego medio para que se haga uniformemente.'
      },
      {
        id: '4',
        stepNumber: 4,
        instruction: 'Sazona con sal, pimienta y las hierbas frescas. Mezcla bien para integrar todos los sabores.',
        duration: 5,
        tip: 'Prueba y ajusta la sazón según tu gusto.'
      },
      {
        id: '5',
        stepNumber: 5,
        instruction: 'Termina la cocción y deja reposar unos minutos antes de servir.',
        duration: 5,
        tip: 'El reposo permite que los sabores se asienten.'
      },
    ],
    tags: [
      { id: '1', name: recipe.toolType === 'tradicional' ? 'Tradicional' : recipe.toolType === 'thermomix' ? 'Thermomix' : 'Crockpot', slug: recipe.toolType, color: 'bg-orange-500' },
      { id: '3', name: recipe.mealType.charAt(0).toUpperCase() + recipe.mealType.slice(1), slug: recipe.mealType, color: 'bg-blue-500' },
    ],
    comments: [] as Array<{
      id: string;
      userId: string;
      content: string;
      createdAt: Date;
      user: { id: string; name: string; avatar: string | null };
      rating: number;
    }>,
    substitutions: [
      { ingredient: 'Aceite de oliva', substitute: 'Aceite de girasol', ratio: 1, notes: 'Sabor más neutro' },
      { ingredient: 'Sal', substitute: 'Sal marina', ratio: 0.8, notes: 'Más saludable' },
    ],
  }
}

const portionOptions = [2, 3, 4, 5, 6]

// Not found component
function RecipeNotFound() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      <main className="flex-1 flex items-center justify-center">
        <Card className="max-w-md w-full mx-4">
          <CardHeader className="text-center">
            <CardTitle>Receta no encontrada</CardTitle>
            <CardDescription>
              Lo sentimos, no pudimos encontrar la receta que buscas.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/recetas">
              <Button className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver a recetas
              </Button>
            </Link>
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  )
}

export default function RecipeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  
  // All hooks at the top
  const [servings, setServings] = useState(4)
  const [isFavorite, setIsFavorite] = useState(false)
  const [userRating, setUserRating] = useState(0)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [comment, setComment] = useState('')
  const [isSaved, setIsSaved] = useState(false)
  const [captchaVerified, setCaptchaVerified] = useState(false)
  const { addItem } = useShoppingListStore()
  
  // Memoize the recipe lookup
  const foundRecipe = useMemo(() => allRecipes.find(r => r.id === id), [id])
  const recipe = useMemo(() => foundRecipe ? generateRecipeDetails(foundRecipe) : null, [foundRecipe])
  
  // If recipe not found, show error
  if (!foundRecipe || !recipe) {
    return <RecipeNotFound />
  }

  // Calculate ingredient quantities based on servings
  const ingredientMultiplier = servings / recipe.servings

  // Add to favorites
  const toggleFavorite = async () => {
    setIsFavorite(!isFavorite)
    toast.success(isFavorite ? 'Eliminado de favoritos' : 'Añadido a favoritos')
  }

  // Add ingredients to shopping list
  const addToShoppingList = () => {
    recipe.ingredients.forEach(ing => {
      addItem({
        shoppingListId: 'default',
        ingredientId: ing.id,
        customName: ing.name,
        quantity: ing.quantity * ingredientMultiplier,
        unit: ing.unit,
        isChecked: false,
        notes: ing.notes,
      })
    })
    toast.success('Ingredientes añadidos a la lista de compras')
  }

  // Toggle offline save
  const toggleOfflineSave = () => {
    if (isSaved) {
      setIsSaved(false)
      toast.success('Receta eliminada del modo offline')
    } else {
      setIsSaved(true)
      toast.success('Receta guardada para uso offline')
    }
  }

  // Share recipe with WhatsApp/Telegram support
  const shareRecipe = async (platform?: 'whatsapp' | 'telegram') => {
    const shareUrl = window.location.href
    const shareTitle = recipe.title
    const shareText = recipe.description
    
    // If specific platform requested
    if (platform === 'whatsapp') {
      const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${shareTitle}\n${shareText}\n${shareUrl}`)}`
      window.open(whatsappUrl, '_blank')
      return
    }
    
    if (platform === 'telegram') {
      const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(`${shareTitle}\n${shareText}`)}`
      window.open(telegramUrl, '_blank')
      return
    }
    
    // Try native share API
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        })
      } catch (error) {
        // User cancelled or error - fallback to clipboard
        if ((error as Error).name !== 'AbortError') {
          navigator.clipboard.writeText(shareUrl)
          toast.success('Enlace copiado al portapapeles')
        }
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(shareUrl)
      toast.success('Enlace copiado al portapapeles')
    }
  }

  // Text-to-speech for hands-free mode
  const speakStep = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'es-ES'
      utterance.rate = 0.9
      utterance.onend = () => setIsSpeaking(false)
      window.speechSynthesis.speak(utterance)
      setIsSpeaking(true)
    }
  }

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  // Format time
  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins > 0 ? `${mins}min` : ''}`
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Hero Image */}
        <div className="relative h-[40vh] md:h-[50vh] overflow-hidden">
          <img
            src={recipe.imageUrl}
            alt={recipe.title}
            className="w-full h-full object-cover"
            onError={(e) => {
              const target = e.target as HTMLImageElement
              target.src = '/images/recipes/placeholder.png'
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          
          {/* Back Button */}
          <div className="absolute top-4 left-4">
            <Link href="/recetas">
              <Button variant="secondary" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
            </Link>
          </div>

          {/* Quick Actions */}
          <div className="absolute top-4 right-4 flex gap-2">
            <Button variant="secondary" size="icon" onClick={toggleFavorite}>
              <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
            </Button>
            <Button variant="secondary" size="icon" onClick={shareRecipe}>
              <Share2 className="h-5 w-5" />
            </Button>
            <Button variant="secondary" size="icon" onClick={toggleOfflineSave}>
              <Bookmark className={cn("h-5 w-5", isSaved && "fill-orange-500 text-orange-500")} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 -mt-20 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Title and Info */}
              <Card>
                <CardHeader>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {recipe.tags.map(tag => (
                      <Badge key={tag.id} className={cn("text-white", tag.color)}>
                        {tag.name}
                      </Badge>
                    ))}
                  </div>
                  <CardTitle className="text-3xl">{recipe.title}</CardTitle>
                  <CardDescription className="text-base">
                    {recipe.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-orange-500" />
                      <div>
                        <div className="font-medium">{formatTime(recipe.totalTime)}</div>
                        <div className="text-muted-foreground text-xs">Tiempo total</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-green-500" />
                      <div>
                        <div className="font-medium">{servings} personas</div>
                        <div className="text-muted-foreground text-xs">Porciones</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                      <div>
                        <div className="font-medium">{recipe.averageRating.toFixed(1)}</div>
                        <div className="text-muted-foreground text-xs">{recipe.ratingCount} valoraciones</div>
                      </div>
                    </div>
                    <Badge variant="outline" className={cn(
                      "text-sm",
                      recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                      recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                      recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                    )}>
                      {recipe.difficulty === 'facil' ? 'Fácil' : 
                       recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Portion Calculator */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Calculadora de Porciones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground">Ajustar para:</span>
                    <Select value={servings.toString()} onValueChange={(v) => setServings(parseInt(v))}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {portionOptions.map(opt => (
                          <SelectItem key={opt} value={opt.toString()}>
                            {opt} {opt === 1 ? 'persona' : 'personas'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {servings !== recipe.servings && (
                      <Badge variant="secondary">
                        Cantidades ajustadas
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Ingredients */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ShoppingCart className="h-5 w-5" />
                      Ingredientes
                    </CardTitle>
                    <Button variant="outline" size="sm" onClick={addToShoppingList}>
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Añadir a compras
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {recipe.ingredients.map((ing) => (
                      <li key={ing.id} className="flex items-start gap-3">
                        <div className="w-5 h-5 rounded-full border-2 border-orange-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="h-3 w-3 text-orange-500 opacity-0 hover:opacity-100" />
                        </div>
                        <div>
                          <span className="font-medium">
                            {(ing.quantity * ingredientMultiplier).toFixed(ing.quantity * ingredientMultiplier % 1 === 0 ? 0 : 1)} {ing.unit}
                          </span>
                          <span> {ing.name}</span>
                          {ing.notes && (
                            <span className="text-muted-foreground text-sm"> ({ing.notes})</span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Steps */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ChefHat className="h-5 w-5" />
                      Preparación
                    </CardTitle>
                    <Link href={`/recetas/${recipe.id}/pasos`}>
                      <Button className="bg-gradient-to-r from-orange-500 to-green-500">
                        <Play className="h-4 w-4 mr-2" />
                        Modo Paso a Paso
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <ol className="space-y-6">
                    {recipe.steps.map((step, index) => (
                      <motion.li
                        key={step.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex gap-4"
                      >
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-green-500 flex items-center justify-center text-white font-bold flex-shrink-0">
                          {step.stepNumber}
                        </div>
                        <div className="flex-1">
                          <p className="text-foreground leading-relaxed">{step.instruction}</p>
                          <div className="flex items-center gap-4 mt-2">
                            {step.duration && (
                              <Badge variant="outline" className="text-xs">
                                <Clock className="h-3 w-3 mr-1" />
                                {step.duration} min
                              </Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => isSpeaking ? stopSpeaking() : speakStep(step.instruction)}
                            >
                              {isSpeaking ? (
                                <VolumeX className="h-4 w-4 mr-1" />
                              ) : (
                                <Volume2 className="h-4 w-4 mr-1" />
                              )}
                              {isSpeaking ? 'Detener' : 'Escuchar'}
                            </Button>
                          </div>
                          {step.tip && (
                            <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                                <strong>💡 Consejo:</strong> {step.tip}
                              </p>
                            </div>
                          )}
                        </div>
                      </motion.li>
                    ))}
                  </ol>
                </CardContent>
              </Card>

              {/* Ingredient Substitutions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Sparkles className="h-5 w-5" />
                    Sustituciones Sugeridas
                  </CardTitle>
                  <CardDescription>
                    Alternativas para adaptar la receta a tus preferencias
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recipe.substitutions.map((sub, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <div className="font-medium">{sub.ingredient}</div>
                          <div className="text-sm text-muted-foreground">
                            → {sub.substitute} (ratio: {sub.ratio})
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground text-right max-w-[200px]">
                          {sub.notes}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Rating */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Valora esta receta</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        onClick={() => setUserRating(star)}
                        className="p-1"
                      >
                        <Star
                          className={cn(
                            "h-8 w-8 transition-colors",
                            star <= userRating
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-muted-foreground"
                          )}
                        />
                      </button>
                    ))}
                    {userRating > 0 && (
                      <span className="ml-4 text-sm text-muted-foreground">
                        {userRating} de 5 estrellas
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Comments */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Comentarios
                  </CardTitle>
                  <CardDescription>
                    Los comentarios son de usuarios reales verificados
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add Comment with CAPTCHA */}
                  <div className="space-y-4">
                    <Textarea
                      placeholder="Comparte tu experiencia con esta receta..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      rows={3}
                    />
                    
                    {/* CAPTCHA verification for comments */}
                    {!captchaVerified && (
                      <Captcha 
                        onVerify={setCaptchaVerified} 
                        isVerified={captchaVerified} 
                      />
                    )}
                    
                    <Button 
                      disabled={!comment.trim() || !captchaVerified}
                      onClick={() => {
                        if (comment.trim() && captchaVerified) {
                          toast.success('Comentario publicado correctamente')
                          setComment('')
                          setCaptchaVerified(false)
                        }
                      }}
                    >
                      {captchaVerified ? (
                        <>
                          <ShieldCheck className="h-4 w-4 mr-2" />
                          Publicar comentario
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Verifica el CAPTCHA primero
                        </>
                      )}
                    </Button>
                  </div>

                  {recipe.comments.length > 0 && (
                    <>
                      <Separator />
                      <div className="space-y-4">
                        {recipe.comments.map(comment => (
                          <div key={comment.id} className="flex gap-3">
                            <Avatar>
                              <AvatarFallback>
                                {comment.user.name?.charAt(0) || 'U'}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{comment.user.name}</span>
                                <Badge variant="outline" className="text-xs">
                                  <ShieldCheck className="h-3 w-3 mr-1 text-green-500" />
                                  Verificado
                                </Badge>
                                <div className="flex items-center">
                                  {[...Array(comment.rating || 0)].map((_, i) => (
                                    <Star key={i} className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                                  ))}
                                </div>
                                <span className="text-xs text-muted-foreground">
                                  {new Date(comment.createdAt).toLocaleDateString('es-ES')}
                                </span>
                              </div>
                              <p className="text-sm text-muted-foreground">{comment.content}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                  
                  {recipe.comments.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <MessageCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                      <p className="text-sm">Sé el primero en comentar esta receta</p>
                      <p className="text-xs mt-1">Todos los comentarios son de usuarios verificados</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions Card */}
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg">Acciones rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href={`/recetas/${recipe.id}/pasos`} className="block">
                    <Button className="w-full bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600">
                      <Play className="h-4 w-4 mr-2" />
                      Iniciar Modo Cocina
                    </Button>
                  </Link>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" onClick={() => window.print()}>
                      <Printer className="h-4 w-4 mr-2" />
                      Imprimir
                    </Button>
                    <Button variant="outline" onClick={shareRecipe}>
                      <Share2 className="h-4 w-4 mr-2" />
                      Compartir
                    </Button>
                  </div>
                  {/* Share Options */}
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 bg-green-500 hover:bg-green-600 text-white border-green-500"
                      onClick={() => shareRecipe('whatsapp')}
                    >
                      <svg className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                      WhatsApp
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="flex-1 bg-blue-500 hover:bg-blue-600 text-white border-blue-500"
                      onClick={() => shareRecipe('telegram')}
                    >
                      <svg className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                      </svg>
                      Telegram
                    </Button>
                  </div>
                  <Button variant="outline" className="w-full" onClick={addToShoppingList}>
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Añadir ingredientes a compras
                  </Button>
                </CardContent>
              </Card>

              {/* Timer Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Timer className="h-5 w-5" />
                    Temporizadores
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Link href="/temporizadores">
                    <Button variant="outline" className="w-full">
                      Abrir temporizadores
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              {/* Info Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Información adicional</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tiempo prep.</span>
                    <span className="font-medium">{recipe.prepTime} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tiempo cocción</span>
                    <span className="font-medium">{recipe.cookTime} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cocina</span>
                    <span className="font-medium capitalize">{recipe.cuisine || 'Internacional'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tipo de plato</span>
                    <span className="font-medium capitalize">{recipe.mealType}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Vistas</span>
                    <span className="font-medium">{(recipe.viewCount ?? 0).toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
