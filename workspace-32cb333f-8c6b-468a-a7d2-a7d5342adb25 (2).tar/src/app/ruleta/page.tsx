"use client"

import { RecipeRoulette } from "@/components/recipe-roulette"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Sparkles, Shuffle, Trophy, Lightbulb } from "lucide-react"
import Link from "next/link"

export default function RuletaPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-md border-b border-orange-100 dark:border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 text-muted-foreground hover:text-orange-500 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              <span>Volver al inicio</span>
            </Link>
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-orange-500" />
              <span className="font-semibold text-orange-500">CocinaViva</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-12">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-100 to-red-100 dark:from-orange-900/30 dark:to-red-900/30 rounded-full px-4 py-2 mb-4">
            <Shuffle className="w-4 h-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-600 dark:text-orange-400">Función Gratuita</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 bg-clip-text text-transparent">
              Ruleta de Recetas
            </span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            ¿No sabes qué cocinar hoy? ¡Deja que el destino decida por ti! 
            Gira la ruleta y descubre recetas deliciosas de forma aleatoria.
          </p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          <div className="flex items-center gap-3 p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-orange-100 dark:border-gray-700">
            <div className="w-10 h-10 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center">
              <Shuffle className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <h3 className="font-semibold">100% Aleatorio</h3>
              <p className="text-sm text-muted-foreground">Cada giro es una sorpresa</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-orange-100 dark:border-gray-700">
            <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-green-500" />
            </div>
            <div>
              <h3 className="font-semibold">2700+ Recetas</h3>
              <p className="text-sm text-muted-foreground">Variedad infinita</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-4 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-orange-100 dark:border-gray-700">
            <div className="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
              <Lightbulb className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h3 className="font-semibold">Sin IA</h3>
              <p className="text-sm text-muted-foreground">Pura diversión mecánica</p>
            </div>
          </div>
        </div>

        {/* Roulette Component */}
        <RecipeRoulette />

        {/* Tips Section */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-lg border border-orange-100 dark:border-gray-700">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-2xl">🎯</span>
              ¿Cómo funciona?
            </h3>
            <ol className="space-y-3">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-orange-500 text-white text-sm flex items-center justify-center flex-shrink-0">1</span>
                <span>Pulsa el botón "¡GIRAR RULETA!" para comenzar</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-orange-500 text-white text-sm flex items-center justify-center flex-shrink-0">2</span>
                <span>Observa cómo la ruleta gira y se detiene</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-orange-500 text-white text-sm flex items-center justify-center flex-shrink-0">3</span>
                <span>¡Descubre tu receta sorpresa con todos los detalles!</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-orange-500 text-white text-sm flex items-center justify-center flex-shrink-0">4</span>
                <span>¿No te convence? ¡Gira de nuevo!</span>
              </li>
            </ol>
          </div>
          
          <div className="p-6 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl shadow-lg text-white">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-2xl">💡</span>
              Tip del Chef
            </h3>
            <p className="mb-4 opacity-90">
              Usa la ruleta cuando:
            </p>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <span>✓</span>
                <span>No sepas qué cocinar</span>
              </li>
              <li className="flex items-center gap-2">
                <span>✓</span>
                <span>Quieras probar algo nuevo</span>
              </li>
              <li className="flex items-center gap-2">
                <span>✓</span>
                <span>Tengas invitados sorpresa</span>
              </li>
              <li className="flex items-center gap-2">
                <span>✓</span>
                <span>Te sientas aventurero</span>
              </li>
            </ul>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Link href="/recetas">
            <Button variant="outline" size="lg" className="border-orange-300 hover:bg-orange-50">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Ver todas las recetas
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-orange-100 dark:border-gray-800 bg-white/50 dark:bg-gray-900/50">
        <div className="container mx-auto px-4 py-6 text-center text-muted-foreground">
          <p>🎰 Ruleta de Recetas - ¡La diversión de cocinar está en el azar!</p>
        </div>
      </footer>
    </div>
  )
}
