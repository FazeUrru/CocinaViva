'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { 
  Sparkles, 
  ChefHat, 
  Plus, 
  X, 
  Loader2, 
  Soup,
  Thermometer,
  Flame,
  RefreshCw,
  Copy,
  Check,
  Lock,
  Crown,
  Clock,
  Users
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useUserStore } from '@/store'
import Link from 'next/link'
import { toast } from 'sonner'

const toolOptions = [
  { id: 'tradicional', name: 'Cocina Tradicional', icon: Flame, description: 'Sartén, horno, batidora...' },
  { id: 'thermomix', name: 'Thermomix', icon: Thermometer, description: 'Robot de cocina Thermomix' },
  { id: 'crockpot', name: 'Crockpot', icon: Soup, description: 'Olla de cocción lenta' },
]

interface GeneratedRecipe {
  title: string
  description: string
  ingredients: string[]
  steps: string[]
  prepTime: number
  cookTime: number
  servings: number
  difficulty: 'Fácil' | 'Medio' | 'Difícil'
  tips: string[]
}

export default function ChefIAPage() {
  const { subscription } = useUserStore()
  const [ingredients, setIngredients] = useState<string[]>([])
  const [currentIngredient, setCurrentIngredient] = useState('')
  const [selectedTool, setSelectedTool] = useState<string>('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedRecipe, setGeneratedRecipe] = useState<GeneratedRecipe | null>(null)
  const [copied, setCopied] = useState(false)

  // Verificar si tiene acceso premium (Chef IA es premium)
  const hasAccess = subscription.plan !== 'basic' && (subscription.isSubscriptionActive || subscription.isTrialActive)

  const addIngredient = () => {
    if (currentIngredient.trim() && ingredients.length < 10) {
      setIngredients([...ingredients, currentIngredient.trim().toLowerCase()])
      setCurrentIngredient('')
    }
  }

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index))
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      addIngredient()
    }
  }

  const generateRecipe = async () => {
    if (ingredients.length < 2) {
      toast.error('Añade al menos 2 ingredientes')
      return
    }
    if (!selectedTool) {
      toast.error('Selecciona una herramienta de cocina')
      return
    }

    setIsGenerating(true)
    
    // Simular generación de receta con IA
    await new Promise(resolve => setTimeout(resolve, 3000))
    
    const toolName = toolOptions.find(t => t.id === selectedTool)?.name || 'tradicional'
    const mainIngredient = ingredients[0]
    const secondIngredient = ingredients[1]
    
    // Generar receta simulada basada en los ingredientes
    const recipe: GeneratedRecipe = {
      title: `${mainIngredient.charAt(0).toUpperCase() + mainIngredient.slice(1)} con ${secondIngredient} (${toolName})`,
      description: `Deliciosa receta preparada con ${ingredients.join(', ')} utilizando ${toolName.toLowerCase()}. Una combinación perfecta de sabores.`,
      ingredients: [
        `${ingredients[0]} - 500g`,
        `${ingredients[1] || 'cebolla'} - 2 unidades`,
        ...ingredients.slice(2).map(ing => `${ing} - al gusto`),
        'Aceite de oliva - 3 cucharadas',
        'Sal y pimienta - al gusto',
        'Ajo - 2 dientes',
      ],
      steps: [
        `Prepara todos los ingredientes: lava y pica ${ingredients[0]}, ${ingredients[1] || 'cebolla'} y los demás ingredientes.`,
        `${selectedTool === 'thermomix' ? 'Añade el aceite en el vaso y programa 3 minutos, velocidad 1, temperatura Varoma.' : selectedTool === 'crockpot' ? 'Enciende la Crockpot en modo alto para precalentar.' : 'Calienta el aceite en una sartén grande a fuego medio.'}`,
        `${selectedTool === 'thermomix' ? 'Incorpora los ingredientes picados y programa 5 minutos, velocidad cuchara, 100°C.' : selectedTool === 'crockpot' ? 'Añade todos los ingredientes a la Crockpot.' : 'Añade los ingredientes comenzando por los más duros.'}`,
        `${selectedTool === 'thermomix' ? 'Añade el ingrediente principal y programa 15 minutos, giro inverso, velocidad cuchara, 100°C.' : selectedTool === 'crockpot' ? 'Cocina durante 4-6 horas en modo alto o 6-8 horas en modo bajo.' : 'Cocina durante 20-25 minutos, removiendo ocasionalmente.'}`,
        'Sazona con sal, pimienta y ajusta los condimentos según tu gusto.',
        'Sirve caliente y decora con hierbas frescas si lo deseas.',
      ],
      prepTime: 15,
      cookTime: selectedTool === 'crockpot' ? 360 : 30,
      servings: 4,
      difficulty: ingredients.length > 5 ? 'Medio' : 'Fácil',
      tips: [
        'Puedes añadir más ingredientes para enriquecer el plato',
        'Ajusta los tiempos según tu preferencia de cocción',
        'Esta receta se puede conservar en el refrigerador por 3 días',
      ],
    }
    
    setGeneratedRecipe(recipe)
    setIsGenerating(false)
    toast.success('¡Receta generada con éxito!')
  }

  const copyRecipe = () => {
    if (!generatedRecipe) return
    
    const recipeText = `
${generatedRecipe.title}

${generatedRecipe.description}

Ingredientes:
${generatedRecipe.ingredients.map(i => `• ${i}`).join('\n')}

Preparación:
${generatedRecipe.steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

Tiempo de preparación: ${generatedRecipe.prepTime} min
Tiempo de cocción: ${generatedRecipe.cookTime} min
Raciones: ${generatedRecipe.servings}
Dificultad: ${generatedRecipe.difficulty}

Consejos:
${generatedRecipe.tips.map(t => `• ${t}`).join('\n')}
    `.trim()
    
    navigator.clipboard.writeText(recipeText)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    toast.success('Receta copiada al portapapeles')
  }

  const resetGenerator = () => {
    setIngredients([])
    setSelectedTool('')
    setGeneratedRecipe(null)
  }

  // Si no tiene acceso premium, mostrar pantalla de bloqueo
  if (!hasAccess) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navigation />
        <main className="flex-1 flex items-center justify-center p-4">
          <Card className="max-w-md w-full border-2 border-dashed border-muted-foreground/30">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 rounded-full bg-gradient-to-br from-purple-100 to-orange-100 dark:from-purple-900/30 dark:to-orange-900/30 flex items-center justify-center mb-4">
                <Lock className="h-8 w-8 text-purple-500" />
              </div>
              <CardTitle className="flex items-center justify-center gap-2">
                Chef IA - Función Premium
                <Badge className="bg-gradient-to-r from-purple-500 to-orange-500">
                  <Crown className="h-3 w-3 mr-1" />
                  Ultra/MasterChef
                </Badge>
              </CardTitle>
              <CardDescription>
                Chef IA está disponible exclusivamente para suscriptores de los planes Ultra y MasterChef
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-sm text-muted-foreground">
                Genera recetas automáticamente con inteligencia artificial usando tus ingredientes disponibles.
              </p>
              <div className="bg-muted p-4 rounded-lg text-left space-y-2">
                <p className="text-sm font-medium">Beneficios de Chef IA:</p>
                <ul className="text-xs text-muted-foreground space-y-1">
                  <li>• Genera recetas con 2+ ingredientes</li>
                  <li>• Compatible con Thermomix, Crockpot y tradicional</li>
                  <li>• Instrucciones paso a paso detalladas</li>
                  <li>• Consejos de cocina personalizados</li>
                </ul>
              </div>
              <Link href="/planes">
                <Button className="w-full bg-gradient-to-r from-purple-500 to-orange-500 hover:from-purple-600 hover:to-orange-600">
                  <Crown className="h-4 w-4 mr-2" />
                  Ver Planes Premium
                </Button>
              </Link>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-purple-500 via-violet-500 to-orange-500 py-16 text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="inline-flex items-center justify-center w-20 h-20 bg-white/20 backdrop-blur rounded-2xl mb-4">
                <Sparkles className="h-10 w-10" />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Chef IA</h1>
              <p className="text-xl text-white/90 mb-2">
                Genera recetas automáticamente con inteligencia artificial
              </p>
              <p className="text-sm text-white/70">
                Añade tus ingredientes, elige tu herramienta y deja que la IA cree la receta perfecta
              </p>
            </motion.div>
          </div>
        </section>

        {/* Generator Section */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Panel */}
              <Card className="h-fit">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ChefHat className="h-5 w-5 text-orange-500" />
                    Configura tu Receta
                  </CardTitle>
                  <CardDescription>
                    Añade al menos 2 ingredientes y selecciona tu herramienta de cocina
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Ingredients Input */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium">Ingredientes disponibles</label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Ej: pollo, tomate, cebolla..."
                        value={currentIngredient}
                        onChange={(e) => setCurrentIngredient(e.target.value)}
                        onKeyPress={handleKeyPress}
                        disabled={ingredients.length >= 10}
                      />
                      <Button 
                        onClick={addIngredient} 
                        disabled={!currentIngredient.trim() || ingredients.length >= 10}
                        size="icon"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {/* Ingredients Tags */}
                    <div className="flex flex-wrap gap-2 min-h-[40px]">
                      {ingredients.map((ing, index) => (
                        <Badge 
                          key={index} 
                          variant="secondary"
                          className="px-3 py-1 text-sm cursor-pointer hover:bg-destructive hover:text-destructive-foreground transition-colors"
                          onClick={() => removeIngredient(index)}
                        >
                          {ing}
                          <X className="h-3 w-3 ml-1" />
                        </Badge>
                      ))}
                      {ingredients.length === 0 && (
                        <p className="text-sm text-muted-foreground">
                          Añade ingredientes (mínimo 2, máximo 10)
                        </p>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {ingredients.length}/10 ingredientes añadidos
                    </p>
                  </div>

                  {/* Tool Selection */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium">Herramienta de cocina</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      {toolOptions.map((tool) => {
                        const Icon = tool.icon
                        return (
                          <Card 
                            key={tool.id}
                            className={`cursor-pointer transition-all hover:shadow-md ${
                              selectedTool === tool.id 
                                ? 'ring-2 ring-orange-500 bg-orange-50 dark:bg-orange-950/20' 
                                : ''
                            }`}
                            onClick={() => setSelectedTool(tool.id)}
                          >
                            <CardContent className="p-4 text-center">
                              <Icon className={`h-8 w-8 mx-auto mb-2 ${
                                selectedTool === tool.id ? 'text-orange-500' : 'text-muted-foreground'
                              }`} />
                              <div className="font-medium text-sm">{tool.name}</div>
                              <div className="text-xs text-muted-foreground">{tool.description}</div>
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  </div>

                  {/* Generate Button */}
                  <Button 
                    className="w-full h-12 text-base bg-gradient-to-r from-purple-500 to-orange-500 hover:from-purple-600 hover:to-orange-600"
                    onClick={generateRecipe}
                    disabled={ingredients.length < 2 || !selectedTool || isGenerating}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                        Generando receta...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-5 w-5 mr-2" />
                        Generar Receta con IA
                      </>
                    )}
                  </Button>

                  {/* Reset Button */}
                  {generatedRecipe && (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={resetGenerator}
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Generar Nueva Receta
                    </Button>
                  )}
                </CardContent>
              </Card>

              {/* Output Panel */}
              <Card className={generatedRecipe ? '' : 'border-dashed'}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-purple-500" />
                    Receta Generada
                  </CardTitle>
                  <CardDescription>
                    {generatedRecipe ? 'Tu receta personalizada' : 'La receta aparecerá aquí'}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isGenerating ? (
                    <div className="flex flex-col items-center justify-center py-12">
                      <Loader2 className="h-12 w-12 animate-spin text-purple-500 mb-4" />
                      <p className="text-muted-foreground">Analizando ingredientes...</p>
                      <p className="text-sm text-muted-foreground">Generando la receta perfecta...</p>
                    </div>
                  ) : generatedRecipe ? (
                    <div className="space-y-6">
                      {/* Recipe Title */}
                      <div>
                        <h3 className="text-xl font-bold mb-2">{generatedRecipe.title}</h3>
                        <p className="text-muted-foreground">{generatedRecipe.description}</p>
                      </div>

                      {/* Recipe Stats */}
                      <div className="flex flex-wrap gap-4">
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Prep: {generatedRecipe.prepTime} min
                        </Badge>
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Cocción: {generatedRecipe.cookTime} min
                        </Badge>
                        <Badge variant="secondary" className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {generatedRecipe.servings} raciones
                        </Badge>
                        <Badge variant="outline">{generatedRecipe.difficulty}</Badge>
                      </div>

                      {/* Ingredients */}
                      <div>
                        <h4 className="font-semibold mb-2">Ingredientes:</h4>
                        <ul className="space-y-1">
                          {generatedRecipe.ingredients.map((ing, i) => (
                            <li key={i} className="text-sm flex items-center gap-2">
                              <span className="w-2 h-2 bg-orange-500 rounded-full" />
                              {ing}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Steps */}
                      <div>
                        <h4 className="font-semibold mb-2">Preparación:</h4>
                        <ol className="space-y-3">
                          {generatedRecipe.steps.map((step, i) => (
                            <li key={i} className="text-sm flex gap-3">
                              <span className="flex-shrink-0 w-6 h-6 bg-purple-500 text-white rounded-full flex items-center justify-center text-xs font-medium">
                                {i + 1}
                              </span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ol>
                      </div>

                      {/* Tips */}
                      <div className="bg-muted p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Consejos:</h4>
                        <ul className="space-y-1">
                          {generatedRecipe.tips.map((tip, i) => (
                            <li key={i} className="text-sm text-muted-foreground">• {tip}</li>
                          ))}
                        </ul>
                      </div>

                      {/* Copy Button */}
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={copyRecipe}
                      >
                        {copied ? (
                          <>
                            <Check className="h-4 w-4 mr-2 text-green-500" />
                            Copiado
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4 mr-2" />
                            Copiar Receta
                          </>
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <ChefHat className="h-16 w-16 text-muted-foreground/30 mb-4" />
                      <p className="text-muted-foreground">
                        Añade ingredientes y selecciona una herramienta<br />
                        para generar tu receta con IA
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
