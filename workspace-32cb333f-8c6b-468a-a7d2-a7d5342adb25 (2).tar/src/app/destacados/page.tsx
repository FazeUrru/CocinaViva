'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Sparkles,
  Star,
  Clock,
  Search,
  Filter,
  Grid,
  List,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'
import { featuredRecipes } from '@/data/recipes-featured'

const ITEMS_PER_PAGE = 20

const featuredReasons = [
  { value: 'all', label: 'Todas', icon: '⭐' },
  { value: 'popular', label: 'Populares', icon: '🔥' },
  { value: 'trending', label: 'Tendencia', icon: '📈' },
  { value: 'editor_pick', label: 'Editor', icon: '👨‍🍳' },
  { value: 'seasonal', label: 'Temporada', icon: '🍂' },
  { value: 'new', label: 'Nuevas', icon: '✨' },
]

const mealTypes = [
  { value: 'all', label: 'Todos' },
  { value: 'desayuno', label: 'Desayuno', icon: '🥐' },
  { value: 'almuerzo', label: 'Almuerzo', icon: '🍽️' },
  { value: 'cena', label: 'Cena', icon: '🌙' },
  { value: 'postre', label: 'Postre', icon: '🍰' },
  { value: 'snack', label: 'Snack', icon: '🍿' },
]

const difficulties = [
  { value: 'all', label: 'Todas' },
  { value: 'facil', label: 'Fácil', color: 'bg-green-500' },
  { value: 'medio', label: 'Medio', color: 'bg-yellow-500' },
  { value: 'dificil', label: 'Difícil', color: 'bg-red-500' },
]

export default function DestacadosPage() {
  const [search, setSearch] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [filters, setFilters] = useState({
    featuredReason: 'all',
    mealType: 'all',
    difficulty: 'all',
    toolType: 'all',
  })
  const [showFilters, setShowFilters] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)

  // Filter recipes
  const filteredRecipes = useMemo(() => {
    return featuredRecipes.filter(recipe => {
      if (search && !recipe.title.toLowerCase().includes(search.toLowerCase()) && 
          !recipe.description.toLowerCase().includes(search.toLowerCase())) {
        return false
      }
      if (filters.featuredReason !== 'all' && recipe.featuredReason !== filters.featuredReason) {
        return false
      }
      if (filters.mealType !== 'all' && recipe.mealType !== filters.mealType) {
        return false
      }
      if (filters.difficulty !== 'all' && recipe.difficulty !== filters.difficulty) {
        return false
      }
      if (filters.toolType !== 'all' && recipe.toolType !== filters.toolType) {
        return false
      }
      return true
    })
  }, [search, filters])

  // Pagination
  const totalPages = Math.ceil(filteredRecipes.length / ITEMS_PER_PAGE)
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
  const endIndex = startIndex + ITEMS_PER_PAGE
  const paginatedRecipes = filteredRecipes.slice(startIndex, endIndex)

  const updateFilter = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setCurrentPage(1)
  }

  const clearFilters = () => {
    setFilters({
      featuredReason: 'all',
      mealType: 'all',
      difficulty: 'all',
      toolType: 'all',
    })
    setSearch('')
    setCurrentPage(1)
  }

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  // Generate page numbers to display (1,2,3,4,5,6...)
  const getPageNumbers = () => {
    const pages: (number | string)[] = []
    const maxVisible = 7
    
    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i)
      }
    } else {
      // Always show first page
      pages.push(1)
      
      if (currentPage > 3) {
        pages.push('...')
      }
      
      // Show pages around current
      const start = Math.max(2, currentPage - 1)
      const end = Math.min(totalPages - 1, currentPage + 1)
      
      for (let i = start; i <= end; i++) {
        pages.push(i)
      }
      
      if (currentPage < totalPages - 2) {
        pages.push('...')
      }
      
      // Always show last page
      pages.push(totalPages)
    }
    
    return pages
  }

  const activeFiltersCount = [
    filters.featuredReason !== 'all',
    filters.mealType !== 'all',
    filters.difficulty !== 'all',
    filters.toolType !== 'all',
  ].filter(Boolean).length

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50 dark:from-amber-950/20 dark:via-orange-950/20 dark:to-yellow-950/20 py-8">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-3 mb-2">
              <Sparkles className="h-8 w-8 text-amber-500" />
              <h1 className="text-3xl font-bold">Recetas Destacadas</h1>
            </div>
            <p className="text-muted-foreground">
              Las mejores recetas seleccionadas - {featuredRecipes.length} recetas destacadas
            </p>
          </div>
        </section>

        {/* No Stats - Removed unrealistic numbers */}

        {/* Search and Filters */}
        <section className="border-b bg-background sticky top-16 z-40">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-wrap items-center gap-4">
              {/* Search */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar recetas destacadas..."
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>

              {/* Filter Button - Mobile */}
              <Sheet open={showFilters} onOpenChange={setShowFilters}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtros
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 h-5 w-5 p-0 flex items-center justify-center bg-amber-500">
                        {activeFiltersCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                    <SheetDescription>
                      Refina tu búsqueda de recetas destacadas
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <FilterContent 
                      filters={filters} 
                      updateFilter={updateFilter} 
                      clearFilters={clearFilters}
                      onApply={() => setShowFilters(false)}
                    />
                  </div>
                </SheetContent>
              </Sheet>

              {/* Desktop Filters */}
              <div className="hidden lg:flex items-center gap-3">
                <Select value={filters.featuredReason} onValueChange={(v) => updateFilter('featuredReason', v)}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {featuredReasons.map(reason => (
                      <SelectItem key={reason.value} value={reason.value}>
                        {reason.icon} {reason.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filters.mealType} onValueChange={(v) => updateFilter('mealType', v)}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Plato" />
                  </SelectTrigger>
                  <SelectContent>
                    {mealTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.icon} {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filters.toolType} onValueChange={(v) => updateFilter('toolType', v)}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Método" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="tradicional">Tradicional</SelectItem>
                    <SelectItem value="thermomix">Thermomix</SelectItem>
                    <SelectItem value="crockpot">Crockpot</SelectItem>
                  </SelectContent>
                </Select>

                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    Limpiar
                  </Button>
                )}
              </div>

              {/* View Mode Toggle */}
              <div className="flex items-center border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Results */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            {/* Results Count */}
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Mostrando {startIndex + 1}-{Math.min(endIndex, filteredRecipes.length)} de {(filteredRecipes.length ?? 0).toLocaleString()} recetas
              </p>
              <p className="text-sm text-muted-foreground">
                Página {currentPage} de {totalPages}
              </p>
            </div>

            {filteredRecipes.length === 0 ? (
              <div className="text-center py-16">
                <Sparkles className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No se encontraron recetas</h3>
                <p className="text-muted-foreground mb-4">
                  Prueba a modificar los filtros de búsqueda
                </p>
                <Button onClick={clearFilters} className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                  Limpiar filtros
                </Button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {paginatedRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: (index % ITEMS_PER_PAGE) * 0.01 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                        <div className="relative h-48 overflow-hidden bg-gradient-to-br from-amber-100 to-orange-100">
                          <img
                            src={recipe.imageUrl}
                            alt={recipe.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = `/images/recipes/placeholder-${recipe.mealType}.png`
                            }}
                          />
                          <div className="absolute top-3 left-3">
                            <Badge className="bg-amber-500 text-white">
                              #{startIndex + index + 1}
                            </Badge>
                          </div>
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-white/90 text-gray-800">
                              <Star className="h-3 w-3 mr-1 text-yellow-500 fill-yellow-500" />
                              {recipe.averageRating.toFixed(1)}
                            </Badge>
                          </div>
                          <div className="absolute bottom-3 left-3 flex gap-2">
                            {recipe.toolType === 'thermomix' && (
                              <Badge className="bg-cyan-500/90 text-white text-xs">⚡ Thermomix</Badge>
                            )}
                            {recipe.toolType === 'crockpot' && (
                              <Badge className="bg-orange-500/90 text-white text-xs">🍲 Crockpot</Badge>
                            )}
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle className="line-clamp-1 text-base">{recipe.title}</CardTitle>
                          <CardDescription className="line-clamp-2 text-sm">
                            {recipe.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-4">
                          <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {recipe.totalTime} min
                            </div>
                            <Badge variant="outline" className={cn(
                              "text-xs",
                              recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                              recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                              recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                            )}>
                              {recipe.difficulty === 'facil' ? 'Fácil' : 
                               recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">
                              {(recipe.viewCount ?? 0).toLocaleString()} vistas
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {paginatedRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (index % ITEMS_PER_PAGE) * 0.01 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="hover:shadow-lg transition-all cursor-pointer group">
                        <div className="flex">
                          <div className="w-40 h-32 relative flex-shrink-0 overflow-hidden rounded-l-lg bg-gradient-to-br from-amber-100 to-orange-100">
                            <img
                              src={recipe.imageUrl}
                              alt={recipe.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.src = `/images/recipes/placeholder-${recipe.mealType}.png`
                              }}
                            />
                            <div className="absolute bottom-2 left-2">
                              <Badge className="bg-amber-500 text-white text-xs">
                                #{startIndex + index + 1}
                              </Badge>
                            </div>
                          </div>
                          <div className="flex-1 p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                                <CardDescription className="line-clamp-1 mt-1">
                                  {recipe.description}
                                </CardDescription>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                <span className="font-medium">{recipe.averageRating.toFixed(1)}</span>
                                <span className="text-muted-foreground text-sm">({recipe.ratingCount})</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground flex-wrap">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {recipe.totalTime} min
                              </div>
                              <Badge variant="outline" className={cn(
                                "text-xs",
                                recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                                recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                                recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                              )}>
                                {recipe.difficulty === 'facil' ? 'Fácil' : 
                                 recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                              </Badge>
                              <span className="text-xs">
                                {(recipe.viewCount ?? 0).toLocaleString()} vistas
                              </span>
                            </div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Pagination - 1,2,3,4,5,6... */}
            {totalPages > 1 && (
              <div className="mt-8 flex flex-col items-center gap-4">
                <div className="flex items-center gap-2 flex-wrap justify-center">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  {getPageNumbers().map((page, index) => (
                    typeof page === 'number' ? (
                      <Button
                        key={index}
                        variant={currentPage === page ? 'default' : 'outline'}
                        size="icon"
                        onClick={() => goToPage(page)}
                        className={cn(
                          "w-10 h-10",
                          currentPage === page && "bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600"
                        )}
                      >
                        {page}
                      </Button>
                    ) : (
                      <span key={index} className="px-2 text-muted-foreground">...</span>
                    )
                  ))}
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  Página {currentPage} de {totalPages} · {(filteredRecipes.length ?? 0).toLocaleString()} recetas destacadas
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

// Filter Content Component
function FilterContent({ 
  filters, 
  updateFilter, 
  clearFilters,
  onApply 
}: { 
  filters: { featuredReason: string; mealType: string; difficulty: string; toolType: string }
  updateFilter: (key: string, value: string) => void
  clearFilters: () => void
  onApply: () => void
}) {
  return (
    <div className="space-y-6">
      {/* Featured Reason */}
      <div>
        <span className="text-sm font-medium mb-3 block">Tipo de Destacado</span>
        <div className="flex flex-wrap gap-2">
          {featuredReasons.map(reason => (
            <Button
              key={reason.value}
              variant={filters.featuredReason === reason.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('featuredReason', reason.value)}
              className={cn(
                filters.featuredReason === reason.value && "bg-gradient-to-r from-amber-500 to-orange-500"
              )}
            >
              {reason.icon} {reason.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Meal Type */}
      <div>
        <span className="text-sm font-medium mb-3 block">Tipo de Plato</span>
        <div className="flex flex-wrap gap-2">
          {mealTypes.map(type => (
            <Button
              key={type.value}
              variant={filters.mealType === type.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('mealType', type.value)}
              className={cn(
                filters.mealType === type.value && "bg-gradient-to-r from-amber-500 to-orange-500"
              )}
            >
              {type.icon} {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Difficulty */}
      <div>
        <span className="text-sm font-medium mb-3 block">Dificultad</span>
        <div className="flex gap-2">
          {difficulties.map(diff => (
            <Button
              key={diff.value}
              variant={filters.difficulty === diff.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('difficulty', diff.value)}
              className={cn(
                filters.difficulty === diff.value && "bg-gradient-to-r from-amber-500 to-orange-500"
              )}
            >
              {diff.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Tool Type */}
      <div>
        <span className="text-sm font-medium mb-3 block">Método de Cocción</span>
        <div className="flex flex-wrap gap-2">
          {['all', 'tradicional', 'thermomix', 'crockpot'].map(tool => (
            <Button
              key={tool}
              variant={filters.toolType === tool ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('toolType', tool)}
              className={cn(
                filters.toolType === tool && "bg-gradient-to-r from-amber-500 to-orange-500"
              )}
            >
              {tool === 'all' ? 'Todos' : tool.charAt(0).toUpperCase() + tool.slice(1)}
            </Button>
          ))}
        </div>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={clearFilters} className="flex-1">
          Limpiar
        </Button>
        <Button onClick={onApply} className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
          Aplicar
        </Button>
      </div>
    </div>
  )
}
