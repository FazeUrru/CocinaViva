'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Search,
  Filter,
  Grid,
  List,
  Clock,
  Flame,
  Star,
  Timer,
  Soup,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'
import { crockpotRecipes } from '@/data/recipes-crockpot'

const mealTypes = [
  { value: 'desayuno', label: 'Desayuno', icon: '🥐' },
  { value: 'almuerzo', label: 'Almuerzo', icon: '🍽️' },
  { value: 'cena', label: 'Cena', icon: '🌙' },
  { value: 'postre', label: 'Postre', icon: '🍰' },
  { value: 'snack', label: 'Snack', icon: '🍿' },
]

const difficulties = [
  { value: 'facil', label: 'Fácil', color: 'bg-green-500' },
  { value: 'medio', label: 'Medio', color: 'bg-yellow-500' },
  { value: 'dificil', label: 'Difícil', color: 'bg-red-500' },
]

const ITEMS_PER_PAGE = 20

export default function CrockpotPage() {
  const [search, setSearch] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [filters, setFilters] = useState({
    mealType: 'all',
    difficulty: 'all',
  })
  const [showFilters, setShowFilters] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)

  // Filter recipes
  const filteredRecipes = crockpotRecipes.filter(recipe => {
    if (search && !recipe.title.toLowerCase().includes(search.toLowerCase()) && 
        !recipe.description.toLowerCase().includes(search.toLowerCase())) {
      return false
    }
    if (filters.mealType !== 'all' && recipe.mealType !== filters.mealType) {
      return false
    }
    if (filters.difficulty !== 'all' && recipe.difficulty !== filters.difficulty) {
      return false
    }
    return true
  })

  // Pagination
  const totalPages = Math.ceil(filteredRecipes.length / ITEMS_PER_PAGE)
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
  const endIndex = startIndex + ITEMS_PER_PAGE
  const paginatedRecipes = filteredRecipes.slice(startIndex, endIndex)

  const updateFilter = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setCurrentPage(1)
  }

  const clearFilters = () => {
    setFilters({
      mealType: 'all',
      difficulty: 'all',
    })
    setSearch('')
    setCurrentPage(1)
  }

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  const activeFiltersCount = [
    filters.mealType !== 'all',
    filters.difficulty !== 'all',
  ].filter(Boolean).length

  // Generate page numbers to display
  const getPageNumbers = () => {
    const pages: (number | string)[] = []
    const maxVisiblePages = 7
    
    if (totalPages <= maxVisiblePages) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i)
      }
    } else {
      // Always show first page
      pages.push(1)
      
      if (currentPage > 3) {
        pages.push('...')
      }
      
      // Show pages around current page
      const startPage = Math.max(2, currentPage - 1)
      const endPage = Math.min(totalPages - 1, currentPage + 1)
      
      for (let i = startPage; i <= endPage; i++) {
        pages.push(i)
      }
      
      if (currentPage < totalPages - 2) {
        pages.push('...')
      }
      
      // Always show last page
      pages.push(totalPages)
    }
    
    return pages
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-orange-100 via-amber-50 to-orange-200 dark:from-orange-950/30 dark:via-amber-950/20 dark:to-orange-950/30 py-10">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-4 mb-3">
              <div className="p-3 rounded-full bg-gradient-to-br from-orange-500 to-amber-600 shadow-lg">
                <Soup className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-amber-700 bg-clip-text text-transparent">
                  Recetas Crockpot / Slow Cooker
                </h1>
                <p className="text-muted-foreground mt-1">
                  Cocina lenta y sabrosa con nuestra colección de {(crockpotRecipes.length ?? 0).toLocaleString()} recetas
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-3 mt-4">
              <Badge className="bg-orange-500/20 text-orange-700 dark:text-orange-300 border border-orange-300">
                <Timer className="h-3 w-3 mr-1" />
                Cocción lenta
              </Badge>
              <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-300">
                <Flame className="h-3 w-3 mr-1" />
                Sabores intensos
              </Badge>
              <Badge className="bg-orange-600/20 text-orange-800 dark:text-orange-200 border border-orange-400">
                Ahorra tiempo
              </Badge>
            </div>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="border-b bg-background sticky top-16 z-40">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-wrap items-center gap-4">
              {/* Search */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar receta por nombre o ingrediente..."
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>

              {/* Filter Button - Mobile */}
              <Sheet open={showFilters} onOpenChange={setShowFilters}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtros
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 h-5 w-5 p-0 flex items-center justify-center bg-orange-500">
                        {activeFiltersCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                    <SheetDescription>
                      Refina tu búsqueda de recetas Crockpot
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <FilterContent 
                      filters={filters} 
                      updateFilter={updateFilter} 
                      clearFilters={clearFilters}
                      onApply={() => setShowFilters(false)}
                    />
                  </div>
                </SheetContent>
              </Sheet>

              {/* Desktop Filters */}
              <div className="hidden lg:flex items-center gap-4">
                <Select value={filters.mealType} onValueChange={(v) => updateFilter('mealType', v)}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Tipo de plato" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los platos</SelectItem>
                    {mealTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.icon} {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filters.difficulty} onValueChange={(v) => updateFilter('difficulty', v)}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Dificultad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    {difficulties.map(diff => (
                      <SelectItem key={diff.value} value={diff.value}>
                        {diff.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="h-4 w-4 mr-1" />
                    Limpiar
                  </Button>
                )}
              </div>

              {/* View Mode Toggle */}
              <div className="flex items-center border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Results */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            {/* Results Count */}
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Mostrando {startIndex + 1}-{Math.min(endIndex, filteredRecipes.length)} de {(filteredRecipes.length ?? 0).toLocaleString()} recetas
              </p>
              <p className="text-sm text-muted-foreground">
                Página {currentPage} de {totalPages}
              </p>
            </div>

            {filteredRecipes.length === 0 ? (
              <div className="text-center py-16">
                <Soup className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No se encontraron recetas</h3>
                <p className="text-muted-foreground mb-4">
                  Prueba a modificar los filtros de búsqueda
                </p>
                <Button onClick={clearFilters} className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700">
                  Limpiar filtros
                </Button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {paginatedRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: (index % ITEMS_PER_PAGE) * 0.01 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                        <div className="relative h-48 overflow-hidden bg-gradient-to-br from-orange-100 to-amber-100">
                          <img
                            src={recipe.imageUrl}
                            alt={recipe.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = `/images/recipes/placeholder-${recipe.mealType}.png`
                            }}
                          />
                          <div className="absolute top-3 left-3 flex gap-2">
                          </div>
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-yellow-500 hover:bg-yellow-600 text-xs">
                              <Star className="h-3 w-3 mr-1 fill-white" />
                              {recipe.averageRating.toFixed(1)}
                            </Badge>
                          </div>
                          <div className="absolute bottom-3 left-3">
                            <Badge className="bg-gradient-to-r from-orange-500 to-amber-500 text-white text-xs">
                              <Timer className="h-3 w-3 mr-1" />
                              {recipe.slowCookerHours}h {recipe.slowCookerSetting === 'low' ? 'LOW' : 'HIGH'}
                            </Badge>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle className="line-clamp-1 text-base">{recipe.title}</CardTitle>
                          <CardDescription className="line-clamp-2 text-sm">
                            {recipe.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              <span>Prep: {recipe.prepTime}m</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Flame className="h-3 w-3" />
                              <span>Cocción: {Math.floor(recipe.cookTime / 60)}h</span>
                            </div>
                            <Badge variant="outline" className={cn(
                              "text-xs",
                              recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                              recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                              recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                            )}>
                              {recipe.difficulty === 'facil' ? 'Fácil' : 
                               recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {paginatedRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (index % ITEMS_PER_PAGE) * 0.01 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="hover:shadow-lg transition-all cursor-pointer group">
                        <div className="flex">
                          <div className="w-40 h-32 relative flex-shrink-0 overflow-hidden rounded-l-lg bg-gradient-to-br from-orange-100 to-amber-100">
                            <img
                              src={recipe.imageUrl}
                              alt={recipe.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.src = `/images/recipes/placeholder-${recipe.mealType}.png`
                              }}
                            />
                          </div>
                          <div className="flex-1 p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                                <CardDescription className="line-clamp-1 mt-1">
                                  {recipe.description}
                                </CardDescription>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                <span className="font-medium">{recipe.averageRating.toFixed(1)}</span>
                                <span className="text-muted-foreground text-sm">({recipe.ratingCount})</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground flex-wrap">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                Prep: {recipe.prepTime}m
                              </div>
                              <div className="flex items-center gap-1">
                                <Timer className="h-4 w-4 text-orange-500" />
                                {recipe.slowCookerHours}h {recipe.slowCookerSetting === 'low' ? 'LOW' : 'HIGH'}
                              </div>
                              <Badge variant="outline" className={cn(
                                "text-xs",
                                recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                                recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                                recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                              )}>
                                {recipe.difficulty === 'facil' ? 'Fácil' : 
                                 recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex flex-col items-center gap-4">
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  {getPageNumbers().map((page, index) => (
                    page === '...' ? (
                      <span key={`ellipsis-${index}`} className="px-2 text-muted-foreground">...</span>
                    ) : (
                      <Button
                        key={page}
                        variant={currentPage === page ? 'default' : 'outline'}
                        size="icon"
                        onClick={() => goToPage(page as number)}
                        className={cn(
                          "w-10 h-10",
                          currentPage === page && "bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700"
                        )}
                      >
                        {page}
                      </Button>
                    )
                  ))}
                  
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="text-sm text-muted-foreground">
                  Página {currentPage} de {totalPages} ({(filteredRecipes.length ?? 0).toLocaleString()} recetas)
                </div>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

// Filter Content Component
function FilterContent({ 
  filters, 
  updateFilter, 
  clearFilters,
  onApply 
}: { 
  filters: { mealType: string; difficulty: string }
  updateFilter: (key: string, value: string) => void
  clearFilters: () => void
  onApply: () => void
}) {
  return (
    <div className="space-y-6">
      {/* Meal Type */}
      <div>
        <label className="text-sm font-medium mb-3 block">Tipo de Plato</label>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={filters.mealType === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => updateFilter('mealType', 'all')}
            className={filters.mealType === 'all' ? 'bg-gradient-to-r from-orange-500 to-amber-600' : ''}
          >
            Todos
          </Button>
          {mealTypes.map(type => (
            <Button
              key={type.value}
              variant={filters.mealType === type.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('mealType', filters.mealType === type.value ? 'all' : type.value)}
              className={filters.mealType === type.value ? 'bg-gradient-to-r from-orange-500 to-amber-600' : ''}
            >
              {type.icon} {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Difficulty */}
      <div>
        <label className="text-sm font-medium mb-3 block">Dificultad</label>
        <div className="flex gap-2">
          <Button
            variant={filters.difficulty === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => updateFilter('difficulty', 'all')}
            className={filters.difficulty === 'all' ? 'bg-gradient-to-r from-orange-500 to-amber-600' : ''}
          >
            Todas
          </Button>
          {difficulties.map(diff => (
            <Button
              key={diff.value}
              variant={filters.difficulty === diff.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('difficulty', filters.difficulty === diff.value ? 'all' : diff.value)}
              className={filters.difficulty === diff.value ? 'bg-gradient-to-r from-orange-500 to-amber-600' : ''}
            >
              {diff.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={clearFilters} className="flex-1">
          Limpiar
        </Button>
        <Button onClick={onApply} className="flex-1 bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700">
          Aplicar
        </Button>
      </div>
    </div>
  )
}
