'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  ShoppingCart,
  Plus,
  Trash2,
  X,
  Search,
  ChefHat,
  List,
  Share2,
  Copy,
  Check,
  MessageCircle,
  Mail,
  Download,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Separator } from '@/components/ui/separator'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useShoppingListStore } from '@/store'
import { toast } from 'sonner'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

// Demo ingredients database
const ingredientsDB = [
  { id: '1', name: 'Arroz', category: 'cereales', unit: 'g' },
  { id: '2', name: 'Pollo', category: 'carnes', unit: 'g' },
  { id: '3', name: 'Tomate', category: 'verduras', unit: 'unidades' },
  { id: '4', name: 'Cebolla', category: 'verduras', unit: 'unidades' },
  { id: '5', name: 'Ajo', category: 'verduras', unit: 'dientes' },
  { id: '6', name: 'Aceite de oliva', category: 'aceites', unit: 'ml' },
  { id: '7', name: 'Sal', category: 'condimentos', unit: 'g' },
  { id: '8', name: 'Pimienta', category: 'condimentos', unit: 'g' },
  { id: '9', name: 'Leche', category: 'lacteos', unit: 'ml' },
  { id: '10', name: 'Huevos', category: 'huevos', unit: 'unidades' },
]

export default function ComprasPage() {
  const { items, addItem, removeItem, toggleItem, clearChecked, clearAll } = useShoppingListStore()
  const [newItemName, setNewItemName] = useState('')
  const [newItemQuantity, setNewItemQuantity] = useState(1)
  const [newItemUnit, setNewItemUnit] = useState('unidades')
  const [searchQuery, setSearchQuery] = useState('')
  const [shareDialogOpen, setShareDialogOpen] = useState(false)
  const [copied, setCopied] = useState(false)

  const addCustomItem = () => {
    if (!newItemName.trim()) {
      toast.error('Ingresa un nombre para el item')
      return
    }
    addItem({
      shoppingListId: 'default',
      ingredientId: null,
      customName: newItemName,
      quantity: newItemQuantity,
      unit: newItemUnit,
      isChecked: false,
      notes: null,
    })
    setNewItemName('')
    setNewItemQuantity(1)
    toast.success('Item añadido a la lista')
  }

  const addIngredientFromDB = (ingredient: typeof ingredientsDB[0]) => {
    const existing = items.find(item => 
      item.customName === ingredient.name || item.ingredientId === ingredient.id
    )
    if (existing) {
      toast.info(`${ingredient.name} ya está en la lista`)
      return
    }
    addItem({
      shoppingListId: 'default',
      ingredientId: ingredient.id,
      customName: ingredient.name,
      quantity: 1,
      unit: ingredient.unit,
      isChecked: false,
      notes: null,
    })
    toast.success(`${ingredient.name} añadido`)
  }

  const filteredIngredients = ingredientsDB.filter(ing =>
    ing.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const uncheckedItems = items.filter(item => !item.isChecked)
  const checkedItems = items.filter(item => item.isChecked)

  const units = ['unidades', 'g', 'kg', 'ml', 'l', 'cucharadas', 'cucharaditas', 'piezas']

  // Generate shareable text
  const generateShareText = () => {
    const unchecked = items.filter(item => !item.isChecked)
    const header = `🛒 Lista de Compras - CocinaViva\n${'='.repeat(30)}\n\n`
    const itemsText = unchecked.map(item => `☐ ${item.customName} (${item.quantity} ${item.unit})`).join('\n')
    const footer = `\n\n${'─'.repeat(30)}\n📱 Generado con CocinaViva`
    return header + itemsText + footer
  }

  // Copy to clipboard
  const copyToClipboard = async () => {
    const text = generateShareText()
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      toast.success('Lista copiada al portapapeles')
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error('No se pudo copiar la lista')
    }
  }

  // Share via WhatsApp
  const shareWhatsApp = () => {
    const text = encodeURIComponent(generateShareText())
    window.open(`https://wa.me/?text=${text}`, '_blank')
  }

  // Share via Telegram
  const shareTelegram = () => {
    const text = encodeURIComponent(generateShareText())
    window.open(`https://t.me/share/url?text=${text}`, '_blank')
  }

  // Share via Email
  const shareEmail = () => {
    const subject = encodeURIComponent('Mi Lista de Compras - CocinaViva')
    const body = encodeURIComponent(generateShareText())
    window.open(`mailto:?subject=${subject}&body=${body}`, '_blank')
  }

  // Download as text file
  const downloadList = () => {
    const text = generateShareText()
    const blob = new Blob([text], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'lista-compras-cocinaviva.txt'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('Lista descargada')
  }

  // Share via Web Share API (mobile)
  const shareNative = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Mi Lista de Compras',
          text: generateShareText(),
        })
        toast.success('Lista compartida')
      } catch {
        // User cancelled or error
      }
    } else {
      copyToClipboard()
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
                  <ShoppingCart className="h-8 w-8 text-orange-500" />
                  Lista de Compras
                </h1>
                <p className="text-muted-foreground">
                  Gestiona los ingredientes que necesitas para tus recetas
                </p>
              </div>
              
              {/* Share Button */}
              {items.length > 0 && (
                <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 shadow-lg">
                      <Share2 className="h-4 w-4 mr-2" />
                      Compartir Lista
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <Share2 className="h-5 w-5 text-green-500" />
                        Compartir Lista de Compras
                      </DialogTitle>
                      <DialogDescription>
                        Comparte tu lista con familia y amigos
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      {/* Native Share (Mobile) */}
                      {typeof navigator !== 'undefined' && navigator.share && (
                        <Button 
                          onClick={shareNative}
                          className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600"
                        >
                          <Share2 className="h-4 w-4 mr-2" />
                          Compartir (App nativa)
                        </Button>
                      )}
                      
                      {/* Copy to Clipboard */}
                      <Button 
                        variant="outline" 
                        onClick={copyToClipboard}
                        className="w-full"
                      >
                        {copied ? (
                          <>
                            <Check className="h-4 w-4 mr-2 text-green-500" />
                            ¡Copiado!
                          </>
                        ) : (
                          <>
                            <Copy className="h-4 w-4 mr-2" />
                            Copiar al portapapeles
                          </>
                        )}
                      </Button>
                      
                      {/* WhatsApp */}
                      <Button 
                        variant="outline" 
                        onClick={shareWhatsApp}
                        className="w-full bg-green-50 hover:bg-green-100 border-green-200"
                      >
                        <MessageCircle className="h-4 w-4 mr-2 text-green-600" />
                        Compartir por WhatsApp
                      </Button>
                      
                      {/* Telegram */}
                      <Button 
                        variant="outline" 
                        onClick={shareTelegram}
                        className="w-full bg-blue-50 hover:bg-blue-100 border-blue-200"
                      >
                        <svg className="h-4 w-4 mr-2 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.562 8.161c-.18 1.897-.962 6.502-1.359 8.627-.168.9-.5 1.201-.82 1.23-.697.064-1.226-.461-1.901-.903-1.056-.692-1.653-1.123-2.678-1.799-1.185-.781-.417-1.21.258-1.911.177-.184 3.247-2.977 3.307-3.23.007-.032.015-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.139-5.062 3.345-.479.329-.913.489-1.302.481-.428-.009-1.252-.242-1.865-.442-.751-.244-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.831-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635.099-.002.321.023.465.141.121.1.154.234.17.331.015.099.035.32.019.494z"/>
                        </svg>
                        Compartir por Telegram
                      </Button>
                      
                      {/* Email */}
                      <Button 
                        variant="outline" 
                        onClick={shareEmail}
                        className="w-full"
                      >
                        <Mail className="h-4 w-4 mr-2" />
                        Enviar por Email
                      </Button>
                      
                      {/* Download */}
                      <Button 
                        variant="outline" 
                        onClick={downloadList}
                        className="w-full"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Descargar como archivo
                      </Button>
                      
                      {/* Preview */}
                      <div className="mt-4 p-3 bg-muted rounded-lg">
                        <p className="text-xs text-muted-foreground mb-2">Vista previa:</p>
                        <pre className="text-xs whitespace-pre-wrap font-mono">
                          {generateShareText().slice(0, 200)}...
                        </pre>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Shopping List */}
            <div className="lg:col-span-2 space-y-6">
              {/* Quick Add */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Plus className="h-5 w-5" />
                    Añadir item
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    <Input
                      placeholder="Nombre del ingrediente"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      className="flex-1 min-w-[200px]"
                      onKeyDown={(e) => e.key === 'Enter' && addCustomItem()}
                    />
                    <Input
                      type="number"
                      min={0.1}
                      step={0.1}
                      value={newItemQuantity}
                      onChange={(e) => setNewItemQuantity(parseFloat(e.target.value) || 1)}
                      className="w-20"
                    />
                    <select
                      value={newItemUnit}
                      onChange={(e) => setNewItemUnit(e.target.value)}
                      className="border rounded-md px-3 py-2 text-sm"
                    >
                      {units.map(unit => (
                        <option key={unit} value={unit}>{unit}</option>
                      ))}
                    </select>
                    <Button onClick={addCustomItem}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Items List */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <List className="h-5 w-5" />
                        Tu lista
                      </CardTitle>
                      <CardDescription>
                        {items.length} items • {uncheckedItems.length} pendientes
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      {checkedItems.length > 0 && (
                        <Button variant="outline" size="sm" onClick={clearChecked}>
                          <X className="h-4 w-4 mr-1" />
                          Limpiar completados
                        </Button>
                      )}
                      {items.length > 0 && (
                        <Button variant="outline" size="sm" onClick={clearAll}>
                          <Trash2 className="h-4 w-4 mr-1" />
                          Vaciar lista
                        </Button>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {items.length === 0 ? (
                    <div className="text-center py-12">
                      <ChefHat className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Lista vacía</h3>
                      <p className="text-muted-foreground">
                        Añade ingredientes desde las recetas o manualmente
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Unchecked Items */}
                      {uncheckedItems.length > 0 && (
                        <div className="space-y-2">
                          {uncheckedItems.map((item) => (
                            <motion.div
                              key={item.id}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors"
                            >
                              <Checkbox
                                checked={item.isChecked}
                                onCheckedChange={() => toggleItem(item.id)}
                              />
                              <div className="flex-1">
                                <span className="font-medium">{item.customName}</span>
                                {item.notes && (
                                  <span className="text-sm text-muted-foreground ml-2">
                                    ({item.notes})
                                  </span>
                                )}
                              </div>
                              <Badge variant="outline">
                                {item.quantity} {item.unit}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeItem(item.id)}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground" />
                              </Button>
                            </motion.div>
                          ))}
                        </div>
                      )}

                      {/* Separator */}
                      {checkedItems.length > 0 && uncheckedItems.length > 0 && (
                        <Separator />
                      )}

                      {/* Checked Items */}
                      {checkedItems.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm text-muted-foreground font-medium">
                            Completados ({checkedItems.length})
                          </p>
                          {checkedItems.map((item) => (
                            <motion.div
                              key={item.id}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              className="flex items-center gap-3 p-3 rounded-lg bg-muted/50"
                            >
                              <Checkbox
                                checked={item.isChecked}
                                onCheckedChange={() => toggleItem(item.id)}
                              />
                              <div className="flex-1">
                                <span className="font-medium line-through text-muted-foreground">
                                  {item.customName}
                                </span>
                              </div>
                              <Badge variant="outline" className="opacity-50">
                                {item.quantity} {item.unit}
                              </Badge>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeItem(item.id)}
                              >
                                <Trash2 className="h-4 w-4 text-muted-foreground" />
                              </Button>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Quick Add from Database */}
            <div className="space-y-6">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg">Ingredientes comunes</CardTitle>
                  <CardDescription>
                    Añade rápidamente ingredientes frecuentes
                  </CardDescription>
                  <div className="relative mt-2">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar ingrediente..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {filteredIngredients.map((ing) => (
                      <button
                        key={ing.id}
                        onClick={() => addIngredientFromDB(ing)}
                        className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-muted transition-colors text-left"
                      >
                        <span>{ing.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {ing.unit}
                        </Badge>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
