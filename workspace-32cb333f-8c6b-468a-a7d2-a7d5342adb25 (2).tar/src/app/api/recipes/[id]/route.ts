import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Helper: verify session cookie and return the authenticated user ID
async function getAuthenticatedUserId(request: NextRequest): Promise<string | null> {
  const sessionId = request.cookies.get('session')?.value
  if (!sessionId) return null
  return sessionId || null
}

// Allowed fields that can be updated by the recipe owner
const ALLOWED_UPDATE_FIELDS = [
  'title',
  'description',
  'imageUrl',
  'prepTime',
  'cookTime',
  'totalTime',
  'servings',
  'difficulty',
  'cuisineType',
  'mealType',
  'toolType',
  'isPublic',
  'categoryId',
] as const

// GET /api/recipes/[id] - Get single recipe by ID or slug
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params

    const recipe = await db.recipe.findFirst({
      where: {
        OR: [{ id }, { slug: id }],
      },
      include: {
        category: true,
        tags: {
          include: {
            tag: true,
          },
        },
        ingredients: {
          include: {
            ingredient: true,
          },
          orderBy: { order: 'asc' },
        },
        steps: {
          orderBy: { stepNumber: 'asc' },
        },
        comments: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
            replies: {
              include: {
                user: {
                  select: {
                    id: true,
                    name: true,
                    avatar: true,
                  },
                },
              },
            },
          },
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
        ratings: {
          select: {
            rating: true,
            userId: true,
          },
        },
        author: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    if (!recipe) {
      return NextResponse.json(
        { success: false, error: 'Receta no encontrada' },
        { status: 404 }
      )
    }

    // Increment view count
    await db.recipe.update({
      where: { id: recipe.id },
      data: { viewCount: { increment: 1 } },
    })

    return NextResponse.json({ success: true, data: recipe })
  } catch (error) {
    console.error('Error fetching recipe:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener la receta' },
      { status: 500 }
    )
  }
}

// PUT /api/recipes/[id] - Update recipe
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Authentication check
    const userId = await getAuthenticatedUserId(request)
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'No autorizado. Inicia sesión para actualizar recetas.' },
        { status: 401 }
      )
    }

    const { id } = await params
    const body = await request.json()

    // Whitelist allowed fields to prevent mass assignment
    const sanitizedData: Record<string, unknown> = {}
    for (const key of ALLOWED_UPDATE_FIELDS) {
      if (key in body) {
        sanitizedData[key] = body[key]
      }
    }

    if (Object.keys(sanitizedData).length === 0) {
      return NextResponse.json(
        { success: false, error: 'No se proporcionaron campos válidos para actualizar' },
        { status: 400 }
      )
    }

    const recipe = await db.recipe.update({
      where: { id },
      data: {
        ...sanitizedData,
        updatedAt: new Date(),
      },
    })

    return NextResponse.json({ success: true, data: recipe })
  } catch (error) {
    console.error('Error updating recipe:', error)
    return NextResponse.json(
      { success: false, error: 'Error al actualizar la receta' },
      { status: 500 }
    )
  }
}

// DELETE /api/recipes/[id] - Delete recipe
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Authentication check
    const userId = await getAuthenticatedUserId(request)
    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'No autorizado. Inicia sesión para eliminar recetas.' },
        { status: 401 }
      )
    }

    const { id } = await params

    await db.recipe.delete({
      where: { id },
    })

    return NextResponse.json({ success: true, message: 'Receta eliminada' })
  } catch (error) {
    console.error('Error deleting recipe:', error)
    return NextResponse.json(
      { success: false, error: 'Error al eliminar la receta' },
      { status: 500 }
    )
  }
}
