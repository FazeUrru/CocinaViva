import { NextRequest, NextResponse } from 'next/server';
import { getFreeRecipeImage, getOptimizedRecipeImage } from '@/lib/recipe-image-service';

// GET /api/recipe-image - Get free image URL for a recipe
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const title = searchParams.get('title') || 'Recipe';
    const description = searchParams.get('description') || '';
    const mealType = searchParams.get('mealType') || 'almuerzo';
    const toolType = searchParams.get('toolType') || 'tradicional';
    const width = parseInt(searchParams.get('width') || '640');
    const height = parseInt(searchParams.get('height') || '480');

    const imageUrl = getOptimizedRecipeImage(title, description, mealType, toolType, width, height);

    return NextResponse.json({
      success: true,
      imageUrl,
      title,
      mealType,
    });
  } catch (error) {
    console.error('Error generating recipe image URL:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to generate image URL' },
      { status: 500 }
    );
  }
}
