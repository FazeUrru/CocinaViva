import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/tags - List all tags
export async function GET() {
  try {
    const tags = await db.tag.findMany({
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({ success: true, data: tags })
  } catch (error) {
    console.error('Error fetching tags:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener las etiquetas' },
      { status: 500 }
    )
  }
}
