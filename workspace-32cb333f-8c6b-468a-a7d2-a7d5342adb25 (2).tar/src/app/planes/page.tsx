'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Check,
  X,
  Sparkles,
  Crown,
  Zap,
  Star,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Github,
  Users,
  Share2,
  Clock,
  Cast,
  GraduationCap,
  Flame,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { PaymentModal } from '@/components/payment-modal'
import { LimitedOfferBanner, useLimitedOffer } from '@/components/limited-offer'
import { useUserStore } from '@/store'
import { toast } from 'sonner'

// Time Block Component
const TimeBlock = ({ value, label }: { value: number; label: string }) => (
  <div className="flex flex-col items-center">
    <div className="bg-gradient-to-br from-orange-500 to-red-500 text-white rounded-lg w-12 h-12 flex items-center justify-center text-lg font-bold shadow">
      {value.toString().padStart(2, '0')}
    </div>
    <span className="text-xs text-gray-500 dark:text-gray-400 mt-1">{label}</span>
  </div>
)

// Countdown Timer Component for Limited Offer
function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  })

  useEffect(() => {
    const offerEndDate = new Date('2025-03-20T23:59:59').getTime()

    const updateCountdown = () => {
      const now = new Date().getTime()
      const distance = offerEndDate - now

      if (distance < 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
        return
      }

      setTimeLeft({
        days: Math.floor(distance / (1000 * 60 * 60 * 24)),
        hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((distance % (1000 * 60)) / 1000)
      })
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex items-center gap-1">
      <TimeBlock value={timeLeft.days} label="Días" />
      <span className="text-xl font-bold text-orange-400">:</span>
      <TimeBlock value={timeLeft.hours} label="Horas" />
      <span className="text-xl font-bold text-orange-400">:</span>
      <TimeBlock value={timeLeft.minutes} label="Min" />
      <span className="text-xl font-bold text-orange-400">:</span>
      <TimeBlock value={timeLeft.seconds} label="Seg" />
    </div>
  )
}

const faqs = [
  {
    question: '¿Puedo cancelar mi suscripción en cualquier momento?',
    answer: 'Sí, puedes cancelar tu suscripción en cualquier momento desde la configuración de tu cuenta. Seguirás teniendo acceso hasta el final del período de pago.',
  },
  {
    question: '¿Qué pasa cuando termina mi prueba gratuita?',
    answer: 'Al finalizar los 7 días de prueba, se te cobrará automáticamente el plan seleccionado. Si no te convence, puedes cancelar y volver al plan gratuito. IMPORTANTE: Solo puedes probar UN plan una vez, no ambos.',
  },
  {
    question: '¿Cómo funcionan los favoritos en cada plan?',
    answer: 'El plan Básico incluye 10 favoritos, Ultra te permite hasta 25 favoritos al mes, y MasterChef ofrece favoritos ilimitados.',
  },
  {
    question: '¿Puedo compartir mi plan con otros?',
    answer: 'Sí, puedes compartir tu plan Ultra o MasterChef con 1 persona adicional por 1,99€/mes extra. Cada persona tendrá acceso completo al plan.',
  },
  {
    question: '¿Los logros se pierden si cambio de plan?',
    answer: 'No, los logros desbloqueados se conservan. Sin embargo, algunos logros premium solo son accesibles con planes superiores.',
  },
  {
    question: '¿Qué métodos de pago aceptan?',
    answer: 'Aceptamos tarjetas de crédito/débito (Visa, Mastercard, American Express), PayPal y Google Pay.',
  },
  {
    question: '¿Hay descuento para estudiantes o carnet joven?',
    answer: 'Sí, ofrecemos un 13% de descuento adicional para titulares del Carnet Joven. Contacta con soporte con tu documento verificado.',
  },
  {
    question: '¿Cómo accedo a las funciones de IA?',
    answer: 'Las funciones de IA, como filtros inteligentes y sugerencias personalizadas, están disponibles exclusivamente en el plan MasterChef.',
  },
]

export default function PlanesPage() {
  const [annualBilling, setAnnualBilling] = useState(true)
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null)
  const [showYoungCardDiscount, setShowYoungCardDiscount] = useState(false)
  const [paymentModal, setPaymentModal] = useState<{ isOpen: boolean; plan: 'ultra' | 'masterchef' } | null>(null)
  const { subscription, startTrial, subscribe, cancelSubscription } = useUserStore()
  const [trialTimeRemaining, setTrialTimeRemaining] = useState<string>('')
  const isLimitedOfferActive = useLimitedOffer()
  
  // 27% limited offer discount
  const LIMITED_OFFER_DISCOUNT = 0.27 // 27% discount
  
  // Calculate trial time remaining
  useEffect(() => {
    if (subscription.isTrialActive && subscription.trialEndDate) {
      const updateTimer = () => {
        const now = new Date()
        const trialEnd = new Date(subscription.trialEndDate!)
        const diff = trialEnd.getTime() - now.getTime()
        
        if (diff <= 0) {
          setTrialTimeRemaining('¡Tiempo agotado!')
          // Cuando termina la prueba, se cobra automáticamente
          const plan = subscription.plan
          if (plan !== 'basic') {
            subscribe(plan)
            toast.success(`¡Bienvenido al plan ${plan === 'ultra' ? 'Ultra' : 'MasterChef'}! Tu suscripción ha comenzado.`)
          }
        } else {
          const days = Math.floor(diff / (1000 * 60 * 60 * 24))
          const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
          const seconds = Math.floor((diff % (1000 * 60)) / 1000)
          setTrialTimeRemaining(`${days}d ${hours}h ${minutes}m ${seconds}s`)
        }
      }
      
      updateTimer()
      const interval = setInterval(updateTimer, 1000)
      return () => clearInterval(interval)
    }
  }, [subscription.isTrialActive, subscription.trialEndDate, subscription.plan, subscribe])
  
  const handleSubscribe = (plan: 'ultra' | 'masterchef') => {
    // Si ya tiene una prueba activa
    if (subscription.isTrialActive) {
      toast.error('Ya tienes una prueba activa. Espera a que termine.')
      return
    }
    
    // Si ya usó la prueba gratuita y es mensual
    if (subscription.hasUsedTrial && !annualBilling) {
      toast.error('Ya usaste tu prueba gratuita. Debes suscribirte anualmente.')
      return
    }
    
    // Si ya tiene un plan activo
    if (subscription.plan !== 'basic' && subscription.isSubscriptionActive) {
      toast.error('Ya tienes un plan activo. Cancela tu plan actual primero.')
      return
    }
    
    // Siempre abrir el modal de pago
    setPaymentModal({ isOpen: true, plan })
  }
  
  const handlePaymentSuccess = () => {
    if (!paymentModal) return
    
    if (annualBilling) {
      // Pago directo anual
      subscribe(paymentModal.plan)
      toast.success(`¡Te has suscrito al plan ${paymentModal.plan === 'ultra' ? 'Ultra' : 'MasterChef'}!`)
    } else {
      // Prueba gratuita de 7 días
      startTrial(paymentModal.plan)
      toast.success(`¡Prueba gratuita de 7 días iniciada! Al finalizar se te cobrará automáticamente.`)
    }
    setPaymentModal(null)
  }
  
  // Calcular precio con descuentos
  const getPrice = (plan: 'ultra' | 'masterchef') => {
    const basePrice = plan === 'ultra' ? (annualBilling ? 68.64 : 5.50) : (annualBilling ? 128.40 : 11.50)
    let finalPrice = basePrice
    
    // Apply 27% limited offer discount if active (ONLY for annual billing)
    if (isLimitedOfferActive && annualBilling) {
      finalPrice = finalPrice * (1 - LIMITED_OFFER_DISCOUNT)
    }
    
    // Apply young card discount
    if (showYoungCardDiscount && annualBilling) {
      finalPrice = finalPrice * 0.87
    }
    
    return finalPrice
  }
  
  // Get original price without discounts
  const getOriginalPrice = (plan: 'ultra' | 'masterchef') => {
    return plan === 'ultra' ? (annualBilling ? 68.64 : 5.50) : (annualBilling ? 128.40 : 11.50)
  }
  
  // Calcular precios con descuentos
  const applyYoungCardDiscount = (price: number) => {
    let finalPrice = price
    
    // Apply 27% limited offer discount if active (ONLY for annual billing)
    if (isLimitedOfferActive && annualBilling) {
      finalPrice = finalPrice * (1 - LIMITED_OFFER_DISCOUNT)
    }
    
    if (showYoungCardDiscount) {
      return finalPrice * 0.87 // 13% descuento
    }
    return finalPrice
  }
  
  const getDiscountPercentage = () => {
    let total = 18 // Base annual discount
    
    // Add 27% limited offer
    if (isLimitedOfferActive && annualBilling) {
      total += 9 // Effective ~27% off original
    }
    
    if (showYoungCardDiscount) {
      return total + 13
    }
    return total
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-orange-500 to-green-500 py-16 text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-5xl font-bold mb-4"
            >
              Elige tu Plan
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-xl text-white/90 mb-4"
            >
              Encuentra el plan perfecto para tu aventura culinaria
            </motion.p>
            
            {/* Limited Time Offer Banner - 27% OFF until March 20 */}
            {isLimitedOfferActive && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.15 }}
                className="max-w-4xl mx-auto mb-6"
              >
                <div className="bg-white/95 dark:bg-gray-900/95 rounded-2xl p-4 md:p-6 shadow-2xl border-2 border-orange-400">
                  <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                    {/* Offer Info */}
                    <div className="text-center md:text-left">
                      <div className="flex items-center gap-2 justify-center md:justify-start mb-2">
                        <Flame className="w-6 h-6 text-orange-500 animate-pulse" />
                        <span className="text-2xl md:text-3xl font-black text-orange-500">
                          OFERTA 27% DESCUENTO
                        </span>
                        <Flame className="w-6 h-6 text-orange-500 animate-pulse" />
                      </div>
                      <p className="text-gray-600 dark:text-gray-300 text-sm md:text-base">
                        ¡Solo hasta el <strong className="text-orange-500">20 de Marzo de 2025</strong>!
                      </p>
                    </div>
                    
                    {/* Countdown */}
                    <div className="flex items-center gap-1">
                      <Clock className="w-5 h-5 text-orange-500" />
                      <CountdownTimer />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            
            {/* Trial Countdown - CONTADOR */}
            {subscription.isTrialActive && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white/20 backdrop-blur rounded-xl p-4 max-w-md mx-auto mb-6"
              >
                <div className="flex items-center gap-2 justify-center mb-2">
                  <Clock className="h-5 w-5" />
                  <span className="font-semibold">Prueba Gratuita Activa</span>
                </div>
                <div className="text-3xl font-bold font-mono">{trialTimeRemaining}</div>
                <p className="text-sm text-white/80 mt-1">
                  Tiempo restante - Al finalizar se cobrará automáticamente
                </p>
                <p className="text-xs text-white/70 mt-2">
                  Si no te convence, cancela antes de que termine para volver al plan gratuito
                </p>
              </motion.div>
            )}
            
            {/* Mensaje si ya usó la prueba */}
            {subscription.hasUsedTrial && !subscription.isTrialActive && subscription.plan === 'basic' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-amber-500/80 backdrop-blur rounded-xl p-4 max-w-md mx-auto mb-6"
              >
                <div className="flex items-center gap-2 justify-center mb-2">
                  <Clock className="h-5 w-5" />
                  <span className="font-semibold">Prueba Ya Utilizada</span>
                </div>
                <p className="text-sm">
                  Ya usaste tu prueba gratuita de 7 días. Para disfrutar de premium, suscríbete a un plan.
                </p>
              </motion.div>
            )}
            
            {/* Billing Toggle */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="flex flex-col items-center justify-center gap-4"
            >
              <div className="flex items-center gap-4">
                <Label className={!annualBilling ? 'text-white' : 'text-white/60'}>Mensual (Prueba)</Label>
                <Switch
                  checked={annualBilling}
                  onCheckedChange={setAnnualBilling}
                />
                <Label className={annualBilling ? 'text-white' : 'text-white/60'}>
                  Anual
                  <Badge className="ml-2 bg-yellow-400 text-yellow-900">-{getDiscountPercentage()}%</Badge>
                </Label>
              </div>
              
              {/* Carnet Joven Toggle */}
              <div className="flex items-center gap-2 mt-2">
                <Button
                  variant={showYoungCardDiscount ? "secondary" : "outline"}
                  size="sm"
                  onClick={() => setShowYoungCardDiscount(!showYoungCardDiscount)}
                  className={`text-white border-white/30 ${showYoungCardDiscount ? 'bg-green-500 hover:bg-green-600' : 'hover:bg-white/10'}`}
                >
                  <GraduationCap className="h-4 w-4 mr-2" />
                  {showYoungCardDiscount ? 'Carnet Joven Aplicado (-13%)' : 'Tengo Carnet Joven'}
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {/* Basic Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-2xl">Básico</CardTitle>
                    <CardDescription>Perfecto para empezar a cocinar</CardDescription>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">Gratis</span>
                    </div>
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-blue-600 hover:underline"
                      onClick={() => window.open('https://github.com/FazeUrru/CocinaViva', '_blank')}
                    >
                      <Github className="h-4 w-4 mr-1" />
                      Ver Código en GitHub
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* CARACTERÍSTICAS GRATUITAS - SOLO ESTO */}
                    <div className="bg-green-50 dark:bg-green-950/30 -mx-4 px-4 py-2 mb-2">
                      <p className="text-xs text-green-600 font-semibold">✅ INCLUIDO EN PLAN GRATUITO</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Acceso a 500 recetas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Búsqueda simple</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Favoritos (limitado a 10)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Crear recetas propias (Gratis)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Reseñas de recetas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">125 logros disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Modo Thermomix</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Calculadora nutricional</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Recetario Social (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm font-semibold">SIN PUBLICIDAD</span>
                    </div>
                    <Separator className="my-2" />
                    {/* COMPARTIR INCLUIDO SIN PAGAR */}
                    <div className="flex items-center gap-2">
                      <Share2 className="h-4 w-4 text-green-500" />
                      <span className="text-sm text-green-600 font-medium">Compartir recetas (Gratis)</span>
                    </div>
                    <Separator className="my-2" />
                    {/* FUNCIONES OCULTAS/ENCRYPTADAS */}
                    <div className="bg-gray-100 dark:bg-gray-800 -mx-4 px-4 py-2">
                      <p className="text-xs text-gray-500 font-semibold">🔒 OCULTO - SOLO PLANES DE PAGO</p>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">800+ recetas adicionales</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Filtros Pro (Populares/Cooksnaps)</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Búsqueda avanzada</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Favoritos ilimitados</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">175+ logros adicionales</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Planificador semanal</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Asistente de voz (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Acceso anticipado a funciones</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Chef Virtual IA (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground opacity-60">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Descargar recetas</span>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-2">
                    <Button variant="outline" className="w-full" disabled={subscription.plan === 'basic' && !subscription.isTrialActive}>
                      {subscription.plan === 'basic' && !subscription.isTrialActive ? 'Plan Actual' : 'Plan Gratuito'}
                    </Button>
                    {/* Botón Chromecast - Transmite CocinaViva */}
                    <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => {
                      // Intentar usar la API de Google Cast si está disponible
                      if (typeof window !== 'undefined' && 'PresentationRequest' in window) {
                        const presentationRequest = new PresentationRequest([window.location.href])
                        presentationRequest.start().then((connection) => {
                          toast.success('Transmitiendo CocinaViva a tu dispositivo')
                          connection.onclose = () => toast.info('Transmisión finalizada')
                        }).catch(() => {
                          toast.info('Abre la app de Google Home y busca dispositivos Chromecast')
                        })
                      } else {
                        toast.info('Para transmitir CocinaViva: Abre Google Home > Transmite > Selecciona tu Chromecast')
                      }
                    }}>
                      <Cast className="h-4 w-4 mr-2" />
                      Transmitir CocinaViva
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>

              {/* Ultra Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="h-full border-orange-500 shadow-lg relative">
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-orange-500">
                    POPULAR
                  </Badge>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Zap className="h-6 w-6 text-orange-500" />
                      <CardTitle className="text-2xl">Ultra</CardTitle>
                    </div>
                    <CardDescription>Para cocineros entusiastas</CardDescription>
                    <div className="mt-4">
                      {annualBilling ? (
                        <>
                          <div className="text-sm text-muted-foreground line-through">85.68€/año</div>
                          <span className="text-4xl font-bold">{applyYoungCardDiscount(68.64).toFixed(2).replace('.', ',')}</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/año</span>
                          <div className="text-sm text-muted-foreground mt-1">
                            ({(applyYoungCardDiscount(68.64) / 12).toFixed(2).replace('.', ',')}€/mes)
                          </div>
                          <div className="text-sm text-green-600 font-semibold">
                            Ahorras {(85.68 - applyYoungCardDiscount(68.64)).toFixed(2).replace('.', ',')}€ al año (-{getDiscountPercentage()}%)
                          </div>
                          {showYoungCardDiscount && (
                            <Badge className="mt-1 bg-green-500">Carnet Joven Aplicado</Badge>
                          )}
                        </>
                      ) : (
                        <>
                          <span className="text-4xl font-bold">5,50</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/mes</span>
                          <div className="text-sm text-amber-600 mt-1">
                            7 días de prueba gratis
                          </div>
                        </>
                      )}
                    </div>
                    {!subscription.hasUsedTrial && !annualBilling && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant="secondary" className="bg-green-100 text-green-700">
                          Prueba gratuita disponible
                        </Badge>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* FUNCIONES EXCLUSIVAS ULTRA */}
                    <div className="bg-orange-50 dark:bg-orange-950/30 -mx-4 px-4 py-2 mb-2">
                      <p className="text-xs text-orange-600 font-semibold">⚡ FUNCIONES EXCLUSIVAS ULTRA</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Acceso a 800 recetas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Búsqueda avanzada con filtros</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Favoritos limitado a 25</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Crear recetas propias</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Reseñas verificadas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Filtros Pro (Populares/Cooksnaps)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">175 logros disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Modo Thermomix completo</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Planificador semanal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Calculadora nutricional</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm font-semibold">Sin publicidad</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Acceso anticipado a funciones</span>
                    </div>
                    <Separator className="my-2" />
                    {/* RECETAS DESCARGADAS - NUEVO */}
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-orange-500 flex-shrink-0" />
                      <span className="text-sm text-orange-600 font-medium">Recetas descargadas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Exportar recetas</span>
                    </div>
                    <Separator className="my-2" />
                    {/* COMPARTIR INCLUIDO SIN PAGAR */}
                    <div className="flex items-center gap-2">
                      <Share2 className="h-4 w-4 text-orange-500" />
                      <span className="text-sm text-orange-600 font-medium">Compartir recetas incluido</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span className="text-sm">Compartir plan: +1,99€/mes (2 personas)</span>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-2">
                    <Button 
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600"
                      onClick={() => handleSubscribe('ultra')}
                      disabled={subscription.plan === 'ultra' || (subscription.isTrialActive && subscription.plan !== 'ultra') || (subscription.hasUsedTrial && !annualBilling)}
                    >
                      {subscription.plan === 'ultra' ? 'Plan Actual' : annualBilling ? 'Suscribirse' : subscription.hasUsedTrial ? 'Prueba ya usada' : 'Comenzar prueba gratis'}
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      {annualBilling ? 'Suscripción anual - Cancela cuando quieras' : '7 días gratis - Al finalizar se cobra automáticamente'}
                    </p>
                    {/* Botón Chromecast - Transmite CocinaViva */}
                    <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => {
                      // Intentar usar la API de Google Cast si está disponible
                      if (typeof window !== 'undefined' && 'PresentationRequest' in window) {
                        const presentationRequest = new PresentationRequest([window.location.href])
                        presentationRequest.start().then((connection) => {
                          toast.success('Transmitiendo CocinaViva a tu dispositivo')
                          connection.onclose = () => toast.info('Transmisión finalizada')
                        }).catch(() => {
                          toast.info('Abre la app de Google Home y busca dispositivos Chromecast')
                        })
                      } else {
                        toast.info('Para transmitir CocinaViva: Abre Google Home > Transmite > Selecciona tu Chromecast')
                      }
                    }}>
                      <Cast className="h-4 w-4 mr-2" />
                      Transmitir CocinaViva
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>

              {/* MasterChef Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <Card className="h-full border-purple-500 shadow-lg relative bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20">
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-500">
                    <Crown className="h-3 w-3 mr-1" />
                    PREMIUM
                  </Badge>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Crown className="h-6 w-6 text-purple-500" />
                      <CardTitle className="text-2xl">Master Chef</CardTitle>
                    </div>
                    <CardDescription>La experiencia culinaria completa</CardDescription>
                    <div className="mt-4">
                      {annualBilling ? (
                        <>
                          <div className="text-sm text-muted-foreground line-through">155.88€/año</div>
                          <span className="text-4xl font-bold">{applyYoungCardDiscount(128.40).toFixed(2).replace('.', ',')}</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/año</span>
                          <div className="text-sm text-muted-foreground mt-1">
                            ({(applyYoungCardDiscount(128.40) / 12).toFixed(2).replace('.', ',')}€/mes)
                          </div>
                          <div className="text-sm text-green-600 font-semibold">
                            Ahorras {(155.88 - applyYoungCardDiscount(128.40)).toFixed(2).replace('.', ',')}€ al año (-{getDiscountPercentage()}%)
                          </div>
                          {showYoungCardDiscount && (
                            <Badge className="mt-1 bg-green-500">Carnet Joven Aplicado</Badge>
                          )}
                        </>
                      ) : (
                        <>
                          <span className="text-4xl font-bold">11,50</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/mes</span>
                          <div className="text-sm text-amber-600 mt-1">
                            7 días de prueba gratis
                          </div>
                        </>
                      )}
                    </div>
                    {!subscription.hasUsedTrial && !annualBilling && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                          Prueba gratuita disponible
                        </Badge>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {/* FUNCIONES EXCLUSIVAS MASTERCHEF */}
                    <div className="bg-purple-50 dark:bg-purple-950/30 -mx-4 px-4 py-2 mb-2">
                      <p className="text-xs text-purple-600 font-semibold">👑 FUNCIONES EXCLUSIVAS MASTERCHEF</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Acceso a 1.000+ recetas completas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Filtros IA y Pro</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Guardado y Favoritos Ilimitados</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Crear recetas propias</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Reseñas verificadas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">350 logros disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Modo Thermomix completo</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Planificador semanal avanzado</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Calculadora nutricional avanzada</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Asistente de voz (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm font-semibold">Sin publicidad</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Soporte prioritario 24/7</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Sincronización en la nube</span>
                    </div>
                    {/* FUNCIONES IA */}
                    <Separator className="my-2" />
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-purple-500" />
                      <span className="text-sm text-purple-600 font-medium">Chef Virtual IA (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-purple-500" />
                      <span className="text-sm text-purple-600 font-medium">Análisis Nutricional IA (Beta)</span>
                    </div>
                    {/* RECETAS DESCARGADAS Y FUNCIONES EXCLUSIVAS */}
                    <Separator className="my-2" />
                    <div className="bg-purple-100 dark:bg-purple-900/30 -mx-4 px-4 py-2">
                      <p className="text-xs text-purple-600 font-semibold mb-2">✨ EXCLUSIVO MASTERCHEF</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm font-medium text-purple-600">Recetas descargadas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm font-medium">Descarga recetas en PDF</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm font-medium">Historial de cocina detallado</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm font-medium">Modo sin conexión completo</span>
                    </div>
                    <Separator className="my-2" />
                    {/* COMPARTIR INCLUIDO SIN PAGAR */}
                    <div className="flex items-center gap-2">
                      <Share2 className="h-4 w-4 text-purple-500" />
                      <span className="text-sm text-purple-600 font-medium">Compartir recetas incluido</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="h-4 w-4" />
                      <span className="text-sm">Compartir plan: +1,99€/mes (2 personas)</span>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-2">
                    <Button 
                      className="w-full bg-gradient-to-r from-purple-500 to-indigo-500"
                      onClick={() => handleSubscribe('masterchef')}
                      disabled={subscription.plan === 'masterchef' || (subscription.isTrialActive && subscription.plan !== 'masterchef') || (subscription.hasUsedTrial && !annualBilling)}
                    >
                      {subscription.plan === 'masterchef' ? 'Plan Actual' : annualBilling ? 'Suscribirse' : subscription.hasUsedTrial ? 'Prueba ya usada' : 'Comenzar prueba gratis'}
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      {annualBilling ? 'Suscripción anual - Cancela cuando quieras' : '7 días gratis - Al finalizar se cobra automáticamente'}
                    </p>
                    {/* Botón Chromecast - Transmite CocinaViva */}
                    <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => {
                      // Intentar usar la API de Google Cast si está disponible
                      if (typeof window !== 'undefined' && 'PresentationRequest' in window) {
                        const presentationRequest = new PresentationRequest([window.location.href])
                        presentationRequest.start().then((connection) => {
                          toast.success('Transmitiendo CocinaViva a tu dispositivo')
                          connection.onclose = () => toast.info('Transmisión finalizada')
                        }).catch(() => {
                          toast.info('Abre la app de Google Home y busca dispositivos Chromecast')
                        })
                      } else {
                        toast.info('Para transmitir CocinaViva: Abre Google Home > Transmite > Selecciona tu Chromecast')
                      }
                    }}>
                      <Cast className="h-4 w-4 mr-2" />
                      Transmitir CocinaViva
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Feature Comparison */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-8">Comparación de Funciones</h2>
            
            <div className="overflow-x-auto">
              <table className="w-full max-w-4xl mx-auto">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-4 px-4">Función</th>
                    <th className="text-center py-4 px-4">Básico</th>
                    <th className="text-center py-4 px-4">Ultra</th>
                    <th className="text-center py-4 px-4">MasterChef</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-4">Recetas disponibles</td>
                    <td className="text-center py-3 px-4">500</td>
                    <td className="text-center py-3 px-4">800+</td>
                    <td className="text-center py-3 px-4">1.000+</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Favoritos</td>
                    <td className="text-center py-3 px-4">10</td>
                    <td className="text-center py-3 px-4">25/mes</td>
                    <td className="text-center py-3 px-4">∞</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Logros</td>
                    <td className="text-center py-3 px-4">125</td>
                    <td className="text-center py-3 px-4">175</td>
                    <td className="text-center py-3 px-4">350</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Chef Virtual IA</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Badge>Beta</Badge></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Análisis Nutricional IA</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Badge>Beta</Badge></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Búsqueda avanzada</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Filtros Pro</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Filtros IA</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Compartir plan (+1,99€)</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Temporizador</td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Lista de compras</td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Carnet Joven (-13%)</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b bg-purple-50/50 dark:bg-purple-950/20">
                    <td className="py-3 px-4 font-medium">Descarga recetas en PDF</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b bg-purple-50/50 dark:bg-purple-950/20">
                    <td className="py-3 px-4 font-medium">Historial de cocina detallado</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b bg-purple-50/50 dark:bg-purple-950/20">
                    <td className="py-3 px-4 font-medium">Modo sin conexión completo</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4">Publicidad</td>
                    <td className="text-center py-3 px-4"><Badge variant="secondary">Sin publicidad</Badge></td>
                    <td className="text-center py-3 px-4"><Badge variant="secondary">Sin publicidad</Badge></td>
                    <td className="text-center py-3 px-4"><Badge variant="secondary">Sin publicidad</Badge></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* FAQs */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 max-w-3xl">
            <h2 className="text-3xl font-bold text-center mb-8">Preguntas Frecuentes</h2>
            
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <Card key={index} className="cursor-pointer" onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}>
                  <CardHeader className="py-4">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <HelpCircle className="h-5 w-5 text-orange-500" />
                        {faq.question}
                      </CardTitle>
                      {expandedFaq === index ? (
                        <ChevronUp className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                  </CardHeader>
                  {expandedFaq === index && (
                    <CardContent className="pt-0">
                      <p className="text-muted-foreground">{faq.answer}</p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Contact */}
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl font-bold mb-4">¿Dudas o sugerencias?</h2>
            <p className="text-muted-foreground mb-4">
              Contáctanos en <a href="mailto:iiribasu2010@gmail.com" className="text-orange-500 hover:underline">iiribasu2010@gmail.com</a>
            </p>
            <div className="flex justify-center gap-4 flex-wrap">
              <Button variant="outline" onClick={() => toast.success('Formulario de sugerencias abierto')}>
                <Sparkles className="h-4 w-4 mr-2" />
                Sugerir Función
              </Button>
              <Button variant="outline" onClick={() => window.open('https://github.com/FazeUrru/CocinaViva', '_blank')}>
                <Github className="h-4 w-4 mr-2" />
                Ver Código en GitHub
              </Button>
              <Button variant="ghost" onClick={() => toast.info('Abre la app de Chromecast y selecciona tu dispositivo')}>
                <Cast className="h-4 w-4 mr-2" />
                Enviar a Chromecast
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-6">
              Última actualización: 21 de febrero de 2026
            </p>
          </div>
        </section>
      </main>

      <Footer />
      
      {/* Payment Modal */}
      {paymentModal && (
        <PaymentModal
          isOpen={paymentModal.isOpen}
          onClose={() => setPaymentModal(null)}
          plan={paymentModal.plan}
          isAnnual={annualBilling}
          price={getPrice(paymentModal.plan)}
          onSuccess={handlePaymentSuccess}
        />
      )}
    </div>
  )
}
