"use client"

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Clock, Flame, Sparkles, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import Link from 'next/link'

interface LimitedOfferBannerProps {
  onDismiss?: () => void
  showDismiss?: boolean
}

export function LimitedOfferBanner({ onDismiss, showDismiss = false }: LimitedOfferBannerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isExpired: false
  })

  useEffect(() => {
    // Offer ends on March 20, 2025 at 23:59:59
    const offerEndDate = new Date('2025-03-20T23:59:59').getTime()

    const updateCountdown = () => {
      const now = new Date().getTime()
      const distance = offerEndDate - now

      if (distance < 0) {
        setTimeLeft({
          days: 0,
          hours: 0,
          minutes: 0,
          seconds: 0,
          isExpired: true
        })
        return
      }

      const days = Math.floor(distance / (1000 * 60 * 60 * 24))
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((distance % (1000 * 60)) / 1000)

      setTimeLeft({
        days,
        hours,
        minutes,
        seconds,
        isExpired: false
      })
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)
    return () => clearInterval(interval)
  }, [])

  if (timeLeft.isExpired) {
    return null
  }

  const TimeBlock = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <div className="bg-gradient-to-br from-orange-500 to-red-500 text-white rounded-lg w-14 h-14 md:w-16 md:h-16 flex items-center justify-center text-xl md:text-2xl font-bold shadow-lg">
        {value.toString().padStart(2, '0')}
      </div>
      <span className="text-xs mt-1 text-gray-600 dark:text-gray-400 font-medium">{label}</span>
    </div>
  )

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="relative overflow-hidden"
    >
      {/* Animated background */}
      <div className="absolute inset-0 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 animate-pulse opacity-20" />
      
      {/* Sparkle effects */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-yellow-300 rounded-full"
            initial={{ 
              x: Math.random() * 100 + '%', 
              y: Math.random() * 100 + '%',
              scale: 0 
            }}
            animate={{ 
              scale: [0, 1, 0],
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              delay: Math.random() * 2
            }}
          />
        ))}
      </div>

      <div className="relative bg-gradient-to-r from-orange-50 via-red-50 to-pink-50 dark:from-orange-950/30 dark:via-red-950/30 dark:to-pink-950/30 border-2 border-orange-300 dark:border-orange-700 rounded-2xl p-4 md:p-6">
        {/* Dismiss button */}
        {showDismiss && onDismiss && (
          <button
            onClick={onDismiss}
            className="absolute top-2 right-2 p-1 rounded-full hover:bg-black/10 transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        )}

        <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
          {/* Badge */}
          <div className="flex-shrink-0">
            <motion.div
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-xl px-4 py-2 shadow-lg"
            >
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5" />
                <span className="font-bold text-xl">-27%</span>
              </div>
              <div className="text-xs text-center opacity-90">OFERTA LIMITADA</div>
            </motion.div>
          </div>

          {/* Content */}
          <div className="flex-1 text-center md:text-left">
            <h3 className="text-lg md:text-xl font-bold text-gray-900 dark:text-white mb-1">
              ¡Oferta de Primavera! 
              <span className="text-orange-500 ml-2">27% DE DESCUENTO</span>
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              En todos los planes premium hasta el <strong>20 de Marzo</strong>
            </p>
          </div>

          {/* Countdown */}
          <div className="flex items-center gap-2 md:gap-3">
            <Clock className="w-5 h-5 text-orange-500 animate-pulse hidden md:block" />
            <TimeBlock value={timeLeft.days} label="Días" />
            <span className="text-2xl font-bold text-orange-400">:</span>
            <TimeBlock value={timeLeft.hours} label="Horas" />
            <span className="text-2xl font-bold text-orange-400">:</span>
            <TimeBlock value={timeLeft.minutes} label="Min" />
            <span className="text-2xl font-bold text-orange-400">:</span>
            <TimeBlock value={timeLeft.seconds} label="Seg" />
          </div>

          {/* CTA */}
          <div className="flex-shrink-0">
            <Link href="/planes">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-xl hover:shadow-2xl transition-all animate-bounce"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Ver Oferta
              </Button>
            </Link>
          </div>
        </div>

        {/* Urgency text */}
        <div className="mt-3 text-center">
          <motion.span
            animate={{ opacity: [1, 0.5, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="text-sm font-medium text-red-600 dark:text-red-400"
          >
            ⏰ ¡La oferta termina pronto! No te lo pierdas
          </motion.span>
        </div>
      </div>
    </motion.div>
  )
}

// Hook to check if offer is active
export function useLimitedOffer() {
  const [isActive, setIsActive] = useState(true)

  useEffect(() => {
    const offerEndDate = new Date('2025-03-20T23:59:59').getTime()
    const now = new Date().getTime()
    // Use setTimeout to defer the state update
    const timer = setTimeout(() => {
      setIsActive(now < offerEndDate)
    }, 0)
    return () => clearTimeout(timer)
  }, [])

  return isActive
}

// Compact inline offer badge
export function LimitedOfferBadge() {
  const isActive = useLimitedOffer()
  
  if (!isActive) return null

  return (
    <motion.div
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      className="inline-flex items-center gap-1 bg-gradient-to-r from-orange-500 to-red-500 text-white text-xs px-2 py-1 rounded-full shadow-md"
    >
      <Flame className="w-3 h-3" />
      <span className="font-bold">-27% hasta 20 Mar</span>
    </motion.div>
  )
}

// Price with discount
export function DiscountedPrice({ originalPrice, className = "" }: { originalPrice: number; className?: string }) {
  const isActive = useLimitedOffer()
  const discountPercent = 27
  const discountedPrice = originalPrice * (1 - discountPercent / 100)

  if (!isActive) {
    return <span className={className}>{originalPrice.toFixed(2)}€</span>
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <span className="text-gray-400 line-through text-sm">
        {originalPrice.toFixed(2)}€
      </span>
      <span className="text-lg font-bold text-orange-500">
        {discountedPrice.toFixed(2)}€
      </span>
      <Badge className="bg-red-500 text-xs">
        -{discountPercent}%
      </Badge>
    </div>
  )
}
