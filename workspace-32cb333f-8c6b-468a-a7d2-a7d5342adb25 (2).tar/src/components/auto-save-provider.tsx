'use client'

import { useEffect, useState, useCallback } from 'react'
import { startAutoSave, stopAutoSave, getStorageSize, verifyDataIntegrity, getLastAutosaveTime, createFullBackup } from '@/lib/auto-save'
import { useUserStore } from '@/store'
import { toast } from 'sonner'
import { Save, HardDrive, AlertTriangle, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'

interface AutoSaveProviderProps {
  children: React.ReactNode
}

export function AutoSaveProvider({ children }: AutoSaveProviderProps) {
  const [lastSave, setLastSave] = useState<string | null>(null)
  const [storageStatus, setStorageStatus] = useState<{
    used: number
    available: number
    percentage: number
  } | null>(null)
  const [isSaving, setIsSaving] = useState(false)
  const isAuthenticated = useUserStore((state) => state.isAuthenticated)
  
  // Iniciar auto-guardado cuando el usuario está autenticado
  useEffect(() => {
    if (isAuthenticated) {
      startAutoSave()
      
      // Cargar estado inicial
      setLastSave(getLastAutosaveTime())
      const size = getStorageSize()
      setStorageStatus(size)
      
      // Verificar integridad
      const integrity = verifyDataIntegrity()
      if (!integrity.valid) {
        console.warn('Problemas de integridad detectados:', integrity.issues)
      }
      
      // Actualizar estado cada minuto
      const interval = setInterval(() => {
        setLastSave(getLastAutosaveTime())
        setStorageStatus(getStorageSize())
      }, 60000)
      
      return () => {
        stopAutoSave()
        clearInterval(interval)
      }
    }
  }, [isAuthenticated])
  
  // Guardar manualmente
  const handleManualSave = useCallback(() => {
    setIsSaving(true)
    try {
      createFullBackup()
      setLastSave(getLastAutosaveTime())
      toast.success('Datos guardados correctamente', {
        icon: <CheckCircle className="h-4 w-4 text-green-500" />,
      })
    } catch {
      toast.error('Error al guardar datos')
    } finally {
      setIsSaving(false)
    }
  }, [])
  
  // Formatear tamaño
  const formatSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`
  }
  
  // Formatear tiempo
  const formatTime = (isoString: string | null): string => {
    if (!isoString) return 'Nunca'
    const date = new Date(isoString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    
    if (diff < 60000) return 'Hace un momento'
    if (diff < 3600000) return `Hace ${Math.floor(diff / 60000)} min`
    if (diff < 86400000) return `Hace ${Math.floor(diff / 3600000)} horas`
    return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
  }
  
  return (
    <>
      {children}
      
      {/* Indicador de auto-guardado en la esquina */}
      {isAuthenticated && (
        <div className="fixed bottom-4 right-4 z-50 flex items-center gap-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-background/80 backdrop-blur-sm border shadow-lg"
                  onClick={handleManualSave}
                  disabled={isSaving}
                >
                  {isSaving ? (
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  ) : (
                    <Save className="h-4 w-4" />
                  )}
                  <span className="ml-2 text-xs hidden sm:inline">
                    {formatTime(lastSave)}
                  </span>
                </Button>
              </TooltipTrigger>
              <TooltipContent side="top" className="w-64">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-medium">
                    <HardDrive className="h-4 w-4" />
                    Estado del Almacenamiento
                  </div>
                  {storageStatus && (
                    <>
                      <div className="text-xs space-y-1">
                        <div className="flex justify-between">
                          <span>Usado:</span>
                          <span>{formatSize(storageStatus.used)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Disponible:</span>
                          <span>{formatSize(storageStatus.available)}</span>
                        </div>
                        <div className="w-full bg-secondary rounded-full h-1.5 mt-2">
                          <div
                            className={`h-1.5 rounded-full ${
                              storageStatus.percentage > 80
                                ? 'bg-red-500'
                                : storageStatus.percentage > 50
                                ? 'bg-yellow-500'
                                : 'bg-green-500'
                            }`}
                            style={{ width: `${Math.min(storageStatus.percentage, 100)}%` }}
                          />
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground pt-1 border-t">
                        Último guardado: {formatTime(lastSave)}
                      </div>
                    </>
                  )}
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      )}
    </>
  )
}

export default AutoSaveProvider
