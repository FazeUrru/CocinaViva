'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RefreshCw, ShieldCheck } from 'lucide-react'

interface CaptchaProps {
  onVerify: (verified: boolean) => void
  isVerified: boolean
}

function generateCaptcha() {
  const operations = ['+', '-', '×']
  const operation = operations[Math.floor(Math.random() * operations.length)]
  
  let num1: number, num2: number, answer: number
  
  switch (operation) {
    case '+':
      num1 = Math.floor(Math.random() * 20) + 1
      num2 = Math.floor(Math.random() * 20) + 1
      answer = num1 + num2
      break
    case '-':
      num1 = Math.floor(Math.random() * 20) + 10
      num2 = Math.floor(Math.random() * num1)
      answer = num1 - num2
      break
    case '×':
      num1 = Math.floor(Math.random() * 10) + 1
      num2 = Math.floor(Math.random() * 10) + 1
      answer = num1 * num2
      break
    default:
      num1 = 5
      num2 = 5
      answer = 10
  }
  
  // Generate noise characters
  const noiseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let noise = ''
  for (let i = 0; i < 6; i++) {
    noise += noiseChars[Math.floor(Math.random() * noiseChars.length)]
  }
  
  return {
    question: `${num1} ${operation} ${num2} = ?`,
    answer,
    noise,
    timestamp: Date.now()
  }
}

export function Captcha({ onVerify, isVerified }: CaptchaProps) {
  const [captcha, setCaptcha] = useState(generateCaptcha())
  const [userAnswer, setUserAnswer] = useState('')
  const [error, setError] = useState(false)
  const [attempts, setAttempts] = useState(0)

  const refreshCaptcha = useCallback(() => {
    setCaptcha(generateCaptcha())
    setUserAnswer('')
    setError(false)
  }, [])

  const checkAnswer = useCallback(() => {
    const isCorrect = parseInt(userAnswer) === captcha.answer
    setError(!isCorrect)
    setAttempts(prev => prev + 1)
    onVerify(isCorrect)
    
    if (!isCorrect && attempts >= 2) {
      // After 3 failed attempts, refresh the captcha
      setTimeout(refreshCaptcha, 1000)
    }
  }, [userAnswer, captcha.answer, onVerify, attempts, refreshCaptcha])

  useEffect(() => {
    if (userAnswer.length > 0) {
      const timer = setTimeout(() => {
        if (parseInt(userAnswer) === captcha.answer) {
          onVerify(true)
          setError(false)
        }
      }, 500)
      return () => clearTimeout(timer)
    }
  }, [userAnswer, captcha.answer, onVerify])

  if (isVerified) {
    return (
      <div className="flex items-center gap-2 text-green-600 dark:text-green-400 text-sm">
        <ShieldCheck className="h-4 w-4" />
        <span>Verificación completada</span>
      </div>
    )
  }

  return (
    <Card className="border-2 border-dashed">
      <CardContent className="pt-4">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-orange-500" />
              Verificación de seguridad
            </Label>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={refreshCaptcha}
              className="h-8 w-8 p-0"
            >
              <RefreshCw className="h-3 w-3" />
            </Button>
          </div>
          
          <div className="flex items-center gap-3">
            {/* CAPTCHA Display */}
            <div 
              className="relative bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 rounded-lg px-4 py-3 select-none"
              style={{ 
                fontFamily: 'monospace',
                letterSpacing: '2px'
              }}
            >
              {/* Background noise */}
              <div className="absolute inset-0 overflow-hidden rounded-lg opacity-20">
                {Array.from({ length: 20 }).map((_, i) => (
                  <div
                    key={i}
                    className="absolute text-xs text-gray-500"
                    style={{
                      left: `${Math.random() * 100}%`,
                      top: `${Math.random() * 100}%`,
                      transform: `rotate(${Math.random() * 360}deg)`
                    }}
                  >
                    {captcha.noise[i % captcha.noise.length]}
                  </div>
                ))}
              </div>
              
              {/* Main question */}
              <span className="relative text-lg font-bold tracking-wider text-gray-800 dark:text-gray-200">
                {captcha.question}
              </span>
            </div>
            
            {/* Input */}
            <div className="flex-1">
              <Input
                type="number"
                placeholder="Respuesta"
                value={userAnswer}
                onChange={(e) => {
                  setUserAnswer(e.target.value)
                  setError(false)
                }}
                className={`w-24 ${error ? 'border-red-500 focus-visible:ring-red-500' : ''}`}
                maxLength={4}
              />
            </div>
          </div>
          
          {error && (
            <p className="text-xs text-red-500 flex items-center gap-1">
              Respuesta incorrecta. Intenta de nuevo.
            </p>
          )}
          
          <p className="text-xs text-muted-foreground">
            Resuelve la operación matemática para verificar que eres humano.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}

// Simple invisible captcha for forms
export function useInvisibleCaptcha() {
  const [botDetected, setBotDetected] = useState(false)
  const [formLoadTime, setFormLoadTime] = useState(Date.now())
  const [honeypotValue, setHoneypotValue] = useState('')

  useEffect(() => {
    setFormLoadTime(Date.now())
  }, [])

  const checkBot = useCallback((submittedHoneypot: string) => {
    const submissionTime = Date.now()
    const timeDiff = submissionTime - formLoadTime
    
    // Bot detection rules:
    // 1. Honeypot field should be empty (hidden from users)
    // 2. Form shouldn't be submitted too fast (< 2 seconds = likely bot)
    
    if (submittedHoneypot !== '') {
      setBotDetected(true)
      return true
    }
    
    if (timeDiff < 2000) {
      setBotDetected(true)
      return true
    }
    
    return false
  }, [formLoadTime])

  return {
    botDetected,
    checkBot,
    honeypotValue,
    setHoneypotValue,
    formLoadTime
  }
}

// Honeypot field component (hidden from users, visible to bots)
export function HoneypotField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div 
      className="absolute -left-[9999px] opacity-0 pointer-events-none" 
      aria-hidden="true"
      tabIndex={-1}
    >
      <label htmlFor="website">Website</label>
      <input
        type="text"
        name="website"
        id="website"
        autoComplete="off"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        tabIndex={-1}
      />
    </div>
  )
}
