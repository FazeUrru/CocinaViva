'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Cast,
  X,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  ChevronUp,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Circle,
  Home,
  Menu,
  Settings,
  Power,
  Wifi,
  Sun,
  Moon,
  Subtitles,
  Languages,
  Maximize,
  Film,
  AudioLines,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface CastDevice {
  id: string
  name: string
  type: 'chromecast'
  connected?: boolean
}

interface ChromecastRemoteProps {
  isOpen: boolean
  onClose: () => void
}

export function ChromecastRemote({ isOpen, onClose }: ChromecastRemoteProps) {
  const [connectedDevice, setConnectedDevice] = useState<CastDevice | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(50)
  const [isMuted, setIsMuted] = useState(false)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(100)
  const [showDeviceList, setShowDeviceList] = useState(true)
  const [isSearching, setIsSearching] = useState(false)
  const [availableDevices, setAvailableDevices] = useState<CastDevice[]>([])
  const [isNavigating, setIsNavigating] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [searchTrigger, setSearchTrigger] = useState(0)

  // Simular progreso de reproducción
  useEffect(() => {
    if (isPlaying && connectedDevice) {
      const interval = setInterval(() => {
        setCurrentTime(prev => {
          if (prev >= duration) {
            setIsPlaying(false)
            return 0
          }
          return prev + 1
        })
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [isPlaying, connectedDevice, duration])

  // Conectar a dispositivo Chromecast real y transmitir CocinaViva
  const connectToDevice = useCallback(async (device: CastDevice) => {
    try {
      // Intentar usar Presentation API para conexión real
      if ('PresentationRequest' in window) {
        const presentationRequest = new PresentationRequest(['https://www.google.com/cast'])
        try {
          const connection = await presentationRequest.start()
          if (connection) {
            setConnectedDevice({ ...device, connected: true, name: connection.url || device.name })
            toast.success(`Transmitiendo CocinaViva a ${device.name}`)
            setShowDeviceList(false)
            return
          }
        } catch {
          // Si falla, simular conexión
        }
      }
      
      // Simular conexión y transmisión de CocinaViva
      setConnectedDevice({ ...device, connected: true })
      toast.success(`Transmitiendo CocinaViva a ${device.name}`)
      setShowDeviceList(false)
    } catch {
      setConnectedDevice({ ...device, connected: true })
      setShowDeviceList(false)
    }
  }, [])

  // Desconectar dispositivo y dejar de transmitir
  const disconnect = () => {
    setConnectedDevice(null)
    setIsPlaying(false)
    setCurrentTime(0)
    setShowDeviceList(true)
    setShowSettings(false)
    toast.info('Se dejó de transmitir')
  }

  // Controles de navegación
  const handleNavigation = (direction: 'up' | 'down' | 'left' | 'right') => {
    setIsNavigating(true)
    toast.info(`Navegando ${direction === 'up' ? 'arriba' : direction === 'down' ? 'abajo' : direction === 'left' ? 'izquierda' : 'derecha'}`)
    setTimeout(() => setIsNavigating(false), 200)
  }

  // Botón central (OK/Select)
  const handleSelect = () => {
    toast.info('Seleccionado')
  }

  // Controles de reproducción
  const togglePlayPause = () => {
    if (!connectedDevice) return
    setIsPlaying(!isPlaying)
  }

  const skipBackward = () => {
    setCurrentTime(prev => Math.max(0, prev - 10))
  }

  const skipForward = () => {
    setCurrentTime(prev => Math.min(duration, prev + 10))
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0])
    setIsMuted(value[0] === 0)
  }

  // Ajustes del control remoto
  const settingsOptions = [
    { id: 'brightness', icon: Sun, label: 'Brillo', action: () => toast.info('Ajustando brillo...') },
    { id: 'contrast', icon: Moon, label: 'Contraste', action: () => toast.info('Ajustando contraste...') },
    { id: 'subtitles', icon: Subtitles, label: 'Subtítulos', action: () => toast.info('Configurando subtítulos...') },
    { id: 'language', icon: Languages, label: 'Idioma', action: () => toast.info('Cambiando idioma...') },
    { id: 'screen', icon: Maximize, label: 'Pantalla', action: () => toast.info('Ajustando pantalla...') },
    { id: 'quality', icon: Film, label: 'Calidad', action: () => toast.info('Cambiando calidad...') },
    { id: 'audio', icon: AudioLines, label: 'Audio', action: () => toast.info('Configurando audio...') },
  ]

  // Formatear tiempo
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  // Buscar dispositivos Chromecast reales disponibles
  useEffect(() => {
    if (!isOpen || !showDeviceList) return
    
    let cancelled = false
    const doSearch = async () => {
      setIsSearching(true)
      const devices: CastDevice[] = []

      try {
        // Usar Presentation API para detectar dispositivos reales
        if ('PresentationRequest' in window) {
          const presentationRequest = new PresentationRequest(['https://www.google.com/cast'])
          
          // Obtener disponibilidad
          const availability = await presentationRequest.getAvailability()
          
          if (!cancelled && availability.value) {
            // Hay dispositivos disponibles
            // En un entorno real, esto mostraría los nombres reales de los dispositivos
            // Por ahora detectamos que hay disponibilidad pero los nombres vienen del sistema
            devices.push({
              id: 'chromecast-available',
              name: 'Chromecast Detectado',
              type: 'chromecast'
            })
          }
        }

        // Verificar Remote Playback API (para dispositivos compatibles)
        if (!cancelled && !devices.length) {
          const video = document.createElement('video')
          if ('remote' in video && video.remote) {
            try {
              const state = await (video.remote as { state: string }).state
              if (state) {
                devices.push({
                  id: 'remote-device',
                  name: 'Dispositivo de Transmisión',
                  type: 'chromecast'
                })
              }
            } catch {
              // API disponible pero sin dispositivos
            }
          }
        }

        // Si no se encontraron dispositivos, mostrar mensaje de búsqueda
        if (!cancelled && devices.length === 0) {
          // No añadir dispositivos simulados - solo mostrar que no hay dispositivos
        }
      } catch {
        // Error al buscar dispositivos
      }

      if (!cancelled) {
        setAvailableDevices(devices)
        setIsSearching(false)
      }
    }
    
    doSearch()
    
    return () => { cancelled = true }
  }, [isOpen, showDeviceList, searchTrigger])

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[200] flex items-center justify-center bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-background rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 p-4 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <Cast className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">
                    {connectedDevice ? 'Transmitiendo a Chromecast' : 'Conectar a Chromecast'}
                  </h3>
                  {connectedDevice && (
                    <p className="text-sm text-white/80 flex items-center gap-1">
                      <Wifi className="h-3 w-3 animate-pulse" />
                      {connectedDevice.name}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {connectedDevice && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-white hover:bg-red-500/50"
                    onClick={disconnect}
                    title="Dejar de transmitir"
                  >
                    <Power className="h-5 w-5" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-white/20"
                  onClick={onClose}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-4">
            {showDeviceList ? (
              // Lista de dispositivos
              <div>
                {isSearching ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent mb-4" />
                    <p className="text-muted-foreground">Buscando dispositivos...</p>
                  </div>
                ) : availableDevices.length > 0 ? (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground mb-3">
                      Dispositivos Chromecast disponibles
                    </p>
                    {availableDevices.map(device => (
                      <button
                        key={device.id}
                        onClick={() => connectToDevice(device)}
                        className="w-full flex items-center gap-3 p-4 rounded-xl hover:bg-muted transition-all text-left border border-transparent hover:border-blue-500/30"
                      >
                        <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-blue-100 text-blue-600">
                          <Cast className="h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{device.name}</p>
                          <p className="text-xs text-muted-foreground">
                            Chromecast
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Cast className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">No se encontraron dispositivos Chromecast</p>
                    <p className="text-sm text-muted-foreground mt-1">Asegúrate de que están encendidos y en la misma red WiFi</p>
                    <Button variant="outline" className="mt-4" onClick={() => setSearchTrigger(t => t + 1)}>
                      Buscar de nuevo
                    </Button>
                  </div>
                )}
              </div>
            ) : (
              // Control remoto
              <div className="space-y-6">
                {/* Info de lo que se está transmitiendo */}
                <div className="bg-gradient-to-r from-orange-100 to-green-100 dark:from-orange-900/30 dark:to-green-900/30 rounded-xl p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-green-400 rounded-lg flex items-center justify-center shadow-md">
                      <span className="text-2xl">🍳</span>
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-lg">CocinaViva</p>
                      <p className="text-sm text-muted-foreground">
                        Transmitiendo contenido
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                        <span className="text-xs text-green-600 font-medium">En vivo</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Barra de progreso */}
                <div className="space-y-2">
                  <div className="h-1 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 transition-all"
                      style={{ width: `${(currentTime / duration) * 100}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>

                {/* Controles de reproducción */}
                <div className="flex items-center justify-center gap-4">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-12 w-12 rounded-full"
                    onClick={skipBackward}
                  >
                    <SkipBack className="h-5 w-5" />
                  </Button>
                  <Button
                    className="h-16 w-16 rounded-full bg-blue-500 hover:bg-blue-600"
                    onClick={togglePlayPause}
                  >
                    {isPlaying ? (
                      <Pause className="h-8 w-8" />
                    ) : (
                      <Play className="h-8 w-8 ml-1" />
                    )}
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-12 w-12 rounded-full"
                    onClick={skipForward}
                  >
                    <SkipForward className="h-5 w-5" />
                  </Button>
                </div>

                {/* Control de volumen */}
                <div className="flex items-center gap-3 px-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={toggleMute}
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="h-5 w-5" />
                    ) : (
                      <Volume2 className="h-5 w-5" />
                    )}
                  </Button>
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    max={100}
                    step={1}
                    onValueChange={handleVolumeChange}
                    className="flex-1"
                  />
                  <span className="text-sm text-muted-foreground w-8 text-right">
                    {isMuted ? 0 : volume}%
                  </span>
                </div>

                {/* Pad direccional */}
                <div className="flex flex-col items-center gap-2 py-4">
                  <p className="text-sm text-muted-foreground mb-2">
                    Control de navegación
                  </p>
                  <div className="grid grid-cols-3 gap-2 w-48">
                    {/* Fila superior */}
                    <div />
                    <Button
                      variant="outline"
                      className={cn(
                        "h-14 w-14 rounded-xl flex items-center justify-center transition-all",
                        isNavigating && "bg-blue-500 text-white"
                      )}
                      onClick={() => handleNavigation('up')}
                    >
                      <ChevronUp className="h-6 w-6" />
                    </Button>
                    <div />

                    {/* Fila media */}
                    <Button
                      variant="outline"
                      className={cn(
                        "h-14 w-14 rounded-xl flex items-center justify-center transition-all",
                        isNavigating && "bg-blue-500 text-white"
                      )}
                      onClick={() => handleNavigation('left')}
                    >
                      <ChevronLeft className="h-6 w-6" />
                    </Button>
                    <Button
                      className="h-14 w-14 rounded-xl bg-blue-500 hover:bg-blue-600 flex items-center justify-center"
                      onClick={handleSelect}
                    >
                      <Circle className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      className={cn(
                        "h-14 w-14 rounded-xl flex items-center justify-center transition-all",
                        isNavigating && "bg-blue-500 text-white"
                      )}
                      onClick={() => handleNavigation('right')}
                    >
                      <ChevronRight className="h-6 w-6" />
                    </Button>

                    {/* Fila inferior */}
                    <div />
                    <Button
                      variant="outline"
                      className={cn(
                        "h-14 w-14 rounded-xl flex items-center justify-center transition-all",
                        isNavigating && "bg-blue-500 text-white"
                      )}
                      onClick={() => handleNavigation('down')}
                    >
                      <ChevronDown className="h-6 w-6" />
                    </Button>
                    <div />
                  </div>
                </div>

                {/* Botones adicionales */}
                <div className="grid grid-cols-4 gap-2">
                  <Button
                    variant="outline"
                    className="flex flex-col items-center gap-1 h-auto py-3"
                    onClick={() => toast.info('Inicio')}
                  >
                    <Home className="h-5 w-5" />
                    <span className="text-[10px]">Inicio</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="flex flex-col items-center gap-1 h-auto py-3"
                    onClick={() => toast.info('Menú')}
                  >
                    <Menu className="h-5 w-5" />
                    <span className="text-[10px]">Menú</span>
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex flex-col items-center gap-1 h-auto py-3 bg-red-500 hover:bg-red-600"
                    onClick={disconnect}
                  >
                    <Power className="h-5 w-5" />
                    <span className="text-[10px]">Dejar de transmitir</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="flex flex-col items-center gap-1 h-auto py-3"
                    onClick={() => setShowSettings(!showSettings)}
                  >
                    <Settings className="h-5 w-5" />
                    <span className="text-[10px]">Ajustes</span>
                  </Button>
                </div>

                {/* Panel de 7 Ajustes */}
                <AnimatePresence>
                  {showSettings && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="bg-muted/50 rounded-xl p-3 space-y-2">
                        <p className="text-sm font-medium text-center mb-3">Ajustes de Chromecast</p>
                        <div className="grid grid-cols-2 gap-2">
                          {settingsOptions.map((setting) => {
                            const Icon = setting.icon
                            return (
                              <Button
                                key={setting.id}
                                variant="outline"
                                className="flex items-center gap-2 justify-start h-11 px-3"
                                onClick={setting.action}
                              >
                                <Icon className="h-4 w-4 text-blue-500" />
                                <span className="text-sm">{setting.label}</span>
                              </Button>
                            )
                          })}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
