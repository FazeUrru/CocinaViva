'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  X,
  CreditCard,
  Lock,
  Check,
  AlertCircle,
  Calendar,
  Shield,
  Clock,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  plan: 'ultra' | 'masterchef'
  isAnnual: boolean
  price: number
  onSuccess: () => void
}

export function PaymentModal({ isOpen, onClose, plan, isAnnual, price, onSuccess }: PaymentModalProps) {
  const [step, setStep] = useState<'details' | 'payment' | 'processing' | 'success'>('details')
  const [cardNumber, setCardNumber] = useState('')
  const [cardHolder, setCardHolder] = useState('')
  const [expiryDate, setExpiryDate] = useState('')
  const [cvv, setCvv] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  // Formatear número de tarjeta
  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    const matches = v.match(/\d{4,16}/g)
    const match = (matches && matches[0]) || ''
    const parts = []
    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }
    return parts.length ? parts.join(' ') : v
  }

  // Formatear fecha de expiración
  const formatExpiryDate = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '')
    if (v.length >= 2) {
      return v.substring(0, 2) + '/' + v.substring(2, 4)
    }
    return v
  }

  // Validar formulario
  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    
    if (!cardNumber || cardNumber.replace(/\s/g, '').length < 16) {
      newErrors.cardNumber = 'Ingresa un número de tarjeta válido'
    }
    
    if (!cardHolder || cardHolder.length < 3) {
      newErrors.cardHolder = 'Ingresa el nombre del titular'
    }
    
    if (!expiryDate || expiryDate.length < 5) {
      newErrors.expiryDate = 'Ingresa una fecha válida (MM/AA)'
    }
    
    if (!cvv || cvv.length < 3) {
      newErrors.cvv = 'Ingresa un CVV válido'
    }
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  // Procesar pago
  const handlePayment = async () => {
    if (!validateForm()) return
    
    setStep('processing')
    
    // Simular procesamiento de pago
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Simular éxito (en producción sería una llamada a la API)
    const success = true
    
    if (success) {
      setStep('success')
      setTimeout(() => {
        onSuccess()
        onClose()
      }, 2000)
    } else {
      toast.error('Error al procesar el pago. Inténtalo de nuevo.')
      setStep('payment')
    }
  }

  // Obtener tipo de tarjeta
  const getCardType = () => {
    const num = cardNumber.replace(/\s/g, '')
    if (num.startsWith('4')) return 'visa'
    if (num.startsWith('5')) return 'mastercard'
    if (num.startsWith('3')) return 'amex'
    return null
  }

  if (!isOpen) return null

  const planName = plan === 'ultra' ? 'Ultra' : 'MasterChef'

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[300] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-background rounded-2xl shadow-2xl w-full max-w-md overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-orange-500 to-green-500 p-4 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                  <CreditCard className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">
                    {step === 'success' ? '¡Pago Completado!' : `Plan ${planName}`}
                  </h3>
                  {step !== 'success' && (
                    <p className="text-sm text-white/80">
                      {isAnnual ? 'Suscripción Anual' : 'Suscripción Mensual'}
                    </p>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20"
                onClick={onClose}
              >
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {step === 'details' && (
              <div className="space-y-4">
                {/* Resumen del plan */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">Resumen del Plan</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Plan</span>
                      <Badge className={plan === 'ultra' ? 'bg-orange-500' : 'bg-purple-500'}>
                        {planName}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-muted-foreground">Tipo</span>
                      <span>{isAnnual ? 'Anual' : 'Mensual'}</span>
                    </div>
                    {isAnnual && (
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Descuento</span>
                        <Badge className="bg-green-500">-18%</Badge>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between items-center font-semibold">
                      <span>Total</span>
                      <span className="text-xl">{price.toFixed(2).replace('.', ',')}€</span>
                    </div>
                    {!isAnnual && (
                      <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 p-2 rounded-lg">
                        <Clock className="h-4 w-4" />
                        <span>7 días de prueba gratis incluidos</span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Botón continuar */}
                <Button
                  className="w-full bg-gradient-to-r from-orange-500 to-green-500"
                  onClick={() => setStep('payment')}
                >
                  Continuar al Pago
                </Button>

                {/* Seguridad */}
                <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                  <Shield className="h-4 w-4" />
                  <span>Pago 100% seguro con encriptación SSL</span>
                </div>
              </div>
            )}

            {step === 'payment' && (
              <div className="space-y-4">
                {/* Tarjeta de crédito visual */}
                <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-5 text-white aspect-[1.6/1] flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div className="text-xs uppercase tracking-wider">Tarjeta de Crédito</div>
                    {getCardType() && (
                      <div className="text-right">
                        {getCardType() === 'visa' && (
                          <span className="text-2xl font-bold italic">VISA</span>
                        )}
                        {getCardType() === 'mastercard' && (
                          <div className="flex">
                            <div className="w-6 h-6 bg-red-500 rounded-full opacity-80" />
                            <div className="w-6 h-6 bg-yellow-500 rounded-full opacity-80 -ml-3" />
                          </div>
                        )}
                        {getCardType() === 'amex' && (
                          <span className="text-lg font-bold">AMEX</span>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="font-mono text-xl tracking-wider">
                    {cardNumber || '•••• •••• •••• ••••'}
                  </div>
                  <div className="flex justify-between items-end">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider opacity-70">Titular</div>
                      <div className="text-sm uppercase tracking-wide">
                        {cardHolder || 'NOMBRE DEL TITULAR'}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] uppercase tracking-wider opacity-70">Vence</div>
                      <div className="text-sm">{expiryDate || 'MM/AA'}</div>
                    </div>
                  </div>
                </div>

                {/* Formulario */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="cardNumber">Número de Tarjeta</Label>
                    <Input
                      id="cardNumber"
                      placeholder="1234 5678 9012 3456"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                      maxLength={19}
                      className={errors.cardNumber ? 'border-red-500' : ''}
                    />
                    {errors.cardNumber && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {errors.cardNumber}
                      </p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="cardHolder">Nombre del Titular</Label>
                    <Input
                      id="cardHolder"
                      placeholder="JUAN GARCÍA LÓPEZ"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                      className={errors.cardHolder ? 'border-red-500' : ''}
                    />
                    {errors.cardHolder && (
                      <p className="text-xs text-red-500 flex items-center gap-1">
                        <AlertCircle className="h-3 w-3" />
                        {errors.cardHolder}
                      </p>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expiryDate">Fecha de Expiración</Label>
                      <div className="relative">
                        <Input
                          id="expiryDate"
                          placeholder="MM/AA"
                          value={expiryDate}
                          onChange={(e) => setExpiryDate(formatExpiryDate(e.target.value))}
                          maxLength={5}
                          className={errors.expiryDate ? 'border-red-500' : ''}
                        />
                        <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      </div>
                      {errors.expiryDate && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          {errors.expiryDate}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="cvv">CVV</Label>
                      <Input
                        id="cvv"
                        type="password"
                        placeholder="•••"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
                        maxLength={4}
                        className={errors.cvv ? 'border-red-500' : ''}
                      />
                      {errors.cvv && (
                        <p className="text-xs text-red-500 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          {errors.cvv}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Botones */}
                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setStep('details')}
                  >
                    Atrás
                  </Button>
                  <Button
                    className="flex-1 bg-gradient-to-r from-orange-500 to-green-500"
                    onClick={handlePayment}
                  >
                    <Lock className="h-4 w-4 mr-2" />
                    Pagar {price.toFixed(2).replace('.', ',')}€
                  </Button>
                </div>

                {/* Métodos aceptados */}
                <div className="flex items-center justify-center gap-4 text-muted-foreground">
                  <span className="text-xs">Aceptamos:</span>
                  <div className="flex gap-2">
                    <Badge variant="outline" className="text-xs">VISA</Badge>
                    <Badge variant="outline" className="text-xs">Mastercard</Badge>
                    <Badge variant="outline" className="text-xs">Amex</Badge>
                  </div>
                </div>
              </div>
            )}

            {step === 'processing' && (
              <div className="flex flex-col items-center justify-center py-12">
                <div className="animate-spin rounded-full h-16 w-16 border-4 border-orange-500 border-t-transparent mb-4" />
                <p className="text-lg font-medium">Procesando pago...</p>
                <p className="text-sm text-muted-foreground">Por favor espera un momento</p>
              </div>
            )}

            {step === 'success' && (
              <div className="flex flex-col items-center justify-center py-12">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4"
                >
                  <Check className="h-10 w-10 text-green-500" />
                </motion.div>
                <p className="text-lg font-medium mb-1">¡Pago Exitoso!</p>
                <p className="text-sm text-muted-foreground text-center">
                  Tu suscripción al plan {planName} ha sido activada
                </p>
                {!isAnnual && (
                  <div className="mt-4 bg-amber-50 p-3 rounded-lg text-center">
                    <p className="text-sm text-amber-700">
                      <Clock className="h-4 w-4 inline mr-1" />
                      Tu prueba de 7 días comienza ahora
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          {step !== 'success' && step !== 'processing' && (
            <div className="px-6 pb-4">
              <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <Lock className="h-3 w-3" />
                <span>Tus datos están protegidos con encriptación de 256 bits</span>
              </div>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}
