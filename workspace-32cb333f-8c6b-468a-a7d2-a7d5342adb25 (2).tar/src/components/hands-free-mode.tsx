"use client"

import { useState, useEffect, useCallback, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Hand, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Settings,
  X,
  Info,
  AlertCircle,
  CheckCircle,
  Sparkles
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { toast } from 'sonner'
import { usePremiumAccess } from '@/components/premium-guard'

interface HandsFreeModeProps {
  onPrevious: () => void
  onNext: () => void
  currentStep: number
  totalSteps: number
  isEnabled?: boolean
  onToggle?: (enabled: boolean) => void
}

// Voice commands configuration
const VOICE_COMMANDS = {
  next: ['siguiente', 'siguiente paso', 'adelante', 'avanza', 'next', 'continuar', 'pasar'],
  previous: ['anterior', 'paso anterior', 'atrás', 'retrocede', 'previous', 'volver', 'retroceder'],
  repeat: ['repetir', 'repite', 'otra vez', 'repeat', 'otra vez'],
  stop: ['parar', 'stop', 'alto', 'detener'],
}

export function HandsFreeMode({
  onPrevious,
  onNext,
  currentStep,
  totalSteps,
  isEnabled = false,
  onToggle,
}: HandsFreeModeProps) {
  const [isActive, setIsActive] = useState(isEnabled)
  const [isListening, setIsListening] = useState(false)
  const [speechSupported, setSpeechSupported] = useState(false)
  const [proximitySupported, setProximitySupported] = useState(false)
  const [lastCommand, setLastCommand] = useState<string | null>(null)
  const [showSettings, setShowSettings] = useState(false)
  const [voiceEnabled, setVoiceEnabled] = useState(true)
  const [proximityEnabled, setProximityEnabled] = useState(true)
  const [soundFeedback, setSoundFeedback] = useState(true)
  const [showTutorial, setShowTutorial] = useState(false)
  
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const proximityListenerRef = useRef<number | null>(null)
  const hasPremium = usePremiumAccess('ultra')
  
  // Check browser support
  useEffect(() => {
    // Use setTimeout to defer state updates
    const timer = setTimeout(() => {
      // Check Speech Recognition support
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      if (SpeechRecognition) {
        setSpeechSupported(true)
        recognitionRef.current = new SpeechRecognition()
        recognitionRef.current.continuous = true
        recognitionRef.current.interimResults = false
        recognitionRef.current.lang = 'es-ES'
      }
      
      // Check Proximity Sensor support (Android only)
      if ('ProximitySensor' in window) {
        setProximitySupported(true)
      }
      
      // Show tutorial on first use
      const hasSeenTutorial = localStorage.getItem('handsfree-tutorial-seen')
      if (!hasSeenTutorial) {
        setShowTutorial(true)
      }
    }, 0)
    
    return () => clearTimeout(timer)
  }, [])
  
  // Play sound feedback
  const playSound = useCallback((type: 'success' | 'error' | 'navigate') => {
    if (!soundFeedback) return
    
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()
    
    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)
    
    switch (type) {
      case 'success':
        oscillator.frequency.value = 800
        oscillator.type = 'sine'
        gainNode.gain.value = 0.1
        break
      case 'navigate':
        oscillator.frequency.value = 600
        oscillator.type = 'triangle'
        gainNode.gain.value = 0.15
        break
      case 'error':
        oscillator.frequency.value = 200
        oscillator.type = 'square'
        gainNode.gain.value = 0.1
        break
    }
    
    oscillator.start()
    setTimeout(() => {
      oscillator.stop()
      audioContext.close()
    }, 150)
  }, [soundFeedback])
  
  // Execute command
  const executeCommand = useCallback((command: 'next' | 'previous' | 'repeat' | 'stop') => {
    setLastCommand(command)
    
    switch (command) {
      case 'next':
        if (currentStep < totalSteps - 1) {
          onNext()
          playSound('navigate')
          toast.success('Paso siguiente', { duration: 1000 })
        } else {
          playSound('error')
          toast.info('Ya estás en el último paso')
        }
        break
      case 'previous':
        if (currentStep > 0) {
          onPrevious()
          playSound('navigate')
          toast.success('Paso anterior', { duration: 1000 })
        } else {
          playSound('error')
          toast.info('Ya estás en el primer paso')
        }
        break
      case 'repeat':
        // This would be handled by parent component
        playSound('success')
        toast.info('Repetir paso')
        break
      case 'stop':
        setIsActive(false)
        playSound('success')
        toast.info('Modo manos libres desactivado')
        break
    }
  }, [currentStep, totalSteps, onNext, onPrevious, playSound])
  
  // Process voice command
  const processVoiceCommand = useCallback((transcript: string) => {
    const normalizedTranscript = transcript.toLowerCase().trim()
    
    // Check for each command
    for (const [command, keywords] of Object.entries(VOICE_COMMANDS)) {
      if (keywords.some(keyword => normalizedTranscript.includes(keyword))) {
        executeCommand(command as 'next' | 'previous' | 'repeat' | 'stop')
        return
      }
    }
  }, [executeCommand])
  
  // Start/Stop voice recognition
  const toggleVoiceRecognition = useCallback((start: boolean) => {
    if (!recognitionRef.current) return
    
    if (start && voiceEnabled) {
      try {
        recognitionRef.current.onresult = (event) => {
          const last = event.results.length - 1
          const transcript = event.results[last][0].transcript
          processVoiceCommand(transcript)
        }
        
        recognitionRef.current.onerror = (event) => {
          console.error('Speech recognition error:', event.error)
          if (event.error === 'not-allowed') {
            toast.error('Permiso de micrófono denegado')
          }
        }
        
        recognitionRef.current.onend = () => {
          // Restart if still active
          if (isActive && isListening) {
            recognitionRef.current?.start()
          }
        }
        
        recognitionRef.current.start()
        setIsListening(true)
      } catch (error) {
        console.error('Error starting speech recognition:', error)
      }
    } else {
      recognitionRef.current.stop()
      setIsListening(false)
    }
  }, [voiceEnabled, isActive, isListening, processVoiceCommand])
  
  // Proximity sensor handling
  useEffect(() => {
    if (!proximitySupported || !proximityEnabled || !isActive) return
    
    const handleProximity = (event: any) => {
      const isNear = event.near !== undefined ? event.near : event.value < 5
      
      if (isNear) {
        // Prevent rapid triggers
        if (proximityListenerRef.current) {
          clearTimeout(proximityListenerRef.current)
        }
        
        proximityListenerRef.current = window.setTimeout(() => {
          executeCommand('next')
        }, 300) as unknown as number
      }
    }
    
    // @ts-ignore - ProximitySensor is not in types
    const sensor = new window.ProximitySensor({ frequency: 1 })
    sensor.addEventListener('reading', handleProximity)
    sensor.start()
    
    return () => {
      sensor.removeEventListener('reading', handleProximity)
      sensor.stop()
      if (proximityListenerRef.current) {
        clearTimeout(proximityListenerRef.current)
      }
    }
  }, [proximitySupported, proximityEnabled, isActive, executeCommand])
  
  // Main toggle
  useEffect(() => {
    // Use setTimeout to defer state updates
    const timer = setTimeout(() => {
      if (isActive) {
        toggleVoiceRecognition(true)
        playSound('success')
      } else {
        toggleVoiceRecognition(false)
      }
      
      onToggle?.(isActive)
    }, 0)
    
    return () => clearTimeout(timer)
  }, [isActive, toggleVoiceRecognition, onToggle, playSound])
  
  // Keyboard shortcuts as fallback
  useEffect(() => {
    if (!isActive) return
    
    const handleKeyDown = (e: KeyboardEvent) => {
      // Arrow keys for navigation
      if (e.key === 'ArrowRight') {
        executeCommand('next')
      } else if (e.key === 'ArrowLeft') {
        executeCommand('previous')
      } else if (e.key === 'Escape') {
        setIsActive(false)
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [isActive, executeCommand])
  
  // Mark tutorial as seen
  const closeTutorial = () => {
    setShowTutorial(false)
    localStorage.setItem('handsfree-tutorial-seen', 'true')
  }
  
  if (!hasPremium) {
    return null
  }

  return (
    <>
      {/* Tutorial Dialog */}
      <Dialog open={showTutorial} onOpenChange={setShowTutorial}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Hand className="w-5 h-5 text-orange-500" />
              Modo Manos Sucias
            </DialogTitle>
            <DialogDescription>
              Cocina sin tocar la pantalla
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="bg-orange-50 dark:bg-orange-950/20 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-orange-500 mt-0.5" />
                <div>
                  <p className="font-medium text-orange-700 dark:text-orange-300">
                    ¡Nuevo!
                  </p>
                  <p className="text-sm text-orange-600 dark:text-orange-400">
                    Ahora puedes navegar por los pasos de tu receta sin ensuciar tu dispositivo.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold">Cómo usar:</h4>
              
              {speechSupported && (
                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <Mic className="w-5 h-5 text-blue-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Comandos de Voz</p>
                    <p className="text-sm text-muted-foreground">
                      Di <strong>"Siguiente"</strong> o <strong>"Anterior"</strong> para navegar
                    </p>
                  </div>
                </div>
              )}
              
              {proximitySupported && (
                <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                  <Hand className="w-5 h-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Gestos</p>
                    <p className="text-sm text-muted-foreground">
                      Pasa la mano por encima del sensor de proximidad
                    </p>
                  </div>
                </div>
              )}
              
              <div className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                <ChevronRight className="w-5 h-5 text-purple-500 mt-0.5" />
                <div>
                  <p className="font-medium">Teclado</p>
                  <p className="text-sm text-muted-foreground">
                    Usa las flechas ← → del teclado
                  </p>
                </div>
              </div>
            </div>
            
            <Button onClick={closeTutorial} className="w-full">
              ¡Entendido!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Configuración Manos Libres
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Voice Control */}
            {speechSupported && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Mic className="w-4 h-4 text-blue-500" />
                  <Label>Control por voz</Label>
                </div>
                <Switch 
                  checked={voiceEnabled} 
                  onCheckedChange={setVoiceEnabled}
                />
              </div>
            )}
            
            {/* Proximity Sensor */}
            {proximitySupported && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Hand className="w-4 h-4 text-green-500" />
                  <Label>Sensor de proximidad</Label>
                </div>
                <Switch 
                  checked={proximityEnabled} 
                  onCheckedChange={setProximityEnabled}
                />
              </div>
            )}
            
            <Separator />
            
            {/* Sound Feedback */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {soundFeedback ? (
                  <Volume2 className="w-4 h-4 text-purple-500" />
                ) : (
                  <VolumeX className="w-4 h-4 text-muted-foreground" />
                )}
                <Label>Sonidos de feedback</Label>
              </div>
              <Switch 
                checked={soundFeedback} 
                onCheckedChange={setSoundFeedback}
              />
            </div>
            
            {!speechSupported && !proximitySupported && (
              <div className="flex items-center gap-2 p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                <p className="text-sm text-amber-600 dark:text-amber-400">
                  Tu dispositivo no soporta sensores avanzados. Usa las flechas del teclado.
                </p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Main Control Button */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        className="fixed bottom-24 right-4 z-40"
      >
        <Card className={`p-2 ${isActive ? 'bg-orange-500 text-white border-orange-600' : 'bg-white dark:bg-gray-800'}`}>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsActive(!isActive)}
              className={`relative ${isActive ? 'text-white hover:bg-orange-600' : ''}`}
            >
              <AnimatePresence mode="wait">
                {isActive ? (
                  <motion.div
                    key="active"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                  >
                    <Hand className="w-6 h-6" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="inactive"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    exit={{ scale: 0 }}
                  >
                    <Hand className="w-6 h-6" />
                  </motion.div>
                )}
              </AnimatePresence>
              
              {/* Voice indicator */}
              {isActive && isListening && (
                <motion.div
                  className="absolute inset-0 rounded-full bg-red-500"
                  animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0, 0.5] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              )}
            </Button>
            
            {isActive && (
              <>
                <Separator orientation="vertical" className="h-8 bg-white/20" />
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => executeCommand('previous')}
                  disabled={currentStep === 0}
                  className="text-white hover:bg-orange-600"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => executeCommand('next')}
                  disabled={currentStep === totalSteps - 1}
                  className="text-white hover:bg-orange-600"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
                
                <Separator orientation="vertical" className="h-8 bg-white/20" />
                
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowSettings(true)}
                  className="text-white hover:bg-orange-600"
                >
                  <Settings className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>
        </Card>
      </motion.div>
      
      {/* Status indicator when active */}
      {isActive && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-4 left-1/2 -translate-x-1/2 z-40"
        >
          <Badge 
            variant="outline" 
            className={`px-4 py-2 ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-orange-500 text-white'}`}
          >
            {isListening ? (
              <>
                <Mic className="w-4 h-4 mr-2" />
                Escuchando...
              </>
            ) : (
              <>
                <Hand className="w-4 h-4 mr-2" />
                Modo Manos Libres Activo
              </>
            )}
          </Badge>
        </motion.div>
      )}
      
      {/* Last command feedback */}
      <AnimatePresence>
        {lastCommand && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="fixed bottom-40 left-1/2 -translate-x-1/2 z-40"
          >
            <div className="bg-white dark:bg-gray-800 shadow-xl rounded-full px-6 py-3 flex items-center gap-2">
              {lastCommand === 'next' ? (
                <ChevronRight className="w-5 h-5 text-green-500" />
              ) : lastCommand === 'previous' ? (
                <ChevronLeft className="w-5 h-5 text-blue-500" />
              ) : (
                <CheckCircle className="w-5 h-5 text-orange-500" />
              )}
              <span className="font-medium capitalize">{lastCommand}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}

// Export hook for use in other components
export function useHandsFree() {
  const [isActive, setIsActive] = useState(false)
  const [lastCommand, setLastCommand] = useState<string | null>(null)
  
  const activate = useCallback(() => setIsActive(true), [])
  const deactivate = useCallback(() => setIsActive(false), [])
  const toggle = useCallback(() => setIsActive(prev => !prev), [])
  
  return {
    isActive,
    lastCommand,
    activate,
    deactivate,
    toggle,
    setLastCommand,
  }
}

// Type declarations for Web APIs not in standard lib
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition
    webkitSpeechRecognition: typeof SpeechRecognition
    ProximitySensor: any
  }
}
