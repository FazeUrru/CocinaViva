'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Mail, Lock, Eye, EyeOff, Chrome, Facebook, Twitter, Apple, ChefHat, Loader2, Shield, CheckCircle, RefreshCw } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { useUserStore, type LoginCredentials } from '@/store'
import { toast } from 'sonner'

interface FullscreenLoginProps {
  onLoginSuccess: () => void
}

// Registered users storage key
const REGISTERED_USERS_KEY = 'cocinaviva-registered-users'

interface RegisteredUser {
  email: string
  password: string
  name: string
  createdAt: string
  provider?: string
}

const getRegisteredUsers = (): RegisteredUser[] => {
  if (typeof window === 'undefined') return []
  try {
    const stored = localStorage.getItem(REGISTERED_USERS_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

const saveRegisteredUser = (user: RegisteredUser) => {
  if (typeof window === 'undefined') return
  const users = getRegisteredUsers()
  const existingIndex = users.findIndex(u => u.email.toLowerCase() === user.email.toLowerCase())
  if (existingIndex >= 0) {
    users[existingIndex] = user
  } else {
    users.push(user)
  }
  localStorage.setItem(REGISTERED_USERS_KEY, JSON.stringify(users))
}

const findUserByEmail = (email: string): RegisteredUser | undefined => {
  const users = getRegisteredUsers()
  return users.find(u => u.email.toLowerCase() === email.toLowerCase())
}

// Función para ocultar/encriptar la contraseña (simple obfuscation para demo)
const hashPassword = (password: string): string => {
  return btoa(encodeURIComponent(password).split('').reverse().join(''))
}

// CAPTCHA Generator - returns stable result for SSR
interface CaptchaData {
  num1: number
  num2: number
  operator: string
  answer: number
}

// Default placeholder captcha for SSR
const DEFAULT_CAPTCHA: CaptchaData = { num1: 5, num2: 3, operator: '+', answer: 8 }

// Generate captcha only on client side to avoid hydration mismatch
const generateCaptcha = (): CaptchaData => {
  if (typeof window === 'undefined') return DEFAULT_CAPTCHA
  
  const operators = ['+', '-', '*']
  const operator = operators[Math.floor(Math.random() * 2)] // Only + and - for simplicity
  let num1 = Math.floor(Math.random() * 10) + 1
  let num2 = Math.floor(Math.random() * 10) + 1
  
  // Ensure positive result for subtraction
  if (operator === '-' && num2 > num1) {
    [num1, num2] = [num2, num1]
  }
  
  let answer: number
  switch (operator) {
    case '+': answer = num1 + num2; break
    case '-': answer = num1 - num2; break
    case '*': answer = num1 * num2; break
    default: answer = num1 + num2
  }
  
  return { num1, num2, operator, answer }
}

export default function FullscreenLogin({ onLoginSuccess }: FullscreenLoginProps) {
  const [mode, setMode] = useState<'options' | 'email' | 'register'>('options')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [socialLoading, setSocialLoading] = useState<string | null>(null)
  const { login } = useUserStore()
  
  // CAPTCHA State - start with default to avoid hydration mismatch
  const [captcha, setCaptcha] = useState<CaptchaData>(DEFAULT_CAPTCHA)
  const [captchaInput, setCaptchaInput] = useState('')
  const [captchaError, setCaptchaError] = useState(false)
  
  // Use ref to track if we need to regenerate captcha
  const captchaGeneratedRef = useRef(false)
  
  // Generate captcha on first client-side render
  useEffect(() => {
    // Only generate once on client side
    if (!captchaGeneratedRef.current) {
      captchaGeneratedRef.current = true
      // Use setTimeout to defer state update and avoid cascading renders
      const timer = setTimeout(() => {
        setCaptcha(generateCaptcha())
      }, 0)
      return () => clearTimeout(timer)
    }
  }, [])
  
  // Track mode changes and reset captcha
  const handleModeChange = (newMode: 'options' | 'email' | 'register') => {
    setMode(newMode)
    setCaptchaInput('')
    setCaptchaError(false)
    // Regenerate captcha when switching to register mode
    if (newMode === 'register') {
      setTimeout(() => {
        setCaptcha(generateCaptcha())
      }, 0)
    }
  }

  const refreshCaptcha = useCallback(() => {
    setCaptcha(generateCaptcha())
    setCaptchaInput('')
    setCaptchaError(false)
  }, [])

  const handleSocialLogin = async (provider: 'Google' | 'Facebook' | 'X' | 'Apple') => {
    setSocialLoading(provider)
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Generar email basado en el provider
    const providerEmails: Record<string, string> = {
      'Google': `usuario.google.${Date.now().toString(36)}@gmail.com`,
      'Facebook': `usuario.fb.${Date.now().toString(36)}@facebook.com`,
      'X': `usuario.x.${Date.now().toString(36)}@x.com`,
      'Apple': `usuario.apple.${Date.now().toString(36)}@icloud.com`,
    }
    
    const userEmail = providerEmails[provider]
    const userName = `Usuario ${provider}`
    const userId = `user-${provider.toLowerCase()}-${Date.now()}`
    
    // Crear credenciales con contraseña del proveedor (token simulado)
    const credentials: LoginCredentials = {
      provider: provider,
      email: userEmail,
      passwordHash: hashPassword(`${provider}_token_${Date.now()}_${Math.random().toString(36)}`),
      loginDate: new Date().toISOString(),
    }
    
    // Guardar usuario registrado
    saveRegisteredUser({
      email: userEmail,
      password: '', // Social logins no tienen password local
      name: userName,
      createdAt: new Date().toISOString(),
      provider: provider,
    })
    
    // Login con credenciales
    login(userId, userName, userEmail, undefined, credentials)
    
    toast.success(`¡Bienvenido! Sesión iniciada con ${provider}`)
    setSocialLoading(null)
    onLoginSuccess()
  }

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email || !password) {
      toast.error('Por favor completa todos los campos')
      return
    }
    
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    const registeredUser = findUserByEmail(email)
    
    if (registeredUser) {
      if (registeredUser.provider) {
        setIsLoading(false)
        toast.error(`Este correo está registrado con ${registeredUser.provider}. Usa ese método de inicio.`)
        return
      }
      
      if (registeredUser.password !== password) {
        setIsLoading(false)
        toast.error('Contraseña incorrecta')
        return
      }
      
      // Crear credenciales con contraseña hasheada
      const credentials: LoginCredentials = {
        provider: 'email',
        email: email,
        passwordHash: hashPassword(password),
        loginDate: new Date().toISOString(),
      }
      
      login(
        `user-email-${Date.now()}`,
        registeredUser.name,
        registeredUser.email,
        undefined,
        credentials
      )
      toast.success('¡Bienvenido de vuelta!')
    } else {
      setIsLoading(false)
      toast.error('Usuario no encontrado. Regístrate primero.')
      return
    }
    
    setIsLoading(false)
    onLoginSuccess()
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email || !password || !name) {
      toast.error('Por favor completa todos los campos')
      return
    }

    if (password.length < 8) {
      toast.error('La contraseña debe tener al menos 8 caracteres')
      return
    }
    
    // Verify CAPTCHA
    if (parseInt(captchaInput) !== captcha.answer) {
      setCaptchaError(true)
      toast.error('CAPTCHA incorrecto. Inténtalo de nuevo.')
      refreshCaptcha()
      return
    }
    
    const existingUser = findUserByEmail(email)
    if (existingUser) {
      if (existingUser.provider) {
        toast.error(`Este correo ya está registrado con ${existingUser.provider}`)
      } else {
        toast.error('Este correo ya está registrado')
      }
      return
    }
    
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Guardar usuario
    saveRegisteredUser({
      email,
      password,
      name,
      createdAt: new Date().toISOString(),
    })
    
    // Crear credenciales con contraseña hasheada
    const credentials: LoginCredentials = {
      provider: 'email',
      email: email,
      passwordHash: hashPassword(password),
      loginDate: new Date().toISOString(),
    }
    
    login(
      `user-new-${Date.now()}`,
      name,
      email,
      undefined,
      credentials
    )
    
    toast.success('¡Cuenta creada exitosamente!')
    setIsLoading(false)
    onLoginSuccess()
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-[200] flex flex-col bg-gradient-to-br from-orange-500 via-orange-400 to-green-500"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Content */}
      <div className="flex-1 flex items-center justify-center p-4 relative">
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          transition={{ type: 'spring', damping: 25 }}
          className="w-full max-w-md"
        >
          {/* Logo and Title */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring' }}
              className="inline-flex items-center justify-center w-20 h-20 bg-white rounded-2xl shadow-xl mb-4"
            >
              <ChefHat className="w-10 h-10 text-orange-500" />
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-3xl font-bold text-white mb-2"
            >
              CocinaViva
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-white/80"
            >
              Tu cocina integral
            </motion.p>
          </div>

          {/* Login Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-3xl shadow-2xl overflow-hidden"
          >
            {/* Obligatory Login Banner */}
            <div className="bg-gradient-to-r from-orange-500 to-green-500 p-3 text-white text-center">
              <p className="text-sm font-medium flex items-center justify-center gap-2">
                <Shield className="h-4 w-4" />
                Inicio de sesión obligatorio
              </p>
            </div>

            {/* Card Header */}
            <div className="bg-gradient-to-r from-orange-50 to-green-50 p-6 border-b">
              <h2 className="text-xl font-semibold text-center">
                {mode === 'options' && 'Iniciar Sesión'}
                {mode === 'email' && 'Iniciar con Email'}
                {mode === 'register' && 'Crear Cuenta'}
              </h2>
              <p className="text-sm text-muted-foreground text-center mt-1">
                {mode === 'options' && 'Elige tu método preferido'}
                {mode === 'email' && 'Introduce tus credenciales'}
                {mode === 'register' && 'Únete a nuestra comunidad'}
              </p>
            </div>

            {/* Card Content */}
            <div className="p-6">
              <AnimatePresence mode="wait">
                {mode === 'options' && (
                  <motion.div
                    key="options"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="space-y-3"
                  >
                    {/* Social Login Options */}
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-base"
                      onClick={() => handleSocialLogin('Google')}
                      disabled={socialLoading !== null}
                    >
                      {socialLoading === 'Google' ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <svg className="h-5 w-5" viewBox="0 0 24 24">
                          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                      )}
                      Continuar con Google
                    </Button>
                    
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-base"
                      onClick={() => handleSocialLogin('Facebook')}
                      disabled={socialLoading !== null}
                    >
                      {socialLoading === 'Facebook' ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <Facebook className="h-5 w-5 text-blue-600" />
                      )}
                      Continuar con Facebook
                    </Button>
                    
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-base"
                      onClick={() => handleSocialLogin('X')}
                      disabled={socialLoading !== null}
                    >
                      {socialLoading === 'X' ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <Twitter className="h-5 w-5" />
                      )}
                      Continuar con X (Twitter)
                    </Button>
                    
                    <Button
                      variant="outline"
                      className="w-full justify-start gap-3 h-12 text-base"
                      onClick={() => handleSocialLogin('Apple')}
                      disabled={socialLoading !== null}
                    >
                      {socialLoading === 'Apple' ? (
                        <Loader2 className="h-5 w-5 animate-spin" />
                      ) : (
                        <Apple className="h-5 w-5" />
                      )}
                      Continuar con Apple
                    </Button>

                    <div className="relative my-4">
                      <Separator />
                      <span className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-3 text-xs text-muted-foreground">
                        o continúa con
                      </span>
                    </div>

                    <Button
                      variant="default"
                      className="w-full h-12 text-base bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                      onClick={() => handleModeChange('email')}
                    >
                      <Mail className="h-5 w-5 mr-2" />
                      Correo Electrónico
                    </Button>

                    <div className="text-center mt-4">
                      <button
                        onClick={() => handleModeChange('register')}
                        className="text-sm text-orange-600 hover:underline"
                      >
                        ¿No tienes cuenta? Regístrate
                      </button>
                    </div>
                  </motion.div>
                )}

                {mode === 'email' && (
                  <motion.form
                    key="email"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    onSubmit={handleEmailLogin}
                    className="space-y-4"
                  >
                    <div className="space-y-2">
                      <Label htmlFor="email">Correo electrónico</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="email"
                          type="email"
                          placeholder="tu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10 h-12"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="password">Contraseña</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="••••••••"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 pr-10 h-12"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Info de seguridad */}
                    <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted p-2 rounded-lg">
                      <Shield className="h-4 w-4 text-green-500" />
                      <span>Tus credenciales se guardan de forma segura y oculta</span>
                    </div>

                    <Button
                      type="submit"
                      className="w-full h-12 text-base bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="h-5 w-5 animate-spin mr-2" />
                      ) : null}
                      Iniciar Sesión
                    </Button>

                    <Button
                      type="button"
                      variant="ghost"
                      className="w-full"
                      onClick={() => handleModeChange('options')}
                    >
                      Volver
                    </Button>
                  </motion.form>
                )}

                {mode === 'register' && (
                  <motion.form
                    key="register"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    onSubmit={handleRegister}
                    className="space-y-4"
                  >
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre completo</Label>
                      <Input
                        id="name"
                        type="text"
                        placeholder="Tu nombre"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="h-12"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="reg-email">Correo electrónico</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="reg-email"
                          type="email"
                          placeholder="tu@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="pl-10 h-12"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="reg-password">Contraseña</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="reg-password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="Mínimo 8 caracteres"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          className="pl-10 pr-10 h-12"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>

                    {/* CAPTCHA */}
                    <div className="space-y-2">
                      <Label htmlFor="captcha" className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-500" />
                        Verificación de seguridad
                      </Label>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 flex items-center gap-2 bg-muted rounded-lg px-4 py-3">
                          <span className="text-lg font-mono font-bold select-none">
                            {captcha.num1} {captcha.operator} {captcha.num2} = ?
                          </span>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={refreshCaptcha}
                          className="flex-shrink-0"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                      <Input
                        id="captcha"
                        type="number"
                        placeholder="Introduce el resultado"
                        value={captchaInput}
                        onChange={(e) => {
                          setCaptchaInput(e.target.value)
                          setCaptchaError(false)
                        }}
                        className={`h-12 ${captchaError ? 'border-red-500 focus-visible:ring-red-500' : ''}`}
                      />
                      {captchaError && (
                        <p className="text-xs text-red-500">CAPTCHA incorrecto</p>
                      )}
                    </div>

                    {/* Info de seguridad */}
                    <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted p-2 rounded-lg">
                      <Shield className="h-4 w-4 text-green-500" />
                      <span>Contraseña guardada de forma segura y oculta en tu perfil</span>
                    </div>

                    <label className="flex items-start gap-2 text-sm cursor-pointer">
                      <input type="checkbox" className="rounded mt-1" required />
                      <span className="text-muted-foreground">
                        Acepto los <a href="#" className="text-orange-600 hover:underline">Términos de Servicio</a> y la <a href="#" className="text-orange-600 hover:underline">Política de Privacidad</a>
                      </span>
                    </label>

                    <Button
                      type="submit"
                      className="w-full h-12 text-base bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <Loader2 className="h-5 w-5 animate-spin mr-2" />
                      ) : null}
                      Crear Cuenta
                    </Button>

                    <Button
                      type="button"
                      variant="ghost"
                      className="w-full"
                      onClick={() => handleModeChange('options')}
                    >
                      Volver
                    </Button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </motion.div>

          {/* Security Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-6 bg-white/10 backdrop-blur rounded-xl p-4 text-white"
          >
            <div className="flex items-center gap-3 mb-2">
              <Shield className="h-5 w-5" />
              <span className="font-medium text-sm">Tus datos están protegidos</span>
            </div>
            <div className="space-y-1 text-xs text-white/80">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-3 w-3 text-green-300" />
                <span>Email guardado automáticamente en tu perfil</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-3 w-3 text-green-300" />
                <span>Contraseña oculta y protegida</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-3 w-3 text-green-300" />
                <span>Plan gratuito al registrarte</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-3 w-3 text-green-300" />
                <span>Protegido contra bots con CAPTCHA</span>
              </div>
            </div>
          </motion.div>

          {/* Footer */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-center text-white/60 text-xs mt-4"
          >
            Al continuar, aceptas nuestros Términos de Servicio y Política de Privacidad
          </motion.p>
        </motion.div>
      </div>
    </motion.div>
  )
}
