"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { recipes } from "@/data/roulette-recipes"
import { 
  Sparkles, 
  RotateCcw, 
  Clock, 
  Users, 
  ChefHat,
  Star,
  Heart,
  Share2,
  ExternalLink
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

interface RouletteProps {
  onRecipeSelected?: (recipe: typeof recipes[0]) => void
}

const categories = [
  { name: "Desayuno", color: "#FF6B6B", icon: "🌅" },
  { name: "Almuerzo", color: "#4ECDC4", icon: "🍽️" },
  { name: "Cena", color: "#45B7D1", icon: "🌙" },
  { name: "Postre", color: "#96CEB4", icon: "🍰" },
  { name: "Snack", color: "#FFEAA7", icon: "🍿" },
  { name: "Thermomix", color: "#DDA0DD", icon: "🔧" },
  { name: "Crockpot", color: "#98D8C8", icon: "🍲" },
  { name: "Tradicional", color: "#F7DC6F", icon: "👨‍🍳" },
]

export function RecipeRoulette({ onRecipeSelected }: RouletteProps) {
  const [isSpinning, setIsSpinning] = useState(false)
  const [rotation, setRotation] = useState(0)
  const [selectedRecipe, setSelectedRecipe] = useState<typeof recipes[0] | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [favorites, setFavorites] = useState<Set<string>>(new Set())
  const [isClient, setIsClient] = useState(false)
  const wheelRef = useRef<HTMLDivElement>(null)

  // Track client-side mount for hydration safety
  useEffect(() => {
    // Use a microtask to defer the state update
    const timeout = setTimeout(() => setIsClient(true), 0)
    return () => clearTimeout(timeout)
  }, [])

  const spinWheel = () => {
    if (isSpinning) return
    
    setIsSpinning(true)
    setSelectedRecipe(null)
    setSelectedCategory(null)
    
    // Random rotation between 5-10 full spins plus random angle
    const spins = 5 + Math.random() * 5
    const randomAngle = Math.random() * 360
    const totalRotation = rotation + (spins * 360) + randomAngle
    
    setRotation(totalRotation)
    
    // After spin completes, select a random recipe
    setTimeout(() => {
      const randomIndex = Math.floor(Math.random() * recipes.length)
      const recipe = recipes[randomIndex]
      setSelectedRecipe(recipe)
      
      // Determine category based on recipe
      const categoryIndex = Math.floor(Math.random() * categories.length)
      setSelectedCategory(categories[categoryIndex].name)
      
      setIsSpinning(false)
      
      if (onRecipeSelected) {
        onRecipeSelected(recipe)
      }
    }, 4000)
  }

  const toggleFavorite = (recipeId: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev)
      if (newFavorites.has(recipeId)) {
        newFavorites.delete(recipeId)
      } else {
        newFavorites.add(recipeId)
      }
      return newFavorites
    })
  }

  const spinAgain = () => {
    setSelectedRecipe(null)
    setSelectedCategory(null)
    setTimeout(spinWheel, 100)
  }

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case "facil": return "Fácil"
      case "medio": return "Media"
      case "dificil": return "Difícil"
      default: return difficulty
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "facil": return "bg-green-500"
      case "medio": return "bg-yellow-500"
      case "dificil": return "bg-red-500"
      default: return "bg-gray-500"
    }
  }

  const getToolTypeLabel = (toolType: string) => {
    switch (toolType) {
      case "tradicional": return "Tradicional"
      case "thermomix": return "Thermomix"
      case "crockpot": return "Crockpot"
      default: return toolType
    }
  }

  // Pre-calculate wheel segments to avoid hydration issues
  const wheelSegments = categories.map((category, index) => {
    const angle = 360 / categories.length
    const startAngle = index * angle
    const endAngle = (index + 1) * angle
    return { category, angle, startAngle, endAngle, index }
  })

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Título */}
      <div className="text-center mb-8">
        <h2 className="text-3xl md:text-4xl font-bold mb-2 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 bg-clip-text text-transparent">
          🎰 Ruleta de Recetas
        </h2>
        <p className="text-muted-foreground">
          ¡Gira la ruleta y descubre tu próxima receta sorpresa!
        </p>
      </div>

      {/* Ruleta Visual */}
      <div className="flex flex-col items-center gap-8">
        <div className="relative">
          {/* Puntero */}
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
            <div className="w-0 h-0 border-l-[20px] border-r-[20px] border-t-[30px] border-l-transparent border-r-transparent border-t-orange-500 drop-shadow-lg" />
          </div>
          
          {/* Rueda */}
          <div 
            ref={wheelRef}
            className="relative w-72 h-72 md:w-80 md:h-80 rounded-full shadow-2xl border-8 border-orange-500 overflow-hidden"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: isSpinning ? 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none'
            }}
          >
            {wheelSegments.map(({ category, angle, startAngle, endAngle }) => {
              // Pre-calculated values for consistent SSR/CSR
              const cos1 = 50 + 50 * Math.cos((startAngle - 90) * Math.PI / 180)
              const sin1 = 50 + 50 * Math.sin((startAngle - 90) * Math.PI / 180)
              const cos2 = 50 + 50 * Math.cos((endAngle - 90) * Math.PI / 180)
              const sin2 = 50 + 50 * Math.sin((endAngle - 90) * Math.PI / 180)
              
              return (
                <div
                  key={category.name}
                  className="absolute w-full h-full"
                  style={{
                    background: `conic-gradient(from ${startAngle}deg, ${category.color} ${startAngle}deg, ${category.color} ${endAngle}deg)`,
                    clipPath: `polygon(50% 50%, ${cos1}% ${sin1}%, ${cos2}% ${sin2}%)`
                  }}
                >
                  <div 
                    className="absolute text-2xl font-bold text-white drop-shadow-lg flex items-center justify-center"
                    style={{
                      top: '25%',
                      left: '50%',
                      transform: `rotate(${startAngle + angle / 2}deg) translateX(-50%)`,
                      transformOrigin: '0 100%'
                    }}
                  >
                    <span className="flex items-center gap-1 whitespace-nowrap">
                      <span>{category.icon}</span>
                    </span>
                  </div>
                </div>
              )
            })}
            
            {/* Centro de la ruleta */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 md:w-20 md:h-20 bg-white rounded-full shadow-xl flex items-center justify-center border-4 border-orange-300">
              <ChefHat className="w-8 h-8 md:w-10 md:h-10 text-orange-500" />
            </div>
          </div>
        </div>

        {/* Botón de Girar */}
        <Button
          onClick={spinWheel}
          disabled={isSpinning}
          size="lg"
          className="text-xl px-12 py-6 bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 hover:from-orange-600 hover:via-red-600 hover:to-pink-600 shadow-xl hover:shadow-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSpinning ? (
            <>
              <RotateCcw className="w-6 h-6 mr-2 animate-spin" />
              Girando...
            </>
          ) : (
            <>
              <Sparkles className="w-6 h-6 mr-2" />
              ¡GIRAR RULETA!
            </>
          )}
        </Button>
      </div>

      {/* Receta Seleccionada - only render on client to avoid hydration issues */}
      {isClient && selectedRecipe && !isSpinning && (
        <div className="mt-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <Card className="overflow-hidden border-2 border-orange-200 shadow-2xl">
            <div className="relative h-64 md:h-80">
              <Image
                src={selectedRecipe.imageUrl || `/recipe-placeholder.svg`}
                alt={selectedRecipe.title}
                fill
                className="object-cover"
                unoptimized
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
              
              {/* Badge de categoría */}
              {selectedCategory && (
                <Badge className="absolute top-4 left-4 text-lg px-4 py-1 bg-gradient-to-r from-orange-500 to-red-500 border-0">
                  {selectedCategory}
                </Badge>
              )}
              
              {/* Badge de tipo de herramienta */}
              <Badge className="absolute top-4 left-32 text-sm px-3 py-1 bg-white/90 text-gray-800 border-0">
                {getToolTypeLabel(selectedRecipe.toolType)}
              </Badge>
              
              {/* Botón de favoritos */}
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm hover:bg-white/40"
                onClick={() => toggleFavorite(selectedRecipe.id)}
              >
                <Heart 
                  className={`w-6 h-6 ${favorites.has(selectedRecipe.id) ? 'fill-red-500 text-red-500' : 'text-white'}`} 
                />
              </Button>
              
              {/* Título */}
              <div className="absolute bottom-4 left-4 right-4">
                <h3 className="text-2xl md:text-3xl font-bold text-white mb-2 drop-shadow-lg">
                  {selectedRecipe.title}
                </h3>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-white/20 backdrop-blur-sm border-0">
                    <Clock className="w-3 h-3 mr-1" />
                    {selectedRecipe.totalTime} min
                  </Badge>
                  <Badge className="bg-white/20 backdrop-blur-sm border-0">
                    <Users className="w-3 h-3 mr-1" />
                    4 personas
                  </Badge>
                  <Badge className={`${getDifficultyColor(selectedRecipe.difficulty)} border-0`}>
                    {getDifficultyLabel(selectedRecipe.difficulty)}
                  </Badge>
                </div>
              </div>
            </div>
            
            <CardContent className="p-6">
              <p className="text-muted-foreground mb-4 line-clamp-2">
                {selectedRecipe.description}
              </p>
              
              {/* Estrellas de valoración */}
              <div className="flex items-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${i < Math.floor(selectedRecipe.averageRating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
                  />
                ))}
                <span className="text-sm text-muted-foreground ml-2">
                  ({selectedRecipe.averageRating.toFixed(1)}) · {selectedRecipe.ratingCount} valoraciones
                </span>
              </div>
              
              {/* Info adicional */}
              <div className="grid grid-cols-2 gap-4 mb-4 p-4 bg-muted/50 rounded-lg">
                <div>
                  <p className="text-sm text-muted-foreground">Tiempo preparación</p>
                  <p className="font-semibold">{selectedRecipe.prepTime} min</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tiempo cocción</p>
                  <p className="font-semibold">{selectedRecipe.cookTime} min</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Tipo de cocina</p>
                  <p className="font-semibold capitalize">{selectedRecipe.mealType}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Herramienta</p>
                  <p className="font-semibold">{getToolTypeLabel(selectedRecipe.toolType)}</p>
                </div>
              </div>
              
              {/* Botones de acción */}
              <div className="flex flex-wrap gap-3">
                <Link href={`/recetas/${selectedRecipe.id}`} className="flex-1">
                  <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Ver Receta Completa
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  onClick={spinAgain}
                  className="border-orange-300 hover:bg-orange-50"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Otra Receta
                </Button>
                <Button variant="outline" className="border-orange-300 hover:bg-orange-50">
                  <Share2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Historial de recetas sugeridas - only render on client */}
      {isClient && selectedRecipe && (
        <div className="mt-8 p-6 bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-950/20 dark:to-red-950/20 rounded-xl">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-orange-500" />
            ¿Sabías que...?
          </h3>
          <p className="text-muted-foreground">
            Esta receta de <strong>{selectedRecipe.title}</strong> es perfecta para{' '}
            {selectedRecipe.totalTime < 30 
              ? "cuando tienes poco tiempo" 
              : "ocasiones especiales"
            }. 
            {' '}Con una dificultad <strong>{getDifficultyLabel(selectedRecipe.difficulty).toLowerCase()}</strong>, 
            {' '}es ideal para {selectedRecipe.difficulty === "facil" 
              ? "principiantes en la cocina" 
              : selectedRecipe.difficulty === "medio" 
                ? "cocineros con algo de experiencia"
                : "chef experimentados"
            }.
          </p>
        </div>
      )}
    </div>
  )
}
