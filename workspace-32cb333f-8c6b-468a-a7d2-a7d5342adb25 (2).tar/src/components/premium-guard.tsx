'use client'

import { useUserStore, PlanType } from '@/store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Crown, Lock, Sparkles, X } from 'lucide-react'
import Link from 'next/link'
import { motion } from 'framer-motion'

interface PremiumGuardProps {
  children: React.ReactNode
  requiredPlan: 'ultra' | 'masterchef'
  featureName?: string
}

const planHierarchy: Record<PlanType, number> = {
  basic: 0,
  ultra: 1,
  masterchef: 2,
}

// Component to show "OCULTO - SOLO PLANES DE PAGO" for premium features
export function PremiumGuard({ children, requiredPlan, featureName = 'esta función' }: PremiumGuardProps) {
  const { subscription } = useUserStore()
  const userPlanLevel = planHierarchy[subscription.plan]
  const requiredLevel = planHierarchy[requiredPlan]

  // Si el usuario tiene el plan suficiente, mostrar el contenido
  const hasAccess = userPlanLevel >= requiredLevel && 
    (subscription.isSubscriptionActive || subscription.isTrialActive || subscription.plan === 'basic')

  if (hasAccess) {
    return <>{children}</>
  }

  // Mostrar el bloqueo premium con "OCULTO - SOLO PLANES DE PAGO"
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex items-center justify-center p-4"
    >
      <Card className="max-w-sm w-full border-2 border-dashed border-muted-foreground/30 bg-muted/30">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-12 h-12 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900 flex items-center justify-center mb-3">
            <Lock className="h-6 w-6 text-gray-500" />
          </div>
          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg px-3 py-1.5 mb-2">
            <p className="text-xs font-bold text-gray-600 dark:text-gray-400 tracking-wide">
              🔒 OCULTO - SOLO PLANES DE PAGO
            </p>
          </div>
          <CardTitle className="text-lg">{featureName}</CardTitle>
          <CardDescription>
            Disponible en plan {requiredPlan === 'masterchef' ? 'MasterChef' : 'Ultra'}
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-3 pt-0">
          <Link href="/planes">
            <Button size="sm" className="w-full bg-gradient-to-r from-orange-500 to-purple-500 hover:from-orange-600 hover:to-purple-600">
              <Crown className="h-4 w-4 mr-2" />
              Ver Planes
            </Button>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  )
}

// Component to completely hide content if user doesn't have premium
export function PremiumHide({ children, requiredPlan }: { children: React.ReactNode; requiredPlan: 'ultra' | 'masterchef' }) {
  const { subscription } = useUserStore()
  const userPlanLevel = planHierarchy[subscription.plan]
  const requiredLevel = planHierarchy[requiredPlan]

  const hasAccess = userPlanLevel >= requiredLevel && 
    (subscription.isSubscriptionActive || subscription.isTrialActive)

  if (hasAccess) {
    return <>{children}</>
  }

  return null
}

// Component to show a premium badge
export function PremiumBadge({ requiredPlan }: { requiredPlan: 'ultra' | 'masterchef' }) {
  const { subscription } = useUserStore()
  const userPlanLevel = planHierarchy[subscription.plan]
  const requiredLevel = planHierarchy[requiredPlan]
  const hasAccess = userPlanLevel >= requiredLevel && 
    (subscription.isSubscriptionActive || subscription.isTrialActive)

  if (hasAccess) {
    return null
  }

  return (
    <Badge className="bg-gray-200 text-gray-600 dark:bg-gray-800 dark:text-gray-400 text-xs">
      <Lock className="h-3 w-3 mr-1" />
      Premium
    </Badge>
  )
}

// Component for premium button
export function PremiumButton({ 
  children, 
  requiredPlan,
  className,
  onClick,
}: { 
  children: React.ReactNode
  requiredPlan: 'ultra' | 'masterchef'
  className?: string
  onClick?: () => void
}) {
  const { subscription } = useUserStore()
  const userPlanLevel = planHierarchy[subscription.plan]
  const requiredLevel = planHierarchy[requiredPlan]
  const hasAccess = userPlanLevel >= requiredLevel && 
    (subscription.isSubscriptionActive || subscription.isTrialActive)

  return (
    <Button disabled={!hasAccess} className={className} onClick={onClick}>
      {!hasAccess && <Lock className="h-4 w-4 mr-2" />}
      {children}
    </Button>
  )
}

// Hook to verify premium access
export function usePremiumAccess(requiredPlan: 'ultra' | 'masterchef'): boolean {
  const { subscription } = useUserStore()
  const userPlanLevel = planHierarchy[subscription.plan]
  const requiredLevel = planHierarchy[requiredPlan]
  
  return userPlanLevel >= requiredLevel && 
    (subscription.isSubscriptionActive || subscription.isTrialActive || subscription.plan === 'basic')
}

// Component to show premium overlay on content
export function PremiumOverlay({ 
  children, 
  requiredPlan,
  featureName = 'esta función'
}: { 
  children: React.ReactNode
  requiredPlan: 'ultra' | 'masterchef'
  featureName?: string
}) {
  const { subscription } = useUserStore()
  const userPlanLevel = planHierarchy[subscription.plan]
  const requiredLevel = planHierarchy[requiredPlan]
  const hasAccess = userPlanLevel >= requiredLevel && 
    (subscription.isSubscriptionActive || subscription.isTrialActive)

  if (hasAccess) {
    return <>{children}</>
  }

  return (
    <div className="relative">
      <div className="blur-sm pointer-events-none select-none grayscale">
        {children}
      </div>
      <div className="absolute inset-0 flex items-center justify-center bg-background/80 backdrop-blur-sm rounded-lg">
        <div className="text-center p-4">
          <div className="bg-gray-100 dark:bg-gray-800 rounded-lg px-3 py-1.5 mb-3">
            <p className="text-xs font-bold text-gray-600 dark:text-gray-400 tracking-wide">
              🔒 OCULTO - SOLO PLANES DE PAGO
            </p>
          </div>
          <Lock className="h-8 w-8 mx-auto mb-2 text-gray-500" />
          <p className="text-sm font-medium mb-3">{featureName}</p>
          <Link href="/planes">
            <Button size="sm" className="bg-gradient-to-r from-orange-500 to-purple-500">
              <Crown className="h-3 w-3 mr-1" />
              Desbloquear
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

// Component for listing premium features with proper hiding
export function PremiumFeatureList({ features }: { features: string[] }) {
  const { subscription } = useUserStore()
  const isPremium = subscription.plan !== 'basic' && (subscription.isSubscriptionActive || subscription.isTrialActive)

  return (
    <div className="space-y-1">
      {features.map((feature, index) => (
        <div key={index} className={`flex items-center gap-2 text-sm ${!isPremium ? 'text-muted-foreground opacity-60' : ''}`}>
          {!isPremium ? (
            <X className="h-4 w-4 flex-shrink-0" />
          ) : (
            <Lock className="h-4 w-4 flex-shrink-0 text-green-500" />
          )}
          <span>{feature}</span>
        </div>
      ))}
    </div>
  )
}
