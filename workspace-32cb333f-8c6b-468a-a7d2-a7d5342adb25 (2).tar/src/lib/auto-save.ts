// Sistema de Auto-Guardado para CocinaViva
// Guarda datos automáticamente en múltiples ubicaciones para evitar pérdida de datos

// Claves de almacenamiento
const STORAGE_KEYS = {
  USER: 'cocinaviva-user-v3',
  TIMERS: 'cocinaviva-timers',
  SHOPPING: 'cocinaviva-shopping',
  OFFLINE: 'cocinaviva-offline',
  STEP_TRACKING: 'cocinaviva-step-tracking',
  BACKUP: 'cocinaviva-backup',
  AUTOSAVE_TIMESTAMP: 'cocinaviva-autosave-timestamp',
}

// Intervalo de auto-guardado (30 segundos)
const AUTOSAVE_INTERVAL = 30000

// Backup data structure
interface BackupData {
  timestamp: string
  version: string
  user: unknown
  timers: unknown
  shopping: unknown
  offline: unknown
  stepTracking: unknown
}

// Verificar si localStorage está disponible
function isLocalStorageAvailable(): boolean {
  try {
    if (typeof window === 'undefined') return false
    const test = '__storage_test__'
    localStorage.setItem(test, test)
    localStorage.removeItem(test)
    return true
  } catch {
    return false
  }
}

// Función para crear backup completo
export function createFullBackup(): BackupData | null {
  if (!isLocalStorageAvailable()) {
    console.warn('localStorage no disponible')
    return {
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      user: null,
      timers: null,
      shopping: null,
      offline: null,
      stepTracking: null,
    }
  }
  
  try {
    const timestamp = new Date().toISOString()
    const version = '1.0.0'
    
    // Obtener datos del localStorage de forma segura
    const user = localStorage.getItem(STORAGE_KEYS.USER)
    const timers = localStorage.getItem(STORAGE_KEYS.TIMERS)
    const shopping = localStorage.getItem(STORAGE_KEYS.SHOPPING)
    const offline = localStorage.getItem(STORAGE_KEYS.OFFLINE)
    const stepTracking = localStorage.getItem(STORAGE_KEYS.STEP_TRACKING)
    
    const backup: BackupData = {
      timestamp,
      version,
      user: user ? safeJsonParse(user) : null,
      timers: timers ? safeJsonParse(timers) : null,
      shopping: shopping ? safeJsonParse(shopping) : null,
      offline: offline ? safeJsonParse(offline) : null,
      stepTracking: stepTracking ? safeJsonParse(stepTracking) : null,
    }
    
    // Guardar backup principal
    localStorage.setItem(STORAGE_KEYS.BACKUP, JSON.stringify(backup))
    
    // Crear backup secundario con fecha
    const dateKey = `cocinaviva-backup-${new Date().toISOString().split('T')[0]}`
    localStorage.setItem(dateKey, JSON.stringify(backup))
    
    // Actualizar timestamp
    localStorage.setItem(STORAGE_KEYS.AUTOSAVE_TIMESTAMP, timestamp)
    
    return backup
  } catch (error) {
    console.error('Error al crear backup:', error)
    return null
  }
}

// Parsear JSON de forma segura
function safeJsonParse(str: string): unknown {
  try {
    return JSON.parse(str)
  } catch {
    return null
  }
}

// Función para restaurar desde backup
export function restoreFromBackup(): boolean {
  if (!isLocalStorageAvailable()) return false
  
  try {
    const backupStr = localStorage.getItem(STORAGE_KEYS.BACKUP)
    if (!backupStr) return false
    
    const backup: BackupData = safeJsonParse(backupStr) as BackupData
    if (!backup) return false
    
    // Restaurar cada store
    if (backup.user) {
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(backup.user))
    }
    if (backup.timers) {
      localStorage.setItem(STORAGE_KEYS.TIMERS, JSON.stringify(backup.timers))
    }
    if (backup.shopping) {
      localStorage.setItem(STORAGE_KEYS.SHOPPING, JSON.stringify(backup.shopping))
    }
    if (backup.offline) {
      localStorage.setItem(STORAGE_KEYS.OFFLINE, JSON.stringify(backup.offline))
    }
    if (backup.stepTracking) {
      localStorage.setItem(STORAGE_KEYS.STEP_TRACKING, JSON.stringify(backup.stepTracking))
    }
    
    return true
  } catch (error) {
    console.error('Error al restaurar backup:', error)
    return false
  }
}

// Función para obtener último auto-guardado
export function getLastAutosaveTime(): string | null {
  if (!isLocalStorageAvailable()) return null
  return localStorage.getItem(STORAGE_KEYS.AUTOSAVE_TIMESTAMP)
}

// Función para verificar integridad de datos
export function verifyDataIntegrity(): { valid: boolean; issues: string[] } {
  const issues: string[] = []
  
  if (!isLocalStorageAvailable()) {
    return { valid: false, issues: ['localStorage no disponible'] }
  }
  
  try {
    // Verificar datos de usuario
    const userStr = localStorage.getItem(STORAGE_KEYS.USER)
    if (userStr) {
      const userData = safeJsonParse(userStr) as { state?: { isAuthenticated?: boolean } }
      if (!userData?.state?.isAuthenticated) {
        issues.push('Datos de usuario incompletos')
      }
    }
    
    // Verificar backup
    const backupStr = localStorage.getItem(STORAGE_KEYS.BACKUP)
    if (!backupStr) {
      issues.push('No hay backup disponible')
    }
    
    return { valid: issues.length === 0, issues }
  } catch {
    return { valid: false, issues: ['Error al verificar datos'] }
  }
}

// Función para limpiar datos antiguos (mantener solo últimos 7 días de backups)
export function cleanupOldData(): void {
  if (!isLocalStorageAvailable()) return
  
  try {
    const keys = Object.keys(localStorage)
    const backupKeys = keys.filter(k => k.startsWith('cocinaviva-backup-') && k !== STORAGE_KEYS.BACKUP)
    
    // Ordenar por fecha (más reciente primero)
    backupKeys.sort().reverse()
    
    // Mantener solo los últimos 7 backups diarios
    const toDelete = backupKeys.slice(7)
    toDelete.forEach(key => localStorage.removeItem(key))
  } catch (error) {
    console.error('Error al limpiar datos antiguos:', error)
  }
}

// Función para obtener tamaño de almacenamiento usado
export function getStorageSize(): { used: number; available: number; percentage: number } {
  if (!isLocalStorageAvailable()) {
    return { used: 0, available: 0, percentage: 0 }
  }
  
  try {
    let totalSize = 0
    const keys = Object.keys(localStorage)
    
    keys.forEach(key => {
      if (key.startsWith('cocinaviva-')) {
        const value = localStorage.getItem(key) || ''
        totalSize += key.length + value.length
      }
    })
    
    // localStorage típicamente tiene 5-10MB de límite
    const maxSize = 5 * 1024 * 1024 // 5MB en bytes
    const percentage = (totalSize / maxSize) * 100
    
    return {
      used: totalSize,
      available: maxSize - totalSize,
      percentage: Math.round(percentage * 100) / 100
    }
  } catch {
    return { used: 0, available: 0, percentage: 0 }
  }
}

// Hook para auto-guardado
export function useAutoSave() {
  // Función para forzar guardado inmediato
  const forceSave = () => {
    createFullBackup()
    cleanupOldData()
    return getLastAutosaveTime()
  }
  
  // Función para obtener estado del almacenamiento
  const getStorageStatus = () => {
    const size = getStorageSize()
    const integrity = verifyDataIntegrity()
    const lastSave = getLastAutosaveTime()
    
    return {
      size,
      integrity,
      lastSave,
    }
  }
  
  return {
    forceSave,
    getStorageStatus,
    restoreFromBackup,
    createFullBackup,
  }
}

// Auto-guardado en segundo plano
let autosaveInterval: ReturnType<typeof setInterval> | null = null
let beforeUnloadHandler: (() => void) | null = null
let visibilityChangeHandler: (() => void) | null = null

export function startAutoSave(): void {
  if (autosaveInterval) return
  if (typeof window === 'undefined') return
  
  autosaveInterval = setInterval(() => {
    try {
      createFullBackup()
      cleanupOldData()
    } catch (error) {
      console.error('Error en auto-guardado:', error)
    }
  }, AUTOSAVE_INTERVAL)
  
  // Crear handlers para remover después
  beforeUnloadHandler = () => createFullBackup()
  visibilityChangeHandler = () => {
    if (document.visibilityState === 'hidden') {
      createFullBackup()
    }
  }
  
  // Añadir event listeners
  window.addEventListener('beforeunload', beforeUnloadHandler)
  document.addEventListener('visibilitychange', visibilityChangeHandler)
}

export function stopAutoSave(): void {
  if (autosaveInterval) {
    clearInterval(autosaveInterval)
    autosaveInterval = null
  }
  
  // Remover event listeners
  if (typeof window !== 'undefined') {
    if (beforeUnloadHandler) {
      window.removeEventListener('beforeunload', beforeUnloadHandler)
      beforeUnloadHandler = null
    }
    if (visibilityChangeHandler) {
      document.removeEventListener('visibilitychange', visibilityChangeHandler)
      visibilityChangeHandler = null
    }
  }
}

// Exportar todo
const autoSaveModule = {
  createFullBackup,
  restoreFromBackup,
  getLastAutosaveTime,
  verifyDataIntegrity,
  cleanupOldData,
  getStorageSize,
  useAutoSave,
  startAutoSave,
  stopAutoSave,
  isLocalStorageAvailable,
}

export default autoSaveModule
