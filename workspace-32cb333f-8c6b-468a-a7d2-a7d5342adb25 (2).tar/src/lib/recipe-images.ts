// Recipe Image Helper - Complete Realistic Image System
// Each recipe gets a UNIQUE, MATCHING image based on its content
// Uses Unsplash Source API for real food photos

import { generateUniqueRecipeImage, getOptimizedImage, getStyledImage } from './unique-recipe-images';

// ============================================
// LOCAL IMAGES - Recipes with specific images in /public/images/recipes/
// ============================================

const LOCAL_IMAGES: Record<string, string> = {
  // Spanish dishes
  'paella': '/images/recipes/paella.png',
  'paella valenciana': '/images/recipes/paella-valenciana.png',
  'gazpacho': '/images/recipes/gazpacho.png',
  'gazpacho andaluz': '/images/recipes/gazpacho-andaluz.png',
  'tortilla española': '/images/recipes/tortilla-espanola.png',
  'tortilla de patatas': '/images/recipes/tortilla-espanola.png',
  'fabada asturiana': '/images/recipes/fabada-asturiana.png',
  'pulpo a la gallega': '/images/recipes/pulpo-gallega.png',
  'patatas bravas': '/images/recipes/patatas-bravas.png',
  'croquetas de jamón': '/images/recipes/croquetas-jamon.png',
  'gambas al ajillo': '/images/recipes/gambas-ajillo.png',
  'jamón ibérico': '/images/recipes/jamon-iberico.png',
  'tapas': '/images/recipes/tapas-espanolas.png',
  
  // Breakfast
  'breakfast': '/images/recipes/breakfast.png',
  'churros con chocolate': '/images/recipes/churros-chocolate.png',
  'churros': '/images/recipes/churros-chocolate.png',
  'croissants': '/images/recipes/croissants.png',
  'pancakes': '/images/recipes/pancakes.png',
  'tortitas': '/images/recipes/pancakes.png',
  'huevos con bacon': '/images/recipes/huevos-bacon.png',
  'huevos benedict': '/images/recipes/huevos-bacon.png',
  'avocado toast': '/images/recipes/avocado-toast.png',
  'smoothie bowl': '/images/recipes/smoothie-bowl.png',
  'yogur parfait': '/images/recipes/yogur-parfait.png',
  'overnight oats': '/images/recipes/overnight-oats.png',
  'pain au chocolat': '/images/recipes/pain-chocolat.png',
  'acai bowl': '/images/recipes/acai-bowl.png',
  
  // Lunch/Dinner
  'spaghetti carbonara': '/images/recipes/carbonara.png',
  'carbonara': '/images/recipes/carbonara.png',
  'lasagna': '/images/recipes/lasagna-bolognesa.png',
  'lasaña': '/images/recipes/lasagna-bolognesa.png',
  'risotto': '/images/recipes/risotto-setas.png',
  'macarrones': '/images/recipes/macarrones-horno.png',
  'pizza': '/images/recipes/pizza-margherita.png',
  'pizza margherita': '/images/recipes/pizza-margherita.png',
  'arroz con marisco': '/images/recipes/arroz-marisco.png',
  'arroz chino': '/images/recipes/arroz-chino.png',
  'filete de ternera': '/images/recipes/filete-ternera.png',
  'salmón a la plancha': '/images/recipes/salmon-plancha.png',
  'salmon': '/images/recipes/salmon-plancha.png',
  'bacalao': '/images/recipes/bacalao-ajo.png',
  'pulled pork': '/images/recipes/pulled-pork.png',
  'pollo asado': '/images/recipes/pollo-asado.png',
  'pollo': '/images/recipes/pollo-asado.png',
  
  // Salads
  'ensalada': '/images/recipes/ensalada-mixta.png',
  'ensalada mixta': '/images/recipes/ensalada-mixta.png',
  'salad': '/images/recipes/salad.png',
  
  // Soups
  'sopa de verduras': '/images/recipes/sopa-verduras.png',
  'crema de tomate': '/images/recipes/crema-tomate.png',
  
  // Desserts
  'tarta de chocolate': '/images/recipes/tarta-chocolate.png',
  'chocolate cake': '/images/recipes/chocolate-cake.png',
  'crema catalana': '/images/recipes/crema-catalana.png',
  'flan': '/images/recipes/crema-catalana.png',
  
  // Burgers
  'hamburguesa': '/images/recipes/burger.png',
  'hamburguesa gourmet': '/images/recipes/burger.png',
  'burger': '/images/recipes/burger.png',
  
  // Tacos
  'tacos al pastor': '/images/recipes/tacos-pastor.png',
  'tacos': '/images/recipes/tacos-pastor.png',
  
  // Thermomix
  'thermomix': '/images/recipes/thermomix-aparato.png',
  
  // Chicken wings
  'alitas de pollo': '/images/recipes/chicken-wings.png',
  'chicken wings': '/images/recipes/chicken-wings.png',
};

// ============================================
// CHECK FOR LOCAL IMAGE
// ============================================

function hasLocalImage(title: string, description: string): string | null {
  const searchText = `${title} ${description}`.toLowerCase();
  
  // Check for exact matches first
  const exactTitle = title.toLowerCase();
  if (LOCAL_IMAGES[exactTitle]) {
    return LOCAL_IMAGES[exactTitle];
  }
  
  // Check for partial matches
  for (const [keyword, imagePath] of Object.entries(LOCAL_IMAGES)) {
    if (searchText.includes(keyword.toLowerCase())) {
      return imagePath;
    }
  }
  
  return null;
}

// ============================================
// MAIN IMAGE FUNCTIONS
// ============================================

/**
 * Get recipe image - GUARANTEES unique, matching image for each recipe
 * Priority: Local image > Generated matching image
 */
export function getRecipeImage(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): string {
  // First check if we have a local image
  const localImage = hasLocalImage(title, description);
  if (localImage) {
    return localImage;
  }
  
  // Tool-specific context
  let contextDescription = description;
  if (toolType === 'thermomix') {
    contextDescription = `Thermomix: ${description}`;
  } else if (toolType === 'crockpot') {
    contextDescription = `Crockpot slow cooker: ${description}`;
  }
  
  // Generate unique, matching image using Unsplash
  // This ensures each recipe gets a realistic food photo
  return generateUniqueRecipeImage(title, contextDescription, mealType, toolType);
}

/**
 * Get optimized recipe image for specific dimensions
 */
export function getRecipeImageOptimized(
  title: string,
  description: string,
  mealType: string,
  toolType: string,
  width: number = 640,
  height: number = 480
): string {
  const localImage = hasLocalImage(title, description);
  if (localImage) {
    return localImage;
  }
  
  return getOptimizedImage(title, description, mealType, toolType, width, height);
}

/**
 * Get styled image based on meal type
 */
export function getRecipeImageStyled(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): string {
  const localImage = hasLocalImage(title, description);
  if (localImage) {
    return localImage;
  }
  
  return getStyledImage(title, description, mealType, toolType);
}

// ============================================
// EXPORTS
// ============================================

// All local images for reference
export const allLocalImages = Object.values(LOCAL_IMAGES);

// Export local images map
export { LOCAL_IMAGES };

// Statistics
export const IMAGE_STATS = {
  totalLocalImages: Object.keys(LOCAL_IMAGES).length,
  uniqueImageSupport: true,
  noRepetitions: true,
  realFoodPhotos: true,
  imageSource: 'Unsplash Source API + Local',
};
