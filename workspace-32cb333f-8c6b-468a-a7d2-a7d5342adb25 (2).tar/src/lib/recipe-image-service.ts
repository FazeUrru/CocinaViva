// Recipe Image Service - Free image system without AI
// Uses multiple free image sources for recipe images

// Free image sources configuration
const IMAGE_SOURCES = {
  // LoremFlickr - Free food images by category
  loremflickr: (category: string, seed: number) => 
    `https://loremflickr.com/640/480/${category}?random=${seed}`,
  
  // Picsum - Random high quality images (not food specific but works)
  picsum: (seed: number) => 
    `https://picsum.photos/seed/${seed}/640/480`,
};

// Recipe category to image search terms mapping
const RECIPE_IMAGE_CATEGORIES: Record<string, string[]> = {
  // Desayuno categories
  'tostada': ['toast', 'bread', 'breakfast'],
  'tortilla': ['tortilla', 'omelette', 'eggs'],
  'churros': ['churros', 'donuts', 'pastry'],
  'torrijas': ['french-toast', 'toast', 'sweet'],
  'huevos': ['eggs', 'breakfast', 'fried-eggs'],
  'pancakes': ['pancakes', 'breakfast', 'syrup'],
  'tortitas': ['pancakes', 'breakfast', 'fluffy'],
  'croissant': ['croissant', 'pastry', 'french-breakfast'],
  'waffles': ['waffles', 'breakfast', 'belgian'],
  'crepes': ['crepes', 'french', 'breakfast'],
  'brioche': ['brioche', 'bread', 'french'],
  'muffin': ['muffins', 'bakery', 'breakfast'],
  'bagel': ['bagel', 'cream-cheese', 'breakfast'],
  'granola': ['granola', 'yogurt', 'healthy-breakfast'],
  'yogur': ['yogurt', 'parfait', 'breakfast'],
  'smoothie': ['smoothie', 'healthy', 'fruit-drink'],
  'batido': ['smoothie', 'shake', 'fruit'],
  'acai': ['acai-bowl', 'smoothie-bowl', 'healthy'],
  'avena': ['oatmeal', 'porridge', 'healthy-breakfast'],
  'oatmeal': ['oatmeal', 'porridge', 'breakfast'],
  'chia': ['chia-pudding', 'healthy', 'breakfast'],
  'aguacate': ['avocado', 'avocado-toast', 'healthy'],
  'migas': ['breadcrumbs', 'spanish', 'traditional'],
  'jamon': ['ham', 'spanish-ham', 'iberico'],
  'jamon': ['ham', 'iberico', 'spanish'],
  
  // Almuerzo/Cena categories
  'paella': ['paella', 'spanish-rice', 'seafood-rice'],
  'arroz': ['rice', 'fried-rice', 'spanish-rice'],
  'gazpacho': ['gazpacho', 'cold-soup', 'spanish'],
  'sopa': ['soup', 'vegetable-soup', 'warm'],
  'crema': ['cream-soup', 'puree', 'soup'],
  'pasta': ['pasta', 'italian', 'spaghetti'],
  'spaghetti': ['spaghetti', 'pasta', 'italian'],
  'carbonara': ['carbonara', 'pasta', 'italian'],
  'lasagna': ['lasagna', 'lasagne', 'italian'],
  'risotto': ['risotto', 'italian-rice', 'creamy'],
  'pizza': ['pizza', 'italian', 'cheese'],
  'macarrones': ['macaroni', 'pasta', 'cheese'],
  'ñoquis': ['gnocchi', 'pasta', 'italian'],
  'gnocchi': ['gnocchi', 'pasta', 'potato'],
  
  // Mexican
  'tacos': ['tacos', 'mexican', 'street-food'],
  'taco': ['taco', 'mexican', 'tortilla'],
  'enchiladas': ['enchiladas', 'mexican', 'cheese'],
  'quesadilla': ['quesadilla', 'mexican', 'cheese'],
  'burrito': ['burrito', 'mexican', 'wrap'],
  'guacamole': ['guacamole', 'avocado', 'mexican'],
  'nachos': ['nachos', 'chips', 'cheese'],
  'mole': ['mole', 'mexican', 'sauce'],
  'cochinita': ['pulled-pork', 'mexican', 'slow-cooked'],
  'carnitas': ['carnitas', 'mexican', 'pork'],
  'chili': ['chili', 'spicy', 'stew'],
  'pozole': ['pozole', 'mexican-soup', 'hominy'],
  'tamales': ['tamales', 'mexican', 'wrapped'],
  'fajitas': ['fajitas', 'mexican', 'grilled'],
  'ceviche': ['ceviche', 'seafood', 'mexican'],
  
  // Meats
  'pollo': ['chicken', 'roasted', 'grilled'],
  'chicken': ['chicken', 'roasted', 'dinner'],
  'ternera': ['beef', 'steak', 'grilled'],
  'steak': ['steak', 'beef', 'grilled'],
  'filete': ['steak', 'beef', 'grilled'],
  'carne': ['meat', 'beef', 'grilled'],
  'cordero': ['lamb', 'roasted', 'dinner'],
  'lamb': ['lamb', 'roasted', 'herb'],
  'cerdo': ['pork', 'roasted', 'dinner'],
  'pork': ['pork', 'roasted', 'grilled'],
  'costillas': ['ribs', 'bbq', 'grilled'],
  'ribs': ['ribs', 'bbq', 'meat'],
  'alitas': ['wings', 'chicken-wings', 'buffalo'],
  'wings': ['wicken-wings', 'buffalo', 'appetizer'],
  'bacon': ['bacon', 'crispy', 'breakfast'],
  
  // Seafood
  'salmon': ['salmon', 'fish', 'grilled'],
  'salmon': ['salmon', 'grilled', 'healthy'],
  'bacalao': ['cod', 'fish', 'salted'],
  'cod': ['cod', 'fish', 'fried'],
  'pescado': ['fish', 'seafood', 'grilled'],
  'fish': ['fish', 'grilled', 'dinner'],
  'marisco': ['seafood', 'shellfish', 'dinner'],
  'seafood': ['seafood', 'shellfish', 'platter'],
  'gambas': ['shrimp', 'prawns', 'seafood'],
  'shrimp': ['shrimp', 'prawns', 'grilled'],
  'pulpo': ['octopus', 'seafood', 'grilled'],
  'octopus': ['octopus', 'seafood', 'spanish'],
  'atun': ['tuna', 'fish', 'steak'],
  'tuna': ['tuna', 'fish', 'sashimi'],
  
  // Asian
  'pad-thai': ['pad-thai', 'thai', 'noodles'],
  'ramen': ['ramen', 'japanese', 'noodle-soup'],
  'sushi': ['sushi', 'japanese', 'fish'],
  'curry': ['curry', 'indian', 'spicy'],
  'pho': ['pho', 'vietnamese', 'soup'],
  'bibimbap': ['bibimbap', 'korean', 'rice-bowl'],
  'dim-sum': ['dim-sum', 'chinese', 'dumplings'],
  'banh-mi': ['banh-mi', 'vietnamese', 'sandwich'],
  'congee': ['congee', 'chinese', 'rice-porridge'],
  'nasi-goreng': ['nasi-goreng', 'indonesian', 'fried-rice'],
  'sushi': ['sushi', 'rolls', 'japanese'],
  'dosa': ['dosa', 'indian', 'crepe'],
  'idli': ['idli', 'indian', 'steamed'],
  
  // Mediterranean
  'shakshuka': ['shakshuka', 'eggs', 'tomato'],
  'labneh': ['labneh', 'yogurt', 'middle-eastern'],
  'foul': ['foul', 'beans', 'egyptian'],
  'menemen': ['menemen', 'turkish', 'eggs'],
  'fatteh': ['fatteh', 'lebanese', 'chickpeas'],
  'borek': ['borek', 'turkish', 'pastry'],
  'simit': ['simit', 'turkish', 'bread'],
  'halloumi': ['halloumi', 'cheese', 'grilled'],
  'falafel': ['falafel', 'middle-eastern', 'chickpeas'],
  'hummus': ['hummus', 'chickpea', 'dip'],
  
  // French
  'bourguignon': ['bourguignon', 'beef', 'french'],
  'ratatouille': ['ratatouille', 'vegetables', 'french'],
  'quiche': ['quiche', 'french', 'pie'],
  'french-onion': ['french-onion-soup', 'soup', 'onion'],
  'tarte-tatin': ['tarte-tatin', 'apple-tart', 'french'],
  
  // American
  'hamburguesa': ['burger', 'hamburger', 'american'],
  'burger': ['burger', 'hamburger', 'fast-food'],
  'bbq': ['bbq', 'barbecue', 'grilled'],
  'american': ['american', 'diner', 'classic'],
  
  // Vegetables & Salads
  'ensalada': ['salad', 'vegetables', 'healthy'],
  'salad': ['salad', 'fresh', 'healthy'],
  'verduras': ['vegetables', 'roasted', 'healthy'],
  'vegetables': ['vegetables', 'roasted', 'healthy'],
  'legumbres': ['legumes', 'beans', 'healthy'],
  'legumes': ['legumes', 'beans', 'lentils'],
  'lentejas': ['lentils', 'stew', 'healthy'],
  'alubias': ['beans', 'stew', 'spanish'],
  'fabada': ['fabada', 'beans', 'spanish'],
  'garbanzos': ['chickpeas', 'stew', 'spanish'],
  'escalivada': ['escalivada', 'roasted-peppers', 'catalan'],
  
  // Desserts
  'tarta': ['tart', 'cake', 'dessert'],
  'pastel': ['cake', 'pastry', 'dessert'],
  'cake': ['cake', 'dessert', 'sweet'],
  'galletas': ['cookies', 'biscuits', 'baked'],
  'cookies': ['cookies', 'chocolate-chip', 'baked'],
  'flan': ['flan', 'caramel', 'custard'],
  'custard': ['custard', 'creamy', 'dessert'],
  'mousse': ['mousse', 'creamy', 'dessert'],
  'helado': ['ice-cream', 'frozen', 'dessert'],
  'ice-cream': ['ice-cream', 'cone', 'frozen'],
  'bizcocho': ['sponge-cake', 'cake', 'dessert'],
  'sponge': ['sponge-cake', 'fluffy', 'dessert'],
  'cupcake': ['cupcake', 'frosting', 'dessert'],
  'pudin': ['pudding', 'creamy', 'dessert'],
  'pudding': ['pudding', 'dessert', 'sweet'],
  'brownie': ['brownie', 'chocolate', 'dessert'],
  'cheesecake': ['cheesecake', 'cream-cheese', 'dessert'],
  'tiramisu': ['tiramisu', 'coffee', 'italian-dessert'],
  'panna-cotta': ['panna-cotta', 'italian', 'creamy'],
  'cannoli': ['cannoli', 'sicilian', 'pastry'],
  'gelato': ['gelato', 'italian-ice-cream', 'dessert'],
  'macaron': ['macarons', 'french', 'almond'],
  'eclair': ['eclair', 'french', 'pastry'],
  'profiterole': ['profiteroles', 'cream-puffs', 'chocolate'],
  'creme-brulee': ['creme-brulee', 'french', 'custard'],
  'crema-catalana': ['crema-catalana', 'spanish', 'custard'],
  'arroz-con-leche': ['rice-pudding', 'spanish', 'cinnamon'],
  'apple-pie': ['apple-pie', 'american', 'dessert'],
  'pumpkin-pie': ['pumpkin-pie', 'thanksgiving', 'dessert'],
  'pecan-pie': ['pecan-pie', 'nuts', 'dessert'],
  'key-lime': ['key-lime-pie', 'citrus', 'dessert'],
  'carrot-cake': ['carrot-cake', 'spiced', 'dessert'],
  'red-velvet': ['red-velvet-cake', 'cream-cheese', 'dessert'],
  
  // Snacks
  'patatas': ['potatoes', 'fries', 'snack'],
  'chips': ['chips', 'crisps', 'snack'],
  'nachos': ['nachos', 'tortilla-chips', 'cheese'],
  'dip': ['dip', 'sauce', 'snack'],
  'wings': ['chicken-wings', 'buffalo', 'appetizer'],
  'onion-rings': ['onion-rings', 'fried', 'appetizer'],
  'spring-rolls': ['spring-rolls', 'chinese', 'appetizer'],
  'edamame': ['edamame', 'soybeans', 'japanese'],
  'bruschetta': ['bruschetta', 'italian', 'tomato'],
  'caprese': ['caprese', 'mozzarella', 'tomato'],
  'croquetas': ['croquettes', 'fried', 'spanish'],
  'pincho': ['pinchos', 'tapas', 'spanish'],
  'tapas': ['tapas', 'spanish', 'appetizers'],
  'empanadillas': ['empanadas', 'pastry', 'latin'],
  'pimientos': ['peppers', 'fried', 'spanish'],
  'torreznos': ['pork-rinds', 'crispy', 'spanish'],
  
  // Thermomix & Crockpot
  'thermomix': ['thermomix', 'cooking-appliance', 'kitchen'],
  'crockpot': ['slow-cooker', 'crockpot', 'cooking'],
  'slow-cooker': ['slow-cooker', 'stew', 'cooking'],
  
  // Drinks
  'cafe': ['coffee', 'espresso', 'drink'],
  'coffee': ['coffee', 'latte', 'cappuccino'],
  'te': ['tea', 'herbal', 'drink'],
  'tea': ['tea', 'green', 'herbal'],
  'batido': ['milkshake', 'drink', 'sweet'],
  'milkshake': ['milkshake', 'ice-cream', 'drink'],
  'zumo': ['juice', 'fresh', 'drink'],
  'juice': ['juice', 'orange', 'fresh'],
  
  // Default categories
  'desayuno': ['breakfast', 'morning', 'food'],
  'breakfast': ['breakfast', 'eggs', 'coffee'],
  'almuerzo': ['lunch', 'dinner', 'food'],
  'lunch': ['lunch', 'meal', 'dinner'],
  'cena': ['dinner', 'evening', 'meal'],
  'dinner': ['dinner', 'evening', 'meal'],
  'postre': ['dessert', 'sweet', 'treat'],
  'dessert': ['dessert', 'sweet', 'cake'],
  'snack': ['snack', 'appetizer', 'finger-food'],
  'appetizer': ['appetizer', 'starter', 'tapas'],
};

// Generate a consistent seed from recipe title
function generateSeed(title: string): number {
  let hash = 0;
  for (let i = 0; i < title.length; i++) {
    const char = title.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

// Get image categories from recipe title and description
function getImageCategories(title: string, description: string, mealType: string, toolType: string): string[] {
  const searchText = `${title} ${description} ${mealType} ${toolType}`.toLowerCase();
  const categories: string[] = [];
  
  // Find matching categories
  for (const [keyword, cats] of Object.entries(RECIPE_IMAGE_CATEGORIES)) {
    if (searchText.includes(keyword.toLowerCase())) {
      categories.push(...cats);
    }
  }
  
  // Remove duplicates and limit
  const uniqueCategories = [...new Set(categories)];
  
  // Default fallbacks
  if (uniqueCategories.length === 0) {
    switch (mealType) {
      case 'desayuno':
        return ['breakfast', 'morning', 'food'];
      case 'almuerzo':
        return ['lunch', 'dinner', 'food'];
      case 'cena':
        return ['dinner', 'evening', 'meal'];
      case 'postre':
        return ['dessert', 'sweet', 'treat'];
      case 'snack':
        return ['snack', 'appetizer', 'finger-food'];
      default:
        return ['food', 'cooking', 'delicious'];
    }
  }
  
  return uniqueCategories.slice(0, 3);
}

// Main function to get recipe image URL (FREE - no AI needed)
export function getFreeRecipeImage(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): string {
  const categories = getImageCategories(title, description, mealType, toolType);
  const seed = generateSeed(title);
  
  // Use LoremFlickr with food category
  const category = categories[0] || 'food';
  
  // Use picsum with seed for consistent images
  // This gives us free, high-quality images that are consistent per recipe
  return `https://picsum.photos/seed/${seed}/640/480`;
}

// Alternative: Get image from multiple free sources
export function getRecipeImageFromSource(
  title: string,
  description: string,
  mealType: string,
  toolType: string,
  source: 'picsum' | 'loremflickr' = 'picsum'
): string {
  const categories = getImageCategories(title, description, mealType, toolType);
  const seed = generateSeed(title);
  
  switch (source) {
    case 'loremflickr':
      const category = categories[0] || 'food';
      return IMAGE_SOURCES.loremflickr(category, seed);
    case 'picsum':
    default:
      return IMAGE_SOURCES.picsum(seed);
  }
}

// Get optimized image URL for different sizes
export function getOptimizedRecipeImage(
  title: string,
  description: string,
  mealType: string,
  toolType: string,
  width: number = 640,
  height: number = 480
): string {
  const seed = generateSeed(title);
  return `https://picsum.photos/seed/${seed}/${width}/${height}`;
}

// Batch get images for multiple recipes
export function getBatchRecipeImages(recipes: Array<{
  title: string;
  description: string;
  mealType: string;
  toolType: string;
}>): string[] {
  return recipes.map(r => getFreeRecipeImage(r.title, r.description, r.mealType, r.toolType));
}

// Export the main function as default
export default getFreeRecipeImage;
