// Complete Realistic Recipe Image System
// Each recipe gets a UNIQUE, MATCHING image based on its content
// Uses multiple free image sources for variety and realism

// ============================================
// IMAGE SOURCE CONFIGURATION
// ============================================

// Free image sources that work without API keys
const IMAGE_SOURCES = {
  unsplash: 'https://source.unsplash.com',
  loremflickr: 'https://loremflickr.com',
  picsum: 'https://picsum.photos',
}

// ============================================
// FOOD CATEGORY MAPPINGS
// ============================================

// Detailed food type to search term mappings for realistic images
const FOOD_SEARCH_TERMS: Record<string, string[]> = {
  // Breakfast items
  'tostada': ['toast', 'breakfast-toast', 'spanish-toast'],
  'tortilla_patatas': ['spanish-omelette', 'tortilla', 'potato-omelette'],
  'churros': ['churros', 'spanish-churros', 'churros-chocolate'],
  'torrija': ['french-toast', 'torrija', 'spanish-french-toast'],
  'huevo': ['eggs', 'fried-eggs', 'breakfast-eggs'],
  'migas': ['migas', 'spanish-migas', 'breadcrumbs'],
  'croissant': ['croissant', 'french-croissant', 'pastry'],
  'crepe': ['crepes', 'french-crepes', 'pancake'],
  'pancake': ['pancakes', 'american-pancakes', 'breakfast-pancakes'],
  'waffle': ['waffles', 'belgian-waffles', 'breakfast-waffles'],
  'muffin': ['muffins', 'blueberry-muffins', 'breakfast-muffins'],
  'smoothie': ['smoothie', 'fruit-smoothie', 'breakfast-smoothie'],
  'yogur': ['yogurt', 'greek-yogurt', 'breakfast-yogurt'],
  'avena': ['oatmeal', 'overnight-oats', 'breakfast-oats'],
  'granola': ['granola', 'breakfast-granola', 'cereal'],
  
  // Spanish dishes
  'paella': ['paella', 'spanish-paella', 'valencian-paella', 'seafood-rice'],
  'gazpacho': ['gazpacho', 'spanish-gazpacho', 'cold-soup', 'tomato-soup'],
  'fabada': ['fabada', 'spanish-bean-stew', 'asturian-stew'],
  'pulpo': ['octopus', 'grilled-octopus', 'spanish-octopus', 'galician-octopus'],
  'callos': ['tripe-stew', 'spanish-callos', 'madrid-stew'],
  'cocido': ['cocido', 'spanish-stew', 'chickpea-stew', 'madrid-stew'],
  'jamón': ['ham', 'spanish-ham', 'iberico-ham', 'serrano-ham'],
  'croqueta': ['croquettes', 'spanish-croquettes', 'ham-croquettes'],
  'gamba': ['shrimp', 'garlic-shrimp', 'gambas-al-ajillo', 'prawns'],
  'patata': ['potatoes', 'spanish-potatoes', 'patatas-bravas'],
  'ensaladilla': ['russian-salad', 'ensaladilla-rusa', 'potato-salad'],
  
  // Italian dishes
  'pasta': ['pasta', 'italian-pasta', 'spaghetti', 'pasta-dish'],
  'carbonara': ['carbonara', 'spaghetti-carbonara', 'pasta-carbonara', 'italian-carbonara'],
  'lasagna': ['lasagna', 'lasagne', 'italian-lasagna', 'baked-pasta'],
  'risotto': ['risotto', 'italian-risotto', 'mushroom-risotto', 'creamy-rice'],
  'pizza': ['pizza', 'italian-pizza', 'margherita-pizza', 'wood-fired-pizza'],
  'gnocchi': ['gnocchi', 'potato-gnocchi', 'italian-gnocchi'],
  'ravioli': ['ravioli', 'italian-ravioli', 'stuffed-pasta'],
  'tiramisu': ['tiramisu', 'italian-dessert', 'coffee-dessert'],
  
  // Mexican dishes
  'taco': ['tacos', 'mexican-tacos', 'street-tacos', 'tacos-al-pastor'],
  'burrito': ['burrito', 'mexican-burrito', 'breakfast-burrito'],
  'quesadilla': ['quesadilla', 'mexican-quesadilla', 'cheese-quesadilla'],
  'enchilada': ['enchiladas', 'mexican-enchiladas', 'chicken-enchiladas'],
  'tamal': ['tamales', 'mexican-tamales', 'corn-husk-tamales'],
  'guacamole': ['guacamole', 'avocado-dip', 'mexican-dip'],
  'salsa': ['salsa', 'mexican-salsa', 'tomato-salsa'],
  'nachos': ['nachos', 'loaded-nachos', 'mexican-nachos'],
  'mole': ['mole', 'mexican-mole', 'chicken-mole'],
  'pozole': ['pozole', 'mexican-soup', 'hominy-soup'],
  
  // Asian dishes
  'sushi': ['sushi', 'japanese-sushi', 'sushi-rolls', 'nigiri'],
  'ramen': ['ramen', 'japanese-ramen', 'noodle-soup', 'pork-ramen'],
  'pad_thai': ['pad-thai', 'thai-noodles', 'stir-fry-noodles'],
  'curry': ['curry', 'indian-curry', 'thai-curry', 'yellow-curry'],
  'dim_sum': ['dim-sum', 'chinese-dim-sum', 'dumplings', 'steamed-buns'],
  'fried_rice': ['fried-rice', 'chinese-rice', 'egg-fried-rice'],
  'spring_roll': ['spring-rolls', 'egg-rolls', 'chinese-rolls'],
  'pho': ['pho', 'vietnamese-soup', 'beef-noodle-soup'],
  'bibimbap': ['bibimbap', 'korean-rice', 'korean-bowl'],
  'teriyaki': ['teriyaki', 'chicken-teriyaki', 'japanese-chicken'],
  
  // Meat dishes
  'pollo': ['chicken', 'roasted-chicken', 'grilled-chicken', 'chicken-dish'],
  'carne': ['beef', 'steak', 'grilled-beef', 'meat-dish'],
  'cerdo': ['pork', 'roasted-pork', 'grilled-pork', 'pork-chops'],
  'cordero': ['lamb', 'roasted-lamb', 'lamb-chops', 'grilled-lamb'],
  'ternera': ['veal', 'beef-tenderloin', 'veal-cutlet'],
  
  // Seafood
  'pescado': ['fish', 'grilled-fish', 'baked-fish', 'white-fish'],
  'salmón': ['salmon', 'grilled-salmon', 'baked-salmon', 'salmon-fillet'],
  'marisco': ['seafood', 'seafood-platter', 'shellfish', 'mixed-seafood'],
  'atún': ['tuna', 'tuna-steak', 'seared-tuna'],
  'bacalao': ['cod', 'baked-cod', 'salted-cod', 'fish-fillet'],
  
  // Vegetables
  'ensalada': ['salad', 'green-salad', 'mixed-salad', 'fresh-salad'],
  'verdura': ['vegetables', 'roasted-vegetables', 'grilled-vegetables'],
  'tomate': ['tomato', 'fresh-tomatoes', 'cherry-tomatoes'],
  'espinaca': ['spinach', 'sautéed-spinach', 'fresh-spinach'],
  
  // Rice & Grains
  'arroz': ['rice', 'white-rice', 'spanish-rice', 'fluffy-rice'],
  
  // Desserts
  'chocolate': ['chocolate', 'chocolate-dessert', 'chocolate-cake'],
  'pastel': ['cake', 'birthday-cake', 'layer-cake', 'chocolate-cake'],
  'tarta': ['tart', 'fruit-tart', 'pie', 'apple-pie'],
  'flan': ['flan', 'caramel-flan', 'spanish-flan', 'creme-caramel'],
  'helado': ['ice-cream', 'gelato', 'ice-cream-cone', 'scoop-ice-cream'],
  'fruta': ['fruit', 'fresh-fruit', 'fruit-bowl', 'seasonal-fruit'],
  'postre': ['dessert', 'sweet-dessert', 'gourmet-dessert'],
  'crema': ['creme-brulee', 'custard', 'crema-catalana'],
  'galleta': ['cookies', 'chocolate-cookies', 'homemade-cookies'],
  'brownie': ['brownie', 'chocolate-brownie', 'fudgy-brownie'],
  
  // Soups
  'sopa': ['soup', 'hot-soup', 'homemade-soup', 'vegetable-soup'],
  'caldo': ['broth', 'chicken-broth', 'beef-broth', 'hearty-soup'],
  'crema_verduras': ['cream-soup', 'vegetable-soup', 'vichyssoise'],
  
  // Sandwiches
  'sandwich': ['sandwich', 'club-sandwich', 'toasted-sandwich'],
  'bocadillo': ['sandwich', 'spanish-sandwich', 'baguette-sandwich'],
  'hamburguesa': ['burger', 'hamburger', 'beef-burger', 'gourmet-burger'],
  
  // Drinks
  'café': ['coffee', 'espresso', 'cappuccino', 'latte'],
  'té': ['tea', 'cup-of-tea', 'green-tea', 'herbal-tea'],
  'zumo': ['juice', 'orange-juice', 'fresh-juice', 'fruit-juice'],
  
  // Default
  'default': ['food', 'delicious-food', 'gourmet-food', 'cooked-dish'],
}

// ============================================
// CUISINE STYLE MAPPINGS
// ============================================

const CUISINE_STYLES: Record<string, string[]> = {
  'española': ['spanish', 'spanish-cuisine', 'mediterranean'],
  'español': ['spanish', 'spanish-cuisine', 'mediterranean'],
  'italiana': ['italian', 'italian-cuisine', 'mediterranean'],
  'italiano': ['italian', 'italian-cuisine', 'mediterranean'],
  'mexicana': ['mexican', 'mexican-cuisine', 'latin'],
  'mexicano': ['mexican', 'mexican-cuisine', 'latin'],
  'francesa': ['french', 'french-cuisine', 'european'],
  'frances': ['french', 'french-cuisine', 'european'],
  'americana': ['american', 'american-cuisine', 'western'],
  'asiatica': ['asian', 'asian-cuisine', 'oriental'],
  'asiático': ['asian', 'asian-cuisine', 'oriental'],
  'china': ['chinese', 'chinese-cuisine', 'asian'],
  'japonesa': ['japanese', 'japanese-cuisine', 'asian'],
  'japonés': ['japanese', 'japanese-cuisine', 'asian'],
  'tailandesa': ['thai', 'thai-cuisine', 'southeast-asian'],
  'india': ['indian', 'indian-cuisine', 'south-asian'],
  'mediterranea': ['mediterranean', 'mediterranean-diet', 'healthy'],
  'mediterráneo': ['mediterranean', 'mediterranean-diet', 'healthy'],
}

// ============================================
// MEAL TYPE MAPPINGS
// ============================================

const MEAL_TYPE_VISUALS: Record<string, { lighting: string; setting: string }> = {
  'desayuno': { lighting: 'bright-morning', setting: 'breakfast-table' },
  'almuerzo': { lighting: 'natural-daylight', setting: 'lunch-setting' },
  'cena': { lighting: 'warm-evening', setting: 'dinner-table' },
  'postre': { lighting: 'soft-warm', setting: 'dessert-plate' },
  'snack': { lighting: 'casual-bright', setting: 'snack-setting' },
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

// Hash function for consistent unique values
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

// Detect food type from recipe title and description
function detectFoodType(title: string, description: string): string {
  const text = `${title} ${description}`.toLowerCase();
  
  // Priority matching - check most specific first
  const foodPatterns: [string, string[]][] = [
    // Specific dishes
    ['paella', ['paella', 'arroz con', 'arroz a la']],
    ['carbonara', ['carbonara', 'spaghetti carbonara']],
    ['lasagna', ['lasagna', 'lasaña', 'lasagne']],
    ['risotto', ['risotto', 'risota']],
    ['hamburguesa', ['hamburguesa', 'burger', 'hamburger']],
    ['taco', ['taco', 'tacos']],
    ['pizza', ['pizza', 'pizzería']],
    ['sushi', ['sushi', 'sashimi', 'nigiri', 'maki']],
    ['ramen', ['ramen', 'fideos japones']],
    ['pad_thai', ['pad thai', 'tailandés']],
    ['gazpacho', ['gazpacho', 'sopa fría', 'cold soup']],
    ['flan', ['flan', 'creme caramel', 'pudín']],
    ['tiramisu', ['tiramisú', 'tiramisu']],
    ['croqueta', ['croqueta', 'croquetas']],
    ['tortilla_patatas', ['tortilla de patata', 'tortilla española', 'spanish omelette']],
    ['churros', ['churros', 'churro']],
    
    // General categories
    ['pollo', ['pollo', 'chicken', 'alitas', 'pechuga', 'muslo de pollo']],
    ['carne', ['carne', 'beef', 'ternera', 'steak', 'filete', 'bistec', 'ternera']],
    ['cerdo', ['cerdo', 'pork', 'costillas', 'lomo', 'jamón', 'bacon']],
    ['cordero', ['cordero', 'lamb', 'chuletas de cordero']],
    ['salmón', ['salmón', 'salmon', 'sake']],
    ['pescado', ['pescado', 'fish', 'merluza', 'bacalao', 'atún', 'atun', 'pescado']],
    ['marisco', ['marisco', 'seafood', 'gamba', 'gambas', 'langostino', 'camarón', 'pulpo', 'calamar']],
    ['ensalada', ['ensalada', 'salad', 'ensalada']],
    ['pasta', ['pasta', 'espagueti', 'spaghetti', 'macarron', 'ñoqui', 'gnocchi', 'ravioli', 'fettuccine']],
    ['arroz', ['arroz', 'rice', 'risotto']],
    ['sopa', ['sopa', 'soup', 'caldo', 'crema de']],
    ['postre', ['postre', 'dessert', 'dulce', 'sweet']],
    ['chocolate', ['chocolate', 'choco', 'cacao', 'brownie']],
    ['pastel', ['pastel', 'cake', 'tarta', 'bizcocho', 'muffin', 'cupcake']],
    ['helado', ['helado', 'ice cream', 'sorbet', 'gelato']],
    ['fruta', ['fruta', 'fruit', 'manzana', 'plátano', 'fresa', 'mango', 'piña', 'naranja']],
    ['huevo', ['huevo', 'egg', 'huevos', 'tortilla', 'omelette', 'revuelto']],
    ['pancake', ['pancake', 'tortita', 'hotcake']],
    ['waffle', ['waffle', 'gofre']],
    ['croissant', ['croissant', 'crossant', 'brioche']],
    ['tostada', ['tostada', 'toast', 'pan tostado']],
    ['café', ['café', 'coffee', 'espresso', 'cappuccino', 'latte']],
    ['sandwich', ['sandwich', 'sándwich', 'bocadillo', 'baguette']],
    ['curry', ['curry', 'masala', 'tikka', 'korma']],
    ['tarta', ['tarta', 'pie', 'tart']],
    ['galleta', ['galleta', 'cookie', 'cookies']],
  ];
  
  for (const [foodType, patterns] of foodPatterns) {
    if (patterns.some(pattern => text.includes(pattern))) {
      return foodType;
    }
  }
  
  return 'default';
}

// Detect cuisine from recipe
function detectCuisine(title: string, description: string): string | null {
  const text = `${title} ${description}`.toLowerCase();
  
  for (const [cuisine, patterns] of Object.entries(CUISINE_STYLES)) {
    if (patterns.some(pattern => text.includes(pattern))) {
      return cuisine;
    }
  }
  
  return null;
}

// Generate unique image seed
function generateUniqueSeed(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): number {
  const combined = `${title}|${description}|${mealType}|${toolType}`;
  return hashString(combined);
}

// ============================================
// MAIN IMAGE GENERATION FUNCTIONS
// ============================================

// Get search terms for a recipe
function getSearchTerms(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): string[] {
  const foodType = detectFoodType(title, description);
  const cuisine = detectCuisine(title, description);
  
  // Get food-specific terms
  const foodTerms = FOOD_SEARCH_TERMS[foodType] || FOOD_SEARCH_TERMS['default'];
  
  // Get cuisine terms if available
  const cuisineTerms = cuisine ? (CUISINE_STYLES[cuisine] || []) : [];
  
  // Combine terms with priority
  const allTerms = [
    ...foodTerms.slice(0, 2), // Primary food terms
    ...cuisineTerms.slice(0, 1), // Cuisine context
    foodTerms[2] || 'food', // Fallback
  ];
  
  return allTerms.filter(Boolean);
}

// Generate Unsplash image URL with search query
function getUnsplashImage(searchTerms: string[], seed: number, width: number, height: number): string {
  // Use the first search term for the best match
  const primaryTerm = searchTerms[0] || 'food';
  
  // Unsplash Source API - searches for real food photos
  // Format: https://source.unsplash.com/{width}x{height}/?{search-term}
  return `https://source.unsplash.com/${width}x${height}/?${encodeURIComponent(primaryTerm)},food&sig=${seed}`;
}

// Generate LoremFlickr image URL
function getLoremFlickrImage(searchTerms: string[], seed: number, width: number, height: number): string {
  const primaryTerm = searchTerms[0] || 'food';
  return `https://loremflickr.com/${width}/${height}/${encodeURIComponent(primaryTerm)}?random=${seed}`;
}

// Generate a realistic, matching image for each recipe
export function generateUniqueRecipeImage(
  title: string,
  description: string,
  mealType: string,
  toolType: string,
  difficulty?: string,
  totalTime?: number
): string {
  const seed = generateUniqueSeed(title, description, mealType, toolType);
  const searchTerms = getSearchTerms(title, description, mealType, toolType);
  
  const width = 640;
  const height = 480;
  
  // Primary source: Unsplash (real food photos)
  // This gives the most realistic, matching images
  return getUnsplashImage(searchTerms, seed, width, height);
}

// Alternative sources for variety
export function generateAlternativeImage(
  title: string,
  description: string,
  source: 'unsplash' | 'loremflickr' | 'picsum' = 'unsplash'
): string {
  const seed = hashString(title + description);
  const searchTerms = getSearchTerms(title, description, 'almuerzo', 'tradicional');
  
  switch (source) {
    case 'unsplash':
      return getUnsplashImage(searchTerms, seed, 640, 480);
    case 'loremflickr':
      return getLoremFlickrImage(searchTerms, seed, 640, 480);
    case 'picsum':
      return `https://picsum.photos/seed/${seed}/640/480`;
    default:
      return getUnsplashImage(searchTerms, seed, 640, 480);
  }
}

// Get optimized image for different sizes
export function getOptimizedImage(
  title: string,
  description: string,
  mealType: string,
  toolType: string,
  width: number = 640,
  height: number = 480
): string {
  const seed = generateUniqueSeed(title, description, mealType, toolType);
  const searchTerms = getSearchTerms(title, description, mealType, toolType);
  
  return getUnsplashImage(searchTerms, seed, width, height);
}

// Get styled image based on meal type and cuisine
export function getStyledImage(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): string {
  const seed = generateUniqueSeed(title, description, mealType, toolType);
  const searchTerms = getSearchTerms(title, description, mealType, toolType);
  const mealVisuals = MEAL_TYPE_VISUALS[mealType] || MEAL_TYPE_VISUALS['almuerzo'];
  
  // Add lighting/setting context to search
  const styledTerms = [...searchTerms.slice(0, 2), mealVisuals.setting];
  
  return getUnsplashImage(styledTerms, seed, 640, 480);
}

// Batch generate images ensuring uniqueness
export function batchGenerateImages(recipes: Array<{
  title: string;
  description: string;
  mealType: string;
  toolType: string;
}>): Map<string, string> {
  const imageMap = new Map<string, string>();
  const usedSeeds = new Set<number>();
  
  for (const recipe of recipes) {
    let seed = generateUniqueSeed(
      recipe.title,
      recipe.description,
      recipe.mealType,
      recipe.toolType
    );
    
    // Ensure uniqueness
    let attempts = 0;
    while (usedSeeds.has(seed) && attempts < 100) {
      seed = hashString(`${seed}|${attempts}|${recipe.title}`);
      attempts++;
    }
    
    usedSeeds.add(seed);
    
    const searchTerms = getSearchTerms(
      recipe.title,
      recipe.description,
      recipe.mealType,
      recipe.toolType
    );
    
    imageMap.set(
      recipe.title,
      getUnsplashImage(searchTerms, seed, 640, 480)
    );
  }
  
  return imageMap;
}

// Get image metadata for debugging/analytics
export function getImageMetadata(
  title: string,
  description: string,
  mealType: string,
  toolType: string
): {
  seed: number;
  foodType: string;
  cuisine: string | null;
  searchTerms: string[];
  category: string;
} {
  return {
    seed: generateUniqueSeed(title, description, mealType, toolType),
    foodType: detectFoodType(title, description),
    cuisine: detectCuisine(title, description),
    searchTerms: getSearchTerms(title, description, mealType, toolType),
    category: mealType,
  };
}

// Verify image uniqueness
export function isImageUnique(imageUrl: string, existingUrls: Set<string>): boolean {
  return !existingUrls.has(imageUrl);
}

export default generateUniqueRecipeImage;
