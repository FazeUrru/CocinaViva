import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

const OUTPUT_DIR = './public/images/recipes';

// Ensure output directory exists
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// Image prompts for different recipe categories
const imagePrompts = {
  desayuno: [
    { name: 'pancakes', prompt: 'Delicious fluffy pancakes stacked with maple syrup and butter, professional food photography, top view, bright morning light, appetizing' },
    { name: 'huevos-bacon', prompt: 'Fried eggs with crispy bacon on white plate, classic breakfast, professional food photography, warm lighting' },
    { name: 'tostadas', prompt: 'Toasted bread with tomato and olive oil, Spanish breakfast, rustic wooden table, professional food photography' },
    { name: 'cereal', prompt: 'Bowl of cereal with fresh milk and berries, healthy breakfast, bright food photography, clean white background' },
    { name: 'croissant', prompt: 'Fresh baked golden croissant with coffee, French breakfast, bakery style, professional food photography' },
    { name: 'huevos-revueltos', prompt: 'Scrambled eggs with herbs on plate, creamy texture, breakfast dish, professional food photography, soft lighting' },
    { name: 'waffles', prompt: 'Belgian waffles with strawberries and whipped cream, breakfast delight, professional food photography' },
    { name: 'avena', prompt: 'Oatmeal bowl with fruits and honey, healthy breakfast, ceramic bowl, professional food photography, top view' },
    { name: 'tortilla-patatas', prompt: 'Spanish tortilla de patatas sliced, traditional breakfast, rustic presentation, professional food photography' },
    { name: 'smoothie', prompt: 'Colorful smoothie bowl with granola and fruits, healthy breakfast, vibrant colors, professional food photography' },
  ],
  almuerzo: [
    { name: 'paella', prompt: 'Traditional Spanish paella with saffron rice, seafood and chicken, professional food photography, rustic pan' },
    { name: 'pasta', prompt: 'Creamy pasta carbonara with parmesan, Italian cuisine, professional food photography, appetizing presentation' },
    { name: 'ensalada', prompt: 'Fresh garden salad with vegetables and vinaigrette, healthy lunch, professional food photography, colorful' },
    { name: 'sopa', prompt: 'Hearty vegetable soup in bowl, comforting lunch, steam rising, professional food photography' },
    { name: 'arroz', prompt: 'Flavorful rice dish with vegetables and spices, Asian style, professional food photography, bowl presentation' },
    { name: 'sandwich', prompt: 'Gourmet sandwich with fresh ingredients, lunch meal, professional food photography, cut in half' },
    { name: 'burrito', prompt: 'Mexican burrito wrapped in foil, lunch food, professional food photography, fresh ingredients' },
    { name: 'bowl', prompt: 'Buddha bowl with quinoa, vegetables and protein, healthy lunch, professional food photography, colorful' },
    { name: 'pizza', prompt: 'Fresh margherita pizza slice, Italian lunch, melting cheese, professional food photography' },
    { name: 'gazpacho', prompt: 'Cold Spanish gazpacho soup in bowl, refreshing lunch, professional food photography, garnished' },
  ],
  cena: [
    { name: 'pollo-asado', prompt: 'Roasted chicken with herbs, golden skin, dinner dish, professional food photography, elegant presentation' },
    { name: 'salmon', prompt: 'Grilled salmon fillet with vegetables, healthy dinner, professional food photography, lemon garnish' },
    { name: 'carne', prompt: 'Juicy steak with herbs and butter, elegant dinner, professional food photography, medium rare' },
    { name: 'pescado', prompt: 'Baked white fish with lemon and herbs, light dinner, professional food photography, healthy' },
    { name: 'cordero', prompt: 'Roasted lamb leg with rosemary, special dinner, professional food photography, elegant plating' },
    { name: 'cerdo', prompt: 'Pork tenderloin with sauce, dinner entree, professional food photography, with vegetables' },
    { name: 'mariscos', prompt: 'Seafood platter with shrimp and mussels, dinner feast, professional food photography, lemon wedges' },
    { name: 'pollo-curry', prompt: 'Chicken curry with rice in bowl, aromatic dinner, professional food photography, colorful' },
    { name: 'lasagna', prompt: 'Layered lasagna with melted cheese, Italian dinner, professional food photography, cut slice' },
    { name: 'esterillas', prompt: 'Grilled ribs with barbecue sauce, hearty dinner, professional food photography, smoky' },
  ],
  postre: [
    { name: 'tarta-chocolate', prompt: 'Rich chocolate cake slice with ganache, decadent dessert, professional food photography, elegant plating' },
    { name: 'helado', prompt: 'Ice cream scoops with toppings, sweet dessert, professional food photography, colorful' },
    { name: 'flan', prompt: 'Spanish flan with caramel sauce, creamy dessert, professional food photography, classic presentation' },
    { name: 'tarta-frutas', prompt: 'Fresh fruit tart with custard, elegant dessert, professional food photography, colorful fruits' },
    { name: 'cheesecake', prompt: 'New York cheesecake slice with berries, creamy dessert, professional food photography' },
    { name: 'crema-catalana', prompt: 'Crema catalana with burnt sugar top, Spanish dessert, professional food photography, ramekin' },
    { name: 'mousse', prompt: 'Chocolate mousse in glass, elegant dessert, professional food photography, whipped cream' },
    { name: 'brownie', prompt: 'Fudgy brownie with ice cream, indulgent dessert, professional food photography, chocolate sauce' },
    { name: 'tiramisu', prompt: 'Classic tiramisu slice, Italian dessert, professional food photography, cocoa dusted' },
    { name: 'pastel', prompt: 'Celebration cake with frosting, party dessert, professional food photography, colorful decorations' },
  ],
  snack: [
    { name: 'tapas', prompt: 'Spanish tapas variety platter, appetizer spread, professional food photography, wooden board' },
    { name: 'patatas-bravas', prompt: 'Patatas bravas with spicy sauce, Spanish tapa, professional food photography, rustic dish' },
    { name: 'nachos', prompt: 'Loaded nachos with cheese and toppings, party snack, professional food photography, colorful' },
    { name: 'croquetas', prompt: 'Golden ham croquettes, Spanish tapa, professional food photography, crispy exterior' },
    { name: 'alitas', prompt: 'Buffalo chicken wings with celery, game day snack, professional food photography, sauce' },
    { name: 'queso', prompt: 'Cheese platter with crackers, elegant appetizer, professional food photography, variety' },
    { name: 'hummus', prompt: 'Hummus bowl with pita bread, healthy snack, professional food photography, olive oil drizzle' },
    { name: 'guacamole', prompt: 'Fresh guacamole with tortilla chips, Mexican appetizer, professional food photography, vibrant green' },
    { name: 'empanadas', prompt: 'Golden empanadas on plate, Latin appetizer, professional food photography, flaky pastry' },
    { name: 'bruschetta', prompt: 'Italian bruschetta with tomato, appetizer, professional food photography, fresh basil' },
  ],
  thermomix: [
    { name: 'thermomix-sopa', prompt: 'Creamy vegetable soup, Thermomix recipe, professional food photography, smooth texture' },
    { name: 'thermomix-pure', prompt: 'Smooth mashed potatoes, Thermomix cooking, professional food photography, butter on top' },
    { name: 'thermomix-salsa', prompt: 'Homemade tomato sauce, Thermomix blend, professional food photography, vibrant red' },
    { name: 'thermomix-batido', prompt: 'Fruit smoothie in glass, Thermomix drink, professional food photography, colorful' },
    { name: 'thermomix-masa', prompt: 'Fresh bread dough, Thermomix kneaded, professional food photography, flour dusted' },
    { name: 'thermomix-helado', prompt: 'Homemade ice cream, Thermomix dessert, professional food photography, scooped' },
    { name: 'thermomix-hummus', prompt: 'Creamy hummus dip, Thermomix blended, professional food photography, smooth' },
    { name: 'thermomix-sorpresa', prompt: 'Fruit sorbet, Thermomix frozen, professional food photography, refreshing' },
    { name: 'thermomix-salsa-verde', prompt: 'Green herb sauce, Thermomix blend, professional food photography, vibrant' },
    { name: 'thermomix-crema', prompt: 'Dessert cream in cups, Thermomix recipe, professional food photography, elegant' },
  ],
  crockpot: [
    { name: 'crockpot-estofado', prompt: 'Hearty beef stew, slow cooker meal, professional food photography, rich gravy' },
    { name: 'crockpot-pulled', prompt: 'Pulled pork sandwich, slow cooked meat, professional food photography, saucy' },
    { name: 'crockpot-chili', prompt: 'Bowl of chili con carne, slow cooker dish, professional food photography, topped with cheese' },
    { name: 'crockpot-pollo', prompt: 'Slow cooked chicken, falling apart, professional food photography, tender meat' },
    { name: 'crockpot-sopa', prompt: 'Hearty soup in pot, slow cooker recipe, professional food photography, steaming' },
    { name: 'crockpot-costillas', prompt: 'BBQ ribs, slow cooked tender, professional food photography, glazed' },
    { name: 'crockpot-lentejas', prompt: 'Lentil stew, slow cooker legumes, professional food photography, nutritious' },
    { name: 'crockpot-curry', prompt: 'Slow cooked curry, rich sauce, professional food photography, rice side' },
    { name: 'crockpot-carnitas', prompt: 'Mexican carnitas, slow roasted pork, professional food photography, crispy edges' },
    { name: 'crockpot-potaje', prompt: 'Bean potaje, slow cooker stew, professional food photography, traditional' },
  ],
};

async function generateImages() {
  const zai = await ZAI.create();
  
  const allPrompts = Object.entries(imagePrompts).flatMap(([category, images]) =>
    images.map(img => ({ ...img, category }))
  );

  console.log(`Generating ${allPrompts.length} recipe images...`);

  let successCount = 0;
  let failCount = 0;

  for (let i = 0; i < allPrompts.length; i++) {
    const { name, prompt, category } = allPrompts[i];
    const filename = `${category}-${name}.png`;
    const outputPath = path.join(OUTPUT_DIR, filename);

    // Skip if already exists
    if (fs.existsSync(outputPath)) {
      console.log(`[${i + 1}/${allPrompts.length}] ✓ Already exists: ${filename}`);
      successCount++;
      continue;
    }

    try {
      console.log(`[${i + 1}/${allPrompts.length}] Generating: ${filename}...`);
      
      const response = await zai.images.generations.create({
        prompt: prompt,
        size: '1024x1024'
      });

      const imageBase64 = response.data[0].base64;
      const buffer = Buffer.from(imageBase64, 'base64');
      fs.writeFileSync(outputPath, buffer);

      console.log(`[${i + 1}/${allPrompts.length}] ✓ Generated: ${filename}`);
      successCount++;

      // Small delay to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (error) {
      console.error(`[${i + 1}/${allPrompts.length}] ✗ Failed: ${filename} - ${error}`);
      failCount++;
    }
  }

  console.log('\n=== Generation Complete ===');
  console.log(`✓ Successful: ${successCount}`);
  console.log(`✗ Failed: ${failCount}`);
  console.log(`Total images: ${allPrompts.length}`);
}

generateImages().catch(console.error);
