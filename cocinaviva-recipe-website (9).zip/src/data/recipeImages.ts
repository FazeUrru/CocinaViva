// Mapa de imagenes reales de Unsplash que coinciden con cada receta
// Cada URL apunta a una imagen que representa el plato real

export const recipeImageMap: Record<string, string> = {
  // ENTRANTES
  'Croquetas de Jamón Ibérico': 'https://images.unsplash.com/photo-1554433607-66b5efe9d304?w=400&h=300&fit=crop',
  'Patatas Bravas Madrileñas': 'https://images.unsplash.com/photo-1585540083814-ea6ee8af9e4f?w=400&h=300&fit=crop',
  'Gambas al Ajillo': 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop',
  'Pimientos de Padrón': 'https://images.unsplash.com/photo-1583119022894-919a68a3d0e3?w=400&h=300&fit=crop',
  'Tortilla Española Clásica': 'https://images.unsplash.com/photo-1640464035848-f3a1e43be24e?w=400&h=300&fit=crop',
  'Gazpacho Andaluz': 'https://images.unsplash.com/photo-1600335895229-6e75511892c8?w=400&h=300&fit=crop',
  'Salmorejo Cordobés': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Empanadas Gallegas': 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=400&h=300&fit=crop',
  'Boquerones en Vinagre': 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=400&h=300&fit=crop',
  'Pulpo a la Gallega': 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
  'Huevos Rotos con Jamón': 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=400&h=300&fit=crop',
  'Calamares a la Romana': 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop',
  'Champiñones al Ajillo': 'https://images.unsplash.com/photo-1518977676601-b53f82ber632?w=400&h=300&fit=crop',
  'Croquetas de Bacalao': 'https://images.unsplash.com/photo-1554433607-66b5efe9d304?w=400&h=300&fit=crop',
  'Hummus Casero': 'https://images.unsplash.com/photo-1577805947697-89e18249d767?w=400&h=300&fit=crop',
  'Guacamole Tradicional': 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?w=400&h=300&fit=crop',
  'Nachos con Queso': 'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=400&h=300&fit=crop',

  // SOPAS Y CREMAS
  'Sopa Castellana': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Crema de Calabaza': 'https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?w=400&h=300&fit=crop',
  'Sopa de Cebolla Gratinada': 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=400&h=300&fit=crop',
  'Crema de Espárragos': 'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=400&h=300&fit=crop',
  'Crema de Zanahoria y Jengibre': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Vichyssoise': 'https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?w=400&h=300&fit=crop',
  'Crema de Champiñones': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Crema de Calabacín': 'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=400&h=300&fit=crop',
  'Ajoblanco Malagueño': 'https://images.unsplash.com/photo-1603105037880-880cd4edfb0d?w=400&h=300&fit=crop',

  // ENSALADAS
  'Ensalada Mixta Española': 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop',
  'Ensalada César': 'https://images.unsplash.com/photo-1550304943-4f24f54ddde9?w=400&h=300&fit=crop',
  'Ensaladilla Rusa': 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop',
  'Ensalada Caprese': 'https://images.unsplash.com/photo-1592417817098-8fd3d9eb14a5?w=400&h=300&fit=crop',
  'Ensalada Griega': 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400&h=300&fit=crop',
  'Ensalada de Quinoa': 'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?w=400&h=300&fit=crop',
  'Poke Bowl Mediterráneo': 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop',

  // ARROCES
  'Paella Valenciana': 'https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=400&h=300&fit=crop',
  'Arroz Negro': 'https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400&h=300&fit=crop',
  'Arroz con Bogavante': 'https://images.unsplash.com/photo-1596560548464-f010549b84d7?w=400&h=300&fit=crop',
  'Risotto de Setas': 'https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=400&h=300&fit=crop',
  'Arroz con Leche Asturiano': 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=400&h=300&fit=crop',
  'Arroz a la Cubana': 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&h=300&fit=crop',
  'Fideuá': 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?w=400&h=300&fit=crop',
  'Paella de Mariscos': 'https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=400&h=300&fit=crop',
  'Arroz Tres Delicias': 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&h=300&fit=crop',

  // PASTAS
  'Espaguetis a la Carbonara': 'https://images.unsplash.com/photo-1612874742237-6526221588e3?w=400&h=300&fit=crop',
  'Macarrones con Chorizo': 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop',
  'Lasaña de Carne': 'https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=400&h=300&fit=crop',
  'Pasta Boloñesa': 'https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=400&h=300&fit=crop',
  'Fetuccini Alfredo': 'https://images.unsplash.com/photo-1645112411341-6c4fd023714a?w=400&h=300&fit=crop',
  'Penne al Pesto': 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop',
  'Espaguetis con Almejas': 'https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=400&h=300&fit=crop',
  'Ñoquis de Patata': 'https://images.unsplash.com/photo-1551892374-ecf8754cf8b0?w=400&h=300&fit=crop',
  'Macarrones Gratinados': 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop',

  // CARNES
  'Cochinillo Asado Segoviano': 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&h=300&fit=crop',
  'Rabo de Toro': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop',
  'Chuletón a la Brasa': 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&h=300&fit=crop',
  'Pollo al Ajillo': 'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=400&h=300&fit=crop',
  'Cordero Asado al Horno': 'https://images.unsplash.com/photo-1514516345957-556ca7d90a29?w=400&h=300&fit=crop',
  'Albóndigas en Salsa': 'https://images.unsplash.com/photo-1529042410759-befb1204b468?w=400&h=300&fit=crop',
  'Solomillo al Pedro Ximénez': 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&h=300&fit=crop',
  'Estofado de Ternera': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop',
  'Costillas BBQ': 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&h=300&fit=crop',
  'Secreto Ibérico': 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&h=300&fit=crop',
  'Pollo al Curry': 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
  'Hamburguesa Gourmet': 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop',
  'Pollo Tikka Masala': 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
  'Entrecot con Salsa Pimienta': 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&h=300&fit=crop',
  'Callos a la Madrileña': 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&h=300&fit=crop',

  // PESCADOS
  'Bacalao al Pil-Pil': 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&h=300&fit=crop',
  'Merluza a la Vasca': 'https://images.unsplash.com/photo-1580476262798-bddd9f4b7369?w=400&h=300&fit=crop',
  'Lubina a la Sal': 'https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400&h=300&fit=crop',
  'Dorada al Horno': 'https://images.unsplash.com/photo-1534766555764-ce878a5e3a2b?w=400&h=300&fit=crop',
  'Salmón al Horno con Limón': 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop',
  'Sardinas Asadas': 'https://images.unsplash.com/photo-1559339352-11d035aa65de?w=400&h=300&fit=crop',
  'Salmón en Papillote': 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop',
  'Salmón Teriyaki': 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop',
  'Pescado Frito Andaluz': 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop',
  'Ceviche de Corvina': 'https://images.unsplash.com/photo-1535399831218-d5bd36d1a6b3?w=400&h=300&fit=crop',

  // MARISCOS
  'Langostinos a la Plancha': 'https://images.unsplash.com/photo-1565680018093-ebb6e3c4a792?w=400&h=300&fit=crop',
  'Gambas al Pil-Pil': 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop',
  'Mejillones al Vapor': 'https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?w=400&h=300&fit=crop',
  'Almejas a la Marinera': 'https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=400&h=300&fit=crop',
  'Vieiras a la Gallega': 'https://images.unsplash.com/photo-1565680018093-ebb6e3c4a792?w=400&h=300&fit=crop',
  'Pulpo a la Brasa': 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop',
  'Salpicón de Marisco': 'https://images.unsplash.com/photo-1565680018093-ebb6e3c4a792?w=400&h=300&fit=crop',
  'Cóctel de Gambas': 'https://images.unsplash.com/photo-1565680018093-ebb6e3c4a792?w=400&h=300&fit=crop',

  // VERDURAS
  'Pisto Manchego': 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=300&fit=crop',
  'Espárragos a la Plancha': 'https://images.unsplash.com/photo-1597362925123-77861d3fbac7?w=400&h=300&fit=crop',
  'Menestra de Verduras': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop',
  'Pimientos Rellenos': 'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=400&h=300&fit=crop',
  'Berenjenas Rellenas': 'https://images.unsplash.com/photo-1596797038530-2c107229654b?w=400&h=300&fit=crop',
  'Coliflor Gratinada': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop',
  'Verduras al Horno': 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=300&fit=crop',
  'Ratatouille': 'https://images.unsplash.com/photo-1572453800999-e8d2d1589b7c?w=400&h=300&fit=crop',
  'Wok de Verduras': 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop',
  'Patatas Revolconas': 'https://images.unsplash.com/photo-1585540083814-ea6ee8af9e4f?w=400&h=300&fit=crop',

  // LEGUMBRES
  'Cocido Madrileño': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Fabada Asturiana': 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&h=300&fit=crop',
  'Lentejas con Chorizo': 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400&h=300&fit=crop',
  'Garbanzos con Espinacas': 'https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&h=300&fit=crop',
  'Lentejas al Curry': 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400&h=300&fit=crop',

  // GUISOS
  'Estofado de Ternera con Patatas': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop',
  'Caldereta de Cordero': 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&h=300&fit=crop',
  'Marmitako Vasco': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',

  // POSTRES
  'Crema Catalana': 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop',
  'Flan de Huevo': 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&h=300&fit=crop',
  'Natillas Caseras': 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop',
  'Arroz con Leche': 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?w=400&h=300&fit=crop',
  'Tarta de Santiago': 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop',
  'Torrijas': 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400&h=300&fit=crop',
  'Churros con Chocolate': 'https://images.unsplash.com/photo-1624353365286-3f8d62daad51?w=400&h=300&fit=crop',
  'Tarta de Queso Vasca': 'https://images.unsplash.com/photo-1524351199678-941a58a3df50?w=400&h=300&fit=crop',
  'Coulant de Chocolate': 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&h=300&fit=crop',
  'Tiramisú': 'https://images.unsplash.com/photo-1571877227200-a0d98ea607e9?w=400&h=300&fit=crop',
  'Panna Cotta': 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop',
  'Mousse de Chocolate': 'https://images.unsplash.com/photo-1541783245831-57d6fb0926d3?w=400&h=300&fit=crop',
  'Tarta de Manzana': 'https://images.unsplash.com/photo-1568571780765-9276ac8b75a2?w=400&h=300&fit=crop',
  'Profiteroles': 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400&h=300&fit=crop',
  'Helado de Vainilla Casero': 'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=400&h=300&fit=crop',
  'Sorbete de Limón': 'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=400&h=300&fit=crop',
  'Fresas con Nata': 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop',
  'Tarta de Tres Chocolates': 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop',
  'Flan de Coco': 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=400&h=300&fit=crop',
  'Mousse de Limón': 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop',

  // REPOSTERIA
  'Bizcocho de Yogur': 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=400&h=300&fit=crop',
  'Tarta de Chocolate': 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop',
  'Galletas de Mantequilla': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=300&fit=crop',
  'Magdalenas Caseras': 'https://images.unsplash.com/photo-1587668178277-295251f900ce?w=400&h=300&fit=crop',
  'Brownie de Chocolate': 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&h=300&fit=crop',
  'Cheesecake New York': 'https://images.unsplash.com/photo-1524351199678-941a58a3df50?w=400&h=300&fit=crop',
  'Carrot Cake': 'https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=400&h=300&fit=crop',
  'Cupcakes de Vainilla': 'https://images.unsplash.com/photo-1587668178277-295251f900ce?w=400&h=300&fit=crop',
  'Donuts Caseros': 'https://images.unsplash.com/photo-1551024601-bec78aea704b?w=400&h=300&fit=crop',
  'Cookies de Chocolate': 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=400&h=300&fit=crop',
  'Roscón de Reyes': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop',

  // PAN Y MASAS
  'Pan de Pueblo': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop',
  'Focaccia de Romero': 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=400&h=300&fit=crop',
  'Baguette Francesa': 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?w=400&h=300&fit=crop',
  'Pan de Molde Casero': 'https://images.unsplash.com/photo-1586444248879-bc604bc77133?w=400&h=300&fit=crop',
  'Masa de Pizza Casera': 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=300&fit=crop',
  'Pan Brioche': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop',
  'Croissant': 'https://images.unsplash.com/photo-1555507036-ab1f4038024a?w=400&h=300&fit=crop',

  // SALSAS
  'Salsa de Tomate Casera': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=300&fit=crop',
  'Alioli': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=300&fit=crop',
  'Salsa Romesco': 'https://images.unsplash.com/photo-1589010588553-46e8e7c21788?w=400&h=300&fit=crop',
  'Pesto Genovés': 'https://images.unsplash.com/photo-1589010588553-46e8e7c21788?w=400&h=300&fit=crop',
  'Salsa Chimichurri': 'https://images.unsplash.com/photo-1589010588553-46e8e7c21788?w=400&h=300&fit=crop',
  'Salsa Barbacoa': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=300&fit=crop',
  'Mayonesa Casera': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=300&fit=crop',

  // BEBIDAS
  'Sangría Española': 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=300&fit=crop',
  'Tinto de Verano': 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=300&fit=crop',
  'Horchata Valenciana': 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&h=300&fit=crop',
  'Chocolate a la Taza': 'https://images.unsplash.com/photo-1517578239113-b03992dcdd25?w=400&h=300&fit=crop',
  'Smoothie de Frutas': 'https://images.unsplash.com/photo-1505252585461-04db1eb84625?w=400&h=300&fit=crop',
  'Mojito Clásico': 'https://images.unsplash.com/photo-1551538827-9c037cb4f32a?w=400&h=300&fit=crop',
  'Limonada Casera': 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&h=300&fit=crop',
  'Batido de Chocolate': 'https://images.unsplash.com/photo-1517578239113-b03992dcdd25?w=400&h=300&fit=crop',

  // TAPAS
  'Patatas Alioli': 'https://images.unsplash.com/photo-1585540083814-ea6ee8af9e4f?w=400&h=300&fit=crop',
  'Tortillitas de Camarones': 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop',
  'Gildas Vascas': 'https://images.unsplash.com/photo-1626200419199-391ae4be7f96?w=400&h=300&fit=crop',
  'Chorizo a la Sidra': 'https://images.unsplash.com/photo-1604909052743-94e838986d24?w=400&h=300&fit=crop',
  'Torreznos de Soria': 'https://images.unsplash.com/photo-1515443961218-a51367888e4b?w=400&h=300&fit=crop',
  'Berenjenas con Miel': 'https://images.unsplash.com/photo-1626200419199-391ae4be7f96?w=400&h=300&fit=crop',
  'Pintxo de Tortilla': 'https://images.unsplash.com/photo-1640464035848-f3a1e43be24e?w=400&h=300&fit=crop',

  // DESAYUNOS
  'Tostada con Tomate y Aceite': 'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&h=300&fit=crop',
  'Tortitas Americanas': 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=400&h=300&fit=crop',
  'Huevos Revueltos con Jamón': 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=400&h=300&fit=crop',
  'Croissant de Mantequilla': 'https://images.unsplash.com/photo-1555507036-ab1f4038024a?w=400&h=300&fit=crop',
  'Bowl de Açaí': 'https://images.unsplash.com/photo-1495147466023-ac5c588e2e94?w=400&h=300&fit=crop',
  'Tostada de Aguacate': 'https://images.unsplash.com/photo-1541519227354-08fa5d50c44d?w=400&h=300&fit=crop',
  'Huevos Benedictinos': 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=400&h=300&fit=crop',
  'Granola Casera': 'https://images.unsplash.com/photo-1495147466023-ac5c588e2e94?w=400&h=300&fit=crop',
  'Crepes de Nutella': 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=400&h=300&fit=crop',
  'Gofres Belgas': 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=400&h=300&fit=crop',
  'Yogur con Frutas y Miel': 'https://images.unsplash.com/photo-1495147466023-ac5c588e2e94?w=400&h=300&fit=crop',

  // CENAS LIGERAS
  'Sopa de Verduras': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Ensalada Templada': 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop',
  'Revuelto de Setas': 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop',
  'Merluza al Vapor': 'https://images.unsplash.com/photo-1580476262798-bddd9f4b7369?w=400&h=300&fit=crop',
  'Pollo a la Plancha': 'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=400&h=300&fit=crop',
  'Wrap de Pollo': 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=400&h=300&fit=crop',
  'Bowl de Quinoa': 'https://images.unsplash.com/photo-1505253716362-afaea1d3d1af?w=400&h=300&fit=crop',

  // ESPECIAL FIESTAS
  'Turrón de Jijona': 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400&h=300&fit=crop',
  'Roscon de Reyes Navidad': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop',
  'Cordero Asado Navideño': 'https://images.unsplash.com/photo-1514516345957-556ca7d90a29?w=400&h=300&fit=crop',
  'Pavo Relleno': 'https://images.unsplash.com/photo-1574672280600-4accfa5b6f98?w=400&h=300&fit=crop',
  'Canapés Festivos': 'https://images.unsplash.com/photo-1541014741259-de529411b96a?w=400&h=300&fit=crop',
  'Torrijas de Semana Santa': 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=400&h=300&fit=crop',
};

// Mapa extenso de keywords a imagenes para asegurar que todas encajen
export const keywordImages: Record<string, string[]> = {
  'pollo': [
    'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=400&h=300&fit=crop',
    'https://images.unsplash.com/photo-1598103442097-8b74394b95c6?w=400&h=300&fit=crop',
    'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop'
  ],
  'ternera': [
    'https://images.unsplash.com/photo-1588168333986-5078d3ae3976?w=400&h=300&fit=crop',
    'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=300&fit=crop'
  ],
  'cerdo': ['https://images.unsplash.com/photo-1627308595229-7830f5c92f3f?w=400&h=300&fit=crop'],
  'salmon': ['https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop'],
  'bacalao': ['https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&h=300&fit=crop'],
  'atun': ['https://images.unsplash.com/photo-1501595091296-3aa970afb3ff?w=400&h=300&fit=crop'],
  'merluza': ['https://images.unsplash.com/photo-1580476262798-bddd9f4b7369?w=400&h=300&fit=crop'],
  'gamba': ['https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop'],
  'langostino': ['https://images.unsplash.com/photo-1565680018093-ebb6e3c4a792?w=400&h=300&fit=crop'],
  'pulpo': ['https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&h=300&fit=crop'],
  'calamar': ['https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&h=300&fit=crop'],
  'arroz': ['https://images.unsplash.com/photo-1512058564366-18510be2db19?w=400&h=300&fit=crop'],
  'paella': ['https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=400&h=300&fit=crop'],
  'risotto': ['https://images.unsplash.com/photo-1476124369491-e7addf5db371?w=400&h=300&fit=crop'],
  'pasta': ['https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop'],
  'espagueti': ['https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=400&h=300&fit=crop'],
  'lasaña': ['https://images.unsplash.com/photo-1574894709920-11b28e7367e3?w=400&h=300&fit=crop'],
  'sopa': ['https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop'],
  'crema': ['https://images.unsplash.com/photo-1476718406336-bb5a9690ee2a?w=400&h=300&fit=crop'],
  'ensalada': ['https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop'],
  'tomate': ['https://images.unsplash.com/photo-1592417817098-8fd3d9eb14a5?w=400&h=300&fit=crop'],
  'patata': ['https://images.unsplash.com/photo-1585540083814-ea6ee8af9e4f?w=400&h=300&fit=crop'],
  'lenteja': ['https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400&h=300&fit=crop'],
  'garbanzo': ['https://images.unsplash.com/photo-1515543237350-b3eea1ec8082?w=400&h=300&fit=crop'],
  'tarta': ['https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=400&h=300&fit=crop'],
  'bizcocho': ['https://images.unsplash.com/photo-1464349095431-e9a21285b5f3?w=400&h=300&fit=crop'],
  'chocolate': ['https://images.unsplash.com/photo-1541783245831-57d6fb0926d3?w=400&h=300&fit=crop'],
  'queso': ['https://images.unsplash.com/photo-1524351199678-941a58a3df50?w=400&h=300&fit=crop'],
  'helado': ['https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=400&h=300&fit=crop'],
  'pan': ['https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop'],
  'salsa': ['https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=300&fit=crop'],
  'bebida': ['https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=300&fit=crop'],
  'fruta': ['https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop'],
  'verdura': ['https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=300&fit=crop'],
  'guiso': ['https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&h=300&fit=crop'],
};

// Imagenes genéricas por categoría como fallback
export const categoryFallbackImages: Record<string, string> = {
  'Entrantes': 'https://images.unsplash.com/photo-1541014741259-de529411b96a?w=400&h=300&fit=crop',
  'Sopas y Cremas': 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=400&h=300&fit=crop',
  'Ensaladas': 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop',
  'Arroces': 'https://images.unsplash.com/photo-1534080564583-6be75777b70a?w=400&h=300&fit=crop',
  'Pastas': 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=400&h=300&fit=crop',
  'Carnes': 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&h=300&fit=crop',
  'Pescados': 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&h=300&fit=crop',
  'Mariscos': 'https://images.unsplash.com/photo-1565680018093-ebb6e3c4a792?w=400&h=300&fit=crop',
  'Verduras': 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&h=300&fit=crop',
  'Legumbres': 'https://images.unsplash.com/photo-1546793665-c74683f339c1?w=400&h=300&fit=crop',
  'Guisos': 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&h=300&fit=crop',
  'Postres': 'https://images.unsplash.com/photo-1488477181946-6428a0291777?w=400&h=300&fit=crop',
  'Repostería': 'https://images.unsplash.com/photo-1587668178277-295251f900ce?w=400&h=300&fit=crop',
  'Pan y Masas': 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&h=300&fit=crop',
  'Salsas': 'https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=400&h=300&fit=crop',
  'Bebidas': 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=400&h=300&fit=crop',
  'Tapas': 'https://images.unsplash.com/photo-1515443961218-a51367888e4b?w=400&h=300&fit=crop',
  'Desayunos': 'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?w=400&h=300&fit=crop',
  'Cenas Ligeras': 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop',
  'Especial Fiestas': 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=400&h=300&fit=crop',
};

export function getRecipeImage(name: string, category: string, id?: number): string {
  // Extraer palabra clave del nombre para asegurar que la imagen no se repita y concuerde
  const lowerName = name.toLowerCase();
  
  const keywords = [
    'pollo', 'ternera', 'cerdo', 'salmon', 'bacalao', 'atun', 'merluza', 'gamba', 'langostino', 'pulpo', 'calamar',
    'arroz', 'paella', 'risotto', 'pasta', 'espagueti', 'lasaña', 'sopa', 'crema', 'ensalada', 'tomate', 'patata',
    'lenteja', 'garbanzo', 'tarta', 'bizcocho', 'chocolate', 'queso', 'helado', 'pan', 'salsa', 'bebida', 'fruta',
    'verdura', 'guiso', 'pizza', 'hamburguesa', 'marisco', 'carne', 'pescado', 'postre', 'desayuno', 'tapa', 'huevo', 'dulce'
  ];

  let matchedKeyword = '';
  for (const k of keywords) {
    if (lowerName.includes(k)) {
      matchedKeyword = k;
      break;
    }
  }

  if (!matchedKeyword) {
    matchedKeyword = category.toLowerCase().split(' ')[0];
  }

  // Utilizar loremflickr con un lock basado en el ID para garantizar imágenes únicas que no se repitan,
  // pero que estén ligadas a la palabra clave de la receta para que concuerden siempre.
  const imageId = id || (name.length * 10);
  const cleanKeyword = matchedKeyword.replace(/[^a-zA-Z0-9]/g, '');
  
  return `https://loremflickr.com/400/300/${cleanKeyword},food/all?lock=${imageId}`;
}
