export interface Feature {
  id: number;
  name: string;
  description: string;
  icon: string;
  status: 'activa' | 'beta' | 'proximamente' | 'acceso_anticipado';
  scheduledDate?: string;
  devOnly?: boolean;
}

export const features: Feature[] = [
  { id: 1, name: 'Buscador Inteligente', description: 'Busca recetas por nombre, ingredientes, categoria o region.', icon: 'Search', status: 'activa' },
  { id: 2, name: 'Planificador Semanal', description: 'Organiza tus comidas de toda la semana con drag & drop.', icon: 'Calendar', status: 'beta' },
  { id: 3, name: 'Lista de la Compra', description: 'Genera automaticamente la lista a partir de recetas seleccionadas.', icon: 'ShoppingCart', status: 'activa' },
  { id: 4, name: 'Modo Thermomix', description: 'Instrucciones adaptadas con temperaturas, velocidades y tiempos exactos.', icon: 'Gauge', status: 'activa' },
  { id: 5, name: 'Calculadora Nutricional', description: 'Informacion detallada de calorias y macronutrientes.', icon: 'Calculator', status: 'beta' },
  { id: 6, name: 'Favoritos y Colecciones', description: 'Guarda tus recetas favoritas y organizalas en colecciones.', icon: 'Heart', status: 'activa' },
  { id: 7, name: 'Temporizador Integrado', description: 'Temporizadores multiples para cada paso de tu receta.', icon: 'Timer', status: 'activa' },
  { id: 8, name: 'Conversion de Unidades', description: 'Convierte entre gramos, onzas, tazas y cucharadas.', icon: 'ArrowLeftRight', status: 'activa' },
  { id: 9, name: 'Modo Paso a Paso', description: 'Sigue recetas paso a paso con texto claro.', icon: 'ListOrdered', status: 'activa' },
  { id: 10, name: 'Compartir Recetas', description: 'Comparte recetas por WhatsApp, email o redes sociales.', icon: 'Share2', status: 'beta' },
  { id: 11, name: 'Asistente de Voz', description: 'Controla la app con tu voz. Di "siguiente paso".', icon: 'Mic', status: 'beta' },
  { id: 12, name: 'Escaner de Ingredientes', description: 'Escanea ingredientes de tu nevera y te sugerimos recetas.', icon: 'ScanLine', status: 'beta' },
  { id: 13, name: 'Generador de Menus con IA', description: 'Crea menus semanales automaticos basados en tus gustos.', icon: 'BrainCircuit', status: 'beta' },
  { id: 14, name: 'Sincronizacion de Nevera', description: 'Conecta con tickets de compra para tu inventario.', icon: 'Replay', status: 'beta' },
  { id: 15, name: 'Modo Gestos (Sin Manos)', description: 'Avanza pasos moviendo la mano frente a la camara.', icon: 'Hand', status: 'beta' },
  // 3 FUNCIONES BETA
  { id: 16, name: 'Cocina Colaborativa', description: 'Cocina en tiempo real con amigos y familia a distancia. Comparte pantalla y avanza juntos.', icon: 'Users', status: 'beta' },
  { id: 17, name: 'Modo Streaming', description: 'Transmite tu cocina en vivo y comparte tu receta con la comunidad CocinaViva.', icon: 'Video', status: 'beta' },
  { id: 18, name: 'Detector de Alergenos', description: 'Detecta automaticamente alergenos en los ingredientes y sugiere sustitutos seguros.', icon: 'AlertTriangle', status: 'beta' },
  // NUEVA FUNCION GRATUITA BETA
  { id: 19, name: 'Recetario Social', description: 'Comparte tus recetas favoritas con la comunidad, comenta y valora las de otros cocineros. Gratis para todos.', icon: 'MessageCircle', status: 'beta' },
  // FUNCION TESTER EXCLUSIVA ULTRA Y MASTERCHEF
  { id: 20, name: 'Chef AI Tester', description: 'Asistente inteligente que analiza tus recetas, sugiere mejoras y crea variaciones personalizadas. Exclusivo para planes Ultra y Master Chef.', icon: 'BrainCircuit', status: 'beta' },
  // NUEVA FUNCION GRATUITA BETA
  { id: 21, name: 'Escuela de Cocina Virtual', description: 'Accede a lecciones interactivas gratuitas para aprender tecnicas de cocina paso a paso. Desde cortar cebolla hasta emplatados profesionales.', icon: 'GraduationCap', status: 'beta' },
  // NUEVA FUNCION TESTER EXCLUSIVA ULTRA Y MASTERCHEF
  { id: 22, name: 'Maridaje Inteligente', description: 'Recomendaciones automaticas de vinos, cervezas y bebidas para cada receta. Incluye maridaje por region y temporada. Exclusivo Ultra y Master Chef.', icon: 'Wine', status: 'beta' },
  // 3 NUEVAS FUNCIONES GRATUITAS BETA (v1.0.4)
  { id: 23, name: 'Modo Fiesta Compartida', description: 'Crea una lista de compras compartida para eventos y fiestas. Gratis en fase beta.', icon: 'Users', status: 'beta' },
  { id: 24, name: 'Convertidor Visual', description: 'Convierte ingredientes visualmente usando tu camara para estimar porciones. Gratis.', icon: 'Eye', status: 'beta' },
  { id: 25, name: 'Asesor Nutricional Básico', description: 'Tips de salud basados en tus preferencias dietéticas. Gratis en fase beta.', icon: 'Heart', status: 'beta' },
  { id: 26, name: 'Autoguardado en la Nube', description: 'Guarda automáticamente tu progreso al cocinar y en tus listas', icon: 'Save', status: 'beta' },
  // NUEVA FUNCION GRATIS
  { id: 27, name: 'Asistente de Aprovechamiento', description: 'Te sugiere recetas con ingredientes que están a punto de caducar. Totalmente gratuito.', icon: 'Leaf', status: 'beta' },
  { id: 28, name: 'Conversor Inteligente de Medidas', description: 'NUEVA FUNCION GRATIS. Convierte automáticamente entre tazas, onzas, gramos y litros con la cámara.', icon: 'ArrowLeftRight', status: 'activa' },
  { id: 29, name: 'Monitor de Usuarios', description: 'Ver qué usuarios se han registrado y quién quiere comprar un plan premium. Solo modo administrador.', icon: 'Users', status: 'beta', devOnly: true },
  
  // FUNCION BETA TESTER GRATUITA
  { id: 30, name: 'Conversor de Raciones Visual', description: 'Recalcula ingredientes visualmente en un clic. Beta gratuita para todos los planes.', icon: 'PieChart', status: 'beta' },
  
  // FUNCIONES INTEGRADAS OFICIALMENTE
  { id: 31, name: 'Creador de Menús IA (Alpha)', description: 'Generación semántica de 7 días. Crea planificaciones completas e inteligentes automáticamente.', icon: 'BrainCircuit', status: 'beta' },
  { id: 32, name: 'Sincronización P2P en Vivo', description: 'Comparte listas de compra sin servidor en tiempo real con otros usuarios.', icon: 'Wifi', status: 'beta' },
  
  // COLABORACION COOKIDOO (3 Nuevas Funciones)
  { id: 33, name: 'Sincronización Cookidoo', description: 'Sincroniza tus recetas oficiales directamente desde tu cuenta Cookidoo.', icon: 'Download', status: 'activa' },
  { id: 34, name: 'Colecciones Cookidoo', description: 'Accede a los libros digitales y colecciones exclusivas de Cookidoo.', icon: 'BookOpen', status: 'activa' },
  { id: 35, name: 'Inspiración Cookidoo', description: 'Recibe diariamente recomendaciones de Thermomix y retos oficiales de Cookidoo.', icon: 'Flame', status: 'activa' },
  
  // COLABORACION HOLYCOOK
  { id: 36, name: 'Holycook: Guarda e Imprime', description: 'Guarda, organiza e imprime tus recetas con la tecnología exclusiva de Holycook.', icon: 'Printer', status: 'activa' },
  
  // COLABORACION PAPRIKA (De Pago - Opción favorita)
  { id: 37, name: 'Paprika Sync', description: 'Importa y organiza recetas desde Paprika. Sincronización completa con listas de compra y planificación de comidas.', icon: 'Library', status: 'activa' },
  
  // COLABORACION DEGLAZE (Gratis - Sencillez)
  { id: 38, name: 'Deglaze Import', description: 'Importa recetas de forma simple y limpia desde Deglaze. Sin complicaciones ni funciones innecesarias.', icon: 'Download', status: 'activa' },
  
  // COLABORACION SPILLT (Gratis - Aprovechamiento)
  { id: 39, name: 'Spillt Nevera', description: 'Cocina con lo que tienes. Sugiere recetas basadas en ingredientes de tu despensa para reducir desperdicio.', icon: 'Refrigerator', status: 'activa' },
  
  // COLABORACION RECIME (De Pago - Organización + Nutrición)
  { id: 40, name: 'ReciMe Pro', description: 'Guarda recetas, planifica comidas y genera listas automáticas. Seguimiento nutricional avanzado incluido.', icon: 'Activity', status: 'activa' },
  
  // COLABORACION YUMMLY (Freemium)
  { id: 41, name: 'Yummly Connect', description: 'Encuentra recetas basadas en tus gustos, dietas e ingredientes. Filtros avanzados en versión premium.', icon: 'Search', status: 'activa' },
  
  // COLABORACION BIGOVEN (Freemium)
  { id: 42, name: 'BigOven Database', description: 'Acceso a la enorme base de datos de BigOven. Guarda, planifica y genera listas de compra.', icon: 'Database', status: 'activa' },
  
  // 5 NUEVAS FUNCIONALIDADES (En Desarrollo - Beta)
  { id: 43, name: 'AI Chef Personal', description: 'Asistente de cocina con IA que aprende tus gustos y sugiere recetas personalizadas diariamente. [EN DESARROLLO]', icon: 'Brain', status: 'beta' },
  { id: 44, name: 'Realidad Aumentada Cocina', description: 'Visualiza ingredientes y pasos en tu cocina real usando AR. [EN DESARROLLO]', icon: 'Glasses', status: 'beta' },
  { id: 45, name: 'Comunidad en Vivo', description: 'Cocina junto a otros usuarios en tiempo real con video y chat integrado. [EN DESARROLLO]', icon: 'Video', status: 'beta' },
  { id: 46, name: 'Nutrición Predictiva', description: 'Análisis de nutrientes en tiempo real con recomendaciones de equilibrio dietético. [EN DESARROLLO]', icon: 'Activity', status: 'beta' },
  { id: 47, name: 'Mercado Inteligente', description: 'Compara precios de ingredientes en supermercados cercanos y optimiza tu lista de compra. [EN DESARROLLO]', icon: 'ShoppingBag', status: 'beta' },
];

export interface Setting {
  id: number;
  name: string;
  description: string;
  category: 'general' | 'apariencia' | 'notificaciones' | 'privacidad' | 'accesibilidad' | 'cocina' | 'beta' | 'desarrollador' | 'administrador' | 'perfil' | 'chromecast' | 'avanzado';
  type: 'toggle' | 'select' | 'slider' | 'text' | 'color';
  defaultValue: boolean | string | number;
  devOnly?: boolean;
}

export const settings: Setting[] = [
  // General (Nuevos de Rendimiento/Seguridad)
  { id: 400, name: 'Cifrado Local Fuerte', description: 'Protección militar de tus datos locales', category: 'general', type: 'toggle', defaultValue: true },
  { id: 401, name: 'Limpieza Automática', description: 'Borrar caché temporal al salir', category: 'general', type: 'toggle', defaultValue: false },
  { id: 402, name: 'Seguridad Estricta', description: 'Requiere re-login tras inactividad', category: 'general', type: 'toggle', defaultValue: true },
  { id: 403, name: 'Bloqueo de Capturas', description: 'Previene capturas de pantalla de recetas propias', category: 'general', type: 'toggle', defaultValue: false },
  { id: 404, name: 'Modo Rendimiento Máximo', description: 'Desactiva efectos visuales pesados', category: 'general', type: 'toggle', defaultValue: false },

  // General (Existentes)
  { id: 67, name: 'Sugerir Funciones', description: 'Envíanos tus ideas para nuevas funcionalidades', category: 'general', type: 'toggle', defaultValue: false },
  { id: 68, name: 'Modo Vacaciones', description: 'Pausa notificaciones y planes mientras no estás', category: 'general', type: 'toggle', defaultValue: false },
  // 3 Nuevos Ajustes Cookidoo (General)
  { id: 801, name: 'Buscar primero en Cookidoo', description: 'Priorizar recetas de la plataforma Cookidoo en el buscador', category: 'general', type: 'toggle', defaultValue: true },
  { id: 802, name: 'Notificaciones Cookidoo', description: 'Avisarme de nuevas colecciones oficiales de Thermomix Cookidoo', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 803, name: 'Tema Cookidoo', description: 'Utiliza el verde característico de Thermomix Cookidoo como acento visual', category: 'apariencia', type: 'toggle', defaultValue: false },
  { id: 69, name: 'Unidades Precisas', description: 'Mostrar decimales en las cantidades (ej. 1.5 kg)', category: 'general', type: 'toggle', defaultValue: true },
  { id: 70, name: 'Bloqueo de Pantalla Automático', description: 'Permite que la pantalla se bloquee al inactividad', category: 'general', type: 'toggle', defaultValue: false },
  { id: 71, name: 'Copias de Seguridad Automáticas', description: 'Copia de seguridad en la nube diaria', category: 'general', type: 'toggle', defaultValue: true },
  { id: 72, name: 'Modo Concentración', description: 'Oculta elementos innecesarios al cocinar', category: 'general', type: 'toggle', defaultValue: false },
  { id: 73, name: 'Inicio Rápido', description: 'Carga directo a tu última receta vista', category: 'general', type: 'toggle', defaultValue: false },
  { id: 74, name: 'Sugerencias de Temporada', description: 'Priorizar recetas basadas en ingredientes actuales', category: 'general', type: 'toggle', defaultValue: true },
  { id: 1, name: 'Unidades de Medida', description: 'Elige entre sistema metrico o imperial', category: 'general', type: 'select', defaultValue: 'metrico' },
  { id: 2, name: 'Idioma', description: 'Selecciona el idioma de la aplicacion', category: 'general', type: 'select', defaultValue: 'espanol' },
  { id: 3, name: 'Modo Thermomix por Defecto', description: 'Muestra siempre instrucciones para Thermomix', category: 'general', type: 'toggle', defaultValue: false },
  { id: 4, name: 'Autoguardado de Favoritos', description: 'Guarda automaticamente recetas que visitas frecuentemente', category: 'general', type: 'toggle', defaultValue: true },
  { id: 5, name: 'Porciones por Defecto', description: 'Numero de porciones predeterminado', category: 'general', type: 'slider', defaultValue: 4 },
  { id: 6, name: 'Cache de Recetas', description: 'Guarda recetas offline para acceso sin conexion', category: 'general', type: 'toggle', defaultValue: true },
  { id: 60, name: 'Descarga Automática', description: 'Descarga contenido nuevo solo en WiFi', category: 'general', type: 'toggle', defaultValue: true },
  { id: 61, name: 'Sincronización en Segundo Plano', description: 'Mantiene tus listas y favoritos actualizados en todo momento', category: 'general', type: 'toggle', defaultValue: true },
  { id: 62, name: 'Ahorro de Batería', description: 'Reduce animaciones y procesos para ahorrar energía', category: 'general', type: 'toggle', defaultValue: false },
  { id: 63, name: 'Pantalla Siempre Activa', description: 'Evita que la pantalla se apague mientras cocinas', category: 'general', type: 'toggle', defaultValue: true },
  { id: 64, name: 'Zona Horaria Local', description: 'Ajusta los temporizadores a tu hora local', category: 'general', type: 'toggle', defaultValue: true },
  { id: 65, name: 'Sonidos de Navegación', description: 'Pequeños efectos sonoros al moverte por la app', category: 'general', type: 'toggle', defaultValue: false },
  { id: 66, name: 'Formato de Hora', description: 'Usa formato de 24 horas en lugar de 12 horas', category: 'general', type: 'toggle', defaultValue: true },

  // Apariencia (6)
  { id: 7, name: 'Modo Oscuro', description: 'Activa el tema oscuro para reducir la fatiga visual', category: 'apariencia', type: 'toggle', defaultValue: false },
  { id: 8, name: 'Modo Pantalla Completa', description: 'Oculta la barra de navegacion mientras cocinas', category: 'apariencia', type: 'toggle', defaultValue: false },
  { id: 9, name: 'Color de Acento', description: 'Personaliza el color principal de la aplicacion', category: 'apariencia', type: 'select', defaultValue: 'naranja' },
  { id: 10, name: 'Densidad de Tarjetas', description: 'Ajusta el tamano de las tarjetas de recetas', category: 'apariencia', type: 'select', defaultValue: 'normal' },
  { id: 11, name: 'Mostrar Imagenes', description: 'Muestra imagenes de las recetas', category: 'apariencia', type: 'toggle', defaultValue: true },
  { id: 12, name: 'Animaciones', description: 'Activa/desactiva las animaciones de la interfaz', category: 'apariencia', type: 'toggle', defaultValue: true },

  // Notificaciones (5)
  { id: 13, name: 'Notificaciones Push', description: 'Recibe notificaciones de nuevas recetas y tips', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 14, name: 'Alertas de Temporizador', description: 'Sonido y vibracion cuando el temporizador termina', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 15, name: 'Resumen Diario', description: 'Recibe un resumen diario con recetas recomendadas', category: 'notificaciones', type: 'toggle', defaultValue: false },
  { id: 16, name: 'Alertas de Logros', description: 'Notifica cuando desbloqueas un nuevo logro', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 17, name: 'Recordatorios de Cocina', description: 'Recordatorios para cocinar recetas guardadas', category: 'notificaciones', type: 'toggle', defaultValue: false },

  // Privacidad (5)
  { id: 18, name: 'Compartir Actividad', description: 'Permite compartir tu actividad con otros usuarios', category: 'privacidad', type: 'toggle', defaultValue: false },
  { id: 19, name: 'Historial de Busqueda', description: 'Guarda tu historial de busquedas recientes', category: 'privacidad', type: 'toggle', defaultValue: true },
  { id: 20, name: 'Sugerencias Personalizadas', description: 'Recibe sugerencias basadas en tus preferencias', category: 'privacidad', type: 'toggle', defaultValue: true },
  { id: 21, name: 'Perfil Publico', description: 'Permite que otros usuarios vean tu perfil', category: 'privacidad', type: 'toggle', defaultValue: false },
  { id: 22, name: 'Estadisticas Anonimas', description: 'Comparte estadisticas anonimas para mejorar la app', category: 'privacidad', type: 'toggle', defaultValue: true },

  // Accesibilidad (11)
  { id: 23, name: 'Tamano de Texto', description: 'Ajusta el tamano del texto en las recetas', category: 'accesibilidad', type: 'select', defaultValue: 'mediano' },
  { id: 230, name: 'Tipografia Global', description: 'Ajusta el tamano de la tipografia de toda la aplicacion: Pequeno (12px), Mediano (14px), Grande (16px), Enorme (20px)', category: 'accesibilidad', type: 'select', defaultValue: 'mediano' },
  { id: 24, name: 'Alto Contraste', description: 'Aumenta el contraste para mejor legibilidad', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 25, name: 'Lectura en Voz Alta', description: 'Lee los pasos de la receta en voz alta', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 26, name: 'Animaciones Reducidas', description: 'Reduce las animaciones de la interfaz', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 27, name: 'Modo Daltonico', description: 'Ajusta los colores para daltonismo', category: 'accesibilidad', type: 'select', defaultValue: 'desactivado' },
  { id: 271, name: 'Navegación por Teclado', description: 'Mejora la navegación usando solo el teclado', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 272, name: 'Lector de Pantalla Mejorado', description: 'Añade más contexto para lectores de pantalla', category: 'accesibilidad', type: 'toggle', defaultValue: true },
  { id: 273, name: 'Fuente para Dislexia', description: 'Utiliza tipografías adaptadas para dislexia', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 274, name: 'Espaciado Interlineal Ampliado', description: 'Aumenta el espacio entre líneas', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 275, name: 'Sin Temporizadores Automáticos', description: 'Evita que los temporizadores se inicien sin tu acción', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 276, name: 'Asistencia de Contraste Automático', description: 'Ajusta el contraste de texto según el fondo en imágenes', category: 'accesibilidad', type: 'toggle', defaultValue: true },
  { id: 277, name: 'Filtros Daltónicos Avanzados', description: 'Ajuste de filtros para múltiples tipos de daltonismo', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 278, name: 'Subtítulos en Videos', description: 'Muestra siempre subtítulos en contenido multimedia', category: 'accesibilidad', type: 'toggle', defaultValue: true },
  { id: 279, name: 'Lectura con Velocidad Ajustable', description: 'Control para dictado más lento o rápido del texto', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 280, name: 'Controles Táctiles Ampliados', description: 'Aumenta el área de toque de todos los botones', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  // 5 NUEVOS AJUSTES ACCESIBILIDAD (v2.0.0)
  { id: 281, name: 'Modo Manos Libres Total', description: 'Control absoluto con comandos de voz avanzados', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 282, name: 'Reducción de Movimiento', description: 'Elimina las animaciones complejas', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 283, name: 'Dictado de Ingredientes Lento', description: 'Lee las cantidades más pausadamente', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 284, name: 'Alertas Visuales Intensas', description: 'Destellos de pantalla al finalizar temporizadores', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 285, name: 'Modo Alto Contraste Oscuro', description: 'Gris oscuro sólido y texto amarillo brillante', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  // NUEVOS SOLICITADOS
  { id: 236, name: 'Lector de pantalla mejorado', description: 'Optimizado para VoiceOver y TalkBack', category: 'accesibilidad', type: 'toggle', defaultValue: true },
  { id: 237, name: 'Navegación por gestos', description: 'Control total con gestos táctiles', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 238, name: 'Modo daltónico', description: 'Filtros para protanopia, deuteranopia, tritanopia', category: 'accesibilidad', type: 'select', defaultValue: 'desactivado' },
  { id: 239, name: 'Tamaño de cursor', description: 'Cursor grande para mejor visibilidad', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 240, name: 'Espaciado de líneas', description: 'Ajusta el interlineado del texto', category: 'accesibilidad', type: 'slider', defaultValue: 15 },

  // Cocina (3)
  { id: 28, name: 'Modo Ninos', description: 'Interfaz simplificada y recetas aptas para ninos', category: 'cocina', type: 'toggle', defaultValue: false },
  { id: 29, name: 'Nivel de Cocina', description: 'Tu nivel de experiencia en la cocina', category: 'cocina', type: 'select', defaultValue: 'intermedio' },
  { id: 30, name: 'Preferencias Dieteticas', description: 'Filtra recetas segun tu dieta', category: 'cocina', type: 'select', defaultValue: 'ninguna' },

  // Beta (14 = 7 existentes + 7 nuevas)
  { id: 31, name: 'Menus Inteligentes', description: 'Activa el generador automatico de menus semanales', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 32, name: 'Asistente por Voz', description: 'Control de la app hablando al dispositivo', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 33, name: 'Gestos de Camara', description: 'Pasar paginas con movimientos de mano', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 34, name: 'Sync de Nevera', description: 'Conecta con APIs de supermercados', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 35, name: 'Generacion de Imagenes', description: 'Generar imagenes de tus variaciones de recetas', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 36, name: 'Sensibilidad de Gestos', description: 'Ajusta la reaccion de la camara a tu mano', category: 'beta', type: 'slider', defaultValue: 5 },
  { id: 37, name: 'Calidad de Voz', description: 'Define la calidad del asistente de voz', category: 'beta', type: 'select', defaultValue: 'alta' },
  // 7 NUEVOS AJUSTES BETA
  { id: 38, name: 'Cocina Colaborativa en Vivo', description: 'Permite cocinar en tiempo real con otros usuarios conectados', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 39, name: 'Deteccion de Alergenos IA', description: 'Escanea ingredientes y detecta posibles alergenos automaticamente', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 40, name: 'Modo Streaming', description: 'Transmite tu cocina en vivo a la comunidad CocinaViva', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 41, name: 'Recetas por Foto', description: 'Sube una foto de un plato y la IA identifica la receta mas similar', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 42, name: 'Prediccion de Sabor', description: 'La IA predice si una combinacion de ingredientes sera exitosa', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 43, name: 'Auto-ajuste de Porciones', description: 'Ajusta automaticamente las cantidades segun comensales detectados', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 44, name: 'Modo Offline Avanzado', description: 'Descarga videos y multimedia de recetas para uso sin conexion', category: 'beta', type: 'toggle', defaultValue: false },

  // Administrador (solo visible con codigo secreto)
  { id: 45, name: 'Modo Administrador', description: 'Habilita el panel de administracion con herramientas avanzadas de gestion y testing', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 46, name: 'Acceso Anticipado', description: 'Accede a funciones experimentales antes que nadie', category: 'administrador', type: 'toggle', defaultValue: true, devOnly: true },
  { id: 47, name: 'Logs de Rendimiento', description: 'Muestra metricas de rendimiento en la consola', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 48, name: 'Debug Visual', description: 'Muestra bordes de componentes y areas de clic', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 49, name: 'API Endpoint', description: 'Selecciona el servidor de backend a usar', category: 'administrador', type: 'select', defaultValue: 'produccion' },
  { id: 50, name: 'Cache Agresivo', description: 'Cachea todo localmente para desarrollo rapido', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 51, name: 'Resetear Datos', description: 'Borra todos los datos locales y reinicia la app', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 52, name: 'Simular Plan Premium', description: 'Simula la suscripcion Master Chef para testing', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  // 5 NUEVOS AJUSTES ADMIN
  { id: 53, name: 'Autoguardado Profundo', description: 'Nueva funcion tester de autoguardado en tiempo real', category: 'administrador', type: 'toggle', defaultValue: true, devOnly: true },
  { id: 54, name: 'Bypass Auth', description: 'Permite ignorar la autenticacion en entornos locales', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 55, name: 'Simulador de Errores', description: 'Lanza excepciones de prueba para verificar ErrorBoundaries', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 56, name: 'Monitor de Redux/Estado', description: 'Muestra un overlay con el estado de la aplicacion en vivo', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 57, name: 'Forzar Actualizacion OTA', description: 'Simula la recepcion de un nuevo paquete over-the-air', category: 'administrador', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 58, name: 'Monitor de Usuarios', description: 'Ver quién ha iniciado sesión y la intención de compra', category: 'administrador', type: 'toggle', defaultValue: true, devOnly: true },
  
  // Chromecast (7 Nuevos Ajustes Prácticos)
  { id: 500, name: 'Autoconexión Inteligente', description: 'Conecta automáticamente con el Chromecast al abrir la app', category: 'chromecast', type: 'toggle', defaultValue: true },
  { id: 501, name: 'Mando a Distancia Simple', description: 'Oculta texto largo para mostrar botones gigantes', category: 'chromecast', type: 'toggle', defaultValue: false },
  { id: 502, name: 'Silenciar Dispositivo Móvil', description: 'Silencia el teléfono mientras transmites', category: 'chromecast', type: 'toggle', defaultValue: true },
  { id: 503, name: 'Mantener Pantalla Encendida', description: 'Evita que tu teléfono se bloquee al transmitir', category: 'chromecast', type: 'toggle', defaultValue: true },
  { id: 504, name: 'Salvapantallas de Recetas', description: 'Muestra fotos de recetas en HQ al pausar', category: 'chromecast', type: 'toggle', defaultValue: true },
  { id: 505, name: 'Control por Voz de TV', description: 'Permite controlar la TV desde el micrófono del móvil', category: 'chromecast', type: 'toggle', defaultValue: false },
  { id: 506, name: 'Modo Ahorro Batería (Cast)', description: 'Apaga la pantalla de tu móvil reproduciendo vídeos en TV', category: 'chromecast', type: 'toggle', defaultValue: false },
  
  // Ajustes Avanzados (10 nuevos)
  { id: 601, name: 'Aceleración por Hardware', description: 'Usa la GPU para renderizar animaciones y videos fluidamente', category: 'avanzado', type: 'toggle', defaultValue: true },
  { id: 602, name: 'Precarga Inteligente de Imágenes', description: 'Carga las imágenes de las recetas antes de abrirlas', category: 'avanzado', type: 'toggle', defaultValue: true },
  { id: 603, name: 'Tasa de Refresco Máxima', description: 'Fuerza 120Hz si la pantalla lo soporta', category: 'avanzado', type: 'toggle', defaultValue: false },
  { id: 604, name: 'Compresión de Datos', description: 'Reduce el consumo de megas en conexiones móviles', category: 'avanzado', type: 'toggle', defaultValue: false },
  { id: 605, name: 'Modo Depuración Visual', description: 'Muestra los FPS en pantalla y tiempos de carga', category: 'avanzado', type: 'toggle', defaultValue: false, devOnly: true },
  { id: 606, name: 'Optimización de Memoria', description: 'Libera RAM automáticamente si pasas de 500MB', category: 'avanzado', type: 'toggle', defaultValue: true },
  { id: 607, name: 'Limitar Ejecución en Segundo Plano', description: 'Pausa timers si sales de la app (Ahorro agresivo)', category: 'avanzado', type: 'toggle', defaultValue: false },
  { id: 608, name: 'Gestor de Tareas Asíncrono', description: 'Divide la carga para no bloquear la interfaz', category: 'avanzado', type: 'toggle', defaultValue: true },
  { id: 609, name: 'Pre-fetching de Rutas', description: 'Carga páginas en caché al hacer hover', category: 'avanzado', type: 'toggle', defaultValue: true },
  { id: 610, name: 'Caché de Imágenes Permanente', description: 'Guarda las fotos para siempre (ocupa espacio)', category: 'avanzado', type: 'toggle', defaultValue: false },
  
  // 10 AJUSTES AVANZADOS BETA (En Desarrollo)
  { id: 700, name: 'Motor IA Chef Personal', description: 'Entrena la IA con tus gustos específicos [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 701, name: 'Modo Realidad Aumentada', description: 'Activa overlay AR en tu cámara de cocina [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 702, name: 'Streaming de Cocina', description: 'Transmite tu sesión de cocina en vivo [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 703, name: 'Análisis Nutricional Predictivo', description: 'Predicciones de balance dietético semanal [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 704, name: 'Comparador de Precios', description: 'Escanea tickets y compara con otros supermercados [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 705, name: 'Reconocimiento de Voz Avanzado', description: 'Comandos de voz sin internet (offline) [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 706, name: 'Sincronización Multi-Dispositivo', description: 'Cambia entre móvil, tablet y TV sin perder el paso [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 707, name: 'Detección de Calidad de Ingredientes', description: 'IA evalúa frescura por foto [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 708, name: 'Planificación Automática Semanal', description: 'Genera menús completos automáticamente [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 709, name: 'Asistente de Compra Inteligente', description: 'Ordena tu lista por pasillos del supermercado [EN DESARROLLO]', category: 'beta', type: 'toggle', defaultValue: false },
];

// 30 Ajustes de Perfil
export interface ProfileSetting {
  id: number;
  name: string;
  description: string;
  type: 'text' | 'select' | 'toggle' | 'slider' | 'color';
  defaultValue: string | boolean | number;
  group: 'personal' | 'preferencias' | 'dieta' | 'social' | 'privacidad_perfil' | 'experiencia';
}

export const profileSettings: ProfileSetting[] = [
  // Personal (7)
  { id: 31, name: 'URL de Foto de Perfil', description: 'Pega el enlace a tu imagen de perfil', type: 'text', defaultValue: '', group: 'personal' },
  { id: 1, name: 'Nombre de Usuario', description: 'Tu nombre publico en CocinaViva', type: 'text', defaultValue: 'Chef Anonimo', group: 'personal' },
  { id: 2, name: 'Nombre Completo', description: 'Tu nombre real (no se muestra publicamente)', type: 'text', defaultValue: '', group: 'personal' },
  { id: 3, name: 'Email de Contacto', description: 'Email para notificaciones y recuperacion', type: 'text', defaultValue: '', group: 'personal' },
  { id: 4, name: 'Pais', description: 'Tu pais de residencia', type: 'select', defaultValue: 'Espana', group: 'personal' },
  { id: 5, name: 'Ciudad', description: 'Tu ciudad para recetas regionales', type: 'text', defaultValue: '', group: 'personal' },
  { id: 6, name: 'Fecha de Nacimiento', description: 'Para recomendaciones personalizadas', type: 'text', defaultValue: '', group: 'personal' },

  // Preferencias culinarias (6)
  { id: 7, name: 'Nivel de Experiencia', description: 'Tu nivel actual en la cocina', type: 'select', defaultValue: 'Intermedio', group: 'preferencias' },
  { id: 8, name: 'Cocina Favorita', description: 'Tipo de cocina que mas te gusta', type: 'select', defaultValue: 'Espanola', group: 'preferencias' },
  { id: 9, name: 'Dificultad Preferida', description: 'Nivel de dificultad que prefieres', type: 'select', defaultValue: 'Media', group: 'preferencias' },
  { id: 10, name: 'Tiempo Maximo', description: 'Tiempo maximo que dedicas a cocinar (min)', type: 'slider', defaultValue: 60, group: 'preferencias' },
  { id: 11, name: 'Comensales Habituales', description: 'Numero habitual de personas en tu mesa', type: 'slider', defaultValue: 4, group: 'preferencias' },
  { id: 12, name: 'Tipo de Cocina Preferido', description: 'Thermomix o tradicional', type: 'select', defaultValue: 'Ambos', group: 'preferencias' },

  // Dieta y Salud (6)
  { id: 13, name: 'Dieta Principal', description: 'Tu tipo de dieta', type: 'select', defaultValue: 'Omnivoro', group: 'dieta' },
  { id: 14, name: 'Alergias Alimentarias', description: 'Ingredientes a los que eres alergico', type: 'text', defaultValue: 'Ninguna', group: 'dieta' },
  { id: 15, name: 'Intolerancias', description: 'Intolerancias alimentarias conocidas', type: 'text', defaultValue: 'Ninguna', group: 'dieta' },
  { id: 16, name: 'Objetivo Calorico Diario', description: 'Calorias objetivo por dia', type: 'slider', defaultValue: 2000, group: 'dieta' },
  { id: 17, name: 'Dieta Sin Gluten', description: 'Filtrar automaticamente recetas sin gluten', type: 'toggle', defaultValue: false, group: 'dieta' },
  { id: 18, name: 'Bajo en Sodio', description: 'Preferir recetas bajas en sal', type: 'toggle', defaultValue: false, group: 'dieta' },

  // Social (5)
  { id: 19, name: 'Mostrar Actividad', description: 'Otros ven lo que cocinas', type: 'toggle', defaultValue: false, group: 'social' },
  { id: 20, name: 'Permitir Mensajes', description: 'Recibir mensajes de otros usuarios', type: 'toggle', defaultValue: true, group: 'social' },
  { id: 21, name: 'Compartir Logros', description: 'Publicar automaticamente logros desbloqueados', type: 'toggle', defaultValue: true, group: 'social' },
  { id: 22, name: 'Estado en Linea', description: 'Mostrar cuando estas conectado', type: 'toggle', defaultValue: false, group: 'social' },
  { id: 23, name: 'Bio del Perfil', description: 'Descripcion corta sobre ti como cocinero', type: 'text', defaultValue: 'Me encanta cocinar!', group: 'social' },

  // Privacidad del Perfil (4)
  { id: 24, name: 'Perfil Visible', description: 'Tu perfil puede ser encontrado por otros', type: 'toggle', defaultValue: true, group: 'privacidad_perfil' },
  { id: 25, name: 'Mostrar Favoritos', description: 'Otros pueden ver tus recetas favoritas', type: 'toggle', defaultValue: false, group: 'privacidad_perfil' },
  { id: 26, name: 'Mostrar Estadisticas', description: 'Otros pueden ver tus estadisticas de cocina', type: 'toggle', defaultValue: false, group: 'privacidad_perfil' },
  { id: 27, name: 'Bloquear Invitaciones', description: 'No recibir invitaciones de otros usuarios', type: 'toggle', defaultValue: false, group: 'privacidad_perfil' },

  // Experiencia (3)
  { id: 28, name: 'Tutorial Inicial', description: 'Volver a ver el tutorial de inicio', type: 'toggle', defaultValue: false, group: 'experiencia' },
  { id: 29, name: 'Consejos del Chef', description: 'Mostrar consejos y trucos en las recetas', type: 'toggle', defaultValue: true, group: 'experiencia' },
  { id: 30, name: 'Sonidos de la App', description: 'Efectos de sonido al completar acciones', type: 'toggle', defaultValue: true, group: 'experiencia' },

  // Nuevos 10 Ajustes de Perfil (Anti-Hack & Personalización extendida)
  { id: 405, name: 'Apodo de Chef', description: 'Nombre alternativo o pseudónimo', type: 'text', defaultValue: '', group: 'personal' },
  { id: 406, name: 'Lema Personal', description: 'Tu filosofía de cocina (Ej. Nunca demasiada sal)', type: 'text', defaultValue: '', group: 'social' },
  { id: 407, name: 'Nivel de Picante', description: 'Nivel que puedes soportar', type: 'select', defaultValue: 'Suave', group: 'preferencias' },
  { id: 408, name: 'Dieta Extrema', description: 'Régimen de dieta dominante', type: 'select', defaultValue: 'Ninguno', group: 'dieta' },
  { id: 409, name: 'Alerta de Alérgenos Severa', description: 'Bloquea la apertura de recetas con tus alergias', type: 'toggle', defaultValue: true, group: 'dieta' },
  { id: 410, name: 'Invisibilidad en Buscadores', description: 'Evita que Google indexe tu perfil de usuario', type: 'toggle', defaultValue: true, group: 'privacidad_perfil' },
  { id: 411, name: 'Estado de Conexión en Vivo', description: 'Otros chefs verán el punto verde si estás online', type: 'toggle', defaultValue: false, group: 'social' },
  { id: 412, name: 'Alertas de Descuento (Ofertas)', description: 'Recibir avisos de 20% OFF antes de fin de prueba', type: 'toggle', defaultValue: true, group: 'privacidad_perfil' },
  { id: 413, name: 'Canal de YouTube', description: 'URL de tu canal de cocina', type: 'text', defaultValue: '', group: 'social' },
  { id: 414, name: 'Red de Twitch', description: 'URL de tus directos de comida', type: 'text', defaultValue: '', group: 'social' },

  // Nuevos 7 Ajustes de Perfil
  { id: 611, name: 'Pronombres', description: 'Tus pronombres en la comunidad', type: 'select', defaultValue: 'No especificar', group: 'personal' },
  { id: 612, name: 'Nivel de Certificación', description: 'Ej: Chef, Estudiante, Amateur', type: 'select', defaultValue: 'Amateur', group: 'experiencia' },
  // 3 Nuevos Ajustes Perfil Cookpad
  { id: 701, name: 'Vincular cuenta Cookpad', description: 'Conecta tu perfil con la comunidad de Cookpad', type: 'text', defaultValue: '', group: 'social' },
  { id: 702, name: 'Mostrar medallas Cookpad', description: 'Exhibe tus insignias obtenidas en Cookpad', type: 'toggle', defaultValue: true, group: 'social' },
  { id: 703, name: 'Sincronizar Cooksnaps', description: 'Copia automáticamente tus Cooksnaps de Cookpad', type: 'toggle', defaultValue: true, group: 'social' },
  { id: 613, name: 'Estilo de Emplatado', description: 'Rústico, Minimalista, Tradicional', type: 'text', defaultValue: 'Rústico', group: 'preferencias' },
  { id: 614, name: 'Compañero Frecuente', description: 'Nombre de la persona con la que más cocinas', type: 'text', defaultValue: '', group: 'social' },
  { id: 615, name: 'Especialidad', description: 'El plato que siempre te sale perfecto', type: 'text', defaultValue: '', group: 'preferencias' },
  { id: 616, name: 'Cuenta Oculta a Menores', description: 'Tu contenido es solo para adultos', type: 'toggle', defaultValue: false, group: 'privacidad_perfil' },
  { id: 617, name: 'Bloqueo de Menciones', description: 'Nadie puede etiquetarte en recetas', type: 'toggle', defaultValue: false, group: 'privacidad_perfil' },
  
  // 7 NUEVOS AJUSTES DE PERFIL (Colaboraciones)
  { id: 618, name: 'Sincronizar con Paprika', description: 'Vincula tu cuenta de Paprika para importar recetas automáticamente', type: 'toggle', defaultValue: false, group: 'social' },
  { id: 619, name: 'Importar desde Deglaze', description: 'Activa la importación simple desde Deglaze', type: 'toggle', defaultValue: true, group: 'social' },
  { id: 620, name: 'Modo Spillt (Aprovechamiento)', description: 'Prioriza recetas con ingredientes que ya tienes en casa', type: 'toggle', defaultValue: false, group: 'preferencias' },
  { id: 621, name: 'Seguimiento ReciMe Pro', description: 'Activa el seguimiento nutricional avanzado de ReciMe', type: 'toggle', defaultValue: false, group: 'dieta' },
  { id: 622, name: 'Preferencias Yummly', description: 'Sincroniza tus gustos y dietas con Yummly', type: 'toggle', defaultValue: true, group: 'preferencias' },
  { id: 623, name: 'Base de datos BigOven', description: 'Activa búsqueda extendida en la base de datos de BigOven', type: 'toggle', defaultValue: true, group: 'preferencias' },
  { id: 624, name: 'Perfil de Chef Público', description: 'Muestra tu especialidad y estilo de emplatado en tu perfil público', type: 'toggle', defaultValue: true, group: 'social' },
];

export const profileSettingGroups = [
  { key: 'personal', label: 'Datos Personales', icon: 'User' },
  { key: 'preferencias', label: 'Preferencias Culinarias', icon: 'ChefHat' },
  { key: 'dieta', label: 'Dieta y Salud', icon: 'Heart' },
  { key: 'social', label: 'Social', icon: 'Users' },
  { key: 'privacidad_perfil', label: 'Privacidad', icon: 'Lock' },
  { key: 'experiencia', label: 'Experiencia', icon: 'Sparkles' },
];

export const settingCategories = [
  { key: 'general', label: 'General', icon: 'Settings' },
  { key: 'apariencia', label: 'Apariencia', icon: 'Palette' },
  { key: 'notificaciones', label: 'Notificaciones', icon: 'Bell' },
  { key: 'privacidad', label: 'Privacidad', icon: 'Shield' },
  { key: 'accesibilidad', label: 'Accesibilidad', icon: 'Eye' },
  { key: 'cocina', label: 'Cocina', icon: 'ChefHat' },
  { key: 'beta', label: 'Funciones Beta', icon: 'FlaskConical' },
  { key: 'perfil', label: 'Perfil', icon: 'UserCircle' },
  { key: 'chromecast', label: 'Chromecast', icon: 'Cast' },
  { key: 'avanzado', label: 'Avanzado', icon: 'Sliders' },
  { key: 'administrador', label: 'Administrador', icon: 'ShieldCheck' },
];

// 100 Logros
export interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  category: 'recetas' | 'cocina' | 'social' | 'exploracion' | 'maestria' | 'thermomix' | 'coleccion' | 'tiempo' | 'especial' | 'reto';
  points: number;
  unlocked: boolean;
}

export const achievements: Achievement[] = [
  // Recetas (15)
  { id: 1, name: 'Primera Receta', description: 'Cocina tu primera receta', icon: '🍳', category: 'recetas', points: 10, unlocked: true },
  { id: 2, name: 'Chef Novato', description: 'Cocina 5 recetas diferentes', icon: '👨‍🍳', category: 'recetas', points: 25, unlocked: true },
  { id: 3, name: 'Cocinero Activo', description: 'Cocina 10 recetas diferentes', icon: '🔥', category: 'recetas', points: 50, unlocked: false },
  { id: 4, name: 'Chef Entusiasta', description: 'Cocina 25 recetas diferentes', icon: '⭐', category: 'recetas', points: 100, unlocked: false },
  { id: 5, name: 'Maestro de la Cocina', description: 'Cocina 50 recetas diferentes', icon: '👑', category: 'recetas', points: 200, unlocked: false },
  { id: 6, name: 'Chef Experto', description: 'Cocina 100 recetas diferentes', icon: '🏆', category: 'recetas', points: 500, unlocked: false },
  { id: 7, name: 'Leyenda Culinaria', description: 'Cocina 250 recetas diferentes', icon: '🎖️', category: 'recetas', points: 1000, unlocked: false },
  { id: 8, name: 'Chef Supremo', description: 'Cocina 500 recetas diferentes', icon: '💎', category: 'recetas', points: 2500, unlocked: false },
  { id: 9, name: 'Receta Rapida', description: 'Cocina una receta en menos de 15 min', icon: '⚡', category: 'recetas', points: 25, unlocked: false },
  { id: 10, name: 'Receta Elaborada', description: 'Cocina una receta de mas de 2 horas', icon: '⏰', category: 'recetas', points: 50, unlocked: false },
  { id: 11, name: 'Receta Facil', description: 'Cocina 10 recetas de dificultad facil', icon: '😊', category: 'recetas', points: 30, unlocked: false },
  { id: 12, name: 'Receta Media', description: 'Cocina 10 recetas de dificultad media', icon: '💪', category: 'recetas', points: 50, unlocked: false },
  { id: 13, name: 'Receta Dificil', description: 'Cocina 5 recetas de dificultad dificil', icon: '🔥', category: 'recetas', points: 100, unlocked: false },
  { id: 14, name: 'Reto Maestro', description: 'Cocina 25 recetas de dificultad dificil', icon: '🎯', category: 'recetas', points: 300, unlocked: false },
  { id: 15, name: 'Todo Terreno', description: 'Cocina recetas de todas las dificultades', icon: '🌈', category: 'recetas', points: 75, unlocked: false },
  // Cocina (10)
  { id: 16, name: 'Amante del Horno', description: 'Cocina 10 recetas al horno', icon: '🔥', category: 'cocina', points: 40, unlocked: false },
  { id: 17, name: 'Rey de la Sarten', description: 'Cocina 10 recetas a la sarten', icon: '🍳', category: 'cocina', points: 40, unlocked: false },
  { id: 18, name: 'Maestro del Vapor', description: 'Cocina 5 recetas al vapor', icon: '💨', category: 'cocina', points: 50, unlocked: false },
  { id: 19, name: 'Experto en Plancha', description: 'Cocina 10 recetas a la plancha', icon: '🥩', category: 'cocina', points: 40, unlocked: false },
  { id: 20, name: 'Chef de Frituras', description: 'Cocina 5 recetas fritas', icon: '🍟', category: 'cocina', points: 35, unlocked: false },
  { id: 21, name: 'Cocina Saludable', description: 'Cocina 10 recetas bajas en calorias', icon: '🥗', category: 'cocina', points: 60, unlocked: false },
  { id: 22, name: 'Proteinas Power', description: 'Cocina 10 recetas altas en proteinas', icon: '💪', category: 'cocina', points: 50, unlocked: false },
  { id: 23, name: 'Sin Gluten', description: 'Cocina 5 recetas sin gluten', icon: '🌾', category: 'cocina', points: 40, unlocked: false },
  { id: 24, name: 'Veggie Lover', description: 'Cocina 10 recetas vegetarianas', icon: '🥬', category: 'cocina', points: 50, unlocked: false },
  { id: 25, name: 'Vegano Total', description: 'Cocina 10 recetas veganas', icon: '🌱', category: 'cocina', points: 60, unlocked: false },
  // Social (10)
  { id: 26, name: 'Primera Compartida', description: 'Comparte tu primera receta', icon: '📤', category: 'social', points: 15, unlocked: false },
  { id: 27, name: 'Influencer', description: 'Comparte 10 recetas', icon: '📱', category: 'social', points: 50, unlocked: false },
  { id: 28, name: 'Super Compartidor', description: 'Comparte 50 recetas', icon: '🌟', category: 'social', points: 150, unlocked: false },
  { id: 29, name: 'Primera Valoracion', description: 'Valora tu primera receta', icon: '⭐', category: 'social', points: 10, unlocked: false },
  { id: 30, name: 'Critico Gastronomico', description: 'Valora 25 recetas', icon: '📝', category: 'social', points: 75, unlocked: false },
  { id: 31, name: 'Top Reviewer', description: 'Valora 100 recetas', icon: '🏅', category: 'social', points: 200, unlocked: false },
  { id: 32, name: 'Primer Comentario', description: 'Deja tu primer comentario', icon: '💬', category: 'social', points: 10, unlocked: false },
  { id: 33, name: 'Conversador', description: 'Deja 25 comentarios', icon: '🗣️', category: 'social', points: 50, unlocked: false },
  { id: 34, name: 'Comunidad Activa', description: 'Participa en 10 discusiones', icon: '👥', category: 'social', points: 75, unlocked: false },
  { id: 35, name: 'Embajador', description: 'Invita a 5 amigos a usar CocinaViva', icon: '🤝', category: 'social', points: 100, unlocked: false },
  // Exploracion (15)
  { id: 36, name: 'Explorador', description: 'Visita todas las categorias', icon: '🧭', category: 'exploracion', points: 30, unlocked: false },
  { id: 37, name: 'Entrantes Master', description: 'Cocina 10 entrantes', icon: '🥗', category: 'exploracion', points: 40, unlocked: false },
  { id: 38, name: 'Sopas y Cremas', description: 'Cocina 10 sopas o cremas', icon: '🍲', category: 'exploracion', points: 40, unlocked: false },
  { id: 39, name: 'Ensaladas Frescas', description: 'Cocina 10 ensaladas', icon: '🥬', category: 'exploracion', points: 40, unlocked: false },
  { id: 40, name: 'Rey del Arroz', description: 'Cocina 10 arroces', icon: '🍚', category: 'exploracion', points: 50, unlocked: false },
  { id: 41, name: 'Pasta Lover', description: 'Cocina 10 pastas', icon: '🍝', category: 'exploracion', points: 40, unlocked: false },
  { id: 42, name: 'Carnivoro', description: 'Cocina 15 platos de carne', icon: '🥩', category: 'exploracion', points: 60, unlocked: false },
  { id: 43, name: 'Pescador', description: 'Cocina 10 platos de pescado', icon: '🐟', category: 'exploracion', points: 50, unlocked: false },
  { id: 44, name: 'Marisco Deluxe', description: 'Cocina 10 platos de marisco', icon: '🦐', category: 'exploracion', points: 60, unlocked: false },
  { id: 45, name: 'Verde que te quiero', description: 'Cocina 10 platos de verduras', icon: '🥦', category: 'exploracion', points: 40, unlocked: false },
  { id: 46, name: 'Legumbres Power', description: 'Cocina 10 platos de legumbres', icon: '🫘', category: 'exploracion', points: 45, unlocked: false },
  { id: 47, name: 'Guisos Tradicionales', description: 'Cocina 10 guisos', icon: '🍖', category: 'exploracion', points: 50, unlocked: false },
  { id: 48, name: 'Dulce Pasion', description: 'Cocina 15 postres', icon: '🍰', category: 'exploracion', points: 60, unlocked: false },
  { id: 49, name: 'Repostero', description: 'Cocina 10 recetas de reposteria', icon: '🧁', category: 'exploracion', points: 50, unlocked: false },
  { id: 50, name: 'Panadero', description: 'Cocina 10 panes o masas', icon: '🍞', category: 'exploracion', points: 55, unlocked: false },
  // Maestria (10)
  { id: 51, name: 'Salsas Perfectas', description: 'Cocina 10 salsas', icon: '🫙', category: 'maestria', points: 40, unlocked: false },
  { id: 52, name: 'Bartender', description: 'Prepara 10 bebidas', icon: '🍹', category: 'maestria', points: 35, unlocked: false },
  { id: 53, name: 'Rey de las Tapas', description: 'Cocina 20 tapas', icon: '🍢', category: 'maestria', points: 70, unlocked: false },
  { id: 54, name: 'Desayunos Perfectos', description: 'Prepara 15 desayunos', icon: '🥞', category: 'maestria', points: 50, unlocked: false },
  { id: 55, name: 'Cenas Ligeras', description: 'Cocina 10 cenas ligeras', icon: '🥗', category: 'maestria', points: 40, unlocked: false },
  { id: 56, name: 'Chef de Fiestas', description: 'Cocina 10 recetas especiales', icon: '🎉', category: 'maestria', points: 60, unlocked: false },
  { id: 57, name: 'Espana Completa', description: 'Cocina recetas de 10 regiones', icon: '🇪🇸', category: 'maestria', points: 100, unlocked: false },
  { id: 58, name: 'Todas las Regiones', description: 'Cocina recetas de todas las regiones', icon: '🗺️', category: 'maestria', points: 250, unlocked: false },
  { id: 59, name: 'Cocina Internacional', description: 'Cocina 10 recetas internacionales', icon: '🌍', category: 'maestria', points: 50, unlocked: false },
  { id: 60, name: 'Mediterraneo', description: 'Cocina 10 recetas mediterraneas', icon: '🌊', category: 'maestria', points: 45, unlocked: false },
  // Thermomix (15)
  { id: 61, name: 'Primera Thermomix', description: 'Cocina tu primera receta Thermomix', icon: '🤖', category: 'thermomix', points: 20, unlocked: false },
  { id: 62, name: 'Thermomix Novato', description: 'Cocina 5 recetas Thermomix', icon: '⚙️', category: 'thermomix', points: 40, unlocked: false },
  { id: 63, name: 'Thermomix Fan', description: 'Cocina 25 recetas Thermomix', icon: '🔧', category: 'thermomix', points: 100, unlocked: false },
  { id: 64, name: 'Thermomix Expert', description: 'Cocina 50 recetas Thermomix', icon: '🎯', category: 'thermomix', points: 200, unlocked: false },
  { id: 65, name: 'Thermomix Master', description: 'Cocina 100 recetas Thermomix', icon: '👨‍🔬', category: 'thermomix', points: 400, unlocked: false },
  { id: 66, name: 'Thermomix Legend', description: 'Cocina 200 recetas Thermomix', icon: '🏆', category: 'thermomix', points: 800, unlocked: false },
  { id: 67, name: 'Thermomix Supreme', description: 'Cocina 350 recetas Thermomix', icon: '💎', category: 'thermomix', points: 1500, unlocked: false },
  { id: 68, name: 'Velocidad Maxima', description: 'Completa 10 recetas a velocidad turbo', icon: '🚀', category: 'thermomix', points: 50, unlocked: false },
  { id: 69, name: 'Control de Temperatura', description: 'Usa todas las temperaturas', icon: '🌡️', category: 'thermomix', points: 60, unlocked: false },
  { id: 70, name: 'Postres Thermomix', description: 'Cocina 10 postres con Thermomix', icon: '🍮', category: 'thermomix', points: 50, unlocked: false },
  { id: 71, name: 'Postres Thermomix Pro', description: 'Cocina 25 postres con Thermomix', icon: '🎂', category: 'thermomix', points: 100, unlocked: false },
  { id: 72, name: 'Postres Thermomix Master', description: 'Cocina 50 postres con Thermomix', icon: '🏅', category: 'thermomix', points: 200, unlocked: false },
  { id: 73, name: 'Salsas Thermomix', description: 'Prepara 10 salsas con Thermomix', icon: '🫕', category: 'thermomix', points: 45, unlocked: false },
  { id: 74, name: 'Masas Thermomix', description: 'Prepara 10 masas con Thermomix', icon: '🥖', category: 'thermomix', points: 50, unlocked: false },
  { id: 75, name: 'Cremas Thermomix', description: 'Prepara 10 cremas con Thermomix', icon: '🥣', category: 'thermomix', points: 45, unlocked: false },
  // Coleccion (10)
  { id: 76, name: 'Primer Favorito', description: 'Anade tu primera receta a favoritos', icon: '❤️', category: 'coleccion', points: 5, unlocked: true },
  { id: 77, name: 'Coleccionista', description: 'Guarda 10 recetas en favoritos', icon: '📚', category: 'coleccion', points: 25, unlocked: false },
  { id: 78, name: 'Gran Coleccion', description: 'Guarda 50 recetas en favoritos', icon: '📖', category: 'coleccion', points: 75, unlocked: false },
  { id: 79, name: 'Mega Coleccion', description: 'Guarda 100 recetas en favoritos', icon: '📕', category: 'coleccion', points: 150, unlocked: false },
  { id: 80, name: 'Biblioteca Culinaria', description: 'Guarda 250 recetas en favoritos', icon: '🏛️', category: 'coleccion', points: 300, unlocked: false },
  { id: 81, name: 'Primera Lista', description: 'Crea tu primera lista de compra', icon: '📝', category: 'coleccion', points: 10, unlocked: false },
  { id: 82, name: 'Organizador', description: 'Crea 5 listas de compra', icon: '📋', category: 'coleccion', points: 30, unlocked: false },
  { id: 83, name: 'Primera Coleccion', description: 'Crea tu primera coleccion tematica', icon: '📂', category: 'coleccion', points: 15, unlocked: false },
  { id: 84, name: 'Curador', description: 'Crea 5 colecciones tematicas', icon: '🗂️', category: 'coleccion', points: 50, unlocked: false },
  { id: 85, name: 'Archivero', description: 'Organiza recetas en 10 colecciones', icon: '🗃️', category: 'coleccion', points: 100, unlocked: false },
  // Tiempo (10)
  { id: 86, name: 'Primera Semana', description: 'Usa CocinaViva durante una semana', icon: '📅', category: 'tiempo', points: 20, unlocked: false },
  { id: 87, name: 'Un Mes Cocinando', description: 'Usa CocinaViva durante un mes', icon: '🗓️', category: 'tiempo', points: 50, unlocked: false },
  { id: 88, name: 'Tres Meses', description: 'Usa CocinaViva durante 3 meses', icon: '📆', category: 'tiempo', points: 100, unlocked: false },
  { id: 89, name: 'Medio Ano', description: 'Usa CocinaViva durante 6 meses', icon: '🎊', category: 'tiempo', points: 200, unlocked: false },
  { id: 90, name: 'Un Ano', description: 'Usa CocinaViva durante un ano', icon: '🎉', category: 'tiempo', points: 500, unlocked: false },
  { id: 91, name: 'Madrugador', description: 'Cocina antes de las 7 de la manana', icon: '🌅', category: 'tiempo', points: 30, unlocked: false },
  { id: 92, name: 'Chef Nocturno', description: 'Cocina despues de medianoche', icon: '🌙', category: 'tiempo', points: 30, unlocked: false },
  { id: 93, name: 'Cocinero de Fin de Semana', description: 'Cocina 10 recetas en fin de semana', icon: '🏖️', category: 'tiempo', points: 40, unlocked: false },
  { id: 94, name: 'Racha de 7 Dias', description: 'Cocina algo durante 7 dias seguidos', icon: '🔥', category: 'tiempo', points: 75, unlocked: false },
  { id: 95, name: 'Racha de 30 Dias', description: 'Cocina algo durante 30 dias seguidos', icon: '💥', category: 'tiempo', points: 300, unlocked: false },
  // Especial y Reto (5)
  { id: 96, name: 'Beta Tester', description: 'Participa en la version Beta', icon: '🧪', category: 'especial', points: 100, unlocked: true },
  { id: 97, name: 'Early Adopter', description: 'Uno de los primeros 1000 usuarios', icon: '🚀', category: 'especial', points: 200, unlocked: true },
  { id: 98, name: 'Reto Semanal', description: 'Completa tu primer reto semanal', icon: '🎯', category: 'reto', points: 50, unlocked: false },
  { id: 99, name: 'Retador', description: 'Completa 10 retos semanales', icon: '🏋️', category: 'reto', points: 200, unlocked: false },
  { id: 100, name: 'Perfeccionista', description: 'Desbloquea todos los logros', icon: '🌟', category: 'especial', points: 5000, unlocked: false },
  // 50 LOGROS ADICIONALES (101-150)
  // Recetas avanzadas (101-110)
  { id: 101, name: 'Chef de 1000', description: 'Cocina 1000 recetas diferentes', icon: '🏅', category: 'recetas', points: 5000, unlocked: false },
  { id: 102, name: 'Cocina Relampago', description: 'Cocina 5 recetas en un solo dia', icon: '⚡', category: 'recetas', points: 100, unlocked: false },
  { id: 103, name: 'Maratón Culinario', description: 'Cocina 10 recetas en un fin de semana', icon: '🏃', category: 'recetas', points: 150, unlocked: false },
  { id: 104, name: 'Receta Centenaria', description: 'Cocina una receta con mas de 100 anos', icon: '📜', category: 'recetas', points: 75, unlocked: false },
  { id: 105, name: 'Chef Multicultural', description: 'Cocina recetas de 15 regiones', icon: '🌐', category: 'recetas', points: 200, unlocked: false },
  { id: 106, name: 'Repeticion Perfecta', description: 'Cocina la misma receta 10 veces', icon: '🔄', category: 'recetas', points: 80, unlocked: false },
  { id: 107, name: 'Ingrediente Estrella', description: 'Usa el mismo ingrediente en 20 recetas', icon: '⭐', category: 'recetas', points: 60, unlocked: false },
  { id: 108, name: 'Chef Minimalista', description: 'Cocina 5 recetas con menos de 5 ingredientes', icon: '✨', category: 'recetas', points: 45, unlocked: false },
  { id: 109, name: 'Banquete Real', description: 'Cocina un menu completo de 5 platos', icon: '👑', category: 'recetas', points: 120, unlocked: false },
  { id: 110, name: 'Chef Improvisador', description: 'Modifica una receta y guardala como propia', icon: '🎭', category: 'recetas', points: 50, unlocked: false },
  // Exploración avanzada (111-120)
  { id: 111, name: 'Todas las Categorias', description: 'Cocina al menos 1 receta de cada categoria', icon: '📋', category: 'exploracion', points: 200, unlocked: false },
  { id: 112, name: 'Mundo de Salsas', description: 'Domina 20 salsas diferentes', icon: '🫙', category: 'exploracion', points: 100, unlocked: false },
  { id: 113, name: 'Panadero Artesano', description: 'Cocina 20 panes artesanales', icon: '🥖', category: 'exploracion', points: 90, unlocked: false },
  { id: 114, name: 'Rey del Marisco', description: 'Cocina 20 platos de marisco', icon: '🦞', category: 'exploracion', points: 100, unlocked: false },
  { id: 115, name: 'Sopas del Mundo', description: 'Cocina 20 sopas de distintas regiones', icon: '🍜', category: 'exploracion', points: 85, unlocked: false },
  { id: 116, name: 'Maestro Arrocero', description: 'Cocina 20 arroces diferentes', icon: '🍛', category: 'exploracion', points: 90, unlocked: false },
  { id: 117, name: 'Pasta Italiana', description: 'Cocina 15 pastas italianas clasicas', icon: '🍝', category: 'exploracion', points: 70, unlocked: false },
  { id: 118, name: 'Guisos de Abuela', description: 'Cocina 15 guisos tradicionales', icon: '🥘', category: 'exploracion', points: 80, unlocked: false },
  { id: 119, name: 'Cocina de Temporada', description: 'Cocina recetas de las 4 estaciones', icon: '🌸', category: 'exploracion', points: 60, unlocked: false },
  { id: 120, name: 'Chef Festivo', description: 'Cocina recetas para 5 festividades', icon: '🎄', category: 'exploracion', points: 75, unlocked: false },
  // Thermomix avanzado (121-130)
  { id: 121, name: 'Thermomix Total', description: 'Usa todas las funciones de Thermomix', icon: '🔧', category: 'thermomix', points: 300, unlocked: false },
  { id: 122, name: 'Velocidad Cero', description: 'Cocina 10 recetas en velocidad cuchara', icon: '🥄', category: 'thermomix', points: 40, unlocked: false },
  { id: 123, name: 'Varoma Expert', description: 'Usa la funcion Varoma en 15 recetas', icon: '♨️', category: 'thermomix', points: 70, unlocked: false },
  { id: 124, name: 'Turbo Master', description: 'Usa la velocidad turbo en 20 recetas', icon: '💨', category: 'thermomix', points: 60, unlocked: false },
  { id: 125, name: 'Thermomix Gourmet', description: 'Cocina 10 recetas gourmet con Thermomix', icon: '🍽️', category: 'thermomix', points: 100, unlocked: false },
  { id: 126, name: 'Pan en Thermomix', description: 'Haz 10 panes diferentes con Thermomix', icon: '🍞', category: 'thermomix', points: 80, unlocked: false },
  { id: 127, name: 'Sopas Thermomix', description: 'Prepara 15 sopas con Thermomix', icon: '🥣', category: 'thermomix', points: 65, unlocked: false },
  { id: 128, name: 'Helados Thermomix', description: 'Prepara 5 helados caseros con Thermomix', icon: '🍦', category: 'thermomix', points: 55, unlocked: false },
  { id: 129, name: 'Smoothies Pro', description: 'Prepara 10 smoothies con Thermomix', icon: '🥤', category: 'thermomix', points: 40, unlocked: false },
  { id: 130, name: 'Mantequillas Caseras', description: 'Haz 5 mantequillas aromatizadas', icon: '🧈', category: 'thermomix', points: 50, unlocked: false },
  // Social y comunidad (131-140)
  { id: 131, name: 'Chef Mentor', description: 'Ayuda a 10 usuarios con sus recetas', icon: '🎓', category: 'social', points: 100, unlocked: false },
  { id: 132, name: 'Foto Viral', description: 'Tu foto de receta recibe 100 likes', icon: '📸', category: 'social', points: 150, unlocked: false },
  { id: 133, name: 'Receta Original', description: 'Publica tu primera receta propia', icon: '✍️', category: 'social', points: 75, unlocked: false },
  { id: 134, name: 'Chef Publicador', description: 'Publica 10 recetas propias', icon: '📰', category: 'social', points: 200, unlocked: false },
  { id: 135, name: 'Comunidad de 100', description: 'Consigue 100 seguidores', icon: '👥', category: 'social', points: 250, unlocked: false },
  { id: 136, name: 'Reto Comunitario', description: 'Participa en 5 retos de la comunidad', icon: '🤜', category: 'social', points: 100, unlocked: false },
  { id: 137, name: 'Duo Culinario', description: 'Cocina en modo colaborativo con alguien', icon: '👫', category: 'social', points: 50, unlocked: false },
  { id: 138, name: 'Receta Guardada', description: 'Otros guardan tu receta 50 veces', icon: '💾', category: 'social', points: 120, unlocked: false },
  { id: 139, name: 'Experto Reconocido', description: 'Recibe la insignia de experto comunitario', icon: '🏵️', category: 'social', points: 300, unlocked: false },
  { id: 140, name: 'Streaming Chef', description: 'Haz tu primer directo cocinando', icon: '🎥', category: 'social', points: 80, unlocked: false },
  // Especiales y retos (141-150)
  { id: 141, name: 'CocinaViva OG', description: 'Usuario desde la version 1.0', icon: '🏛️', category: 'especial', points: 500, unlocked: true },
  { id: 142, name: 'Admin Supremo', description: 'Activa el modo administrador', icon: '🛡️', category: 'especial', points: 250, unlocked: false },
  { id: 143, name: 'Plan Premium', description: 'Suscribete a un plan de pago', icon: '💎', category: 'especial', points: 100, unlocked: false },
  { id: 144, name: 'Reto 30 Recetas', description: 'Cocina 30 recetas en 30 dias', icon: '📆', category: 'reto', points: 500, unlocked: false },
  { id: 145, name: 'Reto Sin Carne', description: 'Cocina 7 dias sin carne', icon: '🥬', category: 'reto', points: 150, unlocked: false },
  { id: 146, name: 'Reto Cero Desperdicio', description: 'Cocina 5 recetas aprovechando sobras', icon: '♻️', category: 'reto', points: 100, unlocked: false },
  { id: 147, name: 'Reto Internacional', description: 'Cocina recetas de 10 paises en un mes', icon: '✈️', category: 'reto', points: 200, unlocked: false },
  { id: 148, name: 'Reto Express', description: 'Cocina 10 recetas de menos de 15 min', icon: '⏱️', category: 'reto', points: 120, unlocked: false },
  { id: 149, name: 'Masterclass Completa', description: 'Completa todas las masterclass disponibles', icon: '🎓', category: 'reto', points: 400, unlocked: false },
  { id: 150, name: 'Leyenda CocinaViva', description: 'Alcanza el nivel maximo en la plataforma', icon: '🌟', category: 'especial', points: 10000, unlocked: false },
  // 20 LOGROS DE FIDELIDAD (151-170)
  { id: 151, name: 'Primer Dia', description: 'Te registraste en CocinaViva. Bienvenido a la comunidad', icon: '🎉', category: 'tiempo', points: 5, unlocked: true },
  { id: 152, name: 'Fiel 3 Dias', description: 'Has vuelto a CocinaViva durante 3 dias consecutivos', icon: '📱', category: 'tiempo', points: 15, unlocked: false },
  { id: 153, name: 'Fiel 1 Semana', description: 'Llevas 7 dias consecutivos usando CocinaViva', icon: '🗓️', category: 'tiempo', points: 30, unlocked: false },
  { id: 154, name: 'Habitual 2 Semanas', description: '14 dias seguidos cocinando con CocinaViva', icon: '💪', category: 'tiempo', points: 60, unlocked: false },
  { id: 155, name: 'Fiel 1 Mes', description: 'Un mes completo siendo fiel a CocinaViva', icon: '🏅', category: 'tiempo', points: 120, unlocked: false },
  { id: 156, name: 'Devoto 2 Meses', description: '60 dias de uso continuado de la app', icon: '🔥', category: 'tiempo', points: 200, unlocked: false },
  { id: 157, name: 'Leal 3 Meses', description: 'Trimestre completo de fidelidad a CocinaViva', icon: '💎', category: 'tiempo', points: 350, unlocked: false },
  { id: 158, name: 'Fiel Medio Año', description: '6 meses ininterrumpidos usando CocinaViva', icon: '👑', category: 'tiempo', points: 600, unlocked: false },
  { id: 159, name: 'Veterano 1 Año', description: 'Un ano entero siendo parte de la familia CocinaViva', icon: '🏆', category: 'tiempo', points: 1200, unlocked: false },
  { id: 160, name: 'Leyenda de Fidelidad', description: '2 anos de fidelidad absoluta a CocinaViva', icon: '🌟', category: 'tiempo', points: 2500, unlocked: false },
  { id: 161, name: 'Regreso Triunfal', description: 'Volviste a CocinaViva despues de una pausa', icon: '🔄', category: 'tiempo', points: 25, unlocked: false },
  { id: 162, name: 'Amigo Recomendador', description: 'Un amigo que invitaste se registro en CocinaViva', icon: '🤝', category: 'social', points: 50, unlocked: false },
  { id: 163, name: 'Embajador de Fidelidad', description: 'Has invitado a 10 amigos que se registraron', icon: '🏵️', category: 'social', points: 250, unlocked: false },
  { id: 164, name: 'Suscriptor Leal', description: 'Mantuviste tu suscripcion premium 3 meses seguidos', icon: '💳', category: 'especial', points: 150, unlocked: false },
  { id: 165, name: 'Suscriptor Devoto', description: 'Mantuviste tu suscripcion premium 6 meses', icon: '💰', category: 'especial', points: 300, unlocked: false },
  { id: 166, name: 'Suscriptor Anual', description: 'Un ano entero de suscripcion premium activa', icon: '🎖️', category: 'especial', points: 600, unlocked: false },
  { id: 167, name: 'Feedback Valioso', description: 'Enviaste 5 sugerencias de mejora a CocinaViva', icon: '💡', category: 'social', points: 75, unlocked: false },
  { id: 168, name: 'Reportero de Bugs', description: 'Reportaste 3 errores que fueron corregidos', icon: '🐛', category: 'especial', points: 100, unlocked: false },
  { id: 169, name: 'Primer Aniversario', description: 'Celebra tu primer aniversario en CocinaViva', icon: '🎂', category: 'tiempo', points: 500, unlocked: false },
  { id: 170, name: 'Cocinero de por Vida', description: 'Has completado mas de 500 recetas y llevas mas de 1 ano. Eres CocinaViva', icon: '♾️', category: 'especial', points: 5000, unlocked: false },
  // 30 NUEVOS LOGROS (171-200) - v1.0.2
  { id: 171, name: 'Chef de Primavera', description: 'Cocina 10 recetas primaverales', icon: '🌸', category: 'tiempo', points: 50, unlocked: false },
  { id: 172, name: 'Chef de Verano', description: 'Cocina 10 recetas veraniegas', icon: '☀️', category: 'tiempo', points: 50, unlocked: false },
  { id: 173, name: 'Chef de Otoño', description: 'Cocina 10 recetas otoñales', icon: '🍂', category: 'tiempo', points: 50, unlocked: false },
  { id: 174, name: 'Chef de Invierno', description: 'Cocina 10 recetas invernales', icon: '❄️', category: 'tiempo', points: 50, unlocked: false },
  { id: 175, name: 'Amante del Ajo', description: 'Usa ajo en 20 recetas diferentes', icon: '🧄', category: 'cocina', points: 40, unlocked: false },
  { id: 176, name: 'Locura Picante', description: 'Cocina 15 recetas muy picantes', icon: '🌶️', category: 'cocina', points: 60, unlocked: false },
  { id: 177, name: 'Maestro Salsero', description: 'Prepara 15 tipos de salsas desde cero', icon: '🥣', category: 'maestria', points: 80, unlocked: false },
  { id: 178, name: 'Asador Perfecto', description: 'Domina 10 recetas a la parrilla o asado', icon: '🔥', category: 'maestria', points: 90, unlocked: false },
  { id: 179, name: 'Cero Desperdicio Pro', description: 'Guarda 20 recetas de aprovechamiento', icon: '♻️', category: 'coleccion', points: 70, unlocked: false },
  { id: 180, name: 'El Rey del Tupper', description: 'Prepara 15 recetas ideales para llevar', icon: '🍱', category: 'exploracion', points: 55, unlocked: false },
  { id: 181, name: 'Snack Master', description: 'Prepara 10 snacks o aperitivos', icon: '🥨', category: 'exploracion', points: 45, unlocked: false },
  { id: 182, name: 'Cena Romántica', description: 'Prepara un menú completo para dos', icon: '💝', category: 'especial', points: 100, unlocked: false },
  { id: 183, name: 'Chef de Multitudes', description: 'Cocina una receta para 10+ personas', icon: '🥘', category: 'especial', points: 80, unlocked: false },
  { id: 184, name: 'Velocidad de la Luz', description: 'Cocina 5 recetas en menos de 10 min', icon: '⚡', category: 'tiempo', points: 75, unlocked: false },
  { id: 185, name: 'Paciencia Infinita', description: 'Cocina una receta que tarde más de 4h', icon: '⏳', category: 'tiempo', points: 90, unlocked: false },
  { id: 186, name: 'Reseña de Oro', description: 'Una de tus valoraciones recibe 50 likes', icon: '👍', category: 'social', points: 120, unlocked: false },
  { id: 187, name: 'Crítico Experto', description: 'Escribe 50 reseñas detalladas', icon: '📝', category: 'social', points: 150, unlocked: false },
  { id: 188, name: 'Coleccionista Pro', description: 'Crea 20 colecciones diferentes', icon: '📚', category: 'coleccion', points: 100, unlocked: false },
  { id: 189, name: 'Lector Empedernido', description: 'Lee 100 recetas sin cocinarlas', icon: '📖', category: 'exploracion', points: 30, unlocked: false },
  { id: 190, name: 'Curioso Culinario', description: 'Busca 50 ingredientes diferentes', icon: '🔍', category: 'exploracion', points: 40, unlocked: false },
  { id: 191, name: 'Amasado Perfecto', description: 'Amasa 10 veces a mano o robot', icon: '👐', category: 'maestria', points: 60, unlocked: false },
  { id: 192, name: 'Técnica Sous-Vide', description: 'Cocina 5 recetas a baja temperatura', icon: '🌡️', category: 'maestria', points: 150, unlocked: false },
  { id: 193, name: 'Thermomix Hacker', description: 'Modifica una receta oficial Thermomix', icon: '🤖', category: 'thermomix', points: 80, unlocked: false },
  { id: 194, name: 'Batido Perfecto', description: 'Crea 15 smoothies o batidos diferentes', icon: '🥤', category: 'exploracion', points: 45, unlocked: false },
  { id: 195, name: 'Chef Sin Fronteras', description: 'Prueba recetas de 5 continentes', icon: '🌍', category: 'maestria', points: 200, unlocked: false },
  { id: 196, name: 'Reto Sin Azúcar', description: 'Prepara 10 postres sin azúcar añadido', icon: '🚫', category: 'reto', points: 100, unlocked: false },
  { id: 197, name: 'Reto Keto', description: 'Prepara 10 recetas cetogénicas', icon: '🥑', category: 'reto', points: 90, unlocked: false },
  { id: 198, name: 'Cocinero de Madrugada', description: 'Cocina 5 veces entre las 2 AM y 5 AM', icon: '🦉', category: 'tiempo', points: 85, unlocked: false },
  { id: 199, name: 'Cocinero VIP', description: 'Completa 50 recetas exclusivas Premium', icon: '💎', category: 'especial', points: 300, unlocked: false },
  { id: 200, name: 'Dios de la Cocina', description: 'Alcanza el nivel supremo con 200 logros', icon: '👑', category: 'especial', points: 10000, unlocked: false },

  // 50 NUEVOS LOGROS (201-250)
  { id: 201, name: 'Recetario Ambulante', description: 'Accede a tus recetas sin conexión 5 veces', icon: '📱', category: 'coleccion', points: 50, unlocked: false },
  { id: 202, name: 'Batería Inagotable', description: 'Cocina con el móvil a menos del 10%', icon: '🔋', category: 'tiempo', points: 40, unlocked: false },
  { id: 203, name: 'Ahorro Máximo', description: 'Usa recetas en modo bajo consumo', icon: '📉', category: 'tiempo', points: 30, unlocked: false },
  { id: 204, name: 'Dedo Veloz', description: 'Termina un paso en menos de 5 segundos', icon: '👆', category: 'tiempo', points: 20, unlocked: false },
  { id: 205, name: 'Lector Compulsivo', description: 'Revisa todos los ingredientes antes de empezar', icon: '🧐', category: 'exploracion', points: 25, unlocked: false },
  { id: 206, name: 'Mano Derecha', description: 'Añade un compañero frecuente en tu perfil', icon: '🤝', category: 'social', points: 15, unlocked: false },
  { id: 207, name: 'Especialista Supremo', description: 'Define tu especialidad culinaria', icon: '🌟', category: 'social', points: 20, unlocked: false },
  { id: 208, name: 'Amor Fraternal', description: 'Etiqueta a un amigo en una receta', icon: '👥', category: 'social', points: 30, unlocked: false },
  { id: 209, name: 'Buscador Experto', description: 'Filtra resultados 50 veces', icon: '🔍', category: 'exploracion', points: 40, unlocked: false },
  { id: 210, name: 'Comprador Preciso', description: 'Tacha todos los items de tu lista de la compra', icon: '🛒', category: 'exploracion', points: 50, unlocked: false },
  { id: 211, name: 'Mago del Hielo', description: 'Prepara 10 recetas congeladas', icon: '🧊', category: 'maestria', points: 60, unlocked: false },
  { id: 212, name: 'Alquimista Culinario', description: 'Combina ingredientes extraños', icon: '🧪', category: 'maestria', points: 70, unlocked: false },
  { id: 213, name: 'Domador del Fuego', description: 'No quemes el asado (10 asados perfectos)', icon: '🔥', category: 'maestria', points: 80, unlocked: false },
  { id: 214, name: 'Ninja Cortador', description: 'Anota tus tiempos de corte', icon: '🔪', category: 'maestria', points: 90, unlocked: false },
  { id: 215, name: 'Cero Estrés', description: 'Usa temporizadores para todos los pasos', icon: '🧘', category: 'tiempo', points: 100, unlocked: false },
  { id: 216, name: 'Organizador Compulsivo', description: 'Ordena tu semana 4 veces seguidas', icon: '📅', category: 'tiempo', points: 110, unlocked: false },
  { id: 217, name: 'Gurú de la Nutrición', description: 'Cumple tus macros 7 días seguidos', icon: '💪', category: 'reto', points: 120, unlocked: false },
  { id: 218, name: 'Fotógrafo Profesional', description: 'Sube 50 cooksnaps a recetas', icon: '📸', category: 'social', points: 130, unlocked: false },
  { id: 219, name: 'Director de Cine', description: 'Transmite en Chromecast 10 veces', icon: '📺', category: 'especial', points: 140, unlocked: false },
  { id: 220, name: 'Voz de Mando', description: 'Controla la receta por voz 20 veces', icon: '🗣️', category: 'especial', points: 150, unlocked: false },
  { id: 221, name: 'Crítico Cinematográfico', description: 'Haz 5 reviews detalladas (200+ palabras)', icon: '📝', category: 'social', points: 160, unlocked: false },
  { id: 222, name: 'Puntualidad Británica', description: 'La receta dura exactamente el tiempo estipulado', icon: '⏳', category: 'tiempo', points: 170, unlocked: false },
  { id: 223, name: 'Sin Miedo al Éxito', description: 'Afronta tu primera receta Difícil', icon: '🧗', category: 'reto', points: 180, unlocked: false },
  { id: 224, name: 'Con las Manos en la Masa', description: 'Amasa 20 tipos de pan diferentes', icon: '🥖', category: 'maestria', points: 190, unlocked: false },
  { id: 225, name: 'Chef Modernista', description: 'Prueba la cocina molecular o técnicas nuevas', icon: '🔬', category: 'maestria', points: 200, unlocked: false },
  { id: 226, name: 'Ahorro Familiar', description: 'Prepara comidas para toda la familia', icon: '👨‍👩‍👧‍👦', category: 'especial', points: 50, unlocked: false },
  { id: 227, name: 'Desayuno de Campeones', description: '30 días de desayunos perfectos', icon: '🥞', category: 'tiempo', points: 100, unlocked: false },
  { id: 228, name: 'Brunch Master', description: 'Organiza el brunch del domingo', icon: '🥓', category: 'social', points: 150, unlocked: false },
  { id: 229, name: 'Cena a Ciegas', description: 'Deja que la IA elija tu menú', icon: '🎲', category: 'especial', points: 200, unlocked: false },
  { id: 230, name: 'Nervios de Acero', description: 'Cocina un soufflé sin que se baje', icon: '🧁', category: 'maestria', points: 250, unlocked: false },
  { id: 231, name: 'Llorando con Cebollas', description: 'Usa cebolla en 50 recetas', icon: '🧅', category: 'cocina', points: 50, unlocked: false },
  { id: 232, name: 'Tarta Perfecta', description: 'Decora una tarta de cumpleaños', icon: '🎂', category: 'cocina', points: 100, unlocked: false },
  { id: 233, name: 'Sopa de Letras', description: 'Busca todas las letras en ingredientes', icon: '🔠', category: 'exploracion', points: 150, unlocked: false },
  { id: 234, name: 'Cocina de Época', description: 'Busca platos antiguos (siglo XIX o anterior)', icon: '🕰️', category: 'exploracion', points: 200, unlocked: false },
  { id: 235, name: 'Turista Gastronómico', description: 'Valora recetas de 20 países', icon: '🛫', category: 'exploracion', points: 250, unlocked: false },
  { id: 236, name: 'Realeza del Chocolate', description: '10 postres distintos con chocolate', icon: '🍫', category: 'maestria', points: 300, unlocked: false },
  { id: 237, name: 'Locura por el Queso', description: '20 recetas con mucho queso fundido', icon: '🧀', category: 'maestria', points: 350, unlocked: false },
  { id: 238, name: 'En el Punto Exacto', description: 'Carne hecha a la perfección (técnica sellado)', icon: '🥩', category: 'maestria', points: 400, unlocked: false },
  { id: 239, name: 'Revuelta de Sartenes', description: 'Saltea a fuego vivo como un profesional', icon: '🔥', category: 'maestria', points: 450, unlocked: false },
  { id: 240, name: 'Embajador Ultra', description: 'Mantén la suscripción Ultra 1 año', icon: '⭐', category: 'especial', points: 500, unlocked: false },
  { id: 241, name: 'Miembro Vitalicio', description: '2 años de suscripción activa', icon: '💎', category: 'especial', points: 1000, unlocked: false },
  { id: 242, name: 'Experto en Nutrición', description: 'Planificador balanceado por 3 meses', icon: '⚖️', category: 'reto', points: 1500, unlocked: false },
  { id: 243, name: 'Ojo de Halcón', description: 'Detecta un bug y repórtalo', icon: '👁️', category: 'especial', points: 2000, unlocked: false },
  { id: 244, name: 'Maestro Enológico', description: 'Añade el mejor vino a cada plato', icon: '🍷', category: 'maestria', points: 2500, unlocked: false },
  { id: 245, name: 'Poder del Teclado', description: 'Navega en modo Smart TV 50 horas', icon: '⌨️', category: 'tiempo', points: 3000, unlocked: false },
  { id: 246, name: 'Reseñador Legendario', description: '100 reseñas con texto y estrellas', icon: '🌟', category: 'social', points: 4000, unlocked: false },
  { id: 247, name: 'Corazón Abierto', description: '1000 recetas en favoritos', icon: '❤️', category: 'coleccion', points: 5000, unlocked: false },
  { id: 248, name: 'La Máquina Perfecta', description: 'Más de 1000 recetas Thermomix completadas', icon: '⚙️', category: 'thermomix', points: 6000, unlocked: false },
  { id: 249, name: 'Creador Infinito', description: 'Sube 50 recetas originales', icon: '✨', category: 'social', points: 7000, unlocked: false },
  { id: 250, name: 'Gran Maestro CocinaViva', description: 'Desbloquea los 250 logros del sistema', icon: '👑', category: 'especial', points: 15000, unlocked: false },
];

export const achievementCategories = [
  { key: 'recetas', label: 'Recetas', icon: '🍳' },
  { key: 'cocina', label: 'Cocina', icon: '👨‍🍳' },
  { key: 'social', label: 'Social', icon: '👥' },
  { key: 'exploracion', label: 'Exploracion', icon: '🧭' },
  { key: 'maestria', label: 'Maestria', icon: '🏆' },
  { key: 'thermomix', label: 'Thermomix', icon: '🤖' },
  { key: 'coleccion', label: 'Coleccion', icon: '📚' },
  { key: 'tiempo', label: 'Tiempo', icon: '⏰' },
  { key: 'especial', label: 'Especial', icon: '⭐' },
  { key: 'reto', label: 'Retos', icon: '🎯' },
];
