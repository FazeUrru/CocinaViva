import { Menu, X, Search } from 'lucide-react';
import { useState } from 'react';
import { Logo } from './Logo';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

const navItems = [
  { key: 'home', label: 'Inicio' },
  { key: 'recipes', label: 'Recetas' },
  { key: 'categories', label: 'Categorías' },
  { key: 'features', label: 'Funciones' },
  { key: 'plans', label: 'Planes' },
  { key: 'settings', label: 'Ajustes' },
  { key: 'about', label: 'Acerca de' },
];

export function Header({ currentPage, onNavigate, searchQuery, onSearchChange }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-3">
        <div className="flex items-center justify-between h-12">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <Logo size={28} />
            <div className="hidden sm:block">
              <h1 className="text-base font-black text-gray-900 tracking-tight leading-none">CocinaViva<span className="text-orange-500">.com</span></h1>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-[8px] bg-gradient-to-r from-green-500 to-emerald-600 text-white px-1.5 py-0.5 rounded-full font-bold">v2.0.0</span>
                <span className="text-[7px] bg-gray-800 text-white px-1 py-0.5 rounded font-bold">OPEN SOURCE (MIT)</span>
              </div>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-0.5">
            {navItems.map(item => (
              <button
                key={item.key}
                onClick={() => onNavigate(item.key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentPage === item.key
                    ? 'bg-orange-100 text-orange-700'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Quick Access Buttons - 5 Nuevos Destacados + 2 Nuevos */}
          <div className="hidden lg:flex items-center gap-2 border-l border-gray-200 ml-4 pl-4 overflow-x-auto hide-scrollbar whitespace-nowrap max-w-[600px] xl:max-w-none">
            <button onClick={() => onNavigate('settings')} className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">❤️</span> Mis Favoritos
            </button>
            <button onClick={() => onNavigate('features')} className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">⚡</span> Funciones
            </button>
            <button onClick={() => onNavigate('features')} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">📅</span> Planificador
            </button>
            <button onClick={() => onNavigate('features')} className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 hover:bg-green-100 text-green-700 border border-green-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">🛒</span> Mi Compra
            </button>
            <button onClick={() => onNavigate('settings')} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">🏆</span> Mis Logros
            </button>
            <button onClick={() => onNavigate('settings')} className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">💡</span> Sugerir
            </button>
            <button onClick={() => onNavigate('settings')} className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 rounded-full text-[11px] font-bold transition-colors shadow-sm">
              <span className="text-[12px]">📤</span> Compartir
            </button>
          </div>

          {/* Search & Mobile Toggle */}
          <div className="flex items-center gap-1">
            {searchOpen && (
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => onSearchChange(e.target.value)}
                  placeholder="Buscar recetas..."
                  className="w-36 md:w-52 pl-2 pr-6 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent"
                  autoFocus
                />
                <button onClick={() => { setSearchOpen(false); onSearchChange(''); }} className="absolute right-2 top-1/2 -translate-y-1/2">
                  <X className="w-3 h-3 text-gray-400" />
                </button>
              </div>
            )}
            <button
              onClick={() => { setSearchOpen(!searchOpen); if (searchOpen) onSearchChange(''); }}
              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <Search className="w-4 h-4 text-gray-600" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-3 border-t border-gray-100 mt-1 pt-1">
            {navItems.map(item => (
              <button
                key={item.key}
                onClick={() => { onNavigate(item.key); setMobileMenuOpen(false); }}
                className={`block w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  currentPage === item.key
                    ? 'bg-orange-100 text-orange-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
