export interface Recipe {
  id: number;
  name: string;
  category: string;
  type: 'tradicional' | 'thermomix';
  difficulty: 'Fácil' | 'Media' | 'Difícil';
  time: string;
  servings: number;
  ingredients: string[];
  steps: string[];
  image: string;
  rating: number;
  calories: number;
  region?: string;
  tags: string[];
}

export const categories = [
  'Entrantes', 'Sopas y Cremas', 'Ensaladas', 'Arroces', 'Pastas',
  'Carnes', 'Pescados', 'Mariscos', 'Verduras', 'Legumbres',
  'Guisos', 'Postres', 'Repostería', 'Pan y Masas', 'Salsas',
  'Bebidas', 'Tapas', 'Desayunos', 'Cenas Ligeras', 'Especial Fiestas'
];

const regions = [
  'Andalucía', 'Cataluña', 'País Vasco', 'Galicia', 'Castilla y León',
  'Valencia', 'Asturias', 'Aragón', 'Extremadura', 'Murcia',
  'Navarra', 'La Rioja', 'Cantabria', 'Canarias', 'Baleares',
  'Madrid', 'Castilla-La Mancha', 'Internacional', 'Mediterránea', 'Latinoamérica'
];

const tagOptions = [
  'sin gluten', 'vegano', 'vegetariano', 'bajo en calorías', 'alto en proteínas',
  'rápido', 'económico', 'festivo', 'infantil', 'gourmet',
  'picante', 'dulce', 'salado', 'frío', 'caliente',
  'horno', 'fritura', 'vapor', 'plancha', 'crudo'
];

const recipeNames: Record<string, string[]> = {
  'Entrantes': [
    'Croquetas de Jamón Ibérico', 'Patatas Bravas Madrileñas', 'Gambas al Ajillo', 'Pimientos de Padrón',
    'Tortilla Española Clásica', 'Gazpacho Andaluz', 'Salmorejo Cordobés', 'Empanadas Gallegas',
    'Montaditos de Solomillo', 'Boquerones en Vinagre', 'Pulpo a la Gallega', 'Mejillones en Escabeche',
    'Huevos Rotos con Jamón', 'Pinchos Morunos', 'Calamares a la Romana', 'Champiñones al Ajillo',
    'Tostas de Tomate y Jamón', 'Banderillas Picantes', 'Chopitos Fritos', 'Alcachofas Fritas',
    'Croquetas de Bacalao', 'Empanadillas de Atún', 'Rollitos de Primavera', 'Bruschettas Mediterráneas',
    'Hummus Casero', 'Guacamole Tradicional', 'Nachos con Queso', 'Tabla de Quesos Españoles',
    'Jamón Ibérico con Pan Tomaca', 'Anchoas del Cantábrico'
  ],
  'Sopas y Cremas': [
    'Sopa Castellana', 'Crema de Calabaza', 'Sopa de Cebolla Gratinada', 'Crema de Espárragos',
    'Caldo Gallego', 'Sopa de Ajo', 'Crema de Zanahoria y Jengibre', 'Vichyssoise',
    'Sopa de Pescado', 'Crema de Champiñones', 'Sopa Juliana', 'Crema de Puerros',
    'Sopa de Tomate', 'Crema de Calabacín', 'Consomé al Jerez', 'Sopa de Marisco',
    'Crema de Lentejas', 'Sopa Minestrone', 'Crema de Guisantes', 'Sopa de Fideos',
    'Ajoblanco Malagueño', 'Crema de Brócoli', 'Sopa Thai de Coco', 'Crema de Remolacha',
    'Sopa de Pollo con Verduras', 'Crema de Alcachofas', 'Gazpacho de Sandía', 'Sopa Miso',
    'Crema de Coliflor', 'Sopa de Garbanzos'
  ],
  'Ensaladas': [
    'Ensalada Mixta Española', 'Ensalada César', 'Ensaladilla Rusa', 'Ensalada de Pulpo',
    'Ensalada Caprese', 'Ensalada Waldorf', 'Ensalada Griega', 'Ensalada de Pasta',
    'Ensalada Templada de Salmón', 'Ensalada de Quinoa', 'Ensalada de Garbanzos',
    'Ensalada Tropical', 'Pipirrana Jaenera', 'Ensalada de Tomate Rosa', 'Ensalada Nórdica',
    'Xató Catalán', 'Ensalada de Burrata', 'Ensalada de Espinacas y Frutos Secos',
    'Esqueixada de Bacalao', 'Ensalada Murciana', 'Ensalada de Ventresca',
    'Ensalada de Canónigos y Queso de Cabra', 'Ensalada de Arroz', 'Ensalada de Lentejas',
    'Ensalada Campera', 'Ensalada de Mango y Aguacate', 'Tabulé',
    'Ensalada de Remolacha y Nueces', 'Ensalada de Endivias', 'Poke Bowl Mediterráneo'
  ],
  'Arroces': [
    'Paella Valenciana', 'Arroz Negro', 'Arroz al Horno', 'Arroz con Bogavante',
    'Arroz a Banda', 'Arroz Caldoso de Marisco', 'Arroz con Pollo', 'Risotto de Setas',
    'Arroz con Leche Asturiano', 'Arroz a la Cubana', 'Fideuá', 'Arroz con Verduras',
    'Arroz Meloso de Gambas', 'Paella de Mariscos', 'Arroz con Costillas', 'Risotto de Calabaza',
    'Arroz Tres Delicias', 'Arroz con Bacalao', 'Arroz Brut Mallorquín', 'Arroz con Rape',
    'Paella Mixta', 'Arroz con Conejo', 'Risotto de Espárragos', 'Arroz del Senyoret',
    'Arroz con Pato', 'Arroz con Almejas', 'Arroz Empedrado', 'Arroz con Setas',
    'Arroz con Costra Alicantino', 'Arroz Caldoso de Pulpo'
  ],
  'Pastas': [
    'Espaguetis a la Carbonara', 'Macarrones con Chorizo', 'Lasaña de Carne',
    'Canelones de Espinacas', 'Pasta Boloñesa', 'Fetuccini Alfredo', 'Penne al Pesto',
    'Ravioli de Ricotta', 'Espaguetis con Almejas', 'Pasta Putanesca',
    'Tallarines con Gambas', 'Macarrones con Tomate', 'Lasaña de Verduras',
    'Pasta al Salmón', 'Ñoquis de Patata', 'Tortellini en Caldo', 'Pasta Aglio e Olio',
    'Canelones de Carne', 'Pasta con Atún', 'Espaguetis con Mejillones',
    'Pasta Arrabiata', 'Macarrones Gratinados', 'Pasta Primavera', 'Fideos a la Cazuela',
    'Pasta con Setas y Trufa', 'Lasaña de Marisco', 'Pasta con Pesto Rojo',
    'Espaguetis a la Marinera', 'Pasta con Berenjena', 'Rigatoni al Ragú'
  ],
  'Carnes': [
    'Cochinillo Asado Segoviano', 'Rabo de Toro', 'Chuletón a la Brasa', 'Pollo al Ajillo',
    'Cordero Asado al Horno', 'Carrilleras de Cerdo', 'Escalope Milanesa', 'Albóndigas en Salsa',
    'Solomillo al Pedro Ximénez', 'Pollo a la Pepitoria', 'Estofado de Ternera',
    'Chuletas de Cordero a la Plancha', 'Magret de Pato', 'Costillas BBQ', 'Secreto Ibérico',
    'Redondo de Ternera', 'Pollo al Curry', 'Carne Guisada', 'Escalopines al Marsala',
    'Cerdo a la Naranja', 'Hamburguesa Gourmet', 'Codillo Asado', 'Ternera en Salsa',
    'Pollo Tikka Masala', 'Filete de Ternera al Roquefort', 'Pechuga Rellena',
    'Costillas al Horno con Miel', 'Entrecot con Salsa Pimienta', 'Callos a la Madrileña',
    'Manitas de Cerdo', 'Conejo al Romero', 'Perdiz en Escabeche', 'Venado en Salsa',
    'Jabalí Estofado', 'Codornices con Uvas'
  ],
  'Pescados': [
    'Bacalao al Pil-Pil', 'Merluza a la Vasca', 'Lubina a la Sal', 'Dorada al Horno',
    'Atún Encebollado', 'Rape a la Marinera', 'Salmón al Horno con Limón', 'Trucha a la Navarra',
    'Bacalao a la Vizcaína', 'Sardinas Asadas', 'Besugo al Horno', 'Rodaballo a la Plancha',
    'Merluza en Salsa Verde', 'Lenguado a la Meunière', 'Pez Espada a la Plancha',
    'Bacalao con Tomate', 'Salmón en Papillote', 'Corvina al Horno', 'Mero a la Gallega',
    'Bonito con Tomate', 'Pescadilla en Salsa', 'Rape Alangostado', 'Bacalao Dorado',
    'Emperador al Ajillo', 'Pescado Frito Andaluz', 'Salmón Teriyaki', 'Lomo de Bacalao Confitado',
    'Brochetas de Pez Espada', 'Papillote de Lubina', 'Ceviche de Corvina'
  ],
  'Mariscos': [
    'Langostinos a la Plancha', 'Gambas al Pil-Pil', 'Mejillones al Vapor', 'Almejas a la Marinera',
    'Navajas a la Plancha', 'Cigalas al Horno', 'Bogavante a la Plancha', 'Percebes al Natural',
    'Zamburiñas Gratinadas', 'Vieiras a la Gallega', 'Centollo al Horno', 'Nécoras Cocidas',
    'Langosta a la Americana', 'Buey de Mar Cocido', 'Carabineros al Ajillo',
    'Gambas Rojas de Huelva', 'Berberechos al Vapor', 'Ostras al Natural',
    'Cangrejos de Río', 'Pulpo a la Brasa', 'Sepia a la Plancha', 'Chipirón en su Tinta',
    'Calamares Rellenos', 'Salpicón de Marisco', 'Zarzuela de Marisco',
    'Mariscada Gallega', 'Parrillada de Marisco', 'Cóctel de Gambas',
    'Brochetas de Langostinos', 'Tartar de Gamba Roja'
  ],
  'Verduras': [
    'Pisto Manchego', 'Tumbet Mallorquín', 'Escalivada Catalana', 'Espárragos a la Plancha',
    'Menestra de Verduras', 'Samfaina', 'Pimientos Rellenos', 'Berenjenas Rellenas',
    'Calabacines Rellenos', 'Alcachofas a la Plancha', 'Judías Verdes con Jamón',
    'Espinacas a la Catalana', 'Coliflor Gratinada', 'Champiñones Rellenos', 'Borraja con Patatas',
    'Cardos con Almendras', 'Acelgas Rehogadas', 'Cardo en Salsa de Almendras',
    'Brócoli al Vapor con Alioli', 'Verduras al Horno', 'Ratatouille', 'Tempura de Verduras',
    'Wok de Verduras', 'Parrillada de Verduras', 'Verduras en Escabeche',
    'Pimientos Asados', 'Tomates Rellenos', 'Patatas Revolconas', 'Patatas a la Importancia',
    'Patatas a lo Pobre'
  ],
  'Legumbres': [
    'Cocido Madrileño', 'Fabada Asturiana', 'Lentejas con Chorizo', 'Garbanzos con Espinacas',
    'Alubias de Tolosa', 'Potaje de Vigilia', 'Judiones de la Granja', 'Pochas con Almejas',
    'Lentejas Estofadas', 'Garbanzos con Bacalao', 'Marmitako', 'Potaje de Garbanzos',
    'Fabes con Almejas', 'Lentejas con Verduras', 'Garbanzos con Callos',
    'Alubias con Oreja', 'Habas a la Catalana', 'Pote Asturiano', 'Olla Podrida',
    'Michirones Murcianos', 'Rancho Canario', 'Garbanzos Fritos', 'Lentejas Pardinas',
    'Judías con Chorizo', 'Escudella i Carn d\'Olla', 'Potaje Canario',
    'Fabada de Marisco', 'Lentejas al Curry', 'Hummus de Garbanzos', 'Dal de Lentejas Rojas'
  ],
  'Guisos': [
    'Estofado de Ternera con Patatas', 'Guiso de Pollo con Verduras', 'Suquet de Peix',
    'Caldereta de Cordero', 'Guiso Marinero', 'Fricandó Catalán', 'Caldereta Extremeña',
    'Guiso de Patatas con Costillas', 'Caldereta de Langosta', 'Guiso de Judías con Chorizo',
    'Estofado de Cerdo', 'Guiso de Sepia con Patatas', 'Caldereta de Cabrito',
    'Guiso de Garbanzos con Bacalao', 'Marmitako Vasco', 'Guiso de Rape con Almejas',
    'Caldereta de Verduras', 'Estofado de Buey', 'Guiso de Pollo al Chilindrón',
    'Chanfaina Salmantina', 'Pepitoria de Gallina', 'Guiso Castellano',
    'Caldereta Menorquina', 'Ragú de Jabalí', 'Estofado Irlandés',
    'Guiso de Lentejas con Perdiz', 'Guisado de Rabo', 'Caldereta de Pescador',
    'Estofado Provenzal', 'Cazuela de Patatas a la Riojana'
  ],
  'Postres': [
    'Crema Catalana', 'Flan de Huevo', 'Natillas Caseras', 'Arroz con Leche',
    'Tarta de Santiago', 'Leche Frita', 'Torrijas', 'Churros con Chocolate',
    'Filloas Gallegas', 'Buñuelos de Viento', 'Pestiños Andaluces', 'Rosquillas de San Isidro',
    'Quesada Pasiega', 'Pantxineta Vasca', 'Tocinillo de Cielo', 'Bienmesabe Canario',
    'Miguelitos de la Roda', 'Sobaos Pasiegos', 'Ensaimada Mallorquína', 'Tarta de Queso Vasca',
    'Coulant de Chocolate', 'Tiramisú', 'Panna Cotta', 'Mousse de Chocolate',
    'Tarta de Manzana', 'Profiteroles', 'Crème Brûlée', 'Helado de Vainilla Casero',
    'Sorbete de Limón', 'Fresas con Nata', 'Tarta de Tres Chocolates', 'Flan de Coco',
    'Arroz con Leche Cremoso', 'Bizcocho de Chocolate Fundido', 'Mousse de Limón',
    'Tarta de Almendras', 'Crema Pastelera', 'Natillas de Chocolate', 'Flan de Café',
    'Postre de Queso con Frutos Rojos', 'Pannacotta de Vainilla', 'Coulant de Caramelo',
    'Tarta Helada de Turrón', 'Cremoso de Mango', 'Mousse de Maracuyá', 'Sorbete de Fresa',
    'Helado de Dulce de Leche', 'Parfait de Café', 'Semifrío de Chocolate Blanco',
    'Tarta de Frutas del Bosque'
  ],
  'Repostería': [
    'Bizcocho de Yogur', 'Tarta de Chocolate', 'Galletas de Mantequilla', 'Magdalenas Caseras',
    'Brownie de Chocolate', 'Cheesecake New York', 'Carrot Cake', 'Red Velvet',
    'Cupcakes de Vainilla', 'Donuts Caseros', 'Palmeras de Hojaldre', 'Rosquillas Tontas y Listas',
    'Polvorones Caseros', 'Mantecados de Estepa', 'Alfajores', 'Macarons Franceses',
    'Tarta Tatín', 'Milhojas', 'Tarta de Fresas', 'Bizcocho de Limón',
    'Cookies de Chocolate', 'Muffins de Arándanos', 'Tartaletas de Frutas', 'Brazo de Gitano',
    'Roscón de Reyes', 'Panettone Casero', 'Strudel de Manzana', 'Eclairs de Chocolate',
    'Crêpes Suzette', 'Baklava'
  ],
  'Pan y Masas': [
    'Pan de Pueblo', 'Coca de San Juan', 'Empanada Gallega de Atún', 'Pan de Cristal',
    'Hogaza Castellana', 'Chapata Italiana', 'Pan de Centeno', 'Focaccia de Romero',
    'Baguette Francesa', 'Pan de Semillas', 'Pan de Molde Casero', 'Pan de Espelta',
    'Bollos Preñados', 'Pan de Ajo', 'Pita Casera', 'Naan Bread',
    'Pan de Maíz', 'Torta de Aceite', 'Pan Integral', 'Panecillos de Leche',
    'Masa de Pizza Casera', 'Masa de Empanada', 'Masa Quebrada', 'Hojaldre Casero',
    'Masa de Croissant', 'Pan Brioche', 'Bagels Caseros', 'Blinis',
    'Pan de Nueces', 'Tortas de Anís'
  ],
  'Salsas': [
    'Salsa de Tomate Casera', 'Alioli', 'Salsa Romesco', 'Salsa Brava',
    'Mojo Picón', 'Mojo Verde', 'Salsa Española', 'Salsa Bechamel',
    'Vinagreta Clásica', 'Pesto Genovés', 'Salsa Chimichurri', 'Salsa Barbacoa',
    'Salsa Vizcaína', 'Salsa Verde', 'Salsa de Pimientos del Piquillo',
    'Salsa de Cabrales', 'Salsa al Pedro Ximénez', 'Salsa de Setas',
    'Salsa de Almendras', 'Salsa Agridulce', 'Mayonesa Casera', 'Salsa Tártara',
    'Salsa César', 'Salsa Holandesa', 'Pesto Rojo', 'Salsa de Yogur',
    'Salsa Teriyaki Casera', 'Chutney de Mango', 'Salsa Sriracha Casera', 'Sofrito Base'
  ],
  'Bebidas': [
    'Sangría Española', 'Tinto de Verano', 'Agua de Valencia', 'Horchata Valenciana',
    'Granizado de Limón', 'Chocolate a la Taza', 'Café Bombón', 'Queimada Gallega',
    'Rebujito', 'Calimocho', 'Mojito Clásico', 'Piña Colada',
    'Smoothie de Frutas', 'Zumo de Naranja Natural', 'Limonada Casera', 'Batido de Chocolate',
    'Té Chai Latte', 'Café Irlandés', 'Gin Tonic Especial', 'Margarita',
    'Cóctel de Cava', 'Ponche Navideño', 'Sidra Caliente', 'Leche Merengada',
    'Granizado de Café', 'Batido de Fresas', 'Zumo Detox Verde', 'Infusión de Jengibre',
    'Chocolate Caliente con Especias', 'Limonada de Frutos Rojos'
  ],
  'Tapas': [
    'Patatas Alioli', 'Jamón Serrano con Pan', 'Queso Manchego con Membrillo',
    'Tortillitas de Camarones', 'Chipirones a la Andaluza', 'Puntillitas Fritas',
    'Migas Extremeñas', 'Gildas Vascas', 'Tigres (Mejillones Rellenos)', 'Oreja a la Plancha',
    'Morcilla de Burgos', 'Chorizo a la Sidra', 'Habas con Jamón', 'Revuelto de Ajetes',
    'Torreznos de Soria', 'Zarajos Conquenses', 'Flamenquines Cordobeses',
    'Berenjenas con Miel', 'Espetos de Sardinas', 'Mollejas al Ajillo',
    'Pintxo de Txistorra', 'Pintxo de Tortilla', 'Chistorra al Vino', 'Morcilla con Pimientos',
    'Sardinas en Aceite', 'Boquerones Fritos', 'Albóndigas de Sepia', 'Pimientos Rellenos de Bacalao',
    'Calamar a la Plancha', 'Pulpitos en Salsa'
  ],
  'Desayunos': [
    'Tostada con Tomate y Aceite', 'Churros con Chocolate', 'Porras Madrileñas',
    'Tortitas Americanas', 'Gachas Manchegas', 'Huevos Revueltos con Jamón',
    'Croissant de Mantequilla', 'Bowl de Açaí', 'Tostada de Aguacate',
    'Huevos Benedictinos', 'Tortilla Francesa', 'Pan con Tumaca',
    'Granola Casera', 'Overnight Oats', 'Smoothie Bowl', 'Crepes de Nutella',
    'Gofres Belgas', 'Muffins de Plátano', 'Bizcocho para Desayuno',
    'Tostada de Salmón Ahumado', 'Bocadillo de Tortilla', 'Huevos a la Flamenca',
    'Migas con Uvas', 'Pan con Chocolate', 'Bocadillo de Calamares',
    'Mollete con Manteca Colorá', 'Pincho de Tortilla', 'Tostada con Sobrasada y Miel',
    'Yogur con Frutas y Miel', 'Batido Energético de Avena'
  ],
  'Cenas Ligeras': [
    'Sopa de Verduras', 'Tortilla de Calabacín', 'Ensalada Templada', 'Revuelto de Setas',
    'Crema de Verduras', 'Merluza al Vapor', 'Pollo a la Plancha', 'Salmón con Verduras',
    'Wrap de Pollo', 'Bowl de Quinoa', 'Tosta de Hummus', 'Gazpacho Ligero',
    'Verduras Salteadas', 'Omelette Francesa', 'Sopa Miso con Tofu', 'Cuscús con Verduras',
    'Ensalada de Pollo', 'Rollitos de Pavo', 'Brochetas de Pollo', 'Hamburguesa de Pollo',
    'Pasta Integral con Verduras', 'Pescado al Papillote', 'Ensalada de Atún',
    'Crema de Calabacín Light', 'Pollo al Limón', 'Tortilla de Espárragos',
    'Revuelto de Espinacas', 'Sopa de Miso', 'Verduras al Wok', 'Pechugas de Pollo al Curry Ligero'
  ],
  'Especial Fiestas': [
    'Turrón de Jijona', 'Turrón de Alicante', 'Polvorones Navideños', 'Roscón de Reyes',
    'Cordero Asado Navideño', 'Besugo de Nochebuena', 'Sopa de Almendras', 'Lombarda Navideña',
    'Cochinillo de Nochevieja', 'Langostinos de Navidad', 'Canapés Festivos',
    'Hojaldre de Salmón', 'Corona de Navidad', 'Pavo Relleno', 'Compota de Manzana Navideña',
    'Mazapán Casero', 'Mantecados Artesanos', 'Panellets Catalanes', 'Huesos de Santo',
    'Buñuelos de Todos los Santos', 'Pestiños de Semana Santa', 'Monas de Pascua',
    'Torrijas de Semana Santa', 'Hornazo Salmantino', 'Mona de Chocolate',
    'Coca de Sant Joan', 'Roscos de Vino', 'Flores de Carnaval', 'Filloas de Carnaval',
    'Leche Frita de Semana Santa'
  ]
};

const ingredientSets: string[][] = [
  ['200g jamón ibérico', '500ml leche', '50g mantequilla', '50g harina', '2 huevos', 'pan rallado', 'aceite de oliva'],
  ['1kg patatas', 'aceite de oliva', '2 dientes de ajo', '1 cucharada pimentón', 'salsa brava', 'sal'],
  ['500g gambas', '6 dientes de ajo', 'guindilla', 'aceite de oliva virgen extra', 'perejil', 'sal'],
  ['400g pimientos de padrón', 'aceite de oliva', 'sal gruesa'],
  ['1 cochinillo de 4-5kg', 'manteca de cerdo', 'laurel', 'tomillo', 'sal', 'agua'],
  ['1kg rabo de toro', '2 zanahorias', '1 cebolla', 'vino tinto', 'tomate', 'pimentón'],
  ['6 yemas de huevo', '200g azúcar', '500ml leche', 'canela en rama', 'piel de limón', 'maizena'],
  ['6 huevos', '200g azúcar', '1L leche', 'vainilla', 'caramelo líquido'],
];

const stepSets = [
  ['Preparar todos los ingredientes y cortarlos según se indica.', 'Calentar aceite en una sartén a fuego medio-alto.', 'Sofreír los ingredientes principales hasta que estén dorados.', 'Añadir las especias y el condimento, remover bien.', 'Cocinar a fuego lento durante el tiempo indicado.', 'Rectificar de sal y pimienta.', 'Servir caliente con la guarnición elegida.'],
  ['Precalentar el horno a 180°C.', 'Mezclar los ingredientes secos en un bol grande.', 'Incorporar los ingredientes húmedos y mezclar hasta obtener una masa homogénea.', 'Verter en el molde previamente engrasado.', 'Hornear durante el tiempo indicado o hasta que un palillo salga limpio.', 'Dejar enfriar antes de desmoldar.', 'Decorar al gusto y servir.'],
  ['Lavar y pelar todas las verduras necesarias.', 'Cortar en trozos uniformes para una cocción pareja.', 'Rehogar la cebolla y el ajo hasta que estén transparentes.', 'Incorporar el resto de verduras y cocinar 10 minutos.', 'Añadir el caldo y dejar cocinar a fuego medio.', 'Triturar si se desea una textura más fina.', 'Servir con un chorrito de aceite de oliva virgen extra.'],
  ['Preparar la mise en place con todos los ingredientes medidos.', 'Marinar la proteína principal con las especias durante al menos 30 minutos.', 'Calentar el aceite en una cazuela amplia.', 'Sellar la carne/pescado a fuego fuerte.', 'Incorporar las verduras y el líquido de cocción.', 'Tapar y cocinar a fuego lento hasta que esté tierno.', 'Emplatar con cuidado y decorar con hierbas frescas.'],
];

function seededRandom(seed: number): number {
  const x = Math.sin(seed * 9301 + 49297) * 49297;
  return x - Math.floor(x);
}

// Función para generar imagen basada en el nombre de la receta
function getImageForRecipe(recipeName: string, seed: number): string {
  const cleanName = recipeName.toLowerCase()
    .replace(/\([^)]*\)/g, '')
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ñ/g, 'n');
  
  // Mapeo de términos clave para búsquedas específicas
  const keywordMap: Record<string, string> = {
    'croqueta': 'croquettes',
    'patata': 'potato',
    'gamba': 'shrimp',
    'pimiento': 'pepper',
    'tortilla': 'spanish-omelette',
    'gazpacho': 'cold-soup',
    'empanada': 'pie',
    'pulpo': 'octopus',
    'mejillon': 'mussels',
    'calamares': 'squid',
    'paella': 'paella',
    'arroz': 'rice',
    'pasta': 'pasta',
    'sopa': 'soup',
    'crema': 'cream-soup',
    'ensalada': 'salad',
    'cochinillo': 'roast-pig',
    'cordero': 'lamb',
    'pollo': 'chicken',
    'ternera': 'beef',
    'bacalao': 'cod-fish',
    'salmon': 'salmon',
    'merluza': 'hake',
    'flan': 'flan',
    'tarta': 'cake',
    'bizcocho': 'sponge-cake',
    'chocolate': 'chocolate',
    'pan': 'bread',
    'churros': 'churros'
  };

  let searchTerms: string[] = [];
  
  // Buscar términos clave en el nombre
  for (const [spanish, english] of Object.entries(keywordMap)) {
    if (cleanName.includes(spanish)) {
      searchTerms.push(english);
    }
  }
  
  // Si no hay términos específicos, usar el nombre limpio
  if (searchTerms.length === 0) {
    searchTerms.push(cleanName.replace(/\s+/g, '-'));
  }
  
  searchTerms.push('food', 'dish', 'cuisine');
  
  return `https://source.unsplash.com/400x300/?${searchTerms.join(',')}&sig=${seed}`;
}

function generateRecipes(): Recipe[] {
  const recipes: Recipe[] = [];
  let id = 1;
  let thermomixCount = 0;
  let thermomixPostresCount = 0;
  const TOTAL_THERMOMIX = 350;
  const THERMOMIX_POSTRES = 50;

  for (const category of categories) {
    const names = recipeNames[category] || [];

    for (let i = 0; i < names.length; i++) {
      const seed = id * 13 + i * 7;
      const rand = seededRandom(seed);
      
      let type: 'tradicional' | 'thermomix';
      if (category === 'Postres' && thermomixPostresCount < THERMOMIX_POSTRES) {
        type = 'thermomix';
        thermomixPostresCount++;
        thermomixCount++;
      } else if (category !== 'Postres' && thermomixCount < TOTAL_THERMOMIX - THERMOMIX_POSTRES && rand > 0.45) {
        type = 'thermomix';
        thermomixCount++;
      } else {
        type = 'tradicional';
      }

      const difficulties: ('Fácil' | 'Media' | 'Difícil')[] = ['Fácil', 'Media', 'Difícil'];
      const difficulty = difficulties[Math.floor(seededRandom(seed + 1) * 3)];
      const time = `${Math.floor(seededRandom(seed + 2) * 120) + 10} min`;
      const servings = Math.floor(seededRandom(seed + 3) * 8) + 1;
      const ingredientSet = ingredientSets[i % ingredientSets.length];
      const stepsSet = stepSets[Math.floor(seededRandom(seed + 4) * stepSets.length)];
      const rating = Math.round((seededRandom(seed + 5) * 2 + 3) * 10) / 10;
      const calories = Math.floor(seededRandom(seed + 6) * 800) + 100;
      const region = regions[Math.floor(seededRandom(seed + 7) * regions.length)];
      const image = getImageForRecipe(names[i], seed);
      const numTags = Math.floor(seededRandom(seed + 9) * 4) + 1;
      const recipeTags: string[] = [];
      for (let t = 0; t < numTags; t++) {
        const tag = tagOptions[Math.floor(seededRandom(seed + 10 + t) * tagOptions.length)];
        if (!recipeTags.includes(tag)) recipeTags.push(tag);
      }

      recipes.push({
        id,
        name: names[i],
        category,
        type,
        difficulty,
        time,
        servings,
        ingredients: ingredientSet,
        steps: stepsSet,
        image,
        rating,
        calories,
        region,
        tags: recipeTags,
      });
      id++;
    }
  }

  // Generar recetas adicionales hasta 1500
  while (recipes.length < 1500) {
    const catIndex = recipes.length % categories.length;
    const category = categories[catIndex];
    const baseNames = recipeNames[category];
    const variation = Math.floor(recipes.length / categories.length) - Math.floor(baseNames.length / categories.length);
    const baseName = baseNames[recipes.length % baseNames.length];
    const suffix = variation > 0 ? ` (Variante ${Math.ceil(variation)})` : '';
    const name = `${baseName}${suffix}`;
    const seed = recipes.length * 17 + 31;
    const rand = seededRandom(seed);
    
    let type: 'tradicional' | 'thermomix';
    if (thermomixCount < TOTAL_THERMOMIX && rand > 0.6) {
      type = 'thermomix';
      thermomixCount++;
    } else {
      type = 'tradicional';
    }

    const difficulties: ('Fácil' | 'Media' | 'Difícil')[] = ['Fácil', 'Media', 'Difícil'];
    const difficulty = difficulties[Math.floor(seededRandom(seed + 1) * 3)];
    const time = `${Math.floor(seededRandom(seed + 2) * 120) + 10} min`;
    const servings = Math.floor(seededRandom(seed + 3) * 8) + 1;
    const ingredientSet = ingredientSets[recipes.length % ingredientSets.length];
    const stepsSet = stepSets[Math.floor(seededRandom(seed + 4) * stepSets.length)];
    const rating = Math.round((seededRandom(seed + 5) * 2 + 3) * 10) / 10;
    const calories = Math.floor(seededRandom(seed + 6) * 800) + 100;
    const region = regions[Math.floor(seededRandom(seed + 7) * regions.length)];
    const image = getImageForRecipe(name, seed);
    const numTags = Math.floor(seededRandom(seed + 9) * 4) + 1;
    const recipeTags: string[] = [];
    for (let t = 0; t < numTags; t++) {
      const tag = tagOptions[Math.floor(seededRandom(seed + 10 + t) * tagOptions.length)];
      if (!recipeTags.includes(tag)) recipeTags.push(tag);
    }

    recipes.push({
      id: recipes.length + 1,
      name,
      category,
      type,
      difficulty,
      time,
      servings,
      ingredients: ingredientSet,
      steps: stepsSet,
      image,
      rating,
      calories,
      region,
      tags: recipeTags,
    });
  }

  return recipes;
}

export const allRecipes = generateRecipes();
export const allCategories = categories;
export const allRegions = regions;
export const allTags = tagOptions;

export const recipeStats = {
  total: allRecipes.length,
  thermomix: allRecipes.filter(r => r.type === 'thermomix').length,
  tradicional: allRecipes.filter(r => r.type === 'tradicional').length,
  thermomixPostres: allRecipes.filter(r => r.type === 'thermomix' && r.category === 'Postres').length,
  nuevas: 500, // Recetas añadidas en última actualización
};
