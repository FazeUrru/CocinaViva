export interface Plan {
  id: string;
  name: string;
  price: number;
  annualPrice: number;
  trial: number;
  description: string;
  features: Feature[];
  color: string;
  borderColor: string;
  badge?: string;
  popular?: boolean;
}

export interface Feature {
  name: string;
  included: boolean;
}

export const plans: Plan[] = [
  {
    id: 'free',
    name: 'Básico',
    price: 0,
    annualPrice: 0,
    trial: 0,
    description: 'Perfecto para empezar',
    color: 'from-gray-400 to-gray-600',
    borderColor: 'border-gray-200',
    features: [
      { name: 'Acceso a 500 recetas', included: true },
      { name: 'Búsqueda simple', included: true },
      { name: 'Favoritos (limitado a 10)', included: true },
      { name: '5 logros disponibles', included: true },
      { name: 'Modo Thermomix', included: false },
      { name: 'Lista de la compra avanzada', included: false },
      { name: 'Planificador semanal', included: false },
      { name: 'Calculadora nutricional', included: false },
      { name: 'Temporizador múltiple', included: false },
      { name: 'Asistente de voz (Beta)', included: false },
      { name: 'Sin publicidad', included: false },
      { name: 'Acceso a nuevas funciones', included: false },
      { name: 'Soporte prioritario', included: false },
      { name: 'Exportar recetas', included: false },
      { name: 'Sincronización en la nube', included: false }
    ]
  },
  {
    id: 'ultra',
    name: 'Ultra',
    price: 5.99,
    annualPrice: 67.84,
    trial: 14,
    description: 'Para cocineros entusiastas',
    color: 'from-orange-400 to-orange-600',
    borderColor: 'border-orange-300',
    badge: 'POPULAR',
    popular: true,
    features: [
      { name: 'Acceso a 800 recetas', included: true },
      { name: 'Búsqueda avanzada con filtros', included: true },
      { name: 'Favoritos ilimitados', included: true },
      { name: '50 logros disponibles', included: true },
      { name: 'Modo Thermomix completo', included: true },
      { name: 'Lista de la compra avanzada', included: true },
      { name: 'Planificador semanal', included: true },
      { name: 'Calculadora nutricional', included: true },
      { name: 'Temporizador múltiple', included: true },
      { name: 'Asistente de voz (Beta)', included: false },
      { name: 'Sin publicidad', included: true },
      { name: 'Acceso a nuevas funciones', included: true },
      { name: 'Soporte prioritario', included: false },
      { name: 'Exportar recetas', included: true },
      { name: 'Sincronización en la nube', included: false }
    ]
  },
  {
    id: 'masterchef',
    name: 'Master Chef',
    price: 10.99,
    annualPrice: 124.37,
    trial: 14,
    description: 'La experiencia completa',
    color: 'from-purple-500 to-red-500',
    borderColor: 'border-purple-300',
    badge: 'PREMIUM',
    popular: true,
    features: [
      { name: 'Acceso a 1.000+ recetas', included: true },
      { name: 'Búsqueda avanzada con filtros', included: true },
      { name: 'Favoritos ilimitados', included: true },
      { name: '100 logros disponibles', included: true },
      { name: 'Modo Thermomix completo', included: true },
      { name: 'Lista de la compra avanzada', included: true },
      { name: 'Planificador semanal', included: true },
      { name: 'Calculadora nutricional avanzada', included: true },
      { name: 'Temporizador múltiple', included: true },
      { name: 'Asistente de voz (Beta)', included: true },
      { name: 'Sin publicidad', included: true },
      { name: 'Acceso a nuevas funciones', included: true },
      { name: 'Soporte prioritario 24/7', included: true },
      { name: 'Exportar recetas (PDF, imagen, email)', included: true },
      { name: 'Sincronización en la nube', included: true }
    ]
  }
];

export const comparisonFeatures = [
  'Número de recetas',
  'Búsqueda avanzada',
  'Favoritos ilimitados',
  'Logros disponibles',
  'Modo Thermomix',
  'Lista de compra avanzada',
  'Planificador semanal',
  'Calculadora nutricional',
  'Temporizador múltiple',
  'Asistente de voz',
  'Sin publicidad',
  'Nuevas funciones',
  'Soporte prioritario',
  'Exportar recetas',
  'Sincronización nube'
];
