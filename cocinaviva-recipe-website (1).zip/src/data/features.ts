export interface Feature {
  id: number;
  name: string;
  description: string;
  icon: string;
  status: 'activa' | 'beta' | 'próximamente';
}

export const features: Feature[] = [
  {
    id: 1,
    name: 'Buscador Inteligente',
    description: 'Busca recetas por nombre, ingredientes, categoría o región. Nuestro motor de búsqueda avanzado encuentra exactamente lo que necesitas.',
    icon: 'Search',
    status: 'activa',
  },
  {
    id: 2,
    name: 'Planificador Semanal',
    description: 'Organiza tus comidas de toda la semana. Arrastra y suelta recetas en tu calendario semanal personalizado.',
    icon: 'Calendar',
    status: 'beta',
  },
  {
    id: 3,
    name: 'Lista de la Compra',
    description: 'Genera automáticamente la lista de la compra a partir de las recetas seleccionadas. Exporta o comparte con tu familia.',
    icon: 'ShoppingCart',
    status: 'activa',
  },
  {
    id: 4,
    name: 'Modo Thermomix',
    description: 'Instrucciones adaptadas paso a paso para tu Thermomix con temperaturas, velocidades y tiempos exactos.',
    icon: 'Gauge',
    status: 'activa',
  },
  {
    id: 5,
    name: 'Calculadora Nutricional',
    description: 'Información detallada de calorías, macronutrientes y micronutrientes de cada receta. Controla tu alimentación.',
    icon: 'Calculator',
    status: 'beta',
  },
  {
    id: 6,
    name: 'Favoritos y Colecciones',
    description: 'Guarda tus recetas favoritas y organízalas en colecciones personalizadas temáticas.',
    icon: 'Heart',
    status: 'activa',
  },
  {
    id: 7,
    name: 'Temporizador Integrado',
    description: 'Temporizadores múltiples para controlar cada paso de tu receta sin salir de la aplicación.',
    icon: 'Timer',
    status: 'activa',
  },
  {
    id: 8,
    name: 'Conversión de Unidades',
    description: 'Convierte entre gramos, onzas, tazas, cucharadas y más. Adapta las recetas a tus utensilios.',
    icon: 'ArrowLeftRight',
    status: 'activa',
  },
  {
    id: 9,
    name: 'Modo Paso a Paso',
    description: 'Sigue las recetas paso a paso con imágenes grandes y texto claro. Ideal para cocinar con el móvil.',
    icon: 'ListOrdered',
    status: 'activa',
  },
  {
    id: 10,
    name: 'Compartir Recetas',
    description: 'Comparte recetas con amigos y familia por WhatsApp, email o redes sociales con un solo clic.',
    icon: 'Share2',
    status: 'beta',
  },
  {
    id: 11,
    name: 'Asistente de Voz (Beta)',
    description: 'Controla la aplicación con tu voz mientras cocinas. Di "siguiente paso" y la app te guiará.',
    icon: 'Mic',
    status: 'beta',
  },
  {
    id: 12,
    name: 'Escáner de Ingredientes',
    description: 'Escanea los ingredientes que tienes en tu nevera y te sugerimos recetas que puedes preparar.',
    icon: 'ScanLine',
    status: 'beta',
  },
  {
    id: 13,
    name: 'Generador de Menús con IA (Beta)',
    description: 'Crea un menú semanal automático analizando tu historial de gustos, alergias y nutrición.',
    icon: 'BrainCircuit',
    status: 'beta',
  },
  {
    id: 14,
    name: 'Sincronización de Nevera (Beta)',
    description: 'Conecta con tus tickets de compra para mantener tu inventario y sugerir platos.',
    icon: 'Replay',
    status: 'beta',
  },
  {
    id: 15,
    name: 'Modo Gestos (Sin Manos) (Beta)',
    description: 'Avanza los pasos de la receta moviendo la mano frente a la cámara.',
    icon: 'Hand',
    status: 'beta',
  },
  {
    id: 16,
    name: 'Realidad Aumentada (Beta)',
    description: 'Visualiza los platos en 3D sobre tu mesa antes de cocinarlos usando AR.',
    icon: 'Glasses',
    status: 'beta',
  },
  {
    id: 17,
    name: 'Chef Virtual en Vivo (Beta)',
    description: 'Asistente virtual que te guía paso a paso con animaciones en tiempo real.',
    icon: 'Video',
    status: 'beta',
  },
  {
    id: 18,
    name: 'Comunidad en Directo (Beta)',
    description: 'Cocina en vivo con otros usuarios y comparte tu progreso en tiempo real.',
    icon: 'Users',
    status: 'beta',
  },
];

export interface Setting {
  id: number;
  name: string;
  description: string;
  category: 'general' | 'apariencia' | 'notificaciones' | 'privacidad' | 'accesibilidad' | 'cocina' | 'beta' | 'perfil' | 'desarrollador';
  type: 'toggle' | 'select' | 'slider';
  defaultValue: boolean | string | number;
  secret?: boolean;
}

export const settings: Setting[] = [
  // General (6)
  { id: 1, name: 'Unidades de Medida', description: 'Elige entre sistema métrico o imperial', category: 'general', type: 'select', defaultValue: 'métrico' },
  { id: 2, name: 'Idioma', description: 'Selecciona el idioma de la aplicación', category: 'general', type: 'select', defaultValue: 'español' },
  { id: 3, name: 'Modo Thermomix por Defecto', description: 'Muestra siempre las instrucciones para Thermomix', category: 'general', type: 'toggle', defaultValue: false },
  { id: 4, name: 'Autoguardado de Favoritos', description: 'Guarda automáticamente las recetas que visitas frecuentemente', category: 'general', type: 'toggle', defaultValue: true },
  { id: 5, name: 'Porciones por Defecto', description: 'Número de porciones predeterminado', category: 'general', type: 'slider', defaultValue: 4 },
  { id: 6, name: 'Cache de Recetas', description: 'Guarda recetas offline para acceso sin conexión', category: 'general', type: 'toggle', defaultValue: true },
  
  // Apariencia (6)
  { id: 7, name: 'Modo Oscuro', description: 'Activa el tema oscuro para reducir la fatiga visual', category: 'apariencia', type: 'toggle', defaultValue: false },
  { id: 8, name: 'Modo Pantalla Completa', description: 'Oculta la barra de navegación mientras cocinas', category: 'apariencia', type: 'toggle', defaultValue: false },
  { id: 9, name: 'Color de Acento', description: 'Personaliza el color principal de la aplicación', category: 'apariencia', type: 'select', defaultValue: 'naranja' },
  { id: 10, name: 'Densidad de Tarjetas', description: 'Ajusta el tamaño de las tarjetas de recetas', category: 'apariencia', type: 'select', defaultValue: 'normal' },
  { id: 11, name: 'Mostrar Imágenes', description: 'Muestra imágenes de las recetas', category: 'apariencia', type: 'toggle', defaultValue: true },
  { id: 12, name: 'Animaciones', description: 'Activa/desactiva las animaciones de la interfaz', category: 'apariencia', type: 'toggle', defaultValue: true },
  
  // Notificaciones (5)
  { id: 13, name: 'Notificaciones Push', description: 'Recibe notificaciones de nuevas recetas y tips', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 14, name: 'Alertas de Temporizador', description: 'Sonido y vibración cuando el temporizador termina', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 15, name: 'Resumen Diario', description: 'Recibe un resumen diario con recetas recomendadas', category: 'notificaciones', type: 'toggle', defaultValue: false },
  { id: 16, name: 'Alertas de Logros', description: 'Notifica cuando desbloqueas un nuevo logro', category: 'notificaciones', type: 'toggle', defaultValue: true },
  { id: 17, name: 'Recordatorios de Cocina', description: 'Recibe recordatorios para cocinar recetas guardadas', category: 'notificaciones', type: 'toggle', defaultValue: false },
  
  // Privacidad (5)
  { id: 18, name: 'Compartir Actividad', description: 'Permite compartir tu actividad con otros usuarios', category: 'privacidad', type: 'toggle', defaultValue: false },
  { id: 19, name: 'Historial de Búsqueda', description: 'Guarda tu historial de búsquedas recientes', category: 'privacidad', type: 'toggle', defaultValue: true },
  { id: 20, name: 'Sugerencias Personalizadas', description: 'Recibe sugerencias basadas en tus preferencias', category: 'privacidad', type: 'toggle', defaultValue: true },
  { id: 21, name: 'Perfil Público', description: 'Permite que otros usuarios vean tu perfil', category: 'privacidad', type: 'toggle', defaultValue: false },
  { id: 22, name: 'Estadísticas Anónimas', description: 'Comparte estadísticas anónimas para mejorar la app', category: 'privacidad', type: 'toggle', defaultValue: true },
  
  // Accesibilidad (6)
  { id: 23, name: 'Tamaño de Texto', description: 'Ajusta el tamaño del texto en las recetas', category: 'accesibilidad', type: 'select', defaultValue: 'mediano' },
  { id: 24, name: 'Ampliar Tipografía', description: 'Controla el tamaño general de la tipografía en toda la app', category: 'accesibilidad', type: 'select', defaultValue: 'mediano' },
  { id: 25, name: 'Alto Contraste', description: 'Aumenta el contraste para mejor legibilidad', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 26, name: 'Lectura en Voz Alta', description: 'Lee los pasos de la receta en voz alta', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 27, name: 'Animaciones Reducidas', description: 'Reduce las animaciones de la interfaz', category: 'accesibilidad', type: 'toggle', defaultValue: false },
  { id: 28, name: 'Modo Daltónico', description: 'Ajusta los colores para daltonismo', category: 'accesibilidad', type: 'select', defaultValue: 'desactivado' },
  
  // Cocina (3)
  { id: 29, name: 'Modo Niños', description: 'Interfaz simplificada y recetas aptas para niños', category: 'cocina', type: 'toggle', defaultValue: false },
  { id: 30, name: 'Nivel de Cocina', description: 'Tu nivel de experiencia en la cocina', category: 'cocina', type: 'select', defaultValue: 'intermedio' },
  { id: 31, name: 'Preferencias Dietéticas', description: 'Filtra recetas según tu dieta', category: 'cocina', type: 'select', defaultValue: 'ninguna' },

  // Beta (7)
  { id: 32, name: 'Menús Inteligentes (Beta)', description: 'Activa el generador automático de menús semanales', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 33, name: 'Asistente por Voz (Beta)', description: 'Control de la app hablando al dispositivo', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 34, name: 'Gestos de Cámara (Beta)', description: 'Pasar páginas con movimientos de mano', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 35, name: 'Sync de Nevera (Beta)', description: 'Conecta con APIs de supermercados', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 36, name: 'Generación de Imágenes (Beta)', description: 'Generar imágenes de tus variaciones', category: 'beta', type: 'toggle', defaultValue: false },
  { id: 37, name: 'Sensibilidad de Gestos (Beta)', description: 'Ajusta la reacción de la cámara a tu mano', category: 'beta', type: 'slider', defaultValue: 5 },
  { id: 38, name: 'Calidad de Voz (Beta)', description: 'Define la calidad del asistente de voz', category: 'beta', type: 'select', defaultValue: 'alta' },
  
  // Perfil (30 ajustes)
  { id: 39, name: 'Nombre de Usuario', description: 'Tu nombre visible en la comunidad', category: 'perfil', type: 'select', defaultValue: 'Usuario' },
  { id: 40, name: 'Avatar Personalizado', description: 'Sube tu foto de perfil', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 41, name: 'Bio Pública', description: 'Breve descripción sobre ti', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 42, name: 'País de Origen', description: 'Tu país para recomendaciones regionales', category: 'perfil', type: 'select', defaultValue: 'España' },
  { id: 43, name: 'Ciudad', description: 'Tu ciudad para eventos locales', category: 'perfil', type: 'select', defaultValue: '' },
  { id: 44, name: 'Edad', description: 'Tu rango de edad', category: 'perfil', type: 'select', defaultValue: '18-24' },
  { id: 45, name: 'Género', description: 'Tu género (opcional)', category: 'perfil', type: 'select', defaultValue: 'no especificar' },
  { id: 46, name: 'Alergias Alimentarias', description: 'Marca tus alergias para filtrar recetas', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 47, name: 'Intolerancias', description: 'Lactosa, gluten, etc.', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 48, name: 'Dieta Vegetariana', description: 'Activa filtro vegetariano', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 49, name: 'Dieta Vegana', description: 'Activa filtro vegano', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 50, name: 'Dieta Keto', description: 'Activa filtro keto', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 51, name: 'Dieta Paleo', description: 'Activa filtro paleo', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 52, name: 'Dieta Mediterránea', description: 'Activa filtro mediterráneo', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 53, name: 'Control de Calorías', description: 'Límite diario de calorías', category: 'perfil', type: 'slider', defaultValue: 2000 },
  { id: 54, name: 'Objetivo Nutricional', description: 'Pérdida, mantenimiento o ganancia', category: 'perfil', type: 'select', defaultValue: 'mantenimiento' },
  { id: 55, name: 'Presupuesto Semanal', description: 'Presupuesto para compras', category: 'perfil', type: 'slider', defaultValue: 100 },
  { id: 56, name: 'Tamaño de Familia', description: 'Número de personas en casa', category: 'perfil', type: 'slider', defaultValue: 2 },
  { id: 57, name: 'Cocina Disponible', description: 'Equipamiento de cocina', category: 'perfil', type: 'select', defaultValue: 'completa' },
  { id: 58, name: 'Tiempo Promedio Cocina', description: 'Tiempo que dedicas a cocinar', category: 'perfil', type: 'select', defaultValue: '30-60min' },
  { id: 59, name: 'Favoritos Públicos', description: 'Muestra tus favoritos a otros', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 60, name: 'Logros Públicos', description: 'Muestra tus logros a otros', category: 'perfil', type: 'toggle', defaultValue: true },
  { id: 61, name: 'Estadísticas Públicas', description: 'Muestra tus estadísticas', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 62, name: 'Ranking Visible', description: 'Aparece en rankings globales', category: 'perfil', type: 'toggle', defaultValue: true },
  { id: 63, name: 'Chef Favorito', description: 'Tu chef o cocinero favorito', category: 'perfil', type: 'select', defaultValue: 'ninguno' },
  { id: 64, name: 'Cocina Favorita', description: 'Tu tipo de cocina preferido', category: 'perfil', type: 'select', defaultValue: 'española' },
  { id: 65, name: 'Ingrediente Favorito', description: 'Tu ingrediente estrella', category: 'perfil', type: 'select', defaultValue: '' },
  { id: 66, name: 'Redes Sociales', description: 'Enlaza tus redes sociales', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 67, name: 'Certificación Chef', description: 'Marca si eres chef certificado', category: 'perfil', type: 'toggle', defaultValue: false },
  { id: 68, name: 'Años de Experiencia', description: 'Tu experiencia cocinando', category: 'perfil', type: 'slider', defaultValue: 1 },
  
  // Desarrollador (Modo Secreto - solo visible para desarrolladores)
  { id: 69, name: 'Modo Desarrollador', description: 'Activa las herramientas de desarrollo', category: 'desarrollador', type: 'toggle', defaultValue: false, secret: true },
  { id: 70, name: 'Acceso Anticipado', description: 'Activa funciones experimentales no publicadas', category: 'desarrollador', type: 'toggle', defaultValue: false, secret: true },
  { id: 71, name: 'Debug Console', description: 'Muestra consola de depuración', category: 'desarrollador', type: 'toggle', defaultValue: false, secret: true },
];

export const settingCategories = [
  { key: 'general', label: 'General', icon: 'Settings' },
  { key: 'apariencia', label: 'Apariencia', icon: 'Palette' },
  { key: 'notificaciones', label: 'Notificaciones', icon: 'Bell' },
  { key: 'privacidad', label: 'Privacidad', icon: 'Shield' },
  { key: 'accesibilidad', label: 'Accesibilidad', icon: 'Eye' },
  { key: 'cocina', label: 'Cocina', icon: 'ChefHat' },
  { key: 'perfil', label: 'Perfil de Usuario', icon: 'User' },
  { key: 'beta', label: 'Funciones Beta', icon: 'FlaskConical' },
  { key: 'desarrollador', label: 'Desarrollador', icon: 'Code', secret: true },
];

// 100 Logros
export interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  category: 'recetas' | 'cocina' | 'social' | 'exploración' | 'maestría' | 'thermomix' | 'colección' | 'tiempo' | 'especial' | 'reto';
  points: number;
  unlocked: boolean;
}

export const achievements: Achievement[] = [
  // Recetas (15)
  { id: 1, name: 'Primera Receta', description: 'Cocina tu primera receta', icon: '🍳', category: 'recetas', points: 10, unlocked: true },
  { id: 2, name: 'Chef Novato', description: 'Cocina 5 recetas diferentes', icon: '👨‍🍳', category: 'recetas', points: 25, unlocked: true },
  { id: 3, name: 'Cocinero Activo', description: 'Cocina 10 recetas diferentes', icon: '🔥', category: 'recetas', points: 50, unlocked: false },
  { id: 4, name: 'Chef Entusiasta', description: 'Cocina 25 recetas diferentes', icon: '⭐', category: 'recetas', points: 100, unlocked: false },
  { id: 5, name: 'Maestro de la Cocina', description: 'Cocina 50 recetas diferentes', icon: '👑', category: 'recetas', points: 200, unlocked: false },
  { id: 6, name: 'Chef Experto', description: 'Cocina 100 recetas diferentes', icon: '🏆', category: 'recetas', points: 500, unlocked: false },
  { id: 7, name: 'Leyenda Culinaria', description: 'Cocina 250 recetas diferentes', icon: '🎖️', category: 'recetas', points: 1000, unlocked: false },
  { id: 8, name: 'Chef Supremo', description: 'Cocina 500 recetas diferentes', icon: '💎', category: 'recetas', points: 2500, unlocked: false },
  { id: 9, name: 'Receta Rápida', description: 'Cocina una receta en menos de 15 minutos', icon: '⚡', category: 'recetas', points: 25, unlocked: false },
  { id: 10, name: 'Receta Elaborada', description: 'Cocina una receta de más de 2 horas', icon: '⏰', category: 'recetas', points: 50, unlocked: false },
  { id: 11, name: 'Receta Fácil', description: 'Cocina 10 recetas de dificultad fácil', icon: '😊', category: 'recetas', points: 30, unlocked: false },
  { id: 12, name: 'Receta Media', description: 'Cocina 10 recetas de dificultad media', icon: '💪', category: 'recetas', points: 50, unlocked: false },
  { id: 13, name: 'Receta Difícil', description: 'Cocina 5 recetas de dificultad difícil', icon: '🔥', category: 'recetas', points: 100, unlocked: false },
  { id: 14, name: 'Reto Maestro', description: 'Cocina 25 recetas de dificultad difícil', icon: '🎯', category: 'recetas', points: 300, unlocked: false },
  { id: 15, name: 'Todo Terreno', description: 'Cocina recetas de todas las dificultades', icon: '🌈', category: 'recetas', points: 75, unlocked: false },

  // Cocina (10)
  { id: 16, name: 'Amante del Horno', description: 'Cocina 10 recetas al horno', icon: '🔥', category: 'cocina', points: 40, unlocked: false },
  { id: 17, name: 'Rey de la Sartén', description: 'Cocina 10 recetas a la sartén', icon: '🍳', category: 'cocina', points: 40, unlocked: false },
  { id: 18, name: 'Maestro del Vapor', description: 'Cocina 5 recetas al vapor', icon: '💨', category: 'cocina', points: 50, unlocked: false },
  { id: 19, name: 'Experto en Plancha', description: 'Cocina 10 recetas a la plancha', icon: '🥩', category: 'cocina', points: 40, unlocked: false },
  { id: 20, name: 'Chef de Frituras', description: 'Cocina 5 recetas fritas', icon: '🍟', category: 'cocina', points: 35, unlocked: false },
  { id: 21, name: 'Cocina Saludable', description: 'Cocina 10 recetas bajas en calorías', icon: '🥗', category: 'cocina', points: 60, unlocked: false },
  { id: 22, name: 'Proteínas Power', description: 'Cocina 10 recetas altas en proteínas', icon: '💪', category: 'cocina', points: 50, unlocked: false },
  { id: 23, name: 'Sin Gluten', description: 'Cocina 5 recetas sin gluten', icon: '🌾', category: 'cocina', points: 40, unlocked: false },
  { id: 24, name: 'Veggie Lover', description: 'Cocina 10 recetas vegetarianas', icon: '🥬', category: 'cocina', points: 50, unlocked: false },
  { id: 25, name: 'Vegano Total', description: 'Cocina 10 recetas veganas', icon: '🌱', category: 'cocina', points: 60, unlocked: false },

  // Social (10)
  { id: 26, name: 'Primera Compartida', description: 'Comparte tu primera receta', icon: '📤', category: 'social', points: 15, unlocked: false },
  { id: 27, name: 'Influencer', description: 'Comparte 10 recetas', icon: '📱', category: 'social', points: 50, unlocked: false },
  { id: 28, name: 'Super Compartidor', description: 'Comparte 50 recetas', icon: '🌟', category: 'social', points: 150, unlocked: false },
  { id: 29, name: 'Primera Valoración', description: 'Valora tu primera receta', icon: '⭐', category: 'social', points: 10, unlocked: false },
  { id: 30, name: 'Crítico Gastronómico', description: 'Valora 25 recetas', icon: '📝', category: 'social', points: 75, unlocked: false },
  { id: 31, name: 'Top Reviewer', description: 'Valora 100 recetas', icon: '🏅', category: 'social', points: 200, unlocked: false },
  { id: 32, name: 'Primer Comentario', description: 'Deja tu primer comentario', icon: '💬', category: 'social', points: 10, unlocked: false },
  { id: 33, name: 'Conversador', description: 'Deja 25 comentarios', icon: '🗣️', category: 'social', points: 50, unlocked: false },
  { id: 34, name: 'Comunidad Activa', description: 'Participa en 10 discusiones', icon: '👥', category: 'social', points: 75, unlocked: false },
  { id: 35, name: 'Embajador', description: 'Invita a 5 amigos a usar CocinaViva', icon: '🤝', category: 'social', points: 100, unlocked: false },

  // Exploración (15)
  { id: 36, name: 'Explorador', description: 'Visita todas las categorías', icon: '🧭', category: 'exploración', points: 30, unlocked: false },
  { id: 37, name: 'Entrantes Master', description: 'Cocina 10 entrantes', icon: '🥗', category: 'exploración', points: 40, unlocked: false },
  { id: 38, name: 'Sopas y Cremas', description: 'Cocina 10 sopas o cremas', icon: '🍲', category: 'exploración', points: 40, unlocked: false },
  { id: 39, name: 'Ensaladas Frescas', description: 'Cocina 10 ensaladas', icon: '🥬', category: 'exploración', points: 40, unlocked: false },
  { id: 40, name: 'Rey del Arroz', description: 'Cocina 10 arroces', icon: '🍚', category: 'exploración', points: 50, unlocked: false },
  { id: 41, name: 'Pasta Lover', description: 'Cocina 10 pastas', icon: '🍝', category: 'exploración', points: 40, unlocked: false },
  { id: 42, name: 'Carnívoro', description: 'Cocina 15 platos de carne', icon: '🥩', category: 'exploración', points: 60, unlocked: false },
  { id: 43, name: 'Pescador', description: 'Cocina 10 platos de pescado', icon: '🐟', category: 'exploración', points: 50, unlocked: false },
  { id: 44, name: 'Marisco Deluxe', description: 'Cocina 10 platos de marisco', icon: '🦐', category: 'exploración', points: 60, unlocked: false },
  { id: 45, name: 'Verde que te quiero', description: 'Cocina 10 platos de verduras', icon: '🥦', category: 'exploración', points: 40, unlocked: false },
  { id: 46, name: 'Legumbres Power', description: 'Cocina 10 platos de legumbres', icon: '🫘', category: 'exploración', points: 45, unlocked: false },
  { id: 47, name: 'Guisos Tradicionales', description: 'Cocina 10 guisos', icon: '🍖', category: 'exploración', points: 50, unlocked: false },
  { id: 48, name: 'Dulce Pasión', description: 'Cocina 15 postres', icon: '🍰', category: 'exploración', points: 60, unlocked: false },
  { id: 49, name: 'Repostero', description: 'Cocina 10 recetas de repostería', icon: '🧁', category: 'exploración', points: 50, unlocked: false },
  { id: 50, name: 'Panadero', description: 'Cocina 10 panes o masas', icon: '🍞', category: 'exploración', points: 55, unlocked: false },

  // Maestría (10)
  { id: 51, name: 'Salsas Perfectas', description: 'Cocina 10 salsas', icon: '🫙', category: 'maestría', points: 40, unlocked: false },
  { id: 52, name: 'Bartender', description: 'Prepara 10 bebidas', icon: '🍹', category: 'maestría', points: 35, unlocked: false },
  { id: 53, name: 'Rey de las Tapas', description: 'Cocina 20 tapas', icon: '🍢', category: 'maestría', points: 70, unlocked: false },
  { id: 54, name: 'Desayunos Perfectos', description: 'Prepara 15 desayunos', icon: '🥞', category: 'maestría', points: 50, unlocked: false },
  { id: 55, name: 'Cenas Ligeras', description: 'Cocina 10 cenas ligeras', icon: '🥗', category: 'maestría', points: 40, unlocked: false },
  { id: 56, name: 'Chef de Fiestas', description: 'Cocina 10 recetas especiales', icon: '🎉', category: 'maestría', points: 60, unlocked: false },
  { id: 57, name: 'España Completa', description: 'Cocina recetas de 10 regiones españolas', icon: '🇪🇸', category: 'maestría', points: 100, unlocked: false },
  { id: 58, name: 'Todas las Regiones', description: 'Cocina recetas de todas las regiones', icon: '🗺️', category: 'maestría', points: 250, unlocked: false },
  { id: 59, name: 'Cocina Internacional', description: 'Cocina 10 recetas internacionales', icon: '🌍', category: 'maestría', points: 50, unlocked: false },
  { id: 60, name: 'Mediterráneo', description: 'Cocina 10 recetas mediterráneas', icon: '🌊', category: 'maestría', points: 45, unlocked: false },

  // Thermomix (15)
  { id: 61, name: 'Primera Thermomix', description: 'Cocina tu primera receta Thermomix', icon: '🤖', category: 'thermomix', points: 20, unlocked: false },
  { id: 62, name: 'Thermomix Novato', description: 'Cocina 5 recetas Thermomix', icon: '⚙️', category: 'thermomix', points: 40, unlocked: false },
  { id: 63, name: 'Thermomix Fan', description: 'Cocina 25 recetas Thermomix', icon: '🔧', category: 'thermomix', points: 100, unlocked: false },
  { id: 64, name: 'Thermomix Expert', description: 'Cocina 50 recetas Thermomix', icon: '🎯', category: 'thermomix', points: 200, unlocked: false },
  { id: 65, name: 'Thermomix Master', description: 'Cocina 100 recetas Thermomix', icon: '👨‍🔬', category: 'thermomix', points: 400, unlocked: false },
  { id: 66, name: 'Thermomix Legend', description: 'Cocina 200 recetas Thermomix', icon: '🏆', category: 'thermomix', points: 800, unlocked: false },
  { id: 67, name: 'Thermomix Supreme', description: 'Cocina 350 recetas Thermomix', icon: '💎', category: 'thermomix', points: 1500, unlocked: false },
  { id: 68, name: 'Velocidad Máxima', description: 'Completa 10 recetas a velocidad turbo', icon: '🚀', category: 'thermomix', points: 50, unlocked: false },
  { id: 69, name: 'Control de Temperatura', description: 'Usa todas las temperaturas', icon: '🌡️', category: 'thermomix', points: 60, unlocked: false },
  { id: 70, name: 'Postres Thermomix', description: 'Cocina 10 postres con Thermomix', icon: '🍮', category: 'thermomix', points: 50, unlocked: false },
  { id: 71, name: 'Postres Thermomix Pro', description: 'Cocina 25 postres con Thermomix', icon: '🎂', category: 'thermomix', points: 100, unlocked: false },
  { id: 72, name: 'Postres Thermomix Master', description: 'Cocina 50 postres con Thermomix', icon: '🏅', category: 'thermomix', points: 200, unlocked: false },
  { id: 73, name: 'Salsas Thermomix', description: 'Prepara 10 salsas con Thermomix', icon: '🫕', category: 'thermomix', points: 45, unlocked: false },
  { id: 74, name: 'Masas Thermomix', description: 'Prepara 10 masas con Thermomix', icon: '🥖', category: 'thermomix', points: 50, unlocked: false },
  { id: 75, name: 'Cremas Thermomix', description: 'Prepara 10 cremas con Thermomix', icon: '🥣', category: 'thermomix', points: 45, unlocked: false },

  // Colección (10)
  { id: 76, name: 'Primer Favorito', description: 'Añade tu primera receta a favoritos', icon: '❤️', category: 'colección', points: 5, unlocked: true },
  { id: 77, name: 'Coleccionista', description: 'Guarda 10 recetas en favoritos', icon: '📚', category: 'colección', points: 25, unlocked: false },
  { id: 78, name: 'Gran Colección', description: 'Guarda 50 recetas en favoritos', icon: '📖', category: 'colección', points: 75, unlocked: false },
  { id: 79, name: 'Mega Colección', description: 'Guarda 100 recetas en favoritos', icon: '📕', category: 'colección', points: 150, unlocked: false },
  { id: 80, name: 'Biblioteca Culinaria', description: 'Guarda 250 recetas en favoritos', icon: '🏛️', category: 'colección', points: 300, unlocked: false },
  { id: 81, name: 'Primera Lista', description: 'Crea tu primera lista de compra', icon: '📝', category: 'colección', points: 10, unlocked: false },
  { id: 82, name: 'Organizador', description: 'Crea 5 listas de compra', icon: '📋', category: 'colección', points: 30, unlocked: false },
  { id: 83, name: 'Primera Colección', description: 'Crea tu primera colección temática', icon: '📂', category: 'colección', points: 15, unlocked: false },
  { id: 84, name: 'Curador', description: 'Crea 5 colecciones temáticas', icon: '🗂️', category: 'colección', points: 50, unlocked: false },
  { id: 85, name: 'Archivero', description: 'Organiza recetas en 10 colecciones', icon: '🗃️', category: 'colección', points: 100, unlocked: false },

  // Tiempo (10)
  { id: 86, name: 'Primera Semana', description: 'Usa CocinaViva durante una semana', icon: '📅', category: 'tiempo', points: 20, unlocked: false },
  { id: 87, name: 'Un Mes Cocinando', description: 'Usa CocinaViva durante un mes', icon: '🗓️', category: 'tiempo', points: 50, unlocked: false },
  { id: 88, name: 'Tres Meses', description: 'Usa CocinaViva durante 3 meses', icon: '📆', category: 'tiempo', points: 100, unlocked: false },
  { id: 89, name: 'Medio Año', description: 'Usa CocinaViva durante 6 meses', icon: '🎊', category: 'tiempo', points: 200, unlocked: false },
  { id: 90, name: 'Un Año', description: 'Usa CocinaViva durante un año', icon: '🎉', category: 'tiempo', points: 500, unlocked: false },
  { id: 91, name: 'Madrugador', description: 'Cocina antes de las 7 de la mañana', icon: '🌅', category: 'tiempo', points: 30, unlocked: false },
  { id: 92, name: 'Chef Nocturno', description: 'Cocina después de medianoche', icon: '🌙', category: 'tiempo', points: 30, unlocked: false },
  { id: 93, name: 'Cocinero de Fin de Semana', description: 'Cocina 10 recetas en fin de semana', icon: '🏖️', category: 'tiempo', points: 40, unlocked: false },
  { id: 94, name: 'Racha de 7 Días', description: 'Cocina algo durante 7 días seguidos', icon: '🔥', category: 'tiempo', points: 75, unlocked: false },
  { id: 95, name: 'Racha de 30 Días', description: 'Cocina algo durante 30 días seguidos', icon: '💥', category: 'tiempo', points: 300, unlocked: false },

  // Especial y Reto (5)
  { id: 96, name: 'Beta Tester', description: 'Participa en la versión Beta', icon: '🧪', category: 'especial', points: 100, unlocked: true },
  { id: 97, name: 'Early Adopter', description: 'Uno de los primeros 1000 usuarios', icon: '🚀', category: 'especial', points: 200, unlocked: true },
  { id: 98, name: 'Reto Semanal', description: 'Completa tu primer reto semanal', icon: '🎯', category: 'reto', points: 50, unlocked: false },
  { id: 99, name: 'Retador', description: 'Completa 10 retos semanales', icon: '🏋️', category: 'reto', points: 200, unlocked: false },
  { id: 100, name: 'Perfeccionista', description: 'Desbloquea todos los logros', icon: '🌟', category: 'especial', points: 5000, unlocked: false },
];

export const achievementCategories = [
  { key: 'recetas', label: 'Recetas', icon: '🍳' },
  { key: 'cocina', label: 'Cocina', icon: '👨‍🍳' },
  { key: 'social', label: 'Social', icon: '👥' },
  { key: 'exploración', label: 'Exploración', icon: '🧭' },
  { key: 'maestría', label: 'Maestría', icon: '🏆' },
  { key: 'thermomix', label: 'Thermomix', icon: '🤖' },
  { key: 'colección', label: 'Colección', icon: '📚' },
  { key: 'tiempo', label: 'Tiempo', icon: '⏰' },
  { key: 'especial', label: 'Especial', icon: '⭐' },
  { key: 'reto', label: 'Retos', icon: '🎯' },
];
