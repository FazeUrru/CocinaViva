import { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { RecipeDetail } from './components/RecipeDetail';
import { HomePage } from './pages/HomePage';
import { RecipesPage } from './pages/RecipesPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { FeaturesPage } from './pages/FeaturesPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';
import { PlansPage } from './pages/PlansPage';
import { PrivacyPage } from './pages/PrivacyPage';
import type { Recipe } from './data/recipes';
import { recipeStats } from './data/recipes';
import { Logo } from './components/Logo';
import { Heart, Github } from 'lucide-react';

export function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');

  const handleNavigate = useCallback((page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleSelectRecipe = useCallback((recipe: Recipe) => {
    setSelectedRecipe(recipe);
  }, []);

  const handleToggleFavorite = useCallback((id: number) => {
    setFavorites(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleSearchChange = useCallback((q: string) => {
    setSearchQuery(q);
    if (q && currentPage !== 'recipes') {
      setCurrentPage('recipes');
    }
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} />;
      case 'recipes':
        return <RecipesPage onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} searchQuery={searchQuery} />;
      case 'categories':
        return <CategoriesPage onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} />;
      case 'features':
        return <FeaturesPage />;
      case 'settings':
        return <SettingsPage />;
      case 'plans':
        return <PlansPage />;
      case 'about':
        return <AboutPage />;
      case 'privacy':
        return <PrivacyPage />;
      default:
        return <HomePage onNavigate={handleNavigate} onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
      />
      
      <main>
        {renderPage()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Brand */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <Logo size={32} />
                <div>
                  <h3 className="text-sm font-black">CocinaViva</h3>
                  <span className="text-[8px] bg-orange-500 px-1 py-0.5 rounded-full font-bold">BETA v0.9</span>
                </div>
              </div>
              <p className="text-gray-400 text-xs">
                Tu compañero perfecto en la cocina con más de 1.000 recetas tradicionales y de Thermomix.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Navegación</h4>
              <ul className="space-y-1">
                {['home', 'recipes', 'categories', 'features', 'plans', 'settings', 'about'].map(page => (
                  <li key={page}>
                    <button onClick={() => handleNavigate(page)} className="text-gray-400 hover:text-orange-400 text-xs transition-colors capitalize">
                      {page === 'home' ? 'Inicio' : page === 'recipes' ? 'Recetas' : page === 'categories' ? 'Categorías' : page === 'features' ? 'Funciones' : page === 'plans' ? 'Planes' : page === 'settings' ? 'Ajustes' : 'Acerca de'}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Categories */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Categorías Populares</h4>
              <ul className="space-y-1">
                {['Entrantes', 'Carnes', 'Pescados', 'Postres', 'Arroces', 'Tapas'].map(cat => (
                  <li key={cat}>
                    <button onClick={() => handleNavigate('recipes')} className="text-gray-400 hover:text-orange-400 text-xs transition-colors">
                      {cat}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Info */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Información</h4>
              <div className="space-y-1 text-xs text-gray-400">
                <p>📖 1.500 recetas</p>
                <p>🤖 {recipeStats.thermomix} Thermomix</p>
                <p>⚡ 18 funciones</p>
                <p>⚙️ 70 ajustes</p>
                <p>🏆 100 logros</p>
                <p>🧪 Versión Beta v0.9</p>
                <p>🆕 +500 recetas nuevas</p>
              </div>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Legal</h4>
              <ul className="space-y-1">
                <li>
                  <button onClick={() => handleNavigate('privacy')} className="text-gray-400 hover:text-orange-400 text-xs transition-colors">
                    Política de Privacidad
                  </button>
                </li>
                <li>
                  <button onClick={() => handleNavigate('about')} className="text-gray-400 hover:text-orange-400 text-xs transition-colors">
                    Términos de Uso
                  </button>
                </li>
                <li>
                  <button onClick={() => handleNavigate('about')} className="text-gray-400 hover:text-orange-400 text-xs transition-colors">
                    Cookies
                  </button>
                </li>
                <li>
                  <button onClick={() => handleNavigate('about')} className="text-gray-400 hover:text-orange-400 text-xs transition-colors">
                    Contacto
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-6 pt-6 flex flex-col md:flex-row items-center justify-between gap-3">
            <p className="text-gray-500 text-xs">
              © 2024 CocinaViva — Todos los derechos reservados — Beta v0.9
            </p>
            <div className="flex items-center gap-3">
              <span className="text-gray-500 text-xs flex items-center gap-1">
                Hecho con <Heart className="w-3 h-3 text-red-500 fill-red-500" /> en España
              </span>
              <a href="#" className="text-gray-500 hover:text-white transition-colors">
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Recipe Detail Modal */}
      {selectedRecipe && (
        <RecipeDetail
          recipe={selectedRecipe}
          onClose={() => setSelectedRecipe(null)}
          isFavorite={favorites.has(selectedRecipe.id)}
          onToggleFavorite={handleToggleFavorite}
        />
      )}
    </div>
  );
}
