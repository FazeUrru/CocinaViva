import { useState } from 'react';
import { Code2, Zap, Crown, Settings, CheckCircle } from 'lucide-react';

interface DeveloperPanelProps {
  isVisible: boolean;
}

export function DeveloperPanel({ isVisible }: DeveloperPanelProps) {
  const [currentPlan, setCurrentPlan] = useState<'free' | 'ultra' | 'masterchef'>('ultra');

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 right-4 bg-gradient-to-br from-purple-900 to-indigo-900 text-white rounded-2xl shadow-2xl p-6 max-w-md z-50 border-2 border-purple-400">
      <div className="flex items-center gap-3 mb-4 pb-4 border-b border-purple-400">
        <div className="w-10 h-10 bg-purple-500 rounded-xl flex items-center justify-center">
          <Code2 className="w-5 h-5" />
        </div>
        <div>
          <h3 className="font-bold text-lg">Panel de Desarrollador</h3>
          <p className="text-xs text-purple-200">Modo de pruebas activo</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="text-xs font-semibold text-purple-200 mb-2 block">
            Plan Activo (Solo visible para ti)
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setCurrentPlan('free')}
              className={`p-3 rounded-lg text-xs font-bold transition-all ${
                currentPlan === 'free'
                  ? 'bg-white text-purple-900 shadow-lg'
                  : 'bg-purple-800 hover:bg-purple-700'
              }`}
            >
              <Settings className="w-4 h-4 mx-auto mb-1" />
              Básico
            </button>
            <button
              onClick={() => setCurrentPlan('ultra')}
              className={`p-3 rounded-lg text-xs font-bold transition-all ${
                currentPlan === 'ultra'
                  ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white shadow-lg scale-105'
                  : 'bg-purple-800 hover:bg-purple-700'
              }`}
            >
              <Zap className="w-4 h-4 mx-auto mb-1" />
              Ultra
            </button>
            <button
              onClick={() => setCurrentPlan('masterchef')}
              className={`p-3 rounded-lg text-xs font-bold transition-all ${
                currentPlan === 'masterchef'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg scale-105'
                  : 'bg-purple-800 hover:bg-purple-700'
              }`}
            >
              <Crown className="w-4 h-4 mx-auto mb-1" />
              Master
            </button>
          </div>
        </div>

        <div className="bg-purple-800 bg-opacity-50 rounded-xl p-4">
          <h4 className="font-bold text-sm mb-3 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-400" />
            Acceso Activo
          </h4>
          <div className="space-y-2 text-xs">
            {currentPlan === 'free' && (
              <>
                <div className="flex justify-between">
                  <span className="text-purple-200">Recetas:</span>
                  <span className="font-bold">500</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Favoritos:</span>
                  <span className="font-bold">10 max</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Logros:</span>
                  <span className="font-bold">5</span>
                </div>
              </>
            )}
            {currentPlan === 'ultra' && (
              <>
                <div className="flex justify-between">
                  <span className="text-purple-200">Recetas:</span>
                  <span className="font-bold text-orange-300">800</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Favoritos:</span>
                  <span className="font-bold text-orange-300">Ilimitados</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Logros:</span>
                  <span className="font-bold text-orange-300">50</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Thermomix:</span>
                  <span className="font-bold text-green-300">✓ Completo</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Precio:</span>
                  <span className="font-bold text-orange-300">5.99€/mes</span>
                </div>
              </>
            )}
            {currentPlan === 'masterchef' && (
              <>
                <div className="flex justify-between">
                  <span className="text-purple-200">Recetas:</span>
                  <span className="font-bold text-pink-300">1.000+</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Favoritos:</span>
                  <span className="font-bold text-pink-300">Ilimitados</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Logros:</span>
                  <span className="font-bold text-pink-300">100 (Todos)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Thermomix:</span>
                  <span className="font-bold text-green-300">✓ Completo</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Asistente IA:</span>
                  <span className="font-bold text-green-300">✓ Activo</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Precio:</span>
                  <span className="font-bold text-pink-300">12.50€/mes</span>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="bg-yellow-500 bg-opacity-20 border border-yellow-400 rounded-lg p-3">
          <p className="text-xs text-yellow-200">
            <span className="font-bold">⚠️ Modo Prueba:</span> Estás usando el plan{' '}
            <span className="font-bold uppercase">{currentPlan}</span> con todas sus funcionalidades.
          </p>
        </div>
      </div>
    </div>
  );
}
