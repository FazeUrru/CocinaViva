export function Logo({ size = 40, className = '' }: { size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f97316" />
          <stop offset="50%" stopColor="#ef4444" />
          <stop offset="100%" stopColor="#dc2626" />
        </linearGradient>
        <linearGradient id="potGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#374151" />
          <stop offset="100%" stopColor="#1f2937" />
        </linearGradient>
        <linearGradient id="steamGradient" x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      
      {/* Background circle */}
      <circle cx="50" cy="50" r="48" fill="url(#logoGradient)" />
      
      {/* Pot body */}
      <path
        d="M25 45 L25 70 Q25 78 33 78 L67 78 Q75 78 75 70 L75 45 Z"
        fill="url(#potGradient)"
      />
      
      {/* Pot rim */}
      <rect x="22" y="42" width="56" height="6" rx="2" fill="#4b5563" />
      
      {/* Pot handles */}
      <rect x="14" y="50" width="10" height="6" rx="2" fill="#6b7280" />
      <rect x="76" y="50" width="10" height="6" rx="2" fill="#6b7280" />
      
      {/* Lid */}
      <ellipse cx="50" cy="42" rx="26" ry="4" fill="#6b7280" />
      <rect x="47" y="32" width="6" height="10" rx="2" fill="#9ca3af" />
      <ellipse cx="50" cy="32" rx="5" ry="3" fill="#d1d5db" />
      
      {/* Steam lines */}
      <path
        d="M35 28 Q33 22 35 16"
        stroke="url(#steamGradient)"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M50 25 Q48 18 50 10"
        stroke="url(#steamGradient)"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M65 28 Q67 22 65 16"
        stroke="url(#steamGradient)"
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
      />
      
      {/* Flame under pot */}
      <path
        d="M40 82 Q42 88 40 92 Q38 88 40 82"
        fill="#fbbf24"
      />
      <path
        d="M50 80 Q53 88 50 94 Q47 88 50 80"
        fill="#f97316"
      />
      <path
        d="M60 82 Q62 88 60 92 Q58 88 60 82"
        fill="#fbbf24"
      />
      
      {/* Decorative spoon */}
      <ellipse cx="78" cy="35" rx="4" ry="6" fill="#d97706" transform="rotate(-30 78 35)" />
      <rect x="80" y="28" width="3" height="14" rx="1" fill="#b45309" transform="rotate(-30 81 35)" />
    </svg>
  );
}

export function LogoText({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <Logo size={36} />
      <div className="flex flex-col">
        <span className="text-lg font-black tracking-tight bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
          CocinaViva
        </span>
        <span className="text-[9px] font-bold text-white bg-gradient-to-r from-orange-500 to-red-500 px-1.5 py-0.5 rounded-full -mt-0.5 self-start">
          BETA v0.9
        </span>
      </div>
    </div>
  );
}
