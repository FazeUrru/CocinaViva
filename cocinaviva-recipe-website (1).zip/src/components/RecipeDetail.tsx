import { X, Clock, Users, Star, Flame, ChefHat, ArrowLeft, Printer, Share2 } from 'lucide-react';
import type { Recipe } from '../data/recipes';

interface RecipeDetailProps {
  recipe: Recipe;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
}

export function RecipeDetail({ recipe, onClose, isFavorite, onToggleFavorite }: RecipeDetailProps) {
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-start justify-center overflow-y-auto p-4 backdrop-blur-sm">
      <div className="bg-white rounded-3xl max-w-3xl w-full my-8 overflow-hidden shadow-2xl animate-in">
        {/* Header Image */}
        <div className="relative h-64"
          style={{ background: `linear-gradient(135deg, #${recipe.image.split('/')[4]}, #${recipe.image.split('/')[4]}88)` }}>
          <div className="absolute inset-0 flex items-center justify-center text-white">
            <div className="text-center">
              <ChefHat className="w-16 h-16 mx-auto mb-3 opacity-80" />
              <h2 className="text-2xl font-bold px-4">{recipe.name}</h2>
            </div>
          </div>
          <div className="absolute top-4 left-4 flex gap-2">
            <button onClick={onClose} className="bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors shadow-lg">
              <ArrowLeft className="w-5 h-5 text-gray-700" />
            </button>
          </div>
          <div className="absolute top-4 right-4 flex gap-2">
            <button onClick={() => onToggleFavorite(recipe.id)} className={`rounded-full p-2 transition-colors shadow-lg ${isFavorite ? 'bg-red-500 text-white' : 'bg-white/90 backdrop-blur-sm text-gray-700 hover:bg-white'}`}>
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill={isFavorite ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
              </svg>
            </button>
            <button className="bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors shadow-lg">
              <Share2 className="w-5 h-5 text-gray-700" />
            </button>
            <button className="bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors shadow-lg">
              <Printer className="w-5 h-5 text-gray-700" />
            </button>
            <button onClick={onClose} className="bg-white/90 backdrop-blur-sm rounded-full p-2 hover:bg-white transition-colors shadow-lg">
              <X className="w-5 h-5 text-gray-700" />
            </button>
          </div>
          <div className="absolute bottom-4 left-4 flex gap-2">
            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${recipe.type === 'thermomix' ? 'bg-blue-500 text-white' : 'bg-orange-500 text-white'}`}>
              {recipe.type === 'thermomix' ? '🤖 Thermomix' : '👨‍🍳 Tradicional'}
            </span>
          </div>
        </div>

        {/* Info Bar */}
        <div className="grid grid-cols-4 gap-4 p-6 bg-gray-50 border-b">
          <div className="text-center">
            <Clock className="w-5 h-5 mx-auto text-orange-500 mb-1" />
            <p className="text-sm font-semibold text-gray-800">{recipe.time}</p>
            <p className="text-xs text-gray-500">Tiempo</p>
          </div>
          <div className="text-center">
            <Users className="w-5 h-5 mx-auto text-orange-500 mb-1" />
            <p className="text-sm font-semibold text-gray-800">{recipe.servings} pers.</p>
            <p className="text-xs text-gray-500">Raciones</p>
          </div>
          <div className="text-center">
            <Star className="w-5 h-5 mx-auto text-yellow-400 fill-yellow-400 mb-1" />
            <p className="text-sm font-semibold text-gray-800">{recipe.rating}/5</p>
            <p className="text-xs text-gray-500">Valoración</p>
          </div>
          <div className="text-center">
            <Flame className="w-5 h-5 mx-auto text-red-500 mb-1" />
            <p className="text-sm font-semibold text-gray-800">{recipe.calories} kcal</p>
            <p className="text-xs text-gray-500">Calorías</p>
          </div>
        </div>

        {/* Meta info */}
        <div className="px-6 pt-4 flex flex-wrap gap-2">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            recipe.difficulty === 'Fácil' ? 'bg-green-100 text-green-700' :
            recipe.difficulty === 'Media' ? 'bg-yellow-100 text-yellow-700' :
            'bg-red-100 text-red-700'
          }`}>{recipe.difficulty}</span>
          <span className="px-3 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-700">{recipe.category}</span>
          <span className="px-3 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-700">📍 {recipe.region}</span>
          {recipe.tags.map(tag => (
            <span key={tag} className="px-3 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-600">{tag}</span>
          ))}
        </div>

        {/* Ingredients */}
        <div className="p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600">🧂</span>
            Ingredientes
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {recipe.ingredients.map((ingredient, i) => (
              <label key={i} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer group">
                <input type="checkbox" className="w-4 h-4 text-orange-500 rounded border-gray-300 focus:ring-orange-500" />
                <span className="text-sm text-gray-700 group-hover:text-gray-900">{ingredient}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Steps */}
        <div className="p-6 bg-gray-50">
          <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
            <span className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center text-orange-600">📝</span>
            Preparación {recipe.type === 'thermomix' && <span className="text-xs bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full">Modo Thermomix</span>}
          </h3>
          <div className="space-y-4">
            {recipe.steps.map((step, i) => (
              <div key={i} className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {i + 1}
                </div>
                <div className="flex-1 pt-1">
                  <p className="text-sm text-gray-700 leading-relaxed">{step}</p>
                  {recipe.type === 'thermomix' && (
                    <p className="text-xs text-blue-600 mt-1 bg-blue-50 inline-block px-2 py-1 rounded">
                      ⚙️ Vel. {Math.floor(Math.random() * 10) + 1} | {Math.floor(Math.random() * 120) + 37}°C | {Math.floor(Math.random() * 15) + 1} min
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Tips */}
        <div className="p-6">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
            <h4 className="font-semibold text-amber-800 mb-2">💡 Consejo del Chef</h4>
            <p className="text-sm text-amber-700">Para obtener el mejor resultado, utiliza ingredientes frescos y de temporada. No tengas prisa en la cocción, el secreto está en el tiempo y la paciencia.</p>
          </div>
        </div>

        {/* Close Button */}
        <div className="p-6 pt-0">
          <button onClick={onClose} className="w-full py-3 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-semibold transition-colors">
            Cerrar Receta
          </button>
        </div>
      </div>
    </div>
  );
}
