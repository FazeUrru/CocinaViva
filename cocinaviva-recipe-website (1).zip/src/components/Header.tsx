import { Menu, X, Search, Sparkles, TrendingUp, Zap } from 'lucide-react';
import { useState } from 'react';
import { Logo } from './Logo';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

const navItems = [
  { key: 'home', label: 'Inicio' },
  { key: 'recipes', label: 'Recetas' },
  { key: 'categories', label: 'Categorías' },
  { key: 'features', label: 'Funciones' },
  { key: 'plans', label: 'Planes' },
  { key: 'settings', label: 'Ajustes' },
  { key: 'about', label: 'Acerca de' },
];

export function Header({ currentPage, onNavigate, searchQuery, onSearchChange }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
      {/* Quick Action Buttons */}
      <div className="bg-gradient-to-r from-orange-500 to-red-500 py-1">
        <div className="max-w-7xl mx-auto px-3 flex items-center justify-center gap-2 md:gap-4">
          <button
            onClick={() => onNavigate('recipes')}
            className="flex items-center gap-1 px-2 md:px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-white text-[10px] md:text-xs font-bold transition-all"
          >
            <Sparkles className="w-3 h-3" />
            <span className="hidden sm:inline">500 Recetas Nuevas</span>
            <span className="sm:hidden">Nuevas</span>
          </button>
          <button
            onClick={() => onNavigate('plans')}
            className="flex items-center gap-1 px-2 md:px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-white text-[10px] md:text-xs font-bold transition-all"
          >
            <Zap className="w-3 h-3" />
            <span className="hidden sm:inline">Ver Planes</span>
            <span className="sm:hidden">Planes</span>
          </button>
          <button
            onClick={() => onNavigate('features')}
            className="flex items-center gap-1 px-2 md:px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-white text-[10px] md:text-xs font-bold transition-all"
          >
            <TrendingUp className="w-3 h-3" />
            <span className="hidden sm:inline">18 Funciones</span>
            <span className="sm:hidden">Funciones</span>
          </button>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-3">
        <div className="flex items-center justify-between h-12">
          {/* Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <Logo size={28} />
            <div className="hidden sm:block">
              <h1 className="text-base font-black text-gray-900 tracking-tight leading-none">CocinaViva</h1>
              <span className="text-[8px] bg-gradient-to-r from-orange-500 to-red-500 text-white px-1 py-0.5 rounded-full font-bold">BETA v0.9</span>
            </div>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-0.5">
            {navItems.map(item => (
              <button
                key={item.key}
                onClick={() => onNavigate(item.key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  currentPage === item.key
                    ? 'bg-orange-100 text-orange-700'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Search & Mobile Toggle */}
          <div className="flex items-center gap-1">
            {searchOpen && (
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => onSearchChange(e.target.value)}
                  placeholder="Buscar recetas..."
                  className="w-36 md:w-52 pl-2 pr-6 py-1.5 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-400 focus:border-transparent"
                  autoFocus
                />
                <button onClick={() => { setSearchOpen(false); onSearchChange(''); }} className="absolute right-2 top-1/2 -translate-y-1/2">
                  <X className="w-3 h-3 text-gray-400" />
                </button>
              </div>
            )}
            <button
              onClick={() => { setSearchOpen(!searchOpen); if (searchOpen) onSearchChange(''); }}
              className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <Search className="w-4 h-4 text-gray-600" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden pb-3 border-t border-gray-100 mt-1 pt-1">
            {navItems.map(item => (
              <button
                key={item.key}
                onClick={() => { onNavigate(item.key); setMobileMenuOpen(false); }}
                className={`block w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                  currentPage === item.key
                    ? 'bg-orange-100 text-orange-700'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}
