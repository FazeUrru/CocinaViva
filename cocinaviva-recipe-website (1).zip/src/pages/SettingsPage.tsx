
import { useState, useEffect } from 'react';
import { settings, settingCategories, achievements, achievementCategories } from '../data/features';
import { Settings, Palette, Bell, Shield, Eye, RotateCcw, Save, CheckCircle, ChefHat, Trophy, Star, Lock, FlaskConical, User, Code } from 'lucide-react';
import { DeveloperPanel } from '../components/DeveloperPanel';


const iconMap: Record<string, React.ElementType> = {
  Settings, Palette, Bell, Shield, Eye, ChefHat, FlaskConical, User, Code,
};

export function SettingsPage() {
  const [activeCategory, setActiveCategory] = useState('general');
  const [activeTab, setActiveTab] = useState<'settings' | 'achievements'>('settings');
  const [settingsState, setSettingsState] = useState<Record<number, boolean | string | number>>(
    Object.fromEntries(settings.map(s => [s.id, s.defaultValue]))
  );
  const [saved, setSaved] = useState(false);
  const [achievementCategory, setAchievementCategory] = useState('recetas');
  const [devModeUnlocked, setDevModeUnlocked] = useState(false);
  const [clickCount, setClickCount] = useState(0);

  // Aplicar el tamaño de tipografía a toda la app
  useEffect(() => {
    const tipografiaSetting = settings.find(s => s.name === 'Ampliar Tipografía');
    if (tipografiaSetting) {
      const size = settingsState[tipografiaSetting.id] as string;
      const fontSizeMap: Record<string, string> = {
        'pequeño': '11px',
        'mediano': '12px',
        'grande': '14px',
        'enorme': '16px',
      };
      document.documentElement.style.fontSize = fontSizeMap[size] || '12px';
    }
  }, [settingsState]);

  const handleVersionClick = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);
    if (newCount >= 7) {
      setDevModeUnlocked(true);
      setClickCount(0);
    }
  };

  const filteredSettings = settings.filter(s => s.category === activeCategory);
  const filteredAchievements = achievements.filter(a => a.category === achievementCategory);

  const handleToggle = (id: number) => {
    setSettingsState(prev => ({ ...prev, [id]: !prev[id] }));
    setSaved(false);
  };

  const handleSelect = (id: number, value: string) => {
    setSettingsState(prev => ({ ...prev, [id]: value }));
    setSaved(false);
  };

  const handleSlider = (id: number, value: number) => {
    setSettingsState(prev => ({ ...prev, [id]: value }));
    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleReset = () => {
    setSettingsState(Object.fromEntries(settings.map(s => [s.id, s.defaultValue])));
    setSaved(false);
  };

  const totalPoints = achievements.filter(a => a.unlocked).reduce((sum, a) => sum + a.points, 0);
  const unlockedCount = achievements.filter(a => a.unlocked).length;

  return (
    <div className="max-w-5xl mx-auto px-3 py-6">
      {/* Header con versión */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-gray-700 to-gray-900 rounded-xl flex items-center justify-center">
            <Settings className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Ajustes</h1>
            <p className="text-gray-500 text-xs">37 ajustes • 100 logros disponibles</p>
          </div>
        </div>
        <div className="text-right">
          <span 
            onClick={handleVersionClick}
            className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-xs font-bold cursor-pointer hover:shadow-lg transition-shadow"
          >
            BETA v0.9 {clickCount > 0 && clickCount < 7 && `(${clickCount}/7)`}
          </span>
          <p className="text-[10px] text-gray-400 mt-1">CocinaViva</p>
          {devModeUnlocked && clickCount === 0 && (
            <p className="text-[10px] text-green-600 font-bold mt-1">🔓 Modo Desarrollador</p>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeTab === 'settings' ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          <Settings className="w-4 h-4" />
          Ajustes (71)
        </button>
        <button
          onClick={() => setActiveTab('achievements')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
            activeTab === 'achievements' ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          <Trophy className="w-4 h-4" />
          Logros (100)
        </button>
      </div>

      {activeTab === 'settings' ? (
        <div className="flex flex-col md:flex-row gap-4">
          {/* Sidebar */}
          <div className="md:w-44 flex-shrink-0">
            <div className="bg-white border border-gray-100 rounded-xl p-1.5 shadow-sm sticky top-20">
              {settingCategories.map(cat => {
                const Icon = iconMap[cat.icon] || Settings;
                const count = settings.filter(s => s.category === cat.key).length;
                return (
                  <button
                    key={cat.key}
                    onClick={() => setActiveCategory(cat.key)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                      activeCategory === cat.key
                        ? 'bg-orange-100 text-orange-700'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    <span>{cat.label}</span>
                    <span className="ml-auto text-[10px] bg-gray-200 text-gray-600 rounded-full px-1.5 py-0.5">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Settings Content */}
          <div className="flex-1">
            <div className="bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 bg-gray-50 border-b flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-gray-900">
                    {settingCategories.find(c => c.key === activeCategory)?.label}
                  </h2>
                  <p className="text-xs text-gray-500">{filteredSettings.length} ajustes</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleReset}
                    className="flex items-center gap-1 px-3 py-1.5 text-xs font-medium text-gray-600 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    Restablecer
                  </button>
                  <button
                    onClick={handleSave}
                    className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                      saved
                        ? 'bg-green-500 text-white'
                        : 'bg-orange-500 text-white hover:bg-orange-600'
                    }`}
                  >
                    {saved ? <CheckCircle className="w-3 h-3" /> : <Save className="w-3 h-3" />}
                    {saved ? 'Guardado' : 'Guardar'}
                  </button>
                </div>
              </div>

              <div className="divide-y divide-gray-100">
                {filteredSettings.map(setting => (
                  <div key={setting.id} className="p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 text-sm mb-0.5">{setting.name}</h3>
                        <p className="text-xs text-gray-500">{setting.description}</p>
                      </div>
                      <div className="flex-shrink-0">
                        {setting.type === 'toggle' && (
                          <button
                            onClick={() => handleToggle(setting.id)}
                            className={`relative w-11 h-6 rounded-full transition-colors ${
                              settingsState[setting.id] ? 'bg-orange-500' : 'bg-gray-300'
                            }`}
                          >
                            <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-md transition-transform ${
                              settingsState[setting.id] ? 'translate-x-5' : 'translate-x-0.5'
                            }`}></div>
                          </button>
                        )}
                        {setting.type === 'select' && (
                          <select
                            value={settingsState[setting.id] as string}
                            onChange={e => handleSelect(setting.id, e.target.value)}
                            className="px-2 py-1 border border-gray-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-orange-400 bg-white"
                          >
                            {setting.name === 'Tamaño de Texto' && ['pequeño', 'mediano', 'grande', 'muy grande'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Ampliar Tipografía' && ['pequeño', 'mediano', 'grande', 'enorme'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Unidades de Medida' && ['métrico', 'imperial'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Idioma' && ['español', 'english', 'français', 'deutsch', 'português'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Color de Acento' && ['naranja', 'rojo', 'azul', 'verde', 'morado', 'rosa'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Densidad de Tarjetas' && ['compacto', 'normal', 'espaciado'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Modo Daltónico' && ['desactivado', 'protanopia', 'deuteranopia', 'tritanopia'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Nivel de Cocina' && ['principiante', 'intermedio', 'avanzado', 'experto'].map(v => <option key={v} value={v}>{v}</option>)}
                            {setting.name === 'Preferencias Dietéticas' && ['ninguna', 'vegetariano', 'vegano', 'sin gluten', 'bajo en calorías'].map(v => <option key={v} value={v}>{v}</option>)}
                          </select>
                        )}
                        {setting.type === 'slider' && (
                          <div className="flex items-center gap-2">
                            <input
                              type="range"
                              min={1}
                              max={12}
                              value={settingsState[setting.id] as number}
                              onChange={e => handleSlider(setting.id, parseInt(e.target.value))}
                              className="w-20 accent-orange-500"
                            />
                            <span className="text-xs font-semibold text-gray-700 w-6 text-center">{settingsState[setting.id]}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Resumen de todos los ajustes */}
            <div className="mt-6 bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden">
              <div className="p-4 bg-gray-50 border-b flex items-center justify-between">
                <h2 className="text-base font-bold text-gray-900">Todos los Ajustes (37)</h2>
                <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold">
                  BETA v0.9
                </span>
              </div>
              <div className="overflow-x-auto max-h-64 overflow-y-auto">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-gray-50">
                    <tr className="text-left">
                      <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">#</th>
                      <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Ajuste</th>
                      <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Categoría</th>
                      <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Estado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {settings.map((setting, i) => (
                      <tr key={setting.id} className="hover:bg-gray-50">
                        <td className="px-3 py-2 text-gray-500">{i + 1}</td>
                        <td className="px-3 py-2 font-medium text-gray-900">{setting.name}</td>
                        <td className="px-3 py-2">
                          <span className="px-1.5 py-0.5 bg-gray-100 rounded-full text-[10px] font-medium text-gray-600 capitalize">{setting.category}</span>
                        </td>
                        <td className="px-3 py-2">
                          {setting.type === 'toggle' ? (
                            <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${settingsState[setting.id] ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                              {settingsState[setting.id] ? 'Activo' : 'Inactivo'}
                            </span>
                          ) : (
                            <span className="text-gray-700 font-medium">{String(settingsState[setting.id])}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Achievements Tab */
        <div>
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            <div className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-xl p-4 text-white">
              <Trophy className="w-6 h-6 mb-2" />
              <p className="text-2xl font-black">{unlockedCount}/100</p>
              <p className="text-xs opacity-80">Logros Desbloqueados</p>
            </div>
            <div className="bg-gradient-to-br from-purple-400 to-indigo-500 rounded-xl p-4 text-white">
              <Star className="w-6 h-6 mb-2" />
              <p className="text-2xl font-black">{totalPoints}</p>
              <p className="text-xs opacity-80">Puntos Totales</p>
            </div>
            <div className="bg-gradient-to-br from-green-400 to-emerald-500 rounded-xl p-4 text-white">
              <CheckCircle className="w-6 h-6 mb-2" />
              <p className="text-2xl font-black">{Math.round((unlockedCount / 100) * 100)}%</p>
              <p className="text-xs opacity-80">Completado</p>
            </div>
            <div className="bg-gradient-to-br from-blue-400 to-cyan-500 rounded-xl p-4 text-white">
              <Lock className="w-6 h-6 mb-2" />
              <p className="text-2xl font-black">{100 - unlockedCount}</p>
              <p className="text-xs opacity-80">Por Desbloquear</p>
            </div>
          </div>

          {/* Achievement Categories */}
          <div className="flex flex-wrap gap-1 mb-4">
            {achievementCategories.map(cat => (
              <button
                key={cat.key}
                onClick={() => setAchievementCategory(cat.key)}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  achievementCategory === cat.key
                    ? 'bg-orange-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
                <span className="ml-1 bg-white/20 px-1 rounded text-[10px]">
                  {achievements.filter(a => a.category === cat.key).length}
                </span>
              </button>
            ))}
          </div>

          {/* Achievements Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredAchievements.map(achievement => (
              <div
                key={achievement.id}
                className={`relative rounded-xl p-4 border transition-all ${
                  achievement.unlocked
                    ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200'
                    : 'bg-gray-50 border-gray-200 opacity-60'
                }`}
              >
                {!achievement.unlocked && (
                  <div className="absolute top-2 right-2">
                    <Lock className="w-3 h-3 text-gray-400" />
                  </div>
                )}
                <div className="flex items-start gap-3">
                  <div className={`text-2xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                    {achievement.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className={`font-bold text-sm ${achievement.unlocked ? 'text-gray-900' : 'text-gray-500'}`}>
                      {achievement.name}
                    </h3>
                    <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{achievement.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        achievement.unlocked ? 'bg-yellow-200 text-yellow-800' : 'bg-gray-200 text-gray-600'
                      }`}>
                        +{achievement.points} pts
                      </span>
                      {achievement.unlocked && (
                        <span className="text-[10px] text-green-600 font-medium">✓ Desbloqueado</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* All achievements summary */}
          <div className="mt-6 bg-white border border-gray-100 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 bg-gray-50 border-b">
              <h2 className="text-base font-bold text-gray-900">Todos los Logros (100)</h2>
            </div>
            <div className="overflow-x-auto max-h-64 overflow-y-auto">
              <table className="w-full text-xs">
                <thead className="sticky top-0 bg-gray-50">
                  <tr className="text-left">
                    <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">#</th>
                    <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Icono</th>
                    <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Logro</th>
                    <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Categoría</th>
                    <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Puntos</th>
                    <th className="px-3 py-2 text-[10px] font-semibold text-gray-500 uppercase">Estado</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {achievements.map((achievement, i) => (
                    <tr key={achievement.id} className={`hover:bg-gray-50 ${!achievement.unlocked ? 'opacity-50' : ''}`}>
                      <td className="px-3 py-2 text-gray-500">{i + 1}</td>
                      <td className="px-3 py-2">{achievement.icon}</td>
                      <td className="px-3 py-2 font-medium text-gray-900">{achievement.name}</td>
                      <td className="px-3 py-2">
                        <span className="px-1.5 py-0.5 bg-gray-100 rounded-full text-[10px] font-medium text-gray-600 capitalize">{achievement.category}</span>
                      </td>
                      <td className="px-3 py-2 font-bold text-orange-600">+{achievement.points}</td>
                      <td className="px-3 py-2">
                        <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-medium ${
                          achievement.unlocked ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'
                        }`}>
                          {achievement.unlocked ? '✓ Desbloqueado' : 'Bloqueado'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Version info footer */}
      <div className="mt-8 text-center">
        <div className="inline-flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-full">
          <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold">
            BETA v0.9
          </span>
          <span className="text-xs text-gray-600">CocinaViva — 37 Ajustes • 100 Logros • 18 Funciones</span>
        </div>
      </div>

      {/* Developer Panel */}
      <DeveloperPanel isVisible={devModeUnlocked} />
    </div>
  );
}
