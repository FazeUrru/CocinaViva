import { Shield, Lock, Eye, AlertCircle, CheckCircle, FileText, Mail } from 'lucide-react';
import { Logo } from '../components/Logo';

export function PrivacyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="text-center mb-10">
        <div className="flex justify-center mb-4">
          <Logo size={48} />
        </div>
        <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium mb-3">
          <Shield className="w-3 h-3" />
          Política de Privacidad
        </div>
        <h1 className="text-3xl font-black text-gray-900 mb-2">Política de Privacidad</h1>
        <p className="text-gray-500 text-sm">
          Última actualización: Diciembre 2024 • Versión Beta v0.9
        </p>
      </div>

      {/* Resumen Ejecutivo */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200 rounded-2xl p-6 mb-8">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center flex-shrink-0">
            <CheckCircle className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900 mb-2">Resumen Ejecutivo</h2>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-green-500 font-bold">✓</span>
                <span>No vendemos tus datos personales a terceros</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-500 font-bold">✓</span>
                <span>Usamos encriptación SSL/TLS para proteger tu información</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-500 font-bold">✓</span>
                <span>Puedes eliminar tu cuenta y todos tus datos en cualquier momento</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-500 font-bold">✓</span>
                <span>Cumplimos con el RGPD (Reglamento General de Protección de Datos)</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Secciones */}
      <div className="space-y-8">
        {/* 1. Información que Recopilamos */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Eye className="w-5 h-5 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">1. Información que Recopilamos</h2>
          </div>
          
          <div className="space-y-4 text-sm text-gray-700">
            <div>
              <h3 className="font-bold text-gray-900 mb-2">1.1 Información que proporcionas directamente</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Nombre de usuario y correo electrónico (requerido para registro)</li>
                <li>Preferencias dietéticas y alergias alimentarias (opcional)</li>
                <li>Recetas favoritas y listas de compra</li>
                <li>Valoraciones y comentarios de recetas</li>
                <li>Información de perfil (país, ciudad, nivel de cocina, etc.)</li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">1.2 Información recopilada automáticamente</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Dirección IP y tipo de dispositivo</li>
                <li>Navegador web y sistema operativo</li>
                <li>Páginas visitadas y tiempo de uso</li>
                <li>Historial de búsquedas y recetas visualizadas</li>
                <li>Cookies técnicas y de análisis</li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-2">1.3 Información de terceros</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Inicio de sesión con redes sociales (opcional)</li>
                <li>Información pública de tu perfil social si lo vinculas</li>
              </ul>
            </div>
          </div>
        </section>

        {/* 2. Cómo Usamos tu Información */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">2. Cómo Usamos tu Información</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <div className="flex items-start gap-2">
              <span className="text-orange-500 font-bold mt-0.5">•</span>
              <div>
                <strong>Proveer el servicio:</strong> Gestionar tu cuenta, guardar tus preferencias, mostrar recetas personalizadas
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-orange-500 font-bold mt-0.5">•</span>
              <div>
                <strong>Mejorar la experiencia:</strong> Analizar el uso de la app para optimizar funciones y contenido
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-orange-500 font-bold mt-0.5">•</span>
              <div>
                <strong>Comunicación:</strong> Enviarte notificaciones sobre actualizaciones, nuevas recetas y funciones (si lo autorizas)
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-orange-500 font-bold mt-0.5">•</span>
              <div>
                <strong>Seguridad:</strong> Prevenir fraudes, abusos y proteger la seguridad de la plataforma
              </div>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-orange-500 font-bold mt-0.5">•</span>
              <div>
                <strong>Cumplimiento legal:</strong> Cumplir con obligaciones legales y responder a solicitudes de autoridades
              </div>
            </div>
          </div>
        </section>

        {/* 3. Compartir Información */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Lock className="w-5 h-5 text-purple-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">3. Compartir tu Información</h2>
          </div>
          
          <div className="space-y-4 text-sm text-gray-700">
            <p className="font-semibold text-gray-900">
              <strong>NO vendemos</strong> tu información personal a terceros. Solo compartimos datos en estos casos:
            </p>
            
            <div className="space-y-3">
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-bold text-gray-900 mb-1">Proveedores de servicios</h4>
                <p className="text-xs">Empresas que nos ayudan a operar (hosting, análisis, pagos). Tienen acceso limitado y están obligados a proteger tu información.</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-bold text-gray-900 mb-1">Requisitos legales</h4>
                <p className="text-xs">Si la ley nos obliga o para proteger nuestros derechos legales.</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-bold text-gray-900 mb-1">Transferencia de negocio</h4>
                <p className="text-xs">En caso de fusión, adquisición o venta de activos (se te notificará).</p>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-bold text-gray-900 mb-1">Con tu consentimiento</h4>
                <p className="text-xs">Si autorizas específicamente compartir tu información (ej: conectar redes sociales).</p>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Cookies */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-yellow-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">4. Uso de Cookies</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>Utilizamos cookies y tecnologías similares para:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <h4 className="font-bold text-blue-900 mb-1 text-xs">Cookies Esenciales</h4>
                <p className="text-xs text-blue-700">Necesarias para el funcionamiento básico (sesión, seguridad). No se pueden desactivar.</p>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                <h4 className="font-bold text-green-900 mb-1 text-xs">Cookies de Preferencias</h4>
                <p className="text-xs text-green-700">Guardan tus configuraciones (idioma, tema, favoritos).</p>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <h4 className="font-bold text-purple-900 mb-1 text-xs">Cookies Analíticas</h4>
                <p className="text-xs text-purple-700">Nos ayudan a entender cómo usas la app (Google Analytics). Puedes desactivarlas.</p>
              </div>
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                <h4 className="font-bold text-orange-900 mb-1 text-xs">Cookies de Marketing</h4>
                <p className="text-xs text-orange-700">Para mostrarte contenido relevante. Requieren tu consentimiento.</p>
              </div>
            </div>
            <p className="text-xs italic mt-3">Puedes gestionar las cookies en la configuración de tu navegador o en nuestros ajustes.</p>
          </div>
        </section>

        {/* 5. Tus Derechos */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-red-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">5. Tus Derechos (RGPD)</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            {[
              { title: 'Acceso', desc: 'Solicitar una copia de tus datos personales' },
              { title: 'Rectificación', desc: 'Corregir datos inexactos o incompletos' },
              { title: 'Eliminación', desc: 'Eliminar tu cuenta y todos tus datos ("derecho al olvido")' },
              { title: 'Portabilidad', desc: 'Recibir tus datos en formato estructurado' },
              { title: 'Oposición', desc: 'Oponerte al procesamiento de tus datos' },
              { title: 'Limitación', desc: 'Restringir el procesamiento de tus datos' },
            ].map((right, i) => (
              <div key={i} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <h4 className="font-bold text-gray-900 mb-1">{right.title}</h4>
                <p className="text-xs text-gray-600">{right.desc}</p>
              </div>
            ))}
          </div>
          
          <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-xs text-blue-800">
              <strong>Para ejercer tus derechos,</strong> envíanos un email a{' '}
              <a href="mailto:privacidad@cocinaviva.com" className="font-bold underline hover:text-blue-600">
                privacidad@cocinaviva.com
              </a>{' '}
              con el asunto "Ejercicio de Derechos RGPD".
            </p>
          </div>
        </section>

        {/* 6. Seguridad */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
              <Lock className="w-5 h-5 text-indigo-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">6. Seguridad de los Datos</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>Implementamos medidas técnicas y organizativas para proteger tu información:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>Encriptación SSL/TLS</strong> para todas las comunicaciones</li>
              <li><strong>Contraseñas hasheadas</strong> con algoritmos seguros (bcrypt)</li>
              <li><strong>Acceso limitado</strong> solo a personal autorizado</li>
              <li><strong>Backups regulares</strong> y almacenamiento seguro</li>
              <li><strong>Monitoreo continuo</strong> de amenazas de seguridad</li>
              <li><strong>Actualizaciones frecuentes</strong> del software y parches de seguridad</li>
            </ul>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 mt-3">
              <p className="text-xs text-yellow-800">
                <strong>⚠️ Importante:</strong> Ningún sistema es 100% seguro. Te recomendamos usar contraseñas únicas y fuertes, y activar la autenticación de dos factores cuando esté disponible.
              </p>
            </div>
          </div>
        </section>

        {/* 7. Retención de Datos */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-teal-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">7. Retención de Datos</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>Conservamos tu información personal mientras:</p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Tu cuenta esté activa</li>
              <li>Sea necesario para prestarte el servicio</li>
              <li>Exista una obligación legal de conservarla</li>
              <li>Sea necesario para resolver disputas o hacer cumplir nuestros acuerdos</li>
            </ul>
            <p className="mt-3">
              <strong>Eliminación de cuenta:</strong> Cuando eliminas tu cuenta, eliminamos permanentemente tu información personal en un plazo de 30 días, excepto aquella que debamos conservar por ley (facturas, transacciones).
            </p>
          </div>
        </section>

        {/* 8. Menores de Edad */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-pink-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="w-5 h-5 text-pink-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">8. Privacidad de Menores</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>
              CocinaViva está dirigida a usuarios mayores de <strong>13 años</strong>. No recopilamos intencionalmente información de menores de 13 años sin consentimiento parental verificable.
            </p>
            <p>
              Si tienes entre 13 y 18 años, debes obtener permiso de tus padres o tutores antes de usar CocinaViva.
            </p>
            <p className="bg-red-50 border border-red-200 rounded-lg p-3">
              <strong>Si eres padre/madre:</strong> Si crees que tu hijo menor de 13 años nos ha proporcionado información personal, contáctanos inmediatamente para eliminarla.
            </p>
          </div>
        </section>

        {/* 9. Cambios en la Política */}
        <section className="bg-white border border-gray-200 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-gray-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">9. Cambios a esta Política</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>
              Podemos actualizar esta Política de Privacidad ocasionalmente. Te notificaremos de cambios significativos mediante:
            </p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Notificación destacada en la aplicación</li>
              <li>Email a tu dirección registrada</li>
              <li>Actualización de la fecha "Última actualización" arriba</li>
            </ul>
            <p className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <strong>Tu responsabilidad:</strong> Revisar periódicamente esta política. El uso continuado del servicio tras los cambios implica tu aceptación de la nueva política.
            </p>
          </div>
        </section>

        {/* 10. Contacto */}
        <section className="bg-gradient-to-br from-orange-50 to-red-50 border-2 border-orange-200 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <Mail className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">10. Contacto</h2>
          </div>
          
          <div className="space-y-3 text-sm text-gray-700">
            <p>
              Si tienes preguntas, inquietudes o solicitudes sobre esta Política de Privacidad o el tratamiento de tus datos personales, contáctanos:
            </p>
            <div className="bg-white rounded-lg p-4 space-y-2">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-500" />
                <strong>Email:</strong>{' '}
                <a href="mailto:privacidad@cocinaviva.com" className="text-orange-600 hover:underline">
                  privacidad@cocinaviva.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-500" />
                <strong>Email General:</strong>{' '}
                <a href="mailto:soporte@cocinaviva.com" className="text-orange-600 hover:underline">
                  soporte@cocinaviva.com
                </a>
              </div>
              <div className="flex items-start gap-2">
                <Shield className="w-4 h-4 text-orange-500 mt-0.5" />
                <div>
                  <strong>Delegado de Protección de Datos (DPO):</strong>
                  <br />
                  <a href="mailto:dpo@cocinaviva.com" className="text-orange-600 hover:underline">
                    dpo@cocinaviva.com
                  </a>
                </div>
              </div>
            </div>
            <p className="text-xs italic">
              Responderemos a tu solicitud en un plazo máximo de 30 días naturales.
            </p>
          </div>
        </section>
      </div>

      {/* Footer */}
      <div className="mt-10 text-center text-xs text-gray-400 space-y-1">
        <p>© 2024 CocinaViva — Todos los derechos reservados</p>
        <p>Última actualización: Diciembre 2024 • Versión Beta v0.9</p>
        <p className="text-gray-500">Cumplimos con el RGPD (EU) y la LOPD-GDD (España)</p>
      </div>
    </div>
  );
}
