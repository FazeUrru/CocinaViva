import { features } from '../data/features';
import {
  Search, Calendar, ShoppingCart, Gauge, Calculator, Heart,
  Timer, ArrowLeftRight, ListOrdered, Share2, Mic, ScanLine,
  CheckCircle2, Clock, Sparkles, BrainCircuit, RotateCw, Hand
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  Search, Calendar, ShoppingCart, Gauge, Calculator, Heart,
  Timer, ArrowLeftRight, ListOrdered, Share2, Mic, ScanLine,
  BrainCircuit, Replay: RotateCw, Hand
};

export function FeaturesPage() {
  const activeFeatures = features.filter(f => f.status === 'activa');
  const betaFeatures = features.filter(f => f.status === 'beta');

  return (
    <div className="max-w-7xl mx-auto px-3 py-6">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-xs font-medium mb-3">
          <Sparkles className="w-3 h-3" />
          15 Funciones Disponibles
        </div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Funciones de CocinaViva</h1>
        <p className="text-gray-500 max-w-xl mx-auto text-sm">
          Herramientas que hacen de CocinaViva tu compañero perfecto en la cocina. Versión Beta con funciones en desarrollo.
        </p>
      </div>

      {/* Active Features */}
      <div className="mb-10">
        <div className="flex items-center gap-2 mb-4">
          <CheckCircle2 className="w-5 h-5 text-green-500" />
          <h2 className="text-lg font-bold text-gray-900">Funciones Activas</h2>
          <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded-full text-xs font-medium">{activeFeatures.length}</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {activeFeatures.map(feature => {
            const Icon = iconMap[feature.icon] || Search;
            return (
              <div key={feature.id} className="bg-white border border-gray-100 rounded-xl p-4 hover:shadow-lg hover:border-orange-200 transition-all group">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-gradient-to-br from-orange-400 to-red-500 rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg shadow-orange-200 group-hover:scale-110 transition-transform">
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1 mb-0.5">
                      <h3 className="font-bold text-gray-900 text-sm">{feature.name}</h3>
                      <span className="bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full text-[9px] font-medium">Activa</span>
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Beta Features */}
      <div className="mb-10">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-blue-500" />
          <h2 className="text-lg font-bold text-gray-900">Funciones Beta</h2>
          <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-xs font-medium">{betaFeatures.length}</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {betaFeatures.map(feature => {
            const Icon = iconMap[feature.icon] || Search;
            return (
              <div key={feature.id} className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4 hover:shadow-lg transition-all group relative overflow-hidden">
                <div className="absolute top-2 right-2">
                  <span className="bg-blue-500 text-white px-1.5 py-0.5 rounded-full text-[8px] font-bold animate-pulse">BETA</span>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 bg-gradient-to-br from-blue-400 to-indigo-500 rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg shadow-blue-200 group-hover:scale-110 transition-transform">
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-sm mb-0.5">{feature.name}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Feature Comparison Table */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
        <div className="p-4 bg-gray-50 border-b">
          <h2 className="text-base font-bold text-gray-900">Resumen de Funciones</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-gray-50 text-left">
                <th className="px-4 py-2 text-[10px] font-semibold text-gray-500 uppercase">#</th>
                <th className="px-4 py-2 text-[10px] font-semibold text-gray-500 uppercase">Función</th>
                <th className="px-4 py-2 text-[10px] font-semibold text-gray-500 uppercase">Estado</th>
                <th className="px-4 py-2 text-[10px] font-semibold text-gray-500 uppercase hidden md:table-cell">Descripción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {features.map((feature, i) => (
                <tr key={feature.id} className="hover:bg-gray-50">
                  <td className="px-4 py-2 text-gray-500">{i + 1}</td>
                  <td className="px-4 py-2 font-semibold text-gray-900">{feature.name}</td>
                  <td className="px-4 py-2">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                      feature.status === 'activa' ? 'bg-green-100 text-green-700' :
                      feature.status === 'beta' ? 'bg-blue-100 text-blue-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {feature.status === 'activa' ? '✅ Activa' : feature.status === 'beta' ? '🧪 Beta' : '🔜 Próximamente'}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-gray-500 hidden md:table-cell max-w-xs truncate">{feature.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
