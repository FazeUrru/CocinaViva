import { useState } from 'react';
import { Check, X, Zap, Calendar, Gift } from 'lucide-react';
import { plans } from '../data/plans';

export function PlansPage() {
  const [billingPeriod, setBillingPeriod] = useState<'monthly' | 'annual'>('monthly');

  const getPrice = (planId: string) => {
    const plan = plans.find(p => p.id === planId)!;
    return billingPeriod === 'monthly' ? plan.price : plan.annualPrice;
  };

  const getSavings = () => {
    const ultra = plans.find(p => p.id === 'ultra')!;
    const masterchef = plans.find(p => p.id === 'masterchef')!;
    const ultraMonthly = ultra.price * 12;
    const ultraAnnual = ultra.annualPrice;
    const masterchefMonthly = masterchef.price * 12;
    const masterchefAnnual = masterchef.annualPrice;
    return {
      ultra: Math.round(((ultraMonthly - ultraAnnual) / ultraMonthly) * 100),
      masterchef: Math.round(((masterchefMonthly - masterchefAnnual) / masterchefMonthly) * 100)
    };
  };

  const savings = getSavings();

  return (
    <div className="max-w-7xl mx-auto px-3 py-8">
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-xs font-medium mb-4">
          <Zap className="w-3 h-3" />
          Planes de Suscripcion
        </div>
        <h1 className="text-3xl font-black text-gray-900 mb-2">Elige tu Plan Perfecto</h1>
        <p className="text-gray-500 max-w-xl mx-auto text-sm mb-6">
          Acceso a 1000+ recetas con 14 dias de prueba gratuita. Sin contrato, cancela cuando quieras.
        </p>

        <div className="inline-flex items-center gap-2 bg-gray-100 rounded-full p-1.5">
          <button
            onClick={() => setBillingPeriod('monthly')}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${billingPeriod === 'monthly' ? 'bg-white text-orange-600 shadow-sm' : 'text-gray-600'}`}
          >
            Mensual
          </button>
          <button
            onClick={() => setBillingPeriod('annual')}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-1 ${billingPeriod === 'annual' ? 'bg-white text-orange-600 shadow-sm' : 'text-gray-600'}`}
          >
            Anual
            <span className="bg-green-500 text-white px-1.5 py-0.5 rounded-full text-[10px] font-bold">-5.65%</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
        {plans.map((plan) => {
          const price = getPrice(plan.id);
          const isFree = plan.id === 'free';
          const isPopular = plan.popular;

          return (
            <div key={plan.id} className={`relative rounded-2xl overflow-hidden transition-all duration-300 ${isPopular ? 'border-2 border-orange-400 shadow-2xl scale-105 md:scale-100' : 'border border-gray-200 shadow-sm hover:shadow-md hover:border-orange-200'}`}>
              <div className={`absolute inset-0 bg-gradient-to-br ${plan.color} opacity-5`}></div>

              {plan.badge && (
                <div className="absolute top-4 right-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold text-white ${plan.id === 'masterchef' ? 'bg-gradient-to-r from-purple-500 to-red-500' : 'bg-gradient-to-r from-orange-500 to-red-500'}`}>
                    {plan.badge}
                  </span>
                </div>
              )}

              <div className="relative p-6 h-full bg-white">
                <h2 className="text-xl font-black text-gray-900 mb-1">{plan.name}</h2>
                <p className="text-xs text-gray-500 mb-6">{plan.description}</p>

                <div className="mb-6">
                  {isFree ? (
                    <div className="text-4xl font-black text-gray-900">Gratis</div>
                  ) : (
                    <>
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl font-black text-gray-900">${price.toFixed(2)}</span>
                        <span className="text-gray-500 text-sm">/{billingPeriod === 'monthly' ? 'mes' : 'ano'}</span>
                      </div>
                      {plan.trial > 0 && (
                        <p className="text-xs text-green-600 font-semibold mt-2 flex items-center gap-1">
                          <Gift className="w-3 h-3" />
                          {plan.trial} dias de prueba gratis
                        </p>
                      )}
                      {billingPeriod === 'annual' && plan.id !== 'free' && (
                        <div className="mt-2 inline-block">
                          <span className="text-[10px] font-bold text-white bg-green-500 px-2 py-1 rounded-full">
                            Ahorras un {plan.id === 'ultra' ? savings.ultra : savings.masterchef}% anualmente
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                <button className={`w-full py-3 rounded-xl font-bold text-sm transition-all mb-6 ${isFree ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : isPopular ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white hover:shadow-lg hover:shadow-orange-200' : 'bg-orange-100 text-orange-700 hover:bg-orange-200'}`}>
                  {isFree ? 'Estando usando' : 'Comenzar gratis'}
                </button>

                {plan.trial > 0 && !isFree && <p className="text-center text-xs text-gray-500 mb-6 pb-6 border-b border-gray-100">Sin tarjeta de credito requerida</p>}

                <div className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-3">
                      {feature.included ? (
                        <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="w-3 h-3 text-green-600" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <X className="w-3 h-3 text-gray-400" />
                        </div>
                      )}
                      <span className={`text-xs ${feature.included ? 'text-gray-700 font-medium' : 'text-gray-400'}`}>
                        {feature.name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden mb-10">
        <div className="p-6 bg-gray-50 border-b">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-orange-500" />
            Comparativa Completa de Planes
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase tracking-wide">Caracteristica</th>
                {plans.map(plan => <th key={plan.id} className="px-4 py-3 text-center text-xs font-bold text-gray-600 uppercase tracking-wide">{plan.name}</th>)}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              <tr className="hover:bg-gray-50">
                <td className="px-4 py-4 font-semibold text-gray-900">Precio Mensual</td>
                {plans.map(plan => <td key={plan.id} className="px-4 py-4 text-center text-gray-700 font-bold">{plan.id === 'free' ? 'Gratis' : `$${plan.price.toFixed(2)}/mes`}</td>)}
              </tr>
              <tr className="hover:bg-gray-50 bg-green-50">
                <td className="px-4 py-4 font-semibold text-gray-900">Precio Anual (-4%)</td>
                {plans.map(plan => (
                  <td key={plan.id} className="px-4 py-4 text-center font-bold">
                    {plan.id === 'free' ? <span className="text-gray-700">Gratis</span> : <><div className="text-green-700">${plan.annualPrice.toFixed(2)}/ano</div><div className="text-[11px] text-green-600 font-medium">Ahorras {plan.id === 'ultra' ? savings.ultra : savings.masterchef}%</div></> }
                  </td>
                ))}
              </tr>
              <tr className="hover:bg-gray-50">
                <td className="px-4 py-4 font-semibold text-gray-900">Periodo de Prueba</td>
                {plans.map(plan => <td key={plan.id} className="px-4 py-4 text-center text-gray-700">{plan.trial === 0 ? '-' : <span className="font-bold text-green-600">{plan.trial} dias gratis</span>}</td>)}
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Preguntas Frecuentes</h2>
        <div className="space-y-3">
          {[{ q: 'Puedo cancelar en cualquier momento?', a: 'Si, puedes cancelar sin penalizaciones. No hay contratos a largo plazo.' }, { q: 'Necesito tarjeta de credito?', a: 'No, 14 dias gratis sin datos de pago.' }, 
            { q: 'Cual es el descuento anual?', a: 'Un 5.65% de descuento al pagar anualmente. Ahorra casi 2 meses al año.' },
 { q: 'Que diferencia hay entre planes?', a: 'Ultra: 800 recetas, 50 logros. Master Chef: 1000+ recetas, 100 logros, asistente de voz, soporte 24/7.' }].map((faq, i) => (
            <div key={i} className="bg-white border border-gray-100 rounded-xl p-4 hover:shadow-md transition-shadow">
              <h3 className="font-bold text-gray-900 mb-2 text-sm">{faq.q}</h3>
              <p className="text-gray-600 text-xs leading-relaxed">{faq.a}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
