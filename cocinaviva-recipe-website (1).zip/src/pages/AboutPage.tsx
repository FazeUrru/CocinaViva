import { Github, Mail, Heart, Star, BookOpen, Zap, Settings, Users, Award, Coffee, Trophy } from 'lucide-react';
import { Logo } from '../components/Logo';
import { recipeStats } from '../data/recipes';

export function AboutPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Hero */}
      <div className="text-center mb-12">
        <div className="flex justify-center mb-4">
          <Logo size={64} />
        </div>
        <h1 className="text-3xl font-black text-gray-900 mb-2">CocinaViva</h1>
        <div className="flex items-center justify-center gap-2 mb-3">
          <span className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-3 py-1 rounded-full text-xs font-bold">BETA v0.9</span>
          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">Versión Beta</span>
        </div>
        <p className="text-sm text-gray-500 max-w-xl mx-auto">
          La plataforma definitiva de recetas españolas y de Thermomix. Más de 1.500 recetas, 
          {recipeStats.thermomix} para Thermomix, 18 funciones, 70 ajustes y 100 logros. ¡+500 recetas añadidas recientemente!
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
        {[
          { icon: BookOpen, value: '1.500', label: 'Recetas', color: 'from-orange-400 to-red-500' },
          { icon: Zap, value: recipeStats.thermomix, label: 'Thermomix', color: 'from-blue-400 to-indigo-500' },
          { icon: Settings, value: '70', label: 'Ajustes', color: 'from-green-400 to-emerald-500' },
          { icon: Trophy, value: '100', label: 'Logros', color: 'from-yellow-400 to-orange-500' },
        ].map((stat, i) => (
          <div key={i} className="bg-white border border-gray-100 rounded-xl p-4 text-center shadow-sm hover:shadow-md transition-all">
            <div className={`w-10 h-10 bg-gradient-to-br ${stat.color} rounded-lg flex items-center justify-center mx-auto mb-2 shadow-lg`}>
              <stat.icon className="w-5 h-5 text-white" />
            </div>
            <p className="text-2xl font-black text-gray-900">{stat.value}</p>
            <p className="text-xs text-gray-500">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Version Info */}
      <div className="bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-xl p-6 mb-8">
        <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
          <Award className="w-5 h-5 text-orange-500" />
          Notas de la Versión Beta v0.9
        </h2>
        <div className="bg-white rounded-lg p-4 border border-orange-100">
          <div className="flex items-center gap-2 mb-3">
            <span className="bg-orange-500 text-white px-2 py-0.5 rounded-full text-[10px] font-bold">v0.9 BETA</span>
            <span className="text-xs text-gray-500">Versión actual</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-gray-600">
            <div className="space-y-1">
              <p>✅ 1.500 recetas tradicionales y Thermomix</p>
              <p>✅ {recipeStats.thermomix} recetas Thermomix ({recipeStats.thermomixPostres} postres)</p>
              <p>✅ 20 categorías de cocina</p>
              <p>✅ 18 funciones (9 activas + 9 beta)</p>
              <p>✅ 70 ajustes de personalización</p>
              <p>✅ 100 logros desbloqueables</p>
              <p>🆕 +500 recetas nuevas añadidas</p>
            </div>
            <div className="space-y-1">
              <p>✅ Filtro de dificultad en barra lateral</p>
              <p>✅ Búsqueda y filtros avanzados</p>
              <p>✅ Modo Thermomix con instrucciones detalladas</p>
              <p>✅ Diseño responsive y compacto</p>
              <p>🧪 Asistente de voz (Beta)</p>
              <p>🧪 Escáner de ingredientes (Beta)</p>
              <p>🧪 Planificador semanal (Beta)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Features Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Star className="w-4 h-4 text-yellow-500" />
            Características Principales
          </h3>
          <ul className="space-y-2 text-xs text-gray-600">
            <li className="flex items-start gap-2">🍳 <span>Recetas tradicionales de todas las regiones</span></li>
            <li className="flex items-start gap-2">🤖 <span>Instrucciones específicas para Thermomix</span></li>
            <li className="flex items-start gap-2">🔍 <span>Búsqueda avanzada con filtro de dificultad</span></li>
            <li className="flex items-start gap-2">❤️ <span>Sistema de favoritos</span></li>
            <li className="flex items-start gap-2">📊 <span>Información nutricional</span></li>
            <li className="flex items-start gap-2">🏆 <span>100 logros para desbloquear</span></li>
          </ul>
        </div>
        <div className="bg-white border border-gray-100 rounded-xl p-5 shadow-sm">
          <h3 className="text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-500" />
            Tipos de Cocina
          </h3>
          <ul className="space-y-2 text-xs text-gray-600">
            <li className="flex items-start gap-2">🇪🇸 <span>Cocina española regional (20 regiones)</span></li>
            <li className="flex items-start gap-2">🌍 <span>Cocina internacional adaptada</span></li>
            <li className="flex items-start gap-2">🥗 <span>Opciones vegetarianas y veganas</span></li>
            <li className="flex items-start gap-2">🌾 <span>Recetas sin gluten</span></li>
            <li className="flex items-start gap-2">⚡ <span>Recetas rápidas (menos de 30 min)</span></li>
            <li className="flex items-start gap-2">🎉 <span>Recetas especiales para fiestas</span></li>
          </ul>
        </div>
      </div>

      {/* Team */}
      <div className="text-center bg-gray-50 rounded-xl p-6 mb-8">
        <Coffee className="w-8 h-8 text-orange-500 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-gray-900 mb-2">Hecho con ❤️ para amantes de la cocina</h2>
        <p className="text-gray-500 text-xs mb-4 max-w-md mx-auto">
          CocinaViva nace de la pasión por la gastronomía española y la tecnología.
        </p>
        <div className="flex justify-center gap-3">
          <a href="#" className="p-2 bg-white rounded-lg border border-gray-200 hover:border-orange-300 hover:shadow-md transition-all">
            <Github className="w-4 h-4 text-gray-700" />
          </a>
          <a href="#" className="p-2 bg-white rounded-lg border border-gray-200 hover:border-orange-300 hover:shadow-md transition-all">
            <Mail className="w-4 h-4 text-gray-700" />
          </a>
          <a href="#" className="p-2 bg-white rounded-lg border border-gray-200 hover:border-orange-300 hover:shadow-md transition-all">
            <Heart className="w-4 h-4 text-gray-700" />
          </a>
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center text-xs text-gray-400">
        <p>© 2024 CocinaViva — Todos los derechos reservados</p>
        <p className="mt-1">Versión Beta v0.9 — En desarrollo activo</p>
      </div>
    </div>
  );
}
