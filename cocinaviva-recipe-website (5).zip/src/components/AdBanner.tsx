import { useState, useEffect } from 'react';

const ASSET_TYPES = ['image', 'video'];
const AD_CATEGORIES = ['Cocina', 'Supermercado', 'Electrodomesticos', 'Restaurantes', 'Cursos de Cocina'];

// Generate 500 mock ads
const MOCK_ADS = Array.from({ length: 500 }, (_, i) => ({
  id: i + 1,
  type: ASSET_TYPES[Math.floor(Math.random() * ASSET_TYPES.length)],
  category: AD_CATEGORIES[Math.floor(Math.random() * AD_CATEGORIES.length)],
  url: `https://source.unsplash.com/random/800x200/?${AD_CATEGORIES[Math.floor(Math.random() * AD_CATEGORIES.length)].toLowerCase()}&sig=${i}`
}));

interface AdBannerProps {
  activePlan: string;
}

export function AdBanner({ activePlan }: AdBannerProps) {
  const [currentAd, setCurrentAd] = useState(MOCK_ADS[0]);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Solo mostramos publicidad en el plan gratuito
    if (activePlan !== 'free') return;

    // Cambiar anuncio aleatoriamente cada 15 segundos
    const interval = setInterval(() => {
      const randomAd = MOCK_ADS[Math.floor(Math.random() * MOCK_ADS.length)];
      setCurrentAd(randomAd);
      setIsVisible(true);
    }, 15000);

    return () => clearInterval(interval);
  }, [activePlan]);

  if (activePlan !== 'free' || !isVisible) return null;

  return (
    <div className="w-full max-w-4xl mx-auto my-4 bg-gray-100 border border-gray-200 rounded-xl overflow-hidden shadow-sm relative group">
      <div className="absolute top-1 right-2 z-10">
        <span className="bg-black/50 text-white text-[9px] px-1.5 py-0.5 rounded backdrop-blur-sm">Publicidad</span>
      </div>
      <button 
        onClick={() => setIsVisible(false)}
        className="absolute top-1 left-2 z-10 bg-white/80 hover:bg-white text-gray-500 text-[10px] px-1.5 py-0.5 rounded backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity"
      >
        Cerrar anuncio
      </button>
      
      <div className="h-24 md:h-32 w-full bg-gray-200 flex items-center justify-center relative overflow-hidden">
        {currentAd.type === 'video' ? (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900 text-white">
            <span className="text-xs font-bold opacity-50 flex flex-col items-center">
              <svg className="w-8 h-8 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              Video Patrocinado: {currentAd.category}
            </span>
          </div>
        ) : (
          <div className="absolute inset-0 bg-gradient-to-r from-orange-100 to-red-50 flex items-center justify-center">
             <span className="text-gray-500 font-bold text-sm tracking-widest uppercase opacity-40">
               Banner Publicitario - {currentAd.category}
             </span>
          </div>
        )}
      </div>
    </div>
  );
}
