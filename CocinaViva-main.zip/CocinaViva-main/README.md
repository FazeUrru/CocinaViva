# CocinaViva
CocinaViva no es solo una app de recetas. Es el abrazo cálido de tu abuela en forma de guiso. Es el olor a pan recién horneado que te recuerda a casa. Es ese momento en que mezclas ingredientes y, sin querer, mezclas también recuerdos, risas y sueños. Aquí no cocinamos para llenar el estómago… cocinamos para alimentar el alma. 
