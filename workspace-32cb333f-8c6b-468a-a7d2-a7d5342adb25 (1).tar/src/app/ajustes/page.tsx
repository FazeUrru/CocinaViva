'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Settings,
  User,
  Bell,
  Moon,
  Sun,
  Globe,
  Shield,
  Smartphone,
  Palette,
  Volume2,
  ChevronRight,
  Lock,
  LogOut,
  Trash2,
  Download,
  HelpCircle,
  Info,
  Code,
  Database,
  RefreshCw,
  Zap,
  Terminal,
  ChevronLeft,
  Languages,
  Calendar,
  Clock,
  MapPin,
  Wifi,
  HardDrive,
  Cloud,
  Key,
  Eye,
  EyeOff,
  Monitor,
  Tv,
  Speaker,
  Vibrate,
  Mail,
  MessageSquare,
  AtSign,
  Heart,
  Share2,
  Camera,
  Mic,
  Hand,
  Type,
  ZoomIn,
  Contrast,
  Utensils,
  Scale,
  Timer,
  Flame,
  Sparkles,
  Cast,
  Video,
  Bug,
  Activity,
  Server,
  AlertTriangle,
  CheckCircle,
  ShoppingCart,
  Users,
  Home,
  BarChart3,
  ThermometerSun,
  Package,
  RadioIcon,
  ImageOff,
  KeyboardIcon,
  Menu,
  SquareFunction,
  Layers,
  Phone,
  Building,
  CreditCard,
  Cake,
  FileText,
  Award,
  Briefcase,
  Link,
  Instagram,
  Facebook,
  Twitter,
  Github,
  Linkedin,
  Youtube,
  Globe2,
  ChefHat,
  Leaf,
  Apple,
  Fish,
  Droplets,
  Egg,
  Cookie,
  Wine,
  Coffee,
  Soup,
  Sandwich,
  Pizza,
  Burger,
  Salad,
  IceCream,
  CakeSlice,
  Cherry,
  Carrot,
  Beef,
  Chicken,
  Pig,
  Wheat,
  Cpu,
  Binary,
  FileCode,
  TerminalSquare,
  Braces,
  Network,
  ShieldCheck,
  Fingerprint,
  Scan,
  X,
  Ban,
  ThumbsUp,
  GitBranch,
  Rocket,
  Pencil,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { LoginModal } from '@/components/login-modal'
import { useUserStore } from '@/store'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

const ADMIN_PASSWORD = 'COCINAVIVA2026#'

type SettingsCategory = 'main' | 'perfil' | 'general' | 'apariencia' | 'notificaciones' | 'privacidad' | 'accesibilidad' | 'cocina' | 'beta' | 'chromecast' | 'avanzado'

export default function AjustesPage() {
  const { isAuthenticated, userName, userEmail, logout } = useUserStore()
  const [currentCategory, setCurrentCategory] = useState<SettingsCategory>('main')
  
  // All settings states
  const [settings, setSettings] = useState({
    // =============================================
    // PERFIL DE USUARIO (50 ajustes)
    // =============================================
    // Datos Personales (9)
    profileName: '',
    profileLastName: '',
    profileEmail: '',
    profilePhone: '',
    profileBirthdate: '',
    profileGender: 'prefiero_no_decir',
    profileCountry: 'España',
    profileCity: '',
    profileAddress: '',
    
    // Preferencias Culinarias (12)
    cuisineFavorites: [] as string[],
    cookingLevel: 'intermedio',
    cookingFrequency: 'diario',
    preferredMealType: 'almuerzo',
    spiceLevel: 'medio',
    maxCookingTime: 60,
    kitchenTools: [] as string[],
    dietPreferences: [] as string[],
    allergies: [] as string[],
    favoriteIngredients: [] as string[],
    dislikedIngredients: [] as string[],
    cookingStyle: 'tradicional',
    
    // Dieta y Salud (9)
    dietType: 'omnivoro',
    dailyCalories: 2000,
    fitnessGoal: 'mantener',
    healthConditions: [] as string[],
    dietaryRestrictions: [] as string[],
    mealPlanEnabled: false,
    nutritionTracking: false,
    waterReminder: false,
    waterGoal: 8,
    
    // Social (16)
    profileVisibility: 'publico',
    showRecipes: true,
    showFavorites: true,
    showActivity: true,
    showFollowers: true,
    showFollowing: true,
    showCooksnaps: true,
    showComments: true,
    allowComments: true,
    allowFollowers: true,
    allowMessages: true,
    allowTags: true,
    socialShareEnabled: true,
    instagramConnected: false,
    facebookConnected: false,
    twitterConnected: false,
    
    // Privacidad (8)
    privateProfile: false,
    dataCollection: true,
    analyticsEnabled: true,
    personalizedAds: false,
    thirdPartySharing: false,
    cookieConsent: true,
    twoFactorEnabled: false,
    biometricLogin: false,
    
    // Experiencia (4)
    tutorialCompleted: false,
    onboardingStep: 0,
    preferredLanguage: 'es',
    theme: 'auto',
    
    // =============================================
    // General (27 settings)
    // =============================================
    language: 'es',
    timezone: 'Europe/Madrid',
    dateFormat: 'DD/MM/YYYY',
    units: 'metric',
    currency: 'EUR',
    startPage: 'home',
    autoUpdate: true,
    offlineMode: false,
    dataUsage: 'wifi',
    locationServices: true,
    analytics: true,
    crashReports: true,
    usageStats: true,
    personalizedAdsGeneral: false,
    marketingEmails: false,
    newsletter: true,
    tipsTricks: true,
    weeklyDigest: true,
    recipeReminders: true,
    shoppingReminders: false,
    mealPlanning: true,
    voiceAssistant: false,
    aiSuggestions: true,
    smartHome: false,
    cloudSync: true,
    autoBackup: true,
    
    // Apariencia (10 settings)
    darkMode: false,
    themeAppearance: 'auto',
    accentColor: 'orange',
    fontSize: 100,
    fontFamily: 'default',
    animations: true,
    transitions: true,
    compactMode: false,
    sidebarPosition: 'left',
    cardStyle: 'rounded',
    
    // Notificaciones (7 settings)
    pushNotifications: true,
    emailNotifications: true,
    soundEffects: true,
    vibration: true,
    quietHours: false,
    quietHoursStart: '22:00',
    notificationSound: 'default',
    
    // Privacidad General (7 settings)
    showActivityGeneral: true,
    showFavoritesGeneral: true,
    allowFollowersGeneral: true,
    dataCollectionGeneral: true,
    thirdPartySharingGeneral: false,
    cookieConsentGeneral: true,
    privacyLevel: 'estandar',
    
    // Accesibilidad (17 settings)
    screenReader: false,
    highContrast: false,
    reduceMotion: false,
    largeText: false,
    boldText: false,
    voiceControl: false,
    switchControl: false,
    colorBlindMode: false,
    dyslexiaFont: false,
    signLanguage: false,
    subtitles: true,
    audioDescriptions: false,
    hapticFeedback: true,
    focusIndicator: true,
    keyboardNavigation: true,
    textToSpeech: false,
    screenZoom: false,
    
    // Cocina (6 settings)
    defaultServings: 4,
    measurementSystem: 'metric',
    temperatureUnit: 'celsius',
    timerSounds: true,
    autoConvert: true,
    shoppingSort: 'recipe',
    
    // Beta (13 settings)
    aiRecipes: false,
    voiceCooking: false,
    arMode: false,
    smartOven: false,
    fridgeIntegration: false,
    mealKits: false,
    videoRecipes: false,
    liveCooking: false,
    socialCooking: false,
    ingredientRecognition: false,
    wasteTracking: false,
    nutritionAI: false,
    calorieCounter: false,
    
    // Chromecast (7 settings)
    chromecastEnabled: true,
    autoConnect: false,
    quality: 'auto',
    subtitlesCC: true,
    backgroundImage: true,
    screensaver: true,
    deviceName: 'CocinaViva TV',
    
    // =============================================
    // Avanzado (14 settings) - SOLO ADMIN
    // Incluye 9 ajustes avanzados + 5 ajustes de desarrollador
    // =============================================
    developerMode: false,
    debugMode: false,
    apiEndpoint: 'default',
    cacheSize: 500,
    clearCacheOnExit: false,
    experimentalFeatures: false,
    betaChannel: false,
    logLevel: 'info',
    networkTimeout: 30,
    // Desarrollador oculto (5 ajustes adicionales)
    showDevConsole: false,
    enableApiLogger: false,
    mockApiResponses: false,
    showPerformanceMetrics: false,
    debugDatabase: false,
  })

  // Developer options state
  const [adminClickCount, setAdminClickCount] = useState(0)
  const [showPasswordInput, setShowPasswordInput] = useState(false)
  const [passwordInput, setPasswordInput] = useState('')
  const [isAdmin, setIsAdmin] = useState(false)
  const [showLoginModal, setShowLoginModal] = useState(false)

  const updateSetting = (key: string, value: boolean | string | number | string[]) => {
    setSettings(prev => ({ ...prev, [key]: value }))
    toast.success('Configuración guardada')
  }

  // Handle version click for admin mode
  const handleVersionClick = () => {
    if (isAdmin) return
    setAdminClickCount(prev => {
      const newCount = prev + 1
      if (newCount >= 6) {
        setShowPasswordInput(true)
        return 0
      }
      if (newCount >= 3) {
        toast.info(`${6 - newCount} clics más para desbloquear`)
      }
      return newCount
    })
  }

  // Handle admin password submission
  const handlePasswordSubmit = () => {
    if (passwordInput === ADMIN_PASSWORD) {
      setIsAdmin(true)
      setShowPasswordInput(false)
      setPasswordInput('')
      toast.success('Modo administrador activado')
    } else {
      toast.error('Contraseña incorrecta')
      setPasswordInput('')
    }
  }

  // Categories configuration - Avanzado SOLO visible para admin
  const categories = [
    { id: 'perfil' as const, icon: User, label: 'Cuenta de Usuario', count: 50, color: 'from-rose-500 to-pink-500' },
    { id: 'general' as const, icon: Settings, label: 'General', count: 27, color: 'from-blue-500 to-cyan-500' },
    { id: 'apariencia' as const, icon: Palette, label: 'Apariencia', count: 10, color: 'from-purple-500 to-pink-500' },
    { id: 'notificaciones' as const, icon: Bell, label: 'Notificaciones', count: 7, color: 'from-orange-500 to-yellow-500' },
    { id: 'privacidad' as const, icon: Shield, label: 'Privacidad', count: 7, color: 'from-green-500 to-emerald-500' },
    { id: 'accesibilidad' as const, icon: Hand, label: 'Accesibilidad', count: 17, color: 'from-teal-500 to-cyan-500' },
    { id: 'cocina' as const, icon: Utensils, label: 'Cocina', count: 6, color: 'from-red-500 to-orange-500' },
    { id: 'beta' as const, icon: Sparkles, label: 'Funciones Beta', count: 13, color: 'from-violet-500 to-purple-500' },
    { id: 'chromecast' as const, icon: Cast, label: 'Chromecast', count: 7, color: 'from-blue-600 to-indigo-600' },
    // Avanzado SOLO visible para admin (incluye ajustes de desarrollador)
    ...(isAdmin ? [{ id: 'avanzado' as const, icon: Terminal, label: 'Avanzado', count: 14, color: 'from-gray-600 to-gray-800' }] : []),
  ]

  // Settings Item Component
  const SettingsItem = ({ 
    icon: Icon, 
    label, 
    description, 
    type, 
    value, 
    options,
    beta,
    premium,
    onChange,
    onClick 
  }: {
    icon: React.ElementType
    label: string
    description?: string
    type: 'switch' | 'select' | 'button' | 'slider' | 'input' | 'multiselect'
    value?: boolean | string | number | string[]
    options?: { value: string; label: string }[]
    beta?: boolean
    premium?: boolean
    onChange?: (value: string | boolean | number | string[]) => void
    onClick?: () => void
  }) => {
    return (
      <div className="flex items-center justify-between py-3 px-2 hover:bg-muted/50 rounded-lg transition-colors">
        <div className="flex items-center gap-3">
          <Icon className="h-5 w-5 text-muted-foreground" />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-medium">{label}</span>
              {beta && <Badge variant="secondary" className="text-xs bg-purple-100 text-purple-700">BETA</Badge>}
              {premium && <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-700">PRO</Badge>}
            </div>
            {description && <p className="text-sm text-muted-foreground">{description}</p>}
          </div>
        </div>
        
        {type === 'switch' && (
          <Switch checked={value as boolean} onCheckedChange={onChange} />
        )}
        
        {type === 'select' && (
          <select 
            value={value as string}
            onChange={(e) => onChange?.(e.target.value)}
            className="px-3 py-1.5 rounded-md border bg-background text-sm"
          >
            {options?.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
        )}
        
        {type === 'slider' && (
          <div className="w-24">
            <Slider
              value={[value as number]}
              onValueChange={([v]) => onChange?.(v)}
              max={label.includes('Fuente') ? 150 : label.includes('Caché') ? 1000 : label.includes('Calorías') ? 5000 : label.includes('Tiempo') ? 180 : 100}
              step={label.includes('Fuente') ? 10 : label.includes('Caché') ? 50 : 5}
            />
          </div>
        )}
        
        {type === 'input' && (
          <Input
            value={value as string}
            onChange={(e) => onChange?.(e.target.value)}
            className="w-40"
          />
        )}
        
        {type === 'button' && (
          <Button variant="ghost" size="sm" onClick={onClick}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        )}
      </div>
    )
  }

  // Settings content for each category
  const renderSettingsContent = () => {
    switch (currentCategory) {
      case 'perfil':
        return (
          <Tabs defaultValue="personal" className="w-full">
            <TabsList className="mb-4 flex flex-wrap">
              <TabsTrigger value="personal">Datos Personales (9)</TabsTrigger>
              <TabsTrigger value="culinarias">Preferencias Culinarias (12)</TabsTrigger>
              <TabsTrigger value="salud">Dieta y Salud (9)</TabsTrigger>
              <TabsTrigger value="social">Social (16)</TabsTrigger>
              <TabsTrigger value="privacidad">Privacidad (8)</TabsTrigger>
              <TabsTrigger value="experiencia">Experiencia (4)</TabsTrigger>
            </TabsList>
            
            <TabsContent value="personal">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Datos Personales
                  </CardTitle>
                  <CardDescription>Información básica de tu cuenta</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingsItem icon={User} label="Nombre" type="input" value={settings.profileName} onChange={(v) => updateSetting('profileName', v)} />
                  <SettingsItem icon={User} label="Apellidos" type="input" value={settings.profileLastName} onChange={(v) => updateSetting('profileLastName', v)} />
                  <SettingsItem icon={Mail} label="Email" type="input" value={settings.profileEmail} onChange={(v) => updateSetting('profileEmail', v)} />
                  <SettingsItem icon={Phone} label="Teléfono" type="input" value={settings.profilePhone} onChange={(v) => updateSetting('profilePhone', v)} />
                  <SettingsItem icon={Cake} label="Fecha de Nacimiento" type="input" value={settings.profileBirthdate} onChange={(v) => updateSetting('profileBirthdate', v)} />
                  <SettingsItem icon={User} label="Género" type="select" value={settings.profileGender} options={[
                    { value: 'prefiero_no_decir', label: 'Prefiero no decir' },
                    { value: 'masculino', label: 'Masculino' },
                    { value: 'femenino', label: 'Femenino' },
                    { value: 'otro', label: 'Otro' },
                  ]} onChange={(v) => updateSetting('profileGender', v)} />
                  <SettingsItem icon={Globe2} label="País" type="select" value={settings.profileCountry} options={[
                    { value: 'España', label: 'España' },
                    { value: 'México', label: 'México' },
                    { value: 'Argentina', label: 'Argentina' },
                    { value: 'Colombia', label: 'Colombia' },
                    { value: 'Chile', label: 'Chile' },
                    { value: 'Perú', label: 'Perú' },
                    { value: 'Otro', label: 'Otro' },
                  ]} onChange={(v) => updateSetting('profileCountry', v)} />
                  <SettingsItem icon={Building} label="Ciudad" type="input" value={settings.profileCity} onChange={(v) => updateSetting('profileCity', v)} />
                  <SettingsItem icon={MapPin} label="Dirección" type="input" value={settings.profileAddress} onChange={(v) => updateSetting('profileAddress', v)} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="culinarias">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <ChefHat className="h-5 w-5" />
                    Preferencias Culinarias
                  </CardTitle>
                  <CardDescription>Tus gustos y preferencias en la cocina</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingsItem icon={Globe} label="Cocinas Favoritas" description="Selecciona tus cocinas preferidas" type="button" onClick={() => toast.info('Seleccionar cocinas')} />
                  <SettingsItem icon={Award} label="Nivel de Cocina" type="select" value={settings.cookingLevel} options={[
                    { value: 'principiante', label: 'Principiante' },
                    { value: 'intermedio', label: 'Intermedio' },
                    { value: 'avanzado', label: 'Avanzado' },
                    { value: 'experto', label: 'Experto' },
                  ]} onChange={(v) => updateSetting('cookingLevel', v)} />
                  <SettingsItem icon={Clock} label="Frecuencia de Cocina" type="select" value={settings.cookingFrequency} options={[
                    { value: 'diario', label: 'Todos los días' },
                    { value: 'frecuente', label: 'Varias veces por semana' },
                    { value: 'ocasional', label: 'Una vez por semana' },
                    { value: 'raro', label: 'Ocasionalmente' },
                  ]} onChange={(v) => updateSetting('cookingFrequency', v)} />
                  <SettingsItem icon={Sun} label="Tipo de Comida Preferido" type="select" value={settings.preferredMealType} options={[
                    { value: 'desayuno', label: 'Desayuno' },
                    { value: 'almuerzo', label: 'Almuerzo' },
                    { value: 'cena', label: 'Cena' },
                    { value: 'snack', label: 'Snacks' },
                  ]} onChange={(v) => updateSetting('preferredMealType', v)} />
                  <SettingsItem icon={Flame} label="Nivel de Picante" type="select" value={settings.spiceLevel} options={[
                    { value: 'suave', label: 'Suave' },
                    { value: 'medio', label: 'Medio' },
                    { value: 'picante', label: 'Picante' },
                    { value: 'muy_picante', label: 'Muy Picante' },
                  ]} onChange={(v) => updateSetting('spiceLevel', v)} />
                  <SettingsItem icon={Timer} label="Tiempo Máximo de Cocina (min)" type="slider" value={settings.maxCookingTime} onChange={(v) => updateSetting('maxCookingTime', v)} />
                  <SettingsItem icon={Utensils} label="Herramientas de Cocina" description="Equipamiento que tienes disponible" type="button" onClick={() => toast.info('Seleccionar herramientas')} />
                  <SettingsItem icon={Leaf} label="Preferencias Dietéticas" type="button" onClick={() => toast.info('Seleccionar preferencias')} />
                  <SettingsItem icon={AlertTriangle} label="Alergias Alimentarias" description="Importante para recomendaciones" type="button" onClick={() => toast.info('Seleccionar alergias')} />
                  <SettingsItem icon={Heart} label="Ingredientes Favoritos" type="button" onClick={() => toast.info('Seleccionar favoritos')} />
                  <SettingsItem icon={Ban} label="Ingredientes No Deseados" type="button" onClick={() => toast.info('Seleccionar no deseados')} />
                  <SettingsItem icon={Briefcase} label="Estilo de Cocina" type="select" value={settings.cookingStyle} options={[
                    { value: 'tradicional', label: 'Tradicional' },
                    { value: 'moderno', label: 'Moderno' },
                    { value: 'fusion', label: 'Fusión' },
                    { value: 'minimalista', label: 'Minimalista' },
                  ]} onChange={(v) => updateSetting('cookingStyle', v)} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="salud">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Heart className="h-5 w-5" />
                    Dieta y Salud
                  </CardTitle>
                  <CardDescription>Tus objetivos y restricciones de salud</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingsItem icon={Apple} label="Tipo de Dieta" type="select" value={settings.dietType} options={[
                    { value: 'omnivoro', label: 'Omnívoro' },
                    { value: 'vegetariano', label: 'Vegetariano' },
                    { value: 'vegano', label: 'Vegano' },
                    { value: 'pescetariano', label: 'Pescetariano' },
                    { value: 'keto', label: 'Keto' },
                    { value: 'paleo', label: 'Paleo' },
                    { value: 'mediterranea', label: 'Mediterránea' },
                  ]} onChange={(v) => updateSetting('dietType', v)} />
                  <SettingsItem icon={Flame} label="Calorías Diarias Objetivo" type="slider" value={settings.dailyCalories} onChange={(v) => updateSetting('dailyCalories', v)} />
                  <SettingsItem icon={Activity} label="Objetivo Fitness" type="select" value={settings.fitnessGoal} options={[
                    { value: 'perder', label: 'Perder peso' },
                    { value: 'mantener', label: 'Mantener peso' },
                    { value: 'ganar', label: 'Ganar masa muscular' },
                    { value: 'salud', label: 'Mejorar salud' },
                  ]} onChange={(v) => updateSetting('fitnessGoal', v)} />
                  <SettingsItem icon={Shield} label="Condiciones de Salud" description="Selecciona si aplica" type="button" onClick={() => toast.info('Seleccionar condiciones')} />
                  <SettingsItem icon={Lock} label="Restricciones Alimentarias" type="button" onClick={() => toast.info('Seleccionar restricciones')} />
                  <SettingsItem icon={Calendar} label="Plan de Comidas Activado" type="switch" value={settings.mealPlanEnabled} onChange={(v) => updateSetting('mealPlanEnabled', v)} premium />
                  <SettingsItem icon={BarChart3} label="Seguimiento Nutricional" type="switch" value={settings.nutritionTracking} onChange={(v) => updateSetting('nutritionTracking', v)} premium />
                  <SettingsItem icon={Droplets} label="Recordatorio de Agua" type="switch" value={settings.waterReminder} onChange={(v) => updateSetting('waterReminder', v)} />
                  <SettingsItem icon={Droplets} label="Vasos de Agua Diarios" type="slider" value={settings.waterGoal} onChange={(v) => updateSetting('waterGoal', v)} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="social">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Configuración Social
                  </CardTitle>
                  <CardDescription>Controla tu presencia en la comunidad</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingsItem icon={Eye} label="Visibilidad del Perfil" type="select" value={settings.profileVisibility} options={[
                    { value: 'publico', label: 'Público' },
                    { value: 'amigos', label: 'Solo amigos' },
                    { value: 'privado', label: 'Privado' },
                  ]} onChange={(v) => updateSetting('profileVisibility', v)} />
                  <Separator className="my-2" />
                  <p className="text-sm font-medium text-muted-foreground px-2">Mostrar en perfil</p>
                  <SettingsItem icon={ChefHat} label="Mostrar Recetas" type="switch" value={settings.showRecipes} onChange={(v) => updateSetting('showRecipes', v)} />
                  <SettingsItem icon={Heart} label="Mostrar Favoritos" type="switch" value={settings.showFavorites} onChange={(v) => updateSetting('showFavorites', v)} />
                  <SettingsItem icon={Activity} label="Mostrar Actividad" type="switch" value={settings.showActivity} onChange={(v) => updateSetting('showActivity', v)} />
                  <SettingsItem icon={Users} label="Mostrar Seguidores" type="switch" value={settings.showFollowers} onChange={(v) => updateSetting('showFollowers', v)} />
                  <SettingsItem icon={User} label="Mostrar Siguiendo" type="switch" value={settings.showFollowing} onChange={(v) => updateSetting('showFollowing', v)} />
                  <SettingsItem icon={Camera} label="Mostrar Cooksnaps" type="switch" value={settings.showCooksnaps} onChange={(v) => updateSetting('showCooksnaps', v)} />
                  <SettingsItem icon={MessageSquare} label="Mostrar Comentarios" type="switch" value={settings.showComments} onChange={(v) => updateSetting('showComments', v)} />
                  <Separator className="my-2" />
                  <p className="text-sm font-medium text-muted-foreground px-2">Permitir</p>
                  <SettingsItem icon={MessageSquare} label="Permitir Comentarios" type="switch" value={settings.allowComments} onChange={(v) => updateSetting('allowComments', v)} />
                  <SettingsItem icon={Users} label="Permitir Seguidores" type="switch" value={settings.allowFollowers} onChange={(v) => updateSetting('allowFollowers', v)} />
                  <SettingsItem icon={Mail} label="Permitir Mensajes" type="switch" value={settings.allowMessages} onChange={(v) => updateSetting('allowMessages', v)} />
                  <SettingsItem icon={AtSign} label="Permitir Etiquetas" type="switch" value={settings.allowTags} onChange={(v) => updateSetting('allowTags', v)} />
                  <Separator className="my-2" />
                  <p className="text-sm font-medium text-muted-foreground px-2">Redes Sociales</p>
                  <SettingsItem icon={Share2} label="Compartir en Redes" type="switch" value={settings.socialShareEnabled} onChange={(v) => updateSetting('socialShareEnabled', v)} />
                  <SettingsItem icon={Instagram} label="Instagram Conectado" type="switch" value={settings.instagramConnected} onChange={(v) => updateSetting('instagramConnected', v)} />
                  <SettingsItem icon={Facebook} label="Facebook Conectado" type="switch" value={settings.facebookConnected} onChange={(v) => updateSetting('facebookConnected', v)} />
                  <SettingsItem icon={Twitter} label="X (Twitter) Conectado" type="switch" value={settings.twitterConnected} onChange={(v) => updateSetting('twitterConnected', v)} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="privacidad">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Shield className="h-5 w-5" />
                    Privacidad
                  </CardTitle>
                  <CardDescription>Controla tus datos y seguridad</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingsItem icon={Lock} label="Perfil Privado" description="Solo tú verás tu actividad" type="switch" value={settings.privateProfile} onChange={(v) => updateSetting('privateProfile', v)} />
                  <SettingsItem icon={Database} label="Recogida de Datos" type="switch" value={settings.dataCollection} onChange={(v) => updateSetting('dataCollection', v)} />
                  <SettingsItem icon={BarChart3} label="Análisis de Uso" type="switch" value={settings.analyticsEnabled} onChange={(v) => updateSetting('analyticsEnabled', v)} />
                  <SettingsItem icon={AtSign} label="Anuncios Personalizados" type="switch" value={settings.personalizedAds} onChange={(v) => updateSetting('personalizedAds', v)} />
                  <SettingsItem icon={Share2} label="Compartir con Terceros" type="switch" value={settings.thirdPartySharing} onChange={(v) => updateSetting('thirdPartySharing', v)} />
                  <SettingsItem icon={Shield} label="Consentimiento de Cookies" type="switch" value={settings.cookieConsent} onChange={(v) => updateSetting('cookieConsent', v)} />
                  <SettingsItem icon={Key} label="Autenticación de Dos Factores" type="switch" value={settings.twoFactorEnabled} onChange={(v) => updateSetting('twoFactorEnabled', v)} />
                  <SettingsItem icon={Fingerprint} label="Inicio Biométrico" description="Huella dactilar o Face ID" type="switch" value={settings.biometricLogin} onChange={(v) => updateSetting('biometricLogin', v)} />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="experiencia">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Sparkles className="h-5 w-5" />
                    Experiencia
                  </CardTitle>
                  <CardDescription>Personaliza tu experiencia en la app</CardDescription>
                </CardHeader>
                <CardContent className="space-y-1">
                  <SettingsItem icon={HelpCircle} label="Tutorial Completado" type="switch" value={settings.tutorialCompleted} onChange={(v) => updateSetting('tutorialCompleted', v)} />
                  <SettingsItem icon={MapPin} label="Paso de Onboarding" type="slider" value={settings.onboardingStep} onChange={(v) => updateSetting('onboardingStep', v)} />
                  <SettingsItem icon={Languages} label="Idioma Preferido" type="select" value={settings.preferredLanguage} options={[
                    { value: 'es', label: 'Español' },
                    { value: 'en', label: 'English' },
                    { value: 'pt', label: 'Português' },
                  ]} onChange={(v) => updateSetting('preferredLanguage', v)} />
                  <SettingsItem icon={Palette} label="Tema" type="select" value={settings.theme} options={[
                    { value: 'auto', label: 'Automático' },
                    { value: 'light', label: 'Claro' },
                    { value: 'dark', label: 'Oscuro' },
                  ]} onChange={(v) => updateSetting('theme', v)} />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )
      
      case 'general':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Languages} label="Idioma" description="Idioma de la aplicación" type="select" value={settings.language} options={[{ value: 'es', label: 'Español' }, { value: 'en', label: 'English' }, { value: 'pt', label: 'Português' }]} onChange={(v) => updateSetting('language', v)} />
            <SettingsItem icon={Clock} label="Zona Horaria" description="Tu zona horaria local" type="select" value={settings.timezone} options={[{ value: 'Europe/Madrid', label: 'Madrid (GMT+1)' }, { value: 'America/Mexico_City', label: 'Ciudad de México (GMT-6)' }, { value: 'America/New_York', label: 'Nueva York (GMT-5)' }]} onChange={(v) => updateSetting('timezone', v)} />
            <SettingsItem icon={Calendar} label="Formato de Fecha" type="select" value={settings.dateFormat} options={[{ value: 'DD/MM/YYYY', label: 'DD/MM/YYYY' }, { value: 'MM/DD/YYYY', label: 'MM/DD/YYYY' }, { value: 'YYYY-MM-DD', label: 'YYYY-MM-DD' }]} onChange={(v) => updateSetting('dateFormat', v)} />
            <SettingsItem icon={Scale} label="Sistema de Unidades" type="select" value={settings.units} options={[{ value: 'metric', label: 'Métrico' }, { value: 'imperial', label: 'Imperial' }]} onChange={(v) => updateSetting('units', v)} />
            <SettingsItem icon={Globe} label="Moneda" type="select" value={settings.currency} options={[{ value: 'EUR', label: 'Euro (€)' }, { value: 'USD', label: 'Dólar ($)' }, { value: 'MXN', label: 'Peso Mexicano ($)' }]} onChange={(v) => updateSetting('currency', v)} />
            <SettingsItem icon={Smartphone} label="Página de Inicio" type="select" value={settings.startPage} options={[{ value: 'home', label: 'Inicio' }, { value: 'recipes', label: 'Recetario' }, { value: 'favorites', label: 'Favoritos' }]} onChange={(v) => updateSetting('startPage', v)} />
            <SettingsItem icon={RefreshCw} label="Actualización Automática" description="Actualizar la app automáticamente" type="switch" value={settings.autoUpdate} onChange={(v) => updateSetting('autoUpdate', v)} />
            <SettingsItem icon={Wifi} label="Modo Sin Conexión" description="Guardar recetas para ver offline" type="switch" value={settings.offlineMode} onChange={(v) => updateSetting('offlineMode', v)} />
            <SettingsItem icon={Database} label="Uso de Datos" description="Limitar descargas" type="select" value={settings.dataUsage} options={[{ value: 'wifi', label: 'Solo WiFi' }, { value: 'always', label: 'Siempre' }, { value: 'never', label: 'Nunca' }]} onChange={(v) => updateSetting('dataUsage', v)} />
            <SettingsItem icon={MapPin} label="Servicios de Ubicación" type="switch" value={settings.locationServices} onChange={(v) => updateSetting('locationServices', v)} />
            <SettingsItem icon={Activity} label="Análisis de Uso" description="Ayudar a mejorar la app" type="switch" value={settings.analytics} onChange={(v) => updateSetting('analytics', v)} />
            <SettingsItem icon={AlertTriangle} label="Informes de Errores" type="switch" value={settings.crashReports} onChange={(v) => updateSetting('crashReports', v)} />
            <SettingsItem icon={BarChart3} label="Estadísticas de Uso" type="switch" value={settings.usageStats} onChange={(v) => updateSetting('usageStats', v)} />
            <SettingsItem icon={AtSign} label="Anuncios Personalizados" type="switch" value={settings.personalizedAdsGeneral} onChange={(v) => updateSetting('personalizedAdsGeneral', v)} />
            <SettingsItem icon={Mail} label="Emails de Marketing" type="switch" value={settings.marketingEmails} onChange={(v) => updateSetting('marketingEmails', v)} />
            <SettingsItem icon={MessageSquare} label="Newsletter" type="switch" value={settings.newsletter} onChange={(v) => updateSetting('newsletter', v)} />
            <SettingsItem icon={Sparkles} label="Tips y Trucos" type="switch" value={settings.tipsTricks} onChange={(v) => updateSetting('tipsTricks', v)} />
            <SettingsItem icon={Calendar} label="Resumen Semanal" type="switch" value={settings.weeklyDigest} onChange={(v) => updateSetting('weeklyDigest', v)} />
            <SettingsItem icon={Bell} label="Recordatorios de Recetas" type="switch" value={settings.recipeReminders} onChange={(v) => updateSetting('recipeReminders', v)} />
            <SettingsItem icon={ShoppingCart} label="Recordatorios de Compras" type="switch" value={settings.shoppingReminders} onChange={(v) => updateSetting('shoppingReminders', v)} />
            <SettingsItem icon={Calendar} label="Planificación de Comidas" type="switch" value={settings.mealPlanning} onChange={(v) => updateSetting('mealPlanning', v)} />
            <SettingsItem icon={Mic} label="Asistente de Voz" type="switch" value={settings.voiceAssistant} onChange={(v) => updateSetting('voiceAssistant', v)} />
            <SettingsItem icon={Zap} label="Sugerencias IA" type="switch" value={settings.aiSuggestions} onChange={(v) => updateSetting('aiSuggestions', v)} />
            <SettingsItem icon={Home} label="Smart Home" description="Control de dispositivos" type="switch" value={settings.smartHome} onChange={(v) => updateSetting('smartHome', v)} />
            <SettingsItem icon={Cloud} label="Sincronización Cloud" type="switch" value={settings.cloudSync} onChange={(v) => updateSetting('cloudSync', v)} />
            <SettingsItem icon={HardDrive} label="Backup Automático" type="switch" value={settings.autoBackup} onChange={(v) => updateSetting('autoBackup', v)} />
            <SettingsItem icon={User} label="Cuenta de Usuario" type="button" onClick={() => setCurrentCategory('perfil')} />
          </div>
        )
      
      case 'apariencia':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Moon} label="Modo Oscuro" description="Activar tema oscuro" type="switch" value={settings.darkMode} onChange={(v) => updateSetting('darkMode', v)} />
            <SettingsItem icon={Palette} label="Tema" type="select" value={settings.themeAppearance} options={[{ value: 'auto', label: 'Automático' }, { value: 'light', label: 'Claro' }, { value: 'dark', label: 'Oscuro' }]} onChange={(v) => updateSetting('themeAppearance', v)} />
            <SettingsItem icon={Palette} label="Color de Acento" type="select" value={settings.accentColor} options={[{ value: 'orange', label: 'Naranja' }, { value: 'green', label: 'Verde' }, { value: 'blue', label: 'Azul' }, { value: 'purple', label: 'Púrpura' }]} onChange={(v) => updateSetting('accentColor', v)} />
            <SettingsItem icon={Type} label="Tamaño de Fuente" description={`${settings.fontSize}%`} type="slider" value={settings.fontSize} onChange={(v) => updateSetting('fontSize', v)} />
            <SettingsItem icon={Type} label="Tipo de Fuente" type="select" value={settings.fontFamily} options={[{ value: 'default', label: 'Predeterminada' }, { value: 'serif', label: 'Serif' }, { value: 'mono', label: 'Monoespaciada' }]} onChange={(v) => updateSetting('fontFamily', v)} />
            <SettingsItem icon={Zap} label="Animaciones" type="switch" value={settings.animations} onChange={(v) => updateSetting('animations', v)} />
            <SettingsItem icon={RefreshCw} label="Transiciones" type="switch" value={settings.transitions} onChange={(v) => updateSetting('transitions', v)} />
            <SettingsItem icon={Monitor} label="Modo Compacto" type="switch" value={settings.compactMode} onChange={(v) => updateSetting('compactMode', v)} />
            <SettingsItem icon={Menu} label="Posición del Menú" type="select" value={settings.sidebarPosition} options={[{ value: 'left', label: 'Izquierda' }, { value: 'right', label: 'Derecha' }]} onChange={(v) => updateSetting('sidebarPosition', v)} />
            <SettingsItem icon={Layers} label="Estilo de Tarjetas" type="select" value={settings.cardStyle} options={[{ value: 'rounded', label: 'Redondeadas' }, { value: 'square', label: 'Cuadradas' }, { value: 'minimal', label: 'Minimalistas' }]} onChange={(v) => updateSetting('cardStyle', v)} />
          </div>
        )
      
      case 'notificaciones':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Bell} label="Notificaciones Push" type="switch" value={settings.pushNotifications} onChange={(v) => updateSetting('pushNotifications', v)} />
            <SettingsItem icon={Mail} label="Notificaciones por Email" type="switch" value={settings.emailNotifications} onChange={(v) => updateSetting('emailNotifications', v)} />
            <SettingsItem icon={Volume2} label="Efectos de Sonido" type="switch" value={settings.soundEffects} onChange={(v) => updateSetting('soundEffects', v)} />
            <SettingsItem icon={Vibrate} label="Vibración" type="switch" value={settings.vibration} onChange={(v) => updateSetting('vibration', v)} />
            <SettingsItem icon={Moon} label="Horario Silencioso" type="switch" value={settings.quietHours} onChange={(v) => updateSetting('quietHours', v)} />
            <SettingsItem icon={Clock} label="Inicio Horario Silencioso" type="select" value={settings.quietHoursStart} options={[{ value: '22:00', label: '22:00' }, { value: '23:00', label: '23:00' }, { value: '00:00', label: '00:00' }]} onChange={(v) => updateSetting('quietHoursStart', v)} />
            <SettingsItem icon={Speaker} label="Sonido de Notificación" type="select" value={settings.notificationSound} options={[{ value: 'default', label: 'Predeterminado' }, { value: 'bell', label: 'Campana' }, { value: 'chime', label: 'Timbre' }]} onChange={(v) => updateSetting('notificationSound', v)} />
          </div>
        )
      
      case 'privacidad':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Eye} label="Perfil Privado" description="Solo tú verás tu actividad" type="switch" value={settings.privateProfile} onChange={(v) => updateSetting('privateProfile', v)} />
            <SettingsItem icon={Activity} label="Mostrar Actividad" type="switch" value={settings.showActivityGeneral} onChange={(v) => updateSetting('showActivityGeneral', v)} />
            <SettingsItem icon={Heart} label="Mostrar Favoritos" type="switch" value={settings.showFavoritesGeneral} onChange={(v) => updateSetting('showFavoritesGeneral', v)} />
            <SettingsItem icon={Users} label="Permitir Seguidores" type="switch" value={settings.allowFollowersGeneral} onChange={(v) => updateSetting('allowFollowersGeneral', v)} />
            <SettingsItem icon={Database} label="Recogida de Datos" type="switch" value={settings.dataCollectionGeneral} onChange={(v) => updateSetting('dataCollectionGeneral', v)} />
            <SettingsItem icon={Share2} label="Compartir con Terceros" type="switch" value={settings.thirdPartySharingGeneral} onChange={(v) => updateSetting('thirdPartySharingGeneral', v)} />
            <SettingsItem icon={Shield} label="Consentimiento de Cookies" type="switch" value={settings.cookieConsentGeneral} onChange={(v) => updateSetting('cookieConsentGeneral', v)} />
          </div>
        )
      
      case 'accesibilidad':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Volume2} label="Lector de Pantalla" type="switch" value={settings.screenReader} onChange={(v) => updateSetting('screenReader', v)} />
            <SettingsItem icon={Contrast} label="Alto Contraste" type="switch" value={settings.highContrast} onChange={(v) => updateSetting('highContrast', v)} />
            <SettingsItem icon={Zap} label="Reducir Movimiento" type="switch" value={settings.reduceMotion} onChange={(v) => updateSetting('reduceMotion', v)} />
            <SettingsItem icon={Type} label="Texto Grande" type="switch" value={settings.largeText} onChange={(v) => updateSetting('largeText', v)} />
            <SettingsItem icon={Type} label="Texto en Negrita" type="switch" value={settings.boldText} onChange={(v) => updateSetting('boldText', v)} />
            <SettingsItem icon={Mic} label="Control por Voz" type="switch" value={settings.voiceControl} onChange={(v) => updateSetting('voiceControl', v)} />
            <SettingsItem icon={Hand} label="Control por Interruptores" type="switch" value={settings.switchControl} onChange={(v) => updateSetting('switchControl', v)} />
            <SettingsItem icon={Eye} label="Modo Daltonismo" type="switch" value={settings.colorBlindMode} onChange={(v) => updateSetting('colorBlindMode', v)} />
            <SettingsItem icon={Type} label="Fuente para Dislexia" type="switch" value={settings.dyslexiaFont} onChange={(v) => updateSetting('dyslexiaFont', v)} />
            <SettingsItem icon={MessageSquare} label="Lengua de Signos" type="switch" value={settings.signLanguage} onChange={(v) => updateSetting('signLanguage', v)} />
            <SettingsItem icon={Video} label="Subtítulos" type="switch" value={settings.subtitles} onChange={(v) => updateSetting('subtitles', v)} />
            <SettingsItem icon={Volume2} label="Audiodescripciones" type="switch" value={settings.audioDescriptions} onChange={(v) => updateSetting('audioDescriptions', v)} />
            <SettingsItem icon={Vibrate} label="Respuesta Háptica" type="switch" value={settings.hapticFeedback} onChange={(v) => updateSetting('hapticFeedback', v)} />
            <SettingsItem icon={Eye} label="Indicador de Foco" type="switch" value={settings.focusIndicator} onChange={(v) => updateSetting('focusIndicator', v)} />
            <SettingsItem icon={KeyboardIcon} label="Navegación por Teclado" type="switch" value={settings.keyboardNavigation} onChange={(v) => updateSetting('keyboardNavigation', v)} />
            <SettingsItem icon={Volume2} label="Texto a Voz" type="switch" value={settings.textToSpeech} onChange={(v) => updateSetting('textToSpeech', v)} />
            <SettingsItem icon={ZoomIn} label="Zoom de Pantalla" type="switch" value={settings.screenZoom} onChange={(v) => updateSetting('screenZoom', v)} />
          </div>
        )
      
      case 'cocina':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Users} label="Porciones por Defecto" type="select" value={settings.defaultServings.toString()} options={[{ value: '1', label: '1 persona' }, { value: '2', label: '2 personas' }, { value: '4', label: '4 personas' }, { value: '6', label: '6 personas' }]} onChange={(v) => updateSetting('defaultServings', parseInt(v))} />
            <SettingsItem icon={Scale} label="Sistema de Medidas" type="select" value={settings.measurementSystem} options={[{ value: 'metric', label: 'Métrico (g, ml)' }, { value: 'imperial', label: 'Imperial (oz, cups)' }]} onChange={(v) => updateSetting('measurementSystem', v)} />
            <SettingsItem icon={ThermometerSun} label="Unidad de Temperatura" type="select" value={settings.temperatureUnit} options={[{ value: 'celsius', label: 'Celsius (°C)' }, { value: 'fahrenheit', label: 'Fahrenheit (°F)' }]} onChange={(v) => updateSetting('temperatureUnit', v)} />
            <SettingsItem icon={Volume2} label="Sonidos del Temporizador" type="switch" value={settings.timerSounds} onChange={(v) => updateSetting('timerSounds', v)} />
            <SettingsItem icon={RefreshCw} label="Conversión Automática" type="switch" value={settings.autoConvert} onChange={(v) => updateSetting('autoConvert', v)} />
            <SettingsItem icon={ShoppingCart} label="Ordenar Lista de Compras" type="select" value={settings.shoppingSort} options={[{ value: 'recipe', label: 'Por Receta' }, { value: 'category', label: 'Por Categoría' }, { value: 'alphabetical', label: 'Alfabético' }]} onChange={(v) => updateSetting('shoppingSort', v)} />
          </div>
        )
      
      case 'beta':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Sparkles} label="Recetas con IA" description="Generar recetas automáticamente" type="switch" value={settings.aiRecipes} onChange={(v) => updateSetting('aiRecipes', v)} beta />
            <SettingsItem icon={Mic} label="Cocción por Voz" type="switch" value={settings.voiceCooking} onChange={(v) => updateSetting('voiceCooking', v)} beta />
            <SettingsItem icon={Camera} label="Modo AR" description="Realidad aumentada" type="switch" value={settings.arMode} onChange={(v) => updateSetting('arMode', v)} beta />
            <SettingsItem icon={Flame} label="Horno Inteligente" type="switch" value={settings.smartOven} onChange={(v) => updateSetting('smartOven', v)} beta />
            <SettingsItem icon={Database} label="Integración Nevera" type="switch" value={settings.fridgeIntegration} onChange={(v) => updateSetting('fridgeIntegration', v)} beta />
            <SettingsItem icon={Package} label="Meal Kits" type="switch" value={settings.mealKits} onChange={(v) => updateSetting('mealKits', v)} beta />
            <SettingsItem icon={Video} label="Recetas en Video" type="switch" value={settings.videoRecipes} onChange={(v) => updateSetting('videoRecipes', v)} beta />
            <SettingsItem icon={RadioIcon} label="Cocción en Vivo" type="switch" value={settings.liveCooking} onChange={(v) => updateSetting('liveCooking', v)} beta />
            <SettingsItem icon={Users} label="Cocción Social" type="switch" value={settings.socialCooking} onChange={(v) => updateSetting('socialCooking', v)} beta />
            <SettingsItem icon={Camera} label="Reconocimiento de Ingredientes" type="switch" value={settings.ingredientRecognition} onChange={(v) => updateSetting('ingredientRecognition', v)} beta />
            <SettingsItem icon={Trash2} label="Seguimiento de Desperdicio" type="switch" value={settings.wasteTracking} onChange={(v) => updateSetting('wasteTracking', v)} beta />
            <SettingsItem icon={Heart} label="Nutrición IA" type="switch" value={settings.nutritionAI} onChange={(v) => updateSetting('nutritionAI', v)} beta />
            <SettingsItem icon={Activity} label="Contador de Calorías" type="switch" value={settings.calorieCounter} onChange={(v) => updateSetting('calorieCounter', v)} beta />
          </div>
        )
      
      case 'chromecast':
        return (
          <div className="space-y-1">
            <SettingsItem icon={Cast} label="Chromecast Activado" type="switch" value={settings.chromecastEnabled} onChange={(v) => updateSetting('chromecastEnabled', v)} />
            <SettingsItem icon={Wifi} label="Conexión Automática" type="switch" value={settings.autoConnect} onChange={(v) => updateSetting('autoConnect', v)} />
            <SettingsItem icon={Monitor} label="Calidad de Video" type="select" value={settings.quality} options={[{ value: 'auto', label: 'Automático' }, { value: 'hd', label: 'HD' }, { value: '4k', label: '4K' }]} onChange={(v) => updateSetting('quality', v)} />
            <SettingsItem icon={MessageSquare} label="Subtítulos CC" type="switch" value={settings.subtitlesCC} onChange={(v) => updateSetting('subtitlesCC', v)} />
            <SettingsItem icon={ImageOff} label="Imagen de Fondo" type="switch" value={settings.backgroundImage} onChange={(v) => updateSetting('backgroundImage', v)} />
            <SettingsItem icon={Tv} label="Protector de Pantalla" type="switch" value={settings.screensaver} onChange={(v) => updateSetting('screensaver', v)} />
            <SettingsItem icon={Monitor} label="Nombre del Dispositivo" type="input" value={settings.deviceName} onChange={(v) => updateSetting('deviceName', v)} />
          </div>
        )
      
      case 'avanzado':
        // Solo accesible para admin - Incluye 9 ajustes avanzados + 5 de desarrollador oculto
        if (!isAdmin) return null
        return (
          <div className="space-y-4">
            {/* Banner de advertencia */}
            <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-3">
              <div className="flex items-center gap-2 text-red-700 dark:text-red-400">
                <Shield className="h-4 w-4" />
                <span className="font-medium text-sm">Sección de Administrador</span>
              </div>
              <p className="text-xs text-red-600 dark:text-red-500 mt-1">Estos ajustes son avanzados y pueden afectar el funcionamiento de la app.</p>
            </div>
            
            {/* Ajustes Avanzados (9) */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  <Terminal className="h-4 w-4" />
                  Ajustes Avanzados (9)
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-1 p-0 px-6 pb-4">
                <SettingsItem icon={Code} label="Modo Desarrollador" type="switch" value={settings.developerMode} onChange={(v) => updateSetting('developerMode', v)} />
                <SettingsItem icon={Bug} label="Modo Debug" type="switch" value={settings.debugMode} onChange={(v) => updateSetting('debugMode', v)} />
                <SettingsItem icon={Server} label="Endpoint API" type="select" value={settings.apiEndpoint} options={[{ value: 'default', label: 'Predeterminado' }, { value: 'eu', label: 'Europa' }, { value: 'us', label: 'EEUU' }]} onChange={(v) => updateSetting('apiEndpoint', v)} />
                <SettingsItem icon={Database} label="Tamaño de Caché (MB)" type="slider" value={settings.cacheSize} onChange={(v) => updateSetting('cacheSize', v)} />
                <SettingsItem icon={Trash2} label="Limpiar Caché al Salir" type="switch" value={settings.clearCacheOnExit} onChange={(v) => updateSetting('clearCacheOnExit', v)} />
                <SettingsItem icon={Zap} label="Funciones Experimentales" type="switch" value={settings.experimentalFeatures} onChange={(v) => updateSetting('experimentalFeatures', v)} />
                <SettingsItem icon={RadioIcon} label="Canal Beta" type="switch" value={settings.betaChannel} onChange={(v) => updateSetting('betaChannel', v)} />
                <SettingsItem icon={Activity} label="Nivel de Log" type="select" value={settings.logLevel} options={[{ value: 'debug', label: 'Debug' }, { value: 'info', label: 'Info' }, { value: 'warn', label: 'Warning' }, { value: 'error', label: 'Error' }]} onChange={(v) => updateSetting('logLevel', v)} />
                <SettingsItem icon={Clock} label="Timeout de Red (s)" type="slider" value={settings.networkTimeout} onChange={(v) => updateSetting('networkTimeout', v)} />
              </CardContent>
            </Card>
            
            {/* Ajustes de Desarrollador Ocultos (5) */}
            <Card className="border-purple-200 dark:border-purple-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2 text-purple-700 dark:text-purple-400">
                  <TerminalSquare className="h-4 w-4" />
                  Ajustes de Desarrollador Ocultos (5)
                </CardTitle>
                <CardDescription>Estos ajustes son exclusivos para desarrollo y depuración.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-1 p-0 px-6 pb-4">
                <SettingsItem icon={Terminal} label="Consola de Desarrollo" description="Mostrar consola de depuración" type="switch" value={settings.showDevConsole} onChange={(v) => updateSetting('showDevConsole', v)} />
                <SettingsItem icon={FileCode} label="Logger de API" description="Registrar todas las llamadas API" type="switch" value={settings.enableApiLogger} onChange={(v) => updateSetting('enableApiLogger', v)} />
                <SettingsItem icon={Binary} label="Mock API Responses" description="Usar respuestas simuladas" type="switch" value={settings.mockApiResponses} onChange={(v) => updateSetting('mockApiResponses', v)} />
                <SettingsItem icon={BarChart3} label="Métricas de Rendimiento" description="Mostrar FPS y memoria" type="switch" value={settings.showPerformanceMetrics} onChange={(v) => updateSetting('showPerformanceMetrics', v)} />
                <SettingsItem icon={Database} label="Debug de Base de Datos" description="Mostrar consultas DB en consola" type="switch" value={settings.debugDatabase} onChange={(v) => updateSetting('debugDatabase', v)} />
              </CardContent>
            </Card>
          </div>
        )
      
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
                  <Settings className="h-8 w-8 text-orange-500" />
                  Ajustes
                </h1>
                <p className="text-muted-foreground">
                  Personaliza tu experiencia en CocinaViva
                </p>
              </div>
              <div 
                className="cursor-pointer select-none text-right"
                onClick={handleVersionClick}
              >
                <p className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                  v2.0.0
                </p>
                <p className="text-xs text-muted-foreground">© 2026 CocinaViva</p>
                {isAdmin && (
                  <Badge className="mt-1 bg-red-500 text-xs">
                    <Shield className="h-3 w-3 mr-1" />
                    Admin
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8 max-w-2xl">
          {currentCategory === 'main' ? (
            <>
              {/* User Profile Card */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Perfil de Usuario
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {isAuthenticated ? (
                    <>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{userName}</p>
                          <p className="text-sm text-muted-foreground">{userEmail}</p>
                        </div>
                        <Badge variant="secondary">Conectado</Badge>
                      </div>
                      <Separator />
                      <div className="flex gap-2">
                        <Button variant="outline" className="flex-1" onClick={() => setCurrentCategory('perfil')}>
                          <User className="h-4 w-4 mr-2" />
                          Editar Perfil
                        </Button>
                        <Button variant="outline" onClick={() => logout()}>
                          <LogOut className="h-4 w-4 mr-2" />
                          Cerrar Sesión
                        </Button>
                      </div>
                    </>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground mb-4">Inicia sesión para guardar tus preferencias</p>
                      <Button 
                        className="bg-gradient-to-r from-orange-500 to-green-500"
                        onClick={() => setShowLoginModal(true)}
                      >
                        Iniciar Sesión
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Settings Categories */}
              <div className="space-y-2">
                {categories.map((category) => {
                  const Icon = category.icon
                  return (
                    <motion.div
                      key={category.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <Card 
                        className={`cursor-pointer hover:shadow-md transition-all ${
                          category.id === 'avanzado' || category.id === 'desarrollador' 
                            ? 'border-red-200 dark:border-red-800' 
                            : ''
                        }`}
                        onClick={() => setCurrentCategory(category.id)}
                      >
                        <CardContent className="p-4 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center`}>
                              <Icon className="h-5 w-5 text-white" />
                            </div>
                            <div>
                              <p className="font-medium">{category.label}</p>
                              <p className="text-sm text-muted-foreground">{category.count} ajustes</p>
                            </div>
                          </div>
                          <ChevronRight className="h-5 w-5 text-muted-foreground" />
                        </CardContent>
                      </Card>
                    </motion.div>
                  )
                })}
              </div>

              {/* About */}
              <Card className="mt-6">
                <CardContent className="p-4">
                  <div className="text-center cursor-pointer" onClick={handleVersionClick}>
                    <p className="text-sm text-muted-foreground">
                      CocinaViva v2.0.0
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      © 2026 Todos los derechos reservados
                    </p>
                    {isAdmin && (
                      <Badge className="mt-2 bg-red-500">
                        <Shield className="h-3 w-3 mr-1" />
                        Modo Admin Activo
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <>
              {/* Back Button */}
              <Button 
                variant="ghost" 
                className="mb-4"
                onClick={() => setCurrentCategory('main')}
              >
                <ChevronLeft className="h-4 w-4 mr-2" />
                Volver a Ajustes
              </Button>

              {/* Category Title */}
              <div className="flex items-center gap-3 mb-6">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${categories.find(c => c.id === currentCategory)?.color} flex items-center justify-center`}>
                  {(() => {
                    const Icon = categories.find(c => c.id === currentCategory)?.icon || Settings
                    return <Icon className="h-6 w-6 text-white" />
                  })()}
                </div>
                <div>
                  <h2 className="text-2xl font-bold">{categories.find(c => c.id === currentCategory)?.label}</h2>
                  <p className="text-muted-foreground">{categories.find(c => c.id === currentCategory)?.count} ajustes</p>
                </div>
              </div>

              {/* Settings List */}
              <Card>
                <CardContent className="p-4">
                  {renderSettingsContent()}
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>

      {/* Password Input Modal */}
      {showPasswordInput && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50">
          <Card className="w-full max-w-sm mx-4">
            <CardHeader>
              <CardTitle>Modo Administrador</CardTitle>
              <CardDescription>Introduce la contraseña de administrador</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                type="password"
                placeholder="Contraseña"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handlePasswordSubmit()}
              />
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setShowPasswordInput(false)}>
                  Cancelar
                </Button>
                <Button className="flex-1" onClick={handlePasswordSubmit}>
                  Confirmar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Login Modal */}
      <LoginModal 
        isOpen={showLoginModal} 
        onClose={() => setShowLoginModal(false)}
      />

      <Footer />
    </div>
  )
}
