import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/search - Advanced search
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q') || ''
    const ingredients = searchParams.get('ingredients')?.split(',').filter(Boolean) || []

    const where: Record<string, unknown> = {
      isPublic: true,
    }

    if (query) {
      where.OR = [
        { title: { contains: query } },
        { description: { contains: query } },
      ]
    }

    // Get all matching recipes
    let recipes = await db.recipe.findMany({
      where,
      include: {
        category: true,
        tags: {
          include: {
            tag: true,
          },
        },
        ingredients: {
          include: {
            ingredient: true,
          },
        },
      },
      orderBy: { averageRating: 'desc' },
      take: 50,
    })

    // Filter by ingredients if specified
    if (ingredients.length > 0) {
      recipes = recipes.filter(recipe => {
        const recipeIngredientIds = recipe.ingredients.map(ri => ri.ingredientId)
        return ingredients.some(ingId => recipeIngredientIds.includes(ingId))
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        items: recipes,
        total: recipes.length,
        query,
        ingredients,
      },
    })
  } catch (error) {
    console.error('Error searching:', error)
    return NextResponse.json(
      { success: false, error: 'Error en la búsqueda' },
      { status: 500 }
    )
  }
}
