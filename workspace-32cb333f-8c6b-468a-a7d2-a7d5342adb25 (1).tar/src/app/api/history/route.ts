import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/history - Get user cooking history
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const history = await db.history.findMany({
      where: { userId },
      include: {
        recipe: {
          include: {
            category: true,
          },
        },
        historyNotes: true,
      },
      orderBy: { cookedAt: 'desc' },
      take: 50,
    })

    return NextResponse.json({ success: true, data: history })
  } catch (error) {
    console.error('Error fetching history:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener el historial' },
      { status: 500 }
    )
  }
}

// POST /api/history - Add to history
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, recipeId, portions, notes } = body

    if (!userId || !recipeId) {
      return NextResponse.json(
        { success: false, error: 'userId y recipeId son requeridos' },
        { status: 400 }
      )
    }

    const history = await db.history.create({
      data: {
        userId,
        recipeId,
        portions,
        notes,
      },
    })

    return NextResponse.json({ success: true, data: history })
  } catch (error) {
    console.error('Error adding to history:', error)
    return NextResponse.json(
      { success: false, error: 'Error al agregar al historial' },
      { status: 500 }
    )
  }
}
