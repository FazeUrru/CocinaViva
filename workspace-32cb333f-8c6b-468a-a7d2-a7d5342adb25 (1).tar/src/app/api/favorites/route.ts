import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/favorites - Get user favorites
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { success: false, error: 'userId es requerido' },
        { status: 400 }
      )
    }

    const favorites = await db.favorite.findMany({
      where: { userId },
      include: {
        recipe: {
          include: {
            category: true,
            tags: {
              include: {
                tag: true,
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ success: true, data: favorites })
  } catch (error) {
    console.error('Error fetching favorites:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener los favoritos' },
      { status: 500 }
    )
  }
}

// POST /api/favorites - Add favorite
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, recipeId } = body

    if (!userId || !recipeId) {
      return NextResponse.json(
        { success: false, error: 'userId y recipeId son requeridos' },
        { status: 400 }
      )
    }

    // Check if already exists
    const existing = await db.favorite.findUnique({
      where: {
        userId_recipeId: { userId, recipeId },
      },
    })

    if (existing) {
      return NextResponse.json(
        { success: false, error: 'La receta ya está en favoritos' },
        { status: 400 }
      )
    }

    const favorite = await db.favorite.create({
      data: { userId, recipeId },
    })

    return NextResponse.json({ success: true, data: favorite })
  } catch (error) {
    console.error('Error adding favorite:', error)
    return NextResponse.json(
      { success: false, error: 'Error al agregar a favoritos' },
      { status: 500 }
    )
  }
}

// DELETE /api/favorites - Remove favorite
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, recipeId } = body

    if (!userId || !recipeId) {
      return NextResponse.json(
        { success: false, error: 'userId y recipeId son requeridos' },
        { status: 400 }
      )
    }

    await db.favorite.delete({
      where: {
        userId_recipeId: { userId, recipeId },
      },
    })

    return NextResponse.json({ success: true, message: 'Eliminado de favoritos' })
  } catch (error) {
    console.error('Error removing favorite:', error)
    return NextResponse.json(
      { success: false, error: 'Error al eliminar de favoritos' },
      { status: 500 }
    )
  }
}
