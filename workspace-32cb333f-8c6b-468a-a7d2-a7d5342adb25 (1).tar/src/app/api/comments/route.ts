import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/comments - Get comments for a recipe
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const recipeId = searchParams.get('recipeId')

    if (!recipeId) {
      return NextResponse.json(
        { success: false, error: 'recipeId es requerido' },
        { status: 400 }
      )
    }

    const comments = await db.comment.findMany({
      where: {
        recipeId,
        parentId: null, // Only get top-level comments
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
        replies: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true,
              },
            },
          },
          orderBy: { createdAt: 'asc' },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ success: true, data: comments })
  } catch (error) {
    console.error('Error fetching comments:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener los comentarios' },
      { status: 500 }
    )
  }
}

// POST /api/comments - Add comment
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { recipeId, userId, content, rating, parentId } = body

    if (!recipeId || !userId || !content) {
      return NextResponse.json(
        { success: false, error: 'recipeId, userId y content son requeridos' },
        { status: 400 }
      )
    }

    const comment = await db.comment.create({
      data: {
        recipeId,
        userId,
        content,
        rating,
        parentId,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true,
          },
        },
      },
    })

    return NextResponse.json({ success: true, data: comment })
  } catch (error) {
    console.error('Error adding comment:', error)
    return NextResponse.json(
      { success: false, error: 'Error al agregar el comentario' },
      { status: 500 }
    )
  }
}
