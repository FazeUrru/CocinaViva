'use client'

import { useState, use } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Search,
  Filter,
  Grid,
  List,
  Clock,
  Users,
  Star,
  ChefHat,
  Thermometer,
  Soup,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'
import allRecipes from '@/data/recipes'

const mealTypes = [
  { value: 'desayuno', label: 'Desayuno', icon: '🥐' },
  { value: 'almuerzo', label: 'Almuerzo', icon: '🍽️' },
  { value: 'cena', label: 'Cena', icon: '🌙' },
  { value: 'postre', label: 'Postre', icon: '🍰' },
  { value: 'snack', label: 'Snack', icon: '🍿' },
]

const difficulties = [
  { value: 'facil', label: 'Fácil', color: 'bg-green-500' },
  { value: 'medio', label: 'Medio', color: 'bg-yellow-500' },
  { value: 'dificil', label: 'Difícil', color: 'bg-red-500' },
]

const ITEMS_PER_PAGE = 500 // Show 500 items per page for 6 pages

export default function RecetasPage({
  searchParams,
}: {
  searchParams: Promise<{
    search?: string
    toolType?: string
    isGlutenFree?: string
    mealType?: string
    difficulty?: string
    page?: string
  }>
}) {
  const params = use(searchParams)
  
  const [search, setSearch] = useState(params.search || '')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [filters, setFilters] = useState({
    toolType: params.toolType || 'all',
    isGlutenFree: params.isGlutenFree === 'true',
    mealType: params.mealType || 'all',
    difficulty: params.difficulty || 'all',
    maxTime: 120,
  })
  const [showFilters, setShowFilters] = useState(false)
  const [currentPage, setCurrentPage] = useState(parseInt(params.page || '1'))

  // Filter recipes
  const filteredRecipes = allRecipes.filter(recipe => {
    if (search && !recipe.title.toLowerCase().includes(search.toLowerCase()) && 
        !recipe.description.toLowerCase().includes(search.toLowerCase())) {
      return false
    }
    if (filters.toolType !== 'all' && recipe.toolType !== filters.toolType) {
      return false
    }
    if (filters.isGlutenFree && !recipe.isGlutenFree) {
      return false
    }
    if (filters.mealType !== 'all' && recipe.mealType !== filters.mealType) {
      return false
    }
    if (filters.difficulty !== 'all' && recipe.difficulty !== filters.difficulty) {
      return false
    }
    if (recipe.totalTime > filters.maxTime) {
      return false
    }
    return true
  })

  // Pagination
  const totalPages = Math.min(6, Math.ceil(filteredRecipes.length / ITEMS_PER_PAGE))
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE
  const endIndex = startIndex + ITEMS_PER_PAGE
  const paginatedRecipes = filteredRecipes.slice(startIndex, endIndex)

  const updateFilter = (key: string, value: string | boolean | number) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setCurrentPage(1) // Reset to first page when filter changes
  }

  const clearFilters = () => {
    setFilters({
      toolType: 'all',
      isGlutenFree: false,
      mealType: 'all',
      difficulty: 'all',
      maxTime: 120,
    })
    setSearch('')
    setCurrentPage(1)
  }

  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page)
      window.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  const activeFiltersCount = [
    filters.toolType !== 'all',
    filters.isGlutenFree,
    filters.mealType !== 'all',
    filters.difficulty !== 'all',
    filters.maxTime < 120,
  ].filter(Boolean).length

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <ChefHat className="h-8 w-8 text-orange-500" />
              Recetario
            </h1>
            <p className="text-muted-foreground">
              Explora nuestra colección de {allRecipes.length.toLocaleString()}+ recetas deliciosas
            </p>
          </div>
        </section>

        {/* Search and Filters */}
        <section className="border-b bg-background sticky top-16 z-40">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-wrap items-center gap-4">
              {/* Search */}
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar por nombre o ingrediente..."
                  value={search}
                  onChange={(e) => {
                    setSearch(e.target.value)
                    setCurrentPage(1)
                  }}
                  className="pl-10"
                />
              </div>

              {/* Filter Button - Mobile */}
              <Sheet open={showFilters} onOpenChange={setShowFilters}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <Filter className="h-4 w-4 mr-2" />
                    Filtros
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 h-5 w-5 p-0 flex items-center justify-center bg-orange-500">
                        {activeFiltersCount}
                      </Badge>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-80 overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                    <SheetDescription>
                      Refina tu búsqueda de recetas
                    </SheetDescription>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <FilterContent 
                      filters={filters} 
                      updateFilter={updateFilter} 
                      clearFilters={clearFilters}
                      onApply={() => setShowFilters(false)}
                    />
                  </div>
                </SheetContent>
              </Sheet>

              {/* Desktop Filters */}
              <div className="hidden lg:flex items-center gap-4">
                <Select value={filters.toolType} onValueChange={(v) => updateFilter('toolType', v)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Tipo de cocina" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los tipos</SelectItem>
                    <SelectItem value="tradicional">
                      <div className="flex items-center gap-2">
                        <ChefHat className="h-4 w-4" />
                        Tradicional
                      </div>
                    </SelectItem>
                    <SelectItem value="thermomix">
                      <div className="flex items-center gap-2">
                        <Thermometer className="h-4 w-4" />
                        Thermomix
                      </div>
                    </SelectItem>
                    <SelectItem value="crockpot">
                      <div className="flex items-center gap-2">
                        <Soup className="h-4 w-4" />
                        Crockpot
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filters.mealType} onValueChange={(v) => updateFilter('mealType', v)}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Tipo de plato" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    {mealTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.icon} {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select value={filters.difficulty} onValueChange={(v) => updateFilter('difficulty', v)}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Dificultad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas</SelectItem>
                    {difficulties.map(diff => (
                      <SelectItem key={diff.value} value={diff.value}>
                        {diff.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <div className="flex items-center gap-2">
                  <Checkbox
                    id="glutenFree"
                    checked={filters.isGlutenFree}
                    onCheckedChange={(checked) => updateFilter('isGlutenFree', checked === true)}
                  />
                  <Label htmlFor="glutenFree" className="text-sm cursor-pointer">
                    Sin Gluten
                  </Label>
                </div>

                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="h-4 w-4 mr-1" />
                    Limpiar
                  </Button>
                )}
              </div>

              {/* View Mode Toggle */}
              <div className="flex items-center border rounded-lg">
                <Button
                  variant={viewMode === 'grid' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'secondary' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Results */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            {/* Results Count */}
            <div className="mb-6 flex items-center justify-between">
              <p className="text-muted-foreground">
                Mostrando {startIndex + 1}-{Math.min(endIndex, filteredRecipes.length)} de {filteredRecipes.length.toLocaleString()} recetas
              </p>
              <p className="text-sm text-muted-foreground">
                Página {currentPage} de {totalPages}
              </p>
            </div>

            {filteredRecipes.length === 0 ? (
              <div className="text-center py-16">
                <ChefHat className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">No se encontraron recetas</h3>
                <p className="text-muted-foreground mb-4">
                  Prueba a modificar los filtros de búsqueda
                </p>
                <Button onClick={clearFilters}>
                  Limpiar filtros
                </Button>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {paginatedRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: (index % 12) * 0.02 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                        <div className="relative h-48 overflow-hidden bg-gradient-to-br from-orange-100 to-green-100">
                          <img
                            src={recipe.imageUrl}
                            alt={recipe.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement
                              target.src = `/images/recipes/placeholder-${recipe.mealType}.png`
                            }}
                          />
                          <div className="absolute top-3 left-3 flex gap-2">
                            {recipe.isGlutenFree && (
                              <Badge className="bg-green-500 hover:bg-green-600 text-xs">
                                Sin Gluten
                              </Badge>
                            )}
                          </div>
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-yellow-500 hover:bg-yellow-600 text-xs">
                              <Star className="h-3 w-3 mr-1 fill-white" />
                              {recipe.averageRating.toFixed(1)}
                            </Badge>
                          </div>
                          <div className="absolute bottom-3 left-3">
                            <Badge variant="secondary" className="bg-white/90 text-gray-800 text-xs">
                              {recipe.toolType === 'tradicional' ? '🍳 Tradicional' : 
                               recipe.toolType === 'thermomix' ? '⚡ Thermomix' : '🍲 Crockpot'}
                            </Badge>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle className="line-clamp-1 text-base">{recipe.title}</CardTitle>
                          <CardDescription className="line-clamp-2 text-sm">
                            {recipe.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex items-center gap-3 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {recipe.totalTime} min
                            </div>
                            <div className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              4 pers.
                            </div>
                            <Badge variant="outline" className={cn(
                              "text-xs",
                              recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                              recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                              recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                            )}>
                              {recipe.difficulty === 'facil' ? 'Fácil' : 
                               recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {paginatedRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: (index % 12) * 0.02 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="hover:shadow-lg transition-all cursor-pointer group">
                        <div className="flex">
                          <div className="w-40 h-32 relative flex-shrink-0 overflow-hidden rounded-l-lg bg-gradient-to-br from-orange-100 to-green-100">
                            <img
                              src={recipe.imageUrl}
                              alt={recipe.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement
                                target.src = `/images/recipes/placeholder-${recipe.mealType}.png`
                              }}
                            />
                          </div>
                          <div className="flex-1 p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                                <CardDescription className="line-clamp-1 mt-1">
                                  {recipe.description}
                                </CardDescription>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                <span className="font-medium">{recipe.averageRating.toFixed(1)}</span>
                                <span className="text-muted-foreground text-sm">({recipe.ratingCount})</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {recipe.totalTime} min
                              </div>
                              <Badge variant="outline" className={cn(
                                "text-xs",
                                recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                                recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                                recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                              )}>
                                {recipe.difficulty === 'facil' ? 'Fácil' : 
                                 recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                              </Badge>
                              {recipe.isGlutenFree && (
                                <Badge className="bg-green-500 text-xs">Sin Gluten</Badge>
                              )}
                              <Badge variant="secondary" className="text-xs">
                                {recipe.toolType === 'tradicional' ? 'Tradicional' : 
                                 recipe.toolType === 'thermomix' ? 'Thermomix' : 'Crockpot'}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex items-center justify-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => goToPage(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <Button
                    key={page}
                    variant={currentPage === page ? 'default' : 'outline'}
                    size="icon"
                    onClick={() => goToPage(page)}
                    className={cn(
                      "w-10 h-10",
                      currentPage === page && "bg-gradient-to-r from-orange-500 to-green-500"
                    )}
                  >
                    {page}
                  </Button>
                ))}
                
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => goToPage(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

// Filter Content Component
function FilterContent({ 
  filters, 
  updateFilter, 
  clearFilters,
  onApply 
}: { 
  filters: { toolType: string; isGlutenFree: boolean; mealType: string; difficulty: string; maxTime: number }
  updateFilter: (key: string, value: string | boolean | number) => void
  clearFilters: () => void
  onApply: () => void
}) {
  return (
    <div className="space-y-6">
      {/* Tool Type */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Tipo de Cocina</Label>
        <div className="grid grid-cols-2 gap-2">
          {[
            { value: 'all', label: 'Todos' },
            { value: 'tradicional', label: 'Tradicional' },
            { value: 'thermomix', label: 'Thermomix' },
            { value: 'crockpot', label: 'Crockpot' },
          ].map(option => (
            <Button
              key={option.value}
              variant={filters.toolType === option.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('toolType', option.value)}
              className="justify-start"
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Meal Type */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Tipo de Plato</Label>
        <div className="flex flex-wrap gap-2">
          {mealTypes.map(type => (
            <Button
              key={type.value}
              variant={filters.mealType === type.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('mealType', filters.mealType === type.value ? 'all' : type.value)}
            >
              {type.icon} {type.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Difficulty */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Dificultad</Label>
        <div className="flex gap-2">
          {difficulties.map(diff => (
            <Button
              key={diff.value}
              variant={filters.difficulty === diff.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateFilter('difficulty', filters.difficulty === diff.value ? 'all' : diff.value)}
            >
              {diff.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Max Time */}
      <div>
        <Label className="text-sm font-medium mb-3 block">
          Tiempo máximo: {filters.maxTime} minutos
        </Label>
        <Slider
          value={[filters.maxTime]}
          onValueChange={([value]) => updateFilter('maxTime', value)}
          max={180}
          step={15}
        />
      </div>

      {/* Gluten Free */}
      <div className="flex items-center space-x-2">
        <Checkbox
          id="glutenFreeMobile"
          checked={filters.isGlutenFree}
          onCheckedChange={(checked) => updateFilter('isGlutenFree', checked === true)}
        />
        <Label htmlFor="glutenFreeMobile" className="cursor-pointer">
          Solo recetas sin gluten
        </Label>
      </div>

      <div className="flex gap-2 pt-4">
        <Button variant="outline" onClick={clearFilters} className="flex-1">
          Limpiar
        </Button>
        <Button onClick={onApply} className="flex-1 bg-gradient-to-r from-orange-500 to-green-500">
          Aplicar
        </Button>
      </div>
    </div>
  )
}
