'use client'

import { useState, useEffect, use } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  ArrowLeft,
  Clock,
  Users,
  Star,
  Heart,
  Share2,
  Bookmark,
  Printer,
  Timer,
  Play,
  MessageCircle,
  ChefHat,
  Check,
  ShoppingCart,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  AlertCircle,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useShoppingListStore, useUserStore, useStepTrackingStore } from '@/store'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

// Demo recipe data
const recipeData = {
  id: '1',
  title: 'Paella Valenciana',
  description: 'La auténtica paella valenciana con pollo, conejo y judías verdes. Un plato tradicional español que captura la esencia de la cocina mediterránea.',
  imageUrl: '/images/recipes/paella.png',
  prepTime: 20,
  cookTime: 40,
  totalTime: 60,
  servings: 4,
  difficulty: 'medio',
  cuisineType: 'española',
  mealType: 'almuerzo',
  toolType: 'tradicional',
  isGlutenFree: true,
  averageRating: 4.8,
  ratingCount: 156,
  viewCount: 3420,
  ingredients: [
    { id: '1', name: 'Arroz bomba', quantity: 400, unit: 'g', notes: 'preferiblemente arroz de Valencia' },
    { id: '2', name: 'Pollo troceado', quantity: 500, unit: 'g', notes: '' },
    { id: '3', name: 'Conejo troceado', quantity: 400, unit: 'g', notes: '' },
    { id: '4', name: 'Judías verdes', quantity: 200, unit: 'g', notes: 'cortadas en trozos' },
    { id: '5', name: 'Garrofón', quantity: 100, unit: 'g', notes: 'alubias blancas grandes' },
    { id: '6', name: 'Tomate triturado', quantity: 100, unit: 'g', notes: '' },
    { id: '7', name: 'Aceite de oliva', quantity: 80, unit: 'ml', notes: 'virgen extra' },
    { id: '8', name: 'Azafrán', quantity: 1, unit: 'g', notes: 'en hebras' },
    { id: '9', name: 'Pimentón dulce', quantity: 1, unit: 'cucharadita', notes: '' },
    { id: '10', name: 'Agua', quantity: 1.2, unit: 'l', notes: 'caliente' },
    { id: '11', name: 'Sal', quantity: 1, unit: 'cucharadita', notes: 'o al gusto' },
  ],
  steps: [
    {
      id: '1',
      stepNumber: 1,
      instruction: 'Calentar el aceite en la paellera a fuego medio-alto. Cuando el aceite esté caliente, añadir el pollo y el conejo troceados.',
      duration: 5,
      tip: 'El aceite debe cubrir bien el fondo de la paellera para que la carne se dore uniformemente.'
    },
    {
      id: '2',
      stepNumber: 2,
      instruction: 'Dorar la carne por todos lados durante unos 10-15 minutos. Es importante que la carne quede bien dorada para que suelte sus jugos y sabor.',
      duration: 15,
      tip: 'No tengas prisa en este paso, un buen dorado es clave para el sabor final.'
    },
    {
      id: '3',
      stepNumber: 3,
      instruction: 'Apartar la carne hacia los bordes de la paellera y añadir las judías verdes y el garrofón en el centro. Sofreír durante 5 minutos.',
      duration: 5,
      tip: 'Las verduras deben quedar ligeramente doradas pero no quemadas.'
    },
    {
      id: '4',
      stepNumber: 4,
      instruction: 'Hacer un hueco en el centro, añadir el tomate triturado y sofreír hasta que pierda el agua.',
      duration: 5,
      tip: 'El tomate debe quedar oscuro y concentrado.'
    },
    {
      id: '5',
      stepNumber: 5,
      instruction: 'Añadir el pimentón dulce, remover rápidamente e inmediatamente añadir el agua caliente para que no se queme el pimentón.',
      duration: 1,
      tip: 'El pimentón quemado amarga el plato, así que añade el agua rápido.'
    },
    {
      id: '6',
      stepNumber: 6,
      instruction: 'Añadir el azafrán en hebras y la sal. Dejar hervir durante 15-20 minutos para que se haga el caldo.',
      duration: 20,
      tip: 'El caldo debe estar bien sabroso antes de añadir el arroz.'
    },
    {
      id: '7',
      stepNumber: 7,
      instruction: 'Añadir el arroz en forma de cruz o caballón. Distribuir uniformemente por toda la paellera. Subir el fuego al máximo.',
      duration: 1,
      tip: 'No remuevas el arroz una vez distribuido, déjalo cocinar.'
    },
    {
      id: '8',
      stepNumber: 8,
      instruction: 'Cocinar a fuego fuerte durante 8-10 minutos, luego bajar el fuego y cocinar otros 8-10 minutos hasta que el arroz esté en su punto.',
      duration: 18,
      tip: 'El arroz debe quedar seco y con el famoso socarrat en el fondo.'
    },
    {
      id: '9',
      stepNumber: 9,
      instruction: 'Retirar del fuego y dejar reposar 5 minutos antes de servir. El arroz terminará de cocinarse con el calor residual.',
      duration: 5,
      tip: 'Tapar con un paño limpio durante el reposo para que se termine de hacer.'
    },
  ],
  tags: [
    { id: '1', name: 'Tradicional', slug: 'tradicional', color: 'bg-orange-500' },
    { id: '2', name: 'Sin Gluten', slug: 'sin-gluten', color: 'bg-green-500' },
    { id: '3', name: 'Mediterránea', slug: 'mediterranea', color: 'bg-blue-500' },
  ],
  comments: [
    {
      id: '1',
      userId: 'user1',
      content: '¡Increíble receta! La hice ayer y salió perfecta. El socarrat quedó espectacular.',
      createdAt: new Date(Date.now() - 86400000 * 2),
      user: { id: 'user1', name: 'María García', avatar: null },
      rating: 5,
    },
    {
      id: '2',
      userId: 'user2',
      content: 'Muy buena, aunque yo le añado un poco de romero que le da un toque especial.',
      createdAt: new Date(Date.now() - 86400000 * 5),
      user: { id: 'user2', name: 'Carlos López', avatar: null },
      rating: 4,
    },
  ],
  substitutions: [
    { ingredient: 'Arroz bomba', substitute: 'Arroz calasparra', ratio: 1, notes: 'Similar resultado, necesita algo más de tiempo' },
    { ingredient: 'Conejo', substitute: 'Pollo adicional', ratio: 1, notes: 'Para quienes no coman conejo' },
    { ingredient: 'Azafrán', substitute: 'Colorante alimentario', ratio: 1, notes: 'Menos sabor pero mismo color' },
  ],
}

const portionOptions = [2, 3, 4, 5, 6]

export default function RecipeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const recipe = recipeData // In real app, fetch by ID
  
  const [servings, setServings] = useState(recipe.servings)
  const [isFavorite, setIsFavorite] = useState(false)
  const [userRating, setUserRating] = useState(0)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [comment, setComment] = useState('')
  const [showStepByStep, setShowStepByStep] = useState(false)
  
  const { addItem } = useShoppingListStore()
  const { userId, progress } = useUserStore()
  
  // Check if recipe is saved (using local state for demo)
  const [isSaved, setIsSaved] = useState(false)
  const isRecipeSaved = (id: string) => isSaved
  const saveRecipe = (id: string) => setIsSaved(true)
  const removeRecipe = (id: string) => setIsSaved(false)

  // Calculate ingredient quantities based on servings
  const ingredientMultiplier = servings / recipe.servings

  // Add to favorites
  const toggleFavorite = async () => {
    setIsFavorite(!isFavorite)
    toast.success(isFavorite ? 'Eliminado de favoritos' : 'Añadido a favoritos')
  }

  // Add ingredients to shopping list
  const addToShoppingList = () => {
    recipe.ingredients.forEach(ing => {
      addItem({
        shoppingListId: 'default',
        ingredientId: ing.id,
        customName: ing.name,
        quantity: ing.quantity * ingredientMultiplier,
        unit: ing.unit,
        isChecked: false,
        notes: ing.notes,
      })
    })
    toast.success('Ingredientes añadidos a la lista de compras')
  }

  // Toggle offline save
  const toggleOfflineSave = () => {
    if (isRecipeSaved(recipe.id)) {
      removeRecipe(recipe.id)
      toast.success('Receta eliminada del modo offline')
    } else {
      saveRecipe(recipe.id)
      toast.success('Receta guardada para uso offline')
    }
  }

  // Share recipe
  const shareRecipe = async () => {
    if (navigator.share) {
      await navigator.share({
        title: recipe.title,
        text: recipe.description,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      toast.success('Enlace copiado al portapapeles')
    }
  }

  // Text-to-speech for hands-free mode
  const speakStep = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = 'es-ES'
      utterance.rate = 0.9
      utterance.onend = () => setIsSpeaking(false)
      window.speechSynthesis.speak(utterance)
      setIsSpeaking(true)
    }
  }

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
    }
  }

  // Format time
  const formatTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins > 0 ? `${mins}min` : ''}`
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Hero Image */}
        <div className="relative h-[40vh] md:h-[50vh] overflow-hidden">
          <img
            src={recipe.imageUrl}
            alt={recipe.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
          
          {/* Back Button */}
          <div className="absolute top-4 left-4">
            <Link href="/recetas">
              <Button variant="secondary" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Volver
              </Button>
            </Link>
          </div>

          {/* Quick Actions */}
          <div className="absolute top-4 right-4 flex gap-2">
            <Button variant="secondary" size="icon" onClick={toggleFavorite}>
              <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500 text-red-500")} />
            </Button>
            <Button variant="secondary" size="icon" onClick={shareRecipe}>
              <Share2 className="h-5 w-5" />
            </Button>
            <Button variant="secondary" size="icon" onClick={toggleOfflineSave}>
              <Bookmark className={cn("h-5 w-5", isRecipeSaved(recipe.id) && "fill-orange-500 text-orange-500")} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="container mx-auto px-4 -mt-20 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Title and Info */}
              <Card>
                <CardHeader>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {recipe.tags.map(tag => (
                      <Badge key={tag.id} className={cn("text-white", tag.color)}>
                        {tag.name}
                      </Badge>
                    ))}
                    {recipe.isGlutenFree && (
                      <Badge className="bg-green-500 text-white">Sin Gluten</Badge>
                    )}
                    <Badge variant="outline">
                      {recipe.toolType === 'tradicional' ? '🍳 Tradicional' : 
                       recipe.toolType === 'thermomix' ? '⚡ Thermomix' : '🍲 Crockpot'}
                    </Badge>
                  </div>
                  <CardTitle className="text-3xl">{recipe.title}</CardTitle>
                  <CardDescription className="text-base">
                    {recipe.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-orange-500" />
                      <div>
                        <div className="font-medium">{formatTime(recipe.totalTime)}</div>
                        <div className="text-muted-foreground text-xs">Tiempo total</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-green-500" />
                      <div>
                        <div className="font-medium">{servings} personas</div>
                        <div className="text-muted-foreground text-xs">Porciones</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                      <div>
                        <div className="font-medium">{recipe.averageRating.toFixed(1)}</div>
                        <div className="text-muted-foreground text-xs">{recipe.ratingCount} valoraciones</div>
                      </div>
                    </div>
                    <Badge variant="outline" className={cn(
                      "text-sm",
                      recipe.difficulty === 'facil' && "border-green-500 text-green-600",
                      recipe.difficulty === 'medio' && "border-yellow-500 text-yellow-600",
                      recipe.difficulty === 'dificil' && "border-red-500 text-red-600"
                    )}>
                      {recipe.difficulty === 'facil' ? 'Fácil' : 
                       recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Portion Calculator */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Calculadora de Porciones
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground">Ajustar para:</span>
                    <Select value={servings.toString()} onValueChange={(v) => setServings(parseInt(v))}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {portionOptions.map(opt => (
                          <SelectItem key={opt} value={opt.toString()}>
                            {opt} {opt === 1 ? 'persona' : 'personas'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {servings !== recipe.servings && (
                      <Badge variant="secondary">
                        Cantidades ajustadas
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Ingredients */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ShoppingCart className="h-5 w-5" />
                      Ingredientes
                    </CardTitle>
                    <Button variant="outline" size="sm" onClick={addToShoppingList}>
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Añadir a compras
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {recipe.ingredients.map((ing) => (
                      <li key={ing.id} className="flex items-start gap-3">
                        <div className="w-5 h-5 rounded-full border-2 border-orange-300 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <Check className="h-3 w-3 text-orange-500 opacity-0 hover:opacity-100" />
                        </div>
                        <div>
                          <span className="font-medium">
                            {(ing.quantity * ingredientMultiplier).toFixed(ing.quantity * ingredientMultiplier % 1 === 0 ? 0 : 1)} {ing.unit}
                          </span>
                          <span> {ing.name}</span>
                          {ing.notes && (
                            <span className="text-muted-foreground text-sm"> ({ing.notes})</span>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* Steps */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ChefHat className="h-5 w-5" />
                      Preparación
                    </CardTitle>
                    <Link href={`/recetas/${recipe.id}/pasos`}>
                      <Button className="bg-gradient-to-r from-orange-500 to-green-500">
                        <Play className="h-4 w-4 mr-2" />
                        Modo Paso a Paso
                      </Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <ol className="space-y-6">
                    {recipe.steps.map((step, index) => (
                      <motion.li
                        key={step.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex gap-4"
                      >
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-green-500 flex items-center justify-center text-white font-bold flex-shrink-0">
                          {step.stepNumber}
                        </div>
                        <div className="flex-1">
                          <p className="text-foreground leading-relaxed">{step.instruction}</p>
                          <div className="flex items-center gap-4 mt-2">
                            {step.duration && (
                              <Badge variant="outline" className="text-xs">
                                <Clock className="h-3 w-3 mr-1" />
                                {step.duration} min
                              </Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => isSpeaking ? stopSpeaking() : speakStep(step.instruction)}
                            >
                              {isSpeaking ? (
                                <VolumeX className="h-4 w-4 mr-1" />
                              ) : (
                                <Volume2 className="h-4 w-4 mr-1" />
                              )}
                              {isSpeaking ? 'Detener' : 'Escuchar'}
                            </Button>
                          </div>
                          {step.tip && (
                            <div className="mt-3 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg border border-yellow-200 dark:border-yellow-800">
                              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                                <strong>💡 Consejo:</strong> {step.tip}
                              </p>
                            </div>
                          )}
                        </div>
                      </motion.li>
                    ))}
                  </ol>
                </CardContent>
              </Card>

              {/* Ingredient Substitutions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Sparkles className="h-5 w-5" />
                    Sustituciones Sugeridas
                  </CardTitle>
                  <CardDescription>
                    Alternativas para adaptar la receta a tus preferencias
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recipe.substitutions.map((sub, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <div className="font-medium">{sub.ingredient}</div>
                          <div className="text-sm text-muted-foreground">
                            → {sub.substitute} (ratio: {sub.ratio})
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground text-right max-w-[200px]">
                          {sub.notes}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Rating */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Valora esta receta</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        onClick={() => setUserRating(star)}
                        className="p-1"
                      >
                        <Star
                          className={cn(
                            "h-8 w-8 transition-colors",
                            star <= userRating
                              ? "text-yellow-500 fill-yellow-500"
                              : "text-muted-foreground"
                          )}
                        />
                      </button>
                    ))}
                    {userRating > 0 && (
                      <span className="ml-4 text-sm text-muted-foreground">
                        {userRating} de 5 estrellas
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Comments */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MessageCircle className="h-5 w-5" />
                    Comentarios ({recipe.comments.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add Comment */}
                  <div className="space-y-3">
                    <Textarea
                      placeholder="Comparte tu experiencia con esta receta..."
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      rows={3}
                    />
                    <Button disabled={!comment.trim()}>
                      Publicar comentario
                    </Button>
                  </div>

                  <Separator />

                  {/* Comments List */}
                  <div className="space-y-4">
                    {recipe.comments.map(comment => (
                      <div key={comment.id} className="flex gap-3">
                        <Avatar>
                          <AvatarFallback>
                            {comment.user.name?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium">{comment.user.name}</span>
                            <div className="flex items-center">
                              {[...Array(comment.rating || 0)].map((_, i) => (
                                <Star key={i} className="h-3 w-3 text-yellow-500 fill-yellow-500" />
                              ))}
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {new Date(comment.createdAt).toLocaleDateString('es-ES')}
                            </span>
                          </div>
                          <p className="text-sm text-muted-foreground">{comment.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Quick Actions Card */}
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg">Acciones rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Link href={`/recetas/${recipe.id}/pasos`} className="block">
                    <Button className="w-full bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600">
                      <Play className="h-4 w-4 mr-2" />
                      Iniciar Modo Cocina
                    </Button>
                  </Link>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" onClick={() => window.print()}>
                      <Printer className="h-4 w-4 mr-2" />
                      Imprimir
                    </Button>
                    <Button variant="outline" onClick={shareRecipe}>
                      <Share2 className="h-4 w-4 mr-2" />
                      Compartir
                    </Button>
                  </div>
                  <Button variant="outline" className="w-full" onClick={addToShoppingList}>
                    <ShoppingCart className="h-4 w-4 mr-2" />
                    Añadir ingredientes a compras
                  </Button>
                </CardContent>
              </Card>

              {/* Timer Card */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Timer className="h-5 w-5" />
                    Temporizadores
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Link href="/temporizadores">
                    <Button variant="outline" className="w-full">
                      Abrir temporizadores
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              {/* Nutrition Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Información adicional</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tiempo prep.</span>
                    <span className="font-medium">{recipe.prepTime} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tiempo cocción</span>
                    <span className="font-medium">{recipe.cookTime} min</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cocina</span>
                    <span className="font-medium capitalize">{recipe.cuisineType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tipo de plato</span>
                    <span className="font-medium capitalize">{recipe.mealType}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Vistas</span>
                    <span className="font-medium">{recipe.viewCount.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Allergen Warning */}
              {recipe.isGlutenFree && (
                <Card className="border-green-500 bg-green-50 dark:bg-green-900/20">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                        <Check className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-medium text-green-700 dark:text-green-400">
                          Apto para celíacos
                        </div>
                        <div className="text-sm text-green-600 dark:text-green-500">
                          Esta receta no contiene gluten
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
