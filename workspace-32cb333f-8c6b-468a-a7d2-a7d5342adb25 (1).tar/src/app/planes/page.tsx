'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Check,
  X,
  Sparkles,
  Crown,
  Zap,
  Star,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Github,
  Users,
  Share2,
  Clock,
  Cast,
  GraduationCap,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useUserStore } from '@/store'
import { toast } from 'sonner'

const faqs = [
  {
    question: '¿Puedo cancelar mi suscripción en cualquier momento?',
    answer: 'Sí, puedes cancelar tu suscripción en cualquier momento desde la configuración de tu cuenta. Seguirás teniendo acceso hasta el final del período de pago.',
  },
  {
    question: '¿Qué pasa cuando termina mi prueba gratuita?',
    answer: 'Al finalizar los 7 días de prueba, se te cobrará automáticamente el plan seleccionado. Si no te convence, puedes cancelar y volver al plan gratuito. IMPORTANTE: Solo puedes probar UN plan una vez, no ambos.',
  },
  {
    question: '¿Cómo funcionan los favoritos en cada plan?',
    answer: 'El plan Básico incluye 10 favoritos, Ultra te permite hasta 25 favoritos al mes, y MasterChef ofrece favoritos ilimitados.',
  },
  {
    question: '¿Puedo compartir mi plan con otros?',
    answer: 'Sí, puedes compartir tu plan Ultra o MasterChef con 1 persona adicional por 1,99€/mes extra. Cada persona tendrá acceso completo al plan.',
  },
  {
    question: '¿Los logros se pierden si cambio de plan?',
    answer: 'No, los logros desbloqueados se conservan. Sin embargo, algunos logros premium solo son accesibles con planes superiores.',
  },
  {
    question: '¿Qué métodos de pago aceptan?',
    answer: 'Aceptamos tarjetas de crédito/débito (Visa, Mastercard, American Express), PayPal y Google Pay.',
  },
  {
    question: '¿Hay descuento para estudiantes o carnet joven?',
    answer: 'Sí, ofrecemos un 13% de descuento adicional para titulares del Carnet Joven. Contacta con soporte con tu documento verificado.',
  },
  {
    question: '¿Cómo accedo a las funciones de IA?',
    answer: 'Las funciones de IA, como filtros inteligentes y sugerencias personalizadas, están disponibles exclusivamente en el plan MasterChef.',
  },
]

export default function PlanesPage() {
  const [annualBilling, setAnnualBilling] = useState(true)
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null)
  const [showYoungCardDiscount, setShowYoungCardDiscount] = useState(false)
  const { subscription, startTrial, subscribe, cancelSubscription } = useUserStore()
  const [trialTimeRemaining, setTrialTimeRemaining] = useState<string>('')
  
  // Calculate trial time remaining
  useEffect(() => {
    if (subscription.isTrialActive && subscription.trialEndDate) {
      const updateTimer = () => {
        const now = new Date()
        const trialEnd = new Date(subscription.trialEndDate!)
        const diff = trialEnd.getTime() - now.getTime()
        
        if (diff <= 0) {
          setTrialTimeRemaining('¡Tiempo agotado!')
          // Cuando termina la prueba, se cobra automáticamente
          const plan = subscription.plan
          if (plan !== 'basic') {
            subscribe(plan)
            toast.success(`¡Bienvenido al plan ${plan === 'ultra' ? 'Ultra' : 'MasterChef'}! Tu suscripción ha comenzado.`)
          }
        } else {
          const days = Math.floor(diff / (1000 * 60 * 60 * 24))
          const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
          const seconds = Math.floor((diff % (1000 * 60)) / 1000)
          setTrialTimeRemaining(`${days}d ${hours}h ${minutes}m ${seconds}s`)
        }
      }
      
      updateTimer()
      const interval = setInterval(updateTimer, 1000)
      return () => clearInterval(interval)
    }
  }, [subscription.isTrialActive, subscription.trialEndDate, subscription.plan, subscribe])
  
  const handleSubscribe = (plan: 'ultra' | 'masterchef') => {
    // Si ya tiene una prueba activa
    if (subscription.isTrialActive) {
      toast.error('Ya tienes una prueba activa. Espera a que termine.')
      return
    }
    
    // Si ya usó la prueba gratuita, solo puede pagar
    if (subscription.hasUsedTrial && !annualBilling) {
      toast.error('Ya usaste tu prueba gratuita. Debes suscribirte para continuar.')
      return
    }
    
    // Si ya tiene un plan activo
    if (subscription.plan !== 'basic' && subscription.isSubscriptionActive) {
      toast.error('Ya tienes un plan activo. Cancela tu plan actual primero.')
      return
    }
    
    if (annualBilling) {
      // Pago directo anual
      subscribe(plan)
      toast.success(`¡Te has suscrito al plan ${plan === 'ultra' ? 'Ultra' : 'MasterChef'}!`)
    } else {
      // Prueba gratuita de 7 días
      startTrial(plan)
      toast.success(`¡Prueba gratuita de 7 días iniciada para ${plan === 'ultra' ? 'Ultra' : 'MasterChef'}! Al finalizar se te cobrará automáticamente.`)
    }
  }
  
  // Calcular precios con descuentos
  const applyYoungCardDiscount = (price: number) => {
    if (showYoungCardDiscount) {
      return price * 0.87 // 13% descuento
    }
    return price
  }
  
  const getDiscountPercentage = () => {
    if (showYoungCardDiscount) {
      return 31 // 18% anual + 13% carnet joven
    }
    return 18
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-orange-500 to-green-500 py-16 text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-5xl font-bold mb-4"
            >
              Elige tu Plan
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-xl text-white/90 mb-8"
            >
              Encuentra el plan perfecto para tu aventura culinaria
            </motion.p>
            
            {/* Trial Countdown - CONTADOR */}
            {subscription.isTrialActive && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white/20 backdrop-blur rounded-xl p-4 max-w-md mx-auto mb-6"
              >
                <div className="flex items-center gap-2 justify-center mb-2">
                  <Clock className="h-5 w-5" />
                  <span className="font-semibold">Prueba Gratuita Activa</span>
                </div>
                <div className="text-3xl font-bold font-mono">{trialTimeRemaining}</div>
                <p className="text-sm text-white/80 mt-1">
                  Tiempo restante - Al finalizar se cobrará automáticamente
                </p>
                <p className="text-xs text-white/70 mt-2">
                  Si no te convence, cancela antes de que termine para volver al plan gratuito
                </p>
              </motion.div>
            )}
            
            {/* Mensaje si ya usó la prueba */}
            {subscription.hasUsedTrial && !subscription.isTrialActive && subscription.plan === 'basic' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-amber-500/80 backdrop-blur rounded-xl p-4 max-w-md mx-auto mb-6"
              >
                <div className="flex items-center gap-2 justify-center mb-2">
                  <Clock className="h-5 w-5" />
                  <span className="font-semibold">Prueba Ya Utilizada</span>
                </div>
                <p className="text-sm">
                  Ya usaste tu prueba gratuita de 7 días. Para disfrutar de premium, suscríbete a un plan.
                </p>
              </motion.div>
            )}
            
            {/* Billing Toggle */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="flex flex-col items-center justify-center gap-4"
            >
              <div className="flex items-center gap-4">
                <Label className={!annualBilling ? 'text-white' : 'text-white/60'}>Mensual (Prueba)</Label>
                <Switch
                  checked={annualBilling}
                  onCheckedChange={setAnnualBilling}
                />
                <Label className={annualBilling ? 'text-white' : 'text-white/60'}>
                  Anual
                  <Badge className="ml-2 bg-yellow-400 text-yellow-900">-{getDiscountPercentage()}%</Badge>
                </Label>
              </div>
              
              {/* Carnet Joven Toggle */}
              <div className="flex items-center gap-2 mt-2">
                <Button
                  variant={showYoungCardDiscount ? "secondary" : "outline"}
                  size="sm"
                  onClick={() => setShowYoungCardDiscount(!showYoungCardDiscount)}
                  className={`text-white border-white/30 ${showYoungCardDiscount ? 'bg-green-500 hover:bg-green-600' : 'hover:bg-white/10'}`}
                >
                  <GraduationCap className="h-4 w-4 mr-2" />
                  {showYoungCardDiscount ? 'Carnet Joven Aplicado (-13%)' : 'Tengo Carnet Joven'}
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Pricing Cards */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {/* Basic Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-2xl">Básico</CardTitle>
                    <CardDescription>Perfecto para empezar a cocinar</CardDescription>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">Gratis</span>
                    </div>
                    <Button 
                      variant="link" 
                      className="p-0 h-auto text-blue-600 hover:underline"
                      onClick={() => window.open('https://github.com/FazeUrru/CocinaViva/upload/main', '_blank')}
                    >
                      <Github className="h-4 w-4 mr-1" />
                      Ver Código en GitHub
                    </Button>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Acceso a 500 recetas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Búsqueda simple</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Favoritos (limitado a 10)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Crear recetas propias (Gratis)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Reseñas de recetas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">125 logros disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Modo Thermomix</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Calculadora nutricional</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Recetario Social (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm font-semibold">SIN PUBLICIDAD</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Filtros Pro (Populares/Cooksnaps)</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Asistente de voz (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <X className="h-5 w-5 flex-shrink-0" />
                      <span className="text-sm">Acceso anticipado a funciones</span>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-2">
                    <Button variant="outline" className="w-full" disabled={subscription.plan === 'basic' && !subscription.isTrialActive}>
                      {subscription.plan === 'basic' && !subscription.isTrialActive ? 'Plan Actual' : 'Plan Gratuito'}
                    </Button>
                    {/* Botón Chromecast */}
                    <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => toast.info('Abre la app de Chromecast y selecciona tu dispositivo')}>
                      <Cast className="h-4 w-4 mr-2" />
                      Enviar a Chromecast
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>

              {/* Ultra Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
              >
                <Card className="h-full border-orange-500 shadow-lg relative">
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-orange-500">
                    POPULAR
                  </Badge>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Zap className="h-6 w-6 text-orange-500" />
                      <CardTitle className="text-2xl">Ultra</CardTitle>
                    </div>
                    <CardDescription>Para cocineros entusiastas</CardDescription>
                    <div className="mt-4">
                      {annualBilling ? (
                        <>
                          <div className="text-sm text-muted-foreground line-through">85.68€/año</div>
                          <span className="text-4xl font-bold">{applyYoungCardDiscount(68.64).toFixed(2).replace('.', ',')}</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/año</span>
                          <div className="text-sm text-muted-foreground mt-1">
                            ({(applyYoungCardDiscount(68.64) / 12).toFixed(2).replace('.', ',')}€/mes)
                          </div>
                          <div className="text-sm text-green-600 font-semibold">
                            Ahorras {(85.68 - applyYoungCardDiscount(68.64)).toFixed(2).replace('.', ',')}€ al año (-{getDiscountPercentage()}%)
                          </div>
                          {showYoungCardDiscount && (
                            <Badge className="mt-1 bg-green-500">Carnet Joven Aplicado</Badge>
                          )}
                        </>
                      ) : (
                        <>
                          <span className="text-4xl font-bold">6,99</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/mes</span>
                          <div className="text-sm text-amber-600 mt-1">
                            7 días de prueba gratis
                          </div>
                        </>
                      )}
                    </div>
                    {!subscription.hasUsedTrial && !annualBilling && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant="secondary" className="bg-green-100 text-green-700">
                          Prueba gratuita disponible
                        </Badge>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Acceso a 800 recetas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Búsqueda avanzada con filtros</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Favoritos limitado a 25</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Crear recetas propias</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Reseñas verificadas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Filtros Pro (Populares/Cooksnaps)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">175 logros disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Modo Thermomix completo</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Planificador semanal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Calculadora nutricional</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm font-semibold">Sin publicidad</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Acceso anticipado a funciones</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                      <span className="text-sm">Exportar recetas</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex items-center gap-2">
                      <Share2 className="h-4 w-4 text-orange-500" />
                      <span className="text-sm text-orange-600 font-medium">Compartir plan: +1,99€/mes (2 personas)</span>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-2">
                    <Button 
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600"
                      onClick={() => handleSubscribe('ultra')}
                      disabled={subscription.plan === 'ultra' || (subscription.isTrialActive && subscription.plan !== 'ultra') || (subscription.hasUsedTrial && !annualBilling)}
                    >
                      {subscription.plan === 'ultra' ? 'Plan Actual' : annualBilling ? 'Suscribirse' : subscription.hasUsedTrial ? 'Prueba ya usada' : 'Comenzar prueba gratis'}
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      {annualBilling ? 'Suscripción anual - Cancela cuando quieras' : '7 días gratis - Al finalizar se cobra automáticamente'}
                    </p>
                    {/* Botón Chromecast */}
                    <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => toast.info('Abre la app de Chromecast y selecciona tu dispositivo')}>
                      <Cast className="h-4 w-4 mr-2" />
                      Enviar a Chromecast
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>

              {/* MasterChef Plan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
              >
                <Card className="h-full border-purple-500 shadow-lg relative bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/20 dark:to-indigo-950/20">
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-500">
                    <Crown className="h-3 w-3 mr-1" />
                    PREMIUM
                  </Badge>
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Crown className="h-6 w-6 text-purple-500" />
                      <CardTitle className="text-2xl">Master Chef</CardTitle>
                    </div>
                    <CardDescription>La experiencia culinaria completa</CardDescription>
                    <div className="mt-4">
                      {annualBilling ? (
                        <>
                          <div className="text-sm text-muted-foreground line-through">155.88€/año</div>
                          <span className="text-4xl font-bold">{applyYoungCardDiscount(128.40).toFixed(2).replace('.', ',')}</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/año</span>
                          <div className="text-sm text-muted-foreground mt-1">
                            ({(applyYoungCardDiscount(128.40) / 12).toFixed(2).replace('.', ',')}€/mes)
                          </div>
                          <div className="text-sm text-green-600 font-semibold">
                            Ahorras {(155.88 - applyYoungCardDiscount(128.40)).toFixed(2).replace('.', ',')}€ al año (-{getDiscountPercentage()}%)
                          </div>
                          {showYoungCardDiscount && (
                            <Badge className="mt-1 bg-green-500">Carnet Joven Aplicado</Badge>
                          )}
                        </>
                      ) : (
                        <>
                          <span className="text-4xl font-bold">12,99</span>
                          <span className="text-muted-foreground"> EUR</span>
                          <span className="text-muted-foreground">/mes</span>
                          <div className="text-sm text-amber-600 mt-1">
                            7 días de prueba gratis
                          </div>
                        </>
                      )}
                    </div>
                    {!subscription.hasUsedTrial && !annualBilling && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                          Prueba gratuita disponible
                        </Badge>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Acceso a 1.000+ recetas completas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Filtros IA y Pro</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Guardado y Favoritos Ilimitados</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Crear recetas propias</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Reseñas verificadas</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">350 logros disponibles</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Modo Thermomix completo</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Planificador semanal avanzado</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Calculadora nutricional avanzada</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Asistente de voz (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm font-semibold">Sin publicidad</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Soporte prioritario 24/7</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-purple-500 flex-shrink-0" />
                      <span className="text-sm">Sincronización en la nube</span>
                    </div>
                    {/* NEW BETA FEATURES */}
                    <Separator className="my-2" />
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-purple-500" />
                      <span className="text-sm text-purple-600 font-medium">Chef Virtual IA (Beta)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-purple-500" />
                      <span className="text-sm text-purple-600 font-medium">Análisis Nutricional IA (Beta)</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex items-center gap-2">
                      <Share2 className="h-4 w-4 text-purple-500" />
                      <span className="text-sm text-purple-600 font-medium">Compartir plan: +1,99€/mes (2 personas)</span>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col gap-2">
                    <Button 
                      className="w-full bg-gradient-to-r from-purple-500 to-indigo-500"
                      onClick={() => handleSubscribe('masterchef')}
                      disabled={subscription.plan === 'masterchef' || (subscription.isTrialActive && subscription.plan !== 'masterchef') || (subscription.hasUsedTrial && !annualBilling)}
                    >
                      {subscription.plan === 'masterchef' ? 'Plan Actual' : annualBilling ? 'Suscribirse' : subscription.hasUsedTrial ? 'Prueba ya usada' : 'Comenzar prueba gratis'}
                    </Button>
                    <p className="text-xs text-muted-foreground text-center">
                      {annualBilling ? 'Suscripción anual - Cancela cuando quieras' : '7 días gratis - Al finalizar se cobra automáticamente'}
                    </p>
                    {/* Botón Chromecast */}
                    <Button variant="ghost" size="sm" className="w-full text-muted-foreground" onClick={() => toast.info('Abre la app de Chromecast y selecciona tu dispositivo')}>
                      <Cast className="h-4 w-4 mr-2" />
                      Enviar a Chromecast
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Feature Comparison */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-8">Comparación de Funciones</h2>
            
            <div className="overflow-x-auto">
              <table className="w-full max-w-4xl mx-auto">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-4 px-4">Función</th>
                    <th className="text-center py-4 px-4">Básico</th>
                    <th className="text-center py-4 px-4">Ultra</th>
                    <th className="text-center py-4 px-4">MasterChef</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-4">Recetas disponibles</td>
                    <td className="text-center py-3 px-4">500</td>
                    <td className="text-center py-3 px-4">800+</td>
                    <td className="text-center py-3 px-4">1.000+</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Favoritos</td>
                    <td className="text-center py-3 px-4">10</td>
                    <td className="text-center py-3 px-4">25/mes</td>
                    <td className="text-center py-3 px-4">∞</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Logros</td>
                    <td className="text-center py-3 px-4">125</td>
                    <td className="text-center py-3 px-4">175</td>
                    <td className="text-center py-3 px-4">350</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Chef Virtual IA</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Badge>Beta</Badge></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Análisis Nutricional IA</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Badge>Beta</Badge></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Búsqueda avanzada</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Filtros Pro</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Filtros IA</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Compartir plan (+1,99€)</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Temporizador</td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Lista de compras</td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4">Carnet Joven (-13%)</td>
                    <td className="text-center py-3 px-4"><X className="h-5 w-5 mx-auto text-muted-foreground" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-green-500" /></td>
                    <td className="text-center py-3 px-4"><Check className="h-5 w-5 mx-auto text-purple-500" /></td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4">Publicidad</td>
                    <td className="text-center py-3 px-4"><Badge variant="secondary">Sin publicidad</Badge></td>
                    <td className="text-center py-3 px-4"><Badge variant="secondary">Sin publicidad</Badge></td>
                    <td className="text-center py-3 px-4"><Badge variant="secondary">Sin publicidad</Badge></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* FAQs */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4 max-w-3xl">
            <h2 className="text-3xl font-bold text-center mb-8">Preguntas Frecuentes</h2>
            
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <Card key={index} className="cursor-pointer" onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}>
                  <CardHeader className="py-4">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <HelpCircle className="h-5 w-5 text-orange-500" />
                        {faq.question}
                      </CardTitle>
                      {expandedFaq === index ? (
                        <ChevronUp className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                  </CardHeader>
                  {expandedFaq === index && (
                    <CardContent className="pt-0">
                      <p className="text-muted-foreground">{faq.answer}</p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Contact */}
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl font-bold mb-4">¿Dudas o sugerencias?</h2>
            <p className="text-muted-foreground mb-4">
              Contáctanos en <a href="mailto:iiribasu2010@gmail.com" className="text-orange-500 hover:underline">iiribasu2010@gmail.com</a>
            </p>
            <div className="flex justify-center gap-4 flex-wrap">
              <Button variant="outline" onClick={() => toast.success('Formulario de sugerencias abierto')}>
                <Sparkles className="h-4 w-4 mr-2" />
                Sugerir Función
              </Button>
              <Button variant="outline" onClick={() => window.open('https://github.com/FazeUrru/CocinaViva/upload/main', '_blank')}>
                <Github className="h-4 w-4 mr-2" />
                Ver Código en GitHub
              </Button>
              <Button variant="ghost" onClick={() => toast.info('Abre la app de Chromecast y selecciona tu dispositivo')}>
                <Cast className="h-4 w-4 mr-2" />
                Enviar a Chromecast
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-6">
              Última actualización: 21 de febrero de 2026
            </p>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
