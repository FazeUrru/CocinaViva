'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Trophy, Lock, CheckCircle, Star, ChevronRight, Search, Filter } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { useUserStore } from '@/store'
import { allAchievements, achievementCategories, getAchievementsByCategory, type AchievementCategory } from '@/data/achievements'

export default function LogrosPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<AchievementCategory | 'all'>('all')
  const { progress, subscription } = useUserStore()
  
  const filteredAchievements = allAchievements.filter(achievement => {
    const matchesSearch = achievement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          achievement.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || achievement.category === selectedCategory
    
    // Filter by plan access
    if (achievement.isPremium && achievement.requiredPlan) {
      if (achievement.requiredPlan === 'masterchef' && subscription.plan !== 'masterchef') {
        return false
      }
      if (achievement.requiredPlan === 'ultra' && subscription.plan === 'basic') {
        return false
      }
    }
    
    return matchesSearch && matchesCategory
  })
  
  const unlockedCount = progress.achievementsUnlocked
  const totalPoints = progress.userPoints

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        {/* Header */}
        <section className="bg-gradient-to-br from-yellow-500 via-orange-500 to-red-500 py-16 text-white">
          <div className="container mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <Trophy className="h-16 w-16 mx-auto mb-4" />
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Logros</h1>
              <p className="text-xl text-white/90 mb-6">
                Desbloquea 350 logros y conviértete en un maestro culinario
              </p>
            </motion.div>
            
            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-wrap justify-center gap-8"
            >
              <div className="bg-white/20 backdrop-blur rounded-xl px-6 py-4">
                <div className="text-3xl font-bold">{unlockedCount}/350</div>
                <div className="text-sm text-white/80">Logros Desbloqueados</div>
              </div>
              <div className="bg-white/20 backdrop-blur rounded-xl px-6 py-4">
                <div className="text-3xl font-bold">{totalPoints.toLocaleString()}</div>
                <div className="text-sm text-white/80">Puntos Totales</div>
              </div>
              <div className="bg-white/20 backdrop-blur rounded-xl px-6 py-4">
                <div className="text-3xl font-bold">{Math.round((unlockedCount / 350) * 100)}%</div>
                <div className="text-sm text-white/80">Completado</div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Progress Bar */}
        <section className="py-6 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium whitespace-nowrap">Progreso Global</span>
              <Progress value={(unlockedCount / 350) * 100} className="h-3 flex-1" />
              <span className="text-sm text-muted-foreground whitespace-nowrap">{unlockedCount}/350</span>
            </div>
          </div>
        </section>

        {/* Categories Overview */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6">Categorías</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-10 gap-3">
              {achievementCategories.map((category, index) => {
                const categoryAchievements = getAchievementsByCategory(category.id as AchievementCategory)
                const unlockedInCategory = Math.floor(Math.random() * category.count) // Demo: random for now
                
                return (
                  <motion.div
                    key={category.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Card 
                      className={`cursor-pointer transition-all hover:shadow-lg ${
                        selectedCategory === category.id ? 'ring-2 ring-orange-500' : ''
                      }`}
                      onClick={() => setSelectedCategory(selectedCategory === category.id ? 'all' : category.id as AchievementCategory | 'all')}
                    >
                      <CardContent className="p-4 text-center">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${category.color} flex items-center justify-center mx-auto mb-2`}>
                          <span className="text-2xl">{category.icon}</span>
                        </div>
                        <div className="font-medium text-sm">{category.name}</div>
                        <div className="text-xs text-muted-foreground">{category.count} logros</div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Search and Filter */}
        <section className="py-4 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar logros..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button 
                variant="outline" 
                onClick={() => setSelectedCategory('all')}
                disabled={selectedCategory === 'all'}
              >
                <Filter className="h-4 w-4 mr-2" />
                Ver todos ({filteredAchievements.length})
              </Button>
            </div>
          </div>
        </section>

        {/* Achievements Grid */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            <Tabs defaultValue="grid" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="grid">Cuadrícula</TabsTrigger>
                <TabsTrigger value="list">Lista</TabsTrigger>
              </TabsList>
              
              <TabsContent value="grid">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {filteredAchievements.map((achievement, index) => (
                    <motion.div
                      key={achievement.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: Math.min(index * 0.02, 0.5) }}
                    >
                      <Card className={`h-full transition-all hover:shadow-lg ${
                        achievement.unlocked 
                          ? 'border-green-500 bg-green-50/50 dark:bg-green-950/20' 
                          : 'opacity-90'
                      }`}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between mb-2">
                            <span className="text-3xl">{achievement.icon}</span>
                            {achievement.unlocked ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <Lock className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                          <h3 className="font-semibold text-sm mb-1 line-clamp-1">{achievement.title}</h3>
                          <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{achievement.description}</p>
                          
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-muted-foreground">Progreso</span>
                              <span className="font-medium">{achievement.progress}/{achievement.maxProgress}</span>
                            </div>
                            <Progress 
                              value={(achievement.progress / achievement.maxProgress) * 100} 
                              className="h-2"
                            />
                          </div>
                          
                          <div className="flex items-center justify-between mt-3 pt-3 border-t">
                            <Badge variant="secondary" className="text-xs">
                              <Star className="h-3 w-3 mr-1" />
                              {achievement.points} pts
                            </Badge>
                            {achievement.isPremium && (
                              <Badge className="bg-purple-500 text-xs">Premium</Badge>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="list">
                <div className="space-y-2">
                  {filteredAchievements.map((achievement, index) => (
                    <motion.div
                      key={achievement.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: Math.min(index * 0.01, 0.3) }}
                    >
                      <Card className={`transition-all hover:shadow-md ${
                        achievement.unlocked 
                          ? 'border-green-500 bg-green-50/50 dark:bg-green-950/20' 
                          : ''
                      }`}>
                        <CardContent className="p-4 flex items-center gap-4">
                          <span className="text-4xl">{achievement.icon}</span>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{achievement.title}</h3>
                              {achievement.isPremium && (
                                <Badge className="bg-purple-500 text-xs">Premium</Badge>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">{achievement.description}</p>
                            <div className="flex items-center gap-4 mt-2">
                              <Progress 
                                value={(achievement.progress / achievement.maxProgress) * 100} 
                                className="h-2 w-32"
                              />
                              <span className="text-xs text-muted-foreground">
                                {achievement.progress}/{achievement.maxProgress}
                              </span>
                            </div>
                          </div>
                          <div className="flex flex-col items-end gap-2">
                            <Badge variant="secondary">
                              <Star className="h-3 w-3 mr-1" />
                              {achievement.points} pts
                            </Badge>
                            {achievement.unlocked ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <Lock className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>

        {/* Category Stats */}
        <section className="py-8 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6">Estadísticas por Categoría</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {achievementCategories.map((category) => {
                const categoryAchievements = getAchievementsByCategory(category.id as AchievementCategory)
                // Demo: random unlocked count
                const unlocked = Math.floor(Math.random() * category.count)
                const percentage = Math.round((unlocked / category.count) * 100)
                
                return (
                  <Card key={category.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${category.color} flex items-center justify-center`}>
                          <span className="text-xl">{category.icon}</span>
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold">{category.name}</h3>
                          <p className="text-sm text-muted-foreground">{unlocked}/{category.count} desbloqueados</p>
                        </div>
                        <Badge variant="secondary">{percentage}%</Badge>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
