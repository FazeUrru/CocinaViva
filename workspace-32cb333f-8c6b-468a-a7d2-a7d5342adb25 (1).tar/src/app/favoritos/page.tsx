'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Heart,
  Star,
  Clock,
  Users,
  FolderPlus,
  X,
  Plus,
  Trash2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'

// Demo favorites data
const favoriteRecipes = [
  {
    id: '1',
    title: 'Paella Valenciana',
    description: 'La auténtica paella valenciana',
    imageUrl: '/images/recipes/paella.png',
    totalTime: 60,
    difficulty: 'medio',
    averageRating: 4.8,
    isGlutenFree: true,
  },
  {
    id: '4',
    title: 'Tarta de Chocolate',
    description: 'Deliciosa tarta de chocolate con frutos rojos',
    imageUrl: '/images/recipes/chocolate-cake.png',
    totalTime: 75,
    difficulty: 'medio',
    averageRating: 4.9,
    isGlutenFree: false,
  },
]

// Demo collections data
const collections = [
  {
    id: '1',
    name: 'Postres favoritos',
    description: 'Mis postres preferidos',
    icon: '🍰',
    recipeCount: 5,
  },
  {
    id: '2',
    name: 'Cenas rápidas',
    description: 'Recetas para cenas rápidas',
    icon: '⏰',
    recipeCount: 8,
  },
  {
    id: '3',
    name: 'Recetas saludables',
    description: 'Platos nutritivos y balanceados',
    icon: '🥗',
    recipeCount: 12,
  },
]

export default function FavoritosPage() {
  const [collectionsList, setCollectionsList] = useState(collections)
  const [newCollectionName, setNewCollectionName] = useState('')
  const [newCollectionDescription, setNewCollectionDescription] = useState('')
  const [dialogOpen, setDialogOpen] = useState(false)

  const createCollection = () => {
    if (!newCollectionName.trim()) return
    setCollectionsList(prev => [
      ...prev,
      {
        id: Date.now().toString(),
        name: newCollectionName,
        description: newCollectionDescription,
        icon: '📁',
        recipeCount: 0,
      }
    ])
    setNewCollectionName('')
    setNewCollectionDescription('')
    setDialogOpen(false)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Heart className="h-8 w-8 text-red-500" />
              Favoritos y Colecciones
            </h1>
            <p className="text-muted-foreground">
              Organiza tus recetas favoritas en colecciones personalizadas
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <Tabs defaultValue="favorites" className="space-y-6">
            <TabsList>
              <TabsTrigger value="favorites">
                <Heart className="h-4 w-4 mr-2" />
                Favoritos ({favoriteRecipes.length})
              </TabsTrigger>
              <TabsTrigger value="collections">
                <FolderPlus className="h-4 w-4 mr-2" />
                Colecciones ({collectionsList.length})
              </TabsTrigger>
            </TabsList>

            {/* Favorites Tab */}
            <TabsContent value="favorites">
              {favoriteRecipes.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <Heart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Sin favoritos</h3>
                    <p className="text-muted-foreground mb-4">
                      Marca recetas como favoritas para encontrarlas rápidamente
                    </p>
                    <Link href="/recetas">
                      <Button>Explorar recetas</Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {favoriteRecipes.map((recipe, index) => (
                    <motion.div
                      key={recipe.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Link href={`/recetas/${recipe.id}`}>
                        <Card className="h-full overflow-hidden hover:shadow-lg transition-all cursor-pointer group">
                          <div className="relative h-48 overflow-hidden">
                            <img
                              src={recipe.imageUrl}
                              alt={recipe.title}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute top-3 right-3">
                              <Heart className="h-6 w-6 text-red-500 fill-red-500" />
                            </div>
                            <div className="absolute bottom-3 left-3">
                              <Badge className="bg-yellow-500">
                                <Star className="h-3 w-3 mr-1 fill-white" />
                                {recipe.averageRating.toFixed(1)}
                              </Badge>
                            </div>
                          </div>
                          <CardHeader className="pb-2">
                            <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                            <CardDescription className="line-clamp-1">
                              {recipe.description}
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="pb-2">
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {recipe.totalTime} min
                              </div>
                              {recipe.isGlutenFree && (
                                <Badge className="bg-green-500 text-xs">Sin Gluten</Badge>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Collections Tab */}
            <TabsContent value="collections">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-semibold">Tus colecciones</h2>
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-gradient-to-r from-orange-500 to-green-500">
                      <Plus className="h-4 w-4 mr-2" />
                      Nueva colección
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Crear colección</DialogTitle>
                      <DialogDescription>
                        Organiza tus recetas en colecciones temáticas
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="collectionName">Nombre</Label>
                        <Input
                          id="collectionName"
                          placeholder="Ej: Postres de verano"
                          value={newCollectionName}
                          onChange={(e) => setNewCollectionName(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="collectionDesc">Descripción (opcional)</Label>
                        <Input
                          id="collectionDesc"
                          placeholder="Descripción de la colección"
                          value={newCollectionDescription}
                          onChange={(e) => setNewCollectionDescription(e.target.value)}
                        />
                      </div>
                      <Button onClick={createCollection} className="w-full">
                        Crear colección
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {collectionsList.map((collection, index) => (
                  <motion.div
                    key={collection.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="hover:shadow-lg transition-all cursor-pointer group">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <div className="text-4xl mb-2">{collection.icon}</div>
                          <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                            <Trash2 className="h-4 w-4 text-muted-foreground" />
                          </Button>
                        </div>
                        <CardTitle>{collection.name}</CardTitle>
                        <CardDescription>{collection.description}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Badge variant="secondary">
                          {collection.recipeCount} recetas
                        </Badge>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
