'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Sparkles,
  Star,
  Clock,
  Users,
  Heart,
  TrendingUp,
  Flame,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'

// Demo featured recipes
const featuredRecipes = [
  {
    id: '1',
    title: 'Paella Valenciana',
    description: 'La auténtica paella valenciana con pollo, conejo y judías verdes',
    imageUrl: '/images/recipes/paella.png',
    prepTime: 20,
    cookTime: 40,
    totalTime: 60,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.8,
    ratingCount: 156,
    viewCount: 3420,
  },
  {
    id: '4',
    title: 'Tarta de Chocolate',
    description: 'Deliciosa tarta de chocolate con frutos rojos',
    imageUrl: '/images/recipes/chocolate-cake.png',
    prepTime: 30,
    cookTime: 45,
    totalTime: 75,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.9,
    ratingCount: 312,
    viewCount: 5670,
  },
  {
    id: '3',
    title: 'Ensalada Mediterránea',
    description: 'Ensalada fresca con ingredientes mediterráneos',
    imageUrl: '/images/recipes/salad.png',
    prepTime: 10,
    cookTime: 0,
    totalTime: 10,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.7,
    ratingCount: 203,
    viewCount: 2340,
  },
  {
    id: '6',
    title: 'Pasta Carbonara',
    description: 'Auténtica pasta carbonara italiana con guanciale',
    imageUrl: '/images/recipes/carbonara.png',
    prepTime: 10,
    cookTime: 20,
    totalTime: 30,
    difficulty: 'medio',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.7,
    ratingCount: 245,
    viewCount: 4120,
  },
  {
    id: '5',
    title: 'Gazpacho Andaluz',
    description: 'Refrescante sopa fría de tomate tradicional',
    imageUrl: '/images/recipes/gazpacho.png',
    prepTime: 15,
    cookTime: 0,
    totalTime: 15,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: 4.6,
    ratingCount: 178,
    viewCount: 2890,
  },
  {
    id: '2',
    title: 'Hamburguesa Gourmet',
    description: 'Hamburguesa casera con carne seleccionada y vegetales frescos',
    imageUrl: '/images/recipes/burger.png',
    prepTime: 15,
    cookTime: 10,
    totalTime: 25,
    difficulty: 'facil',
    toolType: 'tradicional',
    isGlutenFree: false,
    averageRating: 4.5,
    ratingCount: 89,
    viewCount: 1560,
  },
]

const trendingTags = [
  { name: 'Sin Gluten', count: 156 },
  { name: 'Vegetariano', count: 134 },
  { name: 'Rápido', count: 98 },
  { name: 'Postres', count: 87 },
  { name: 'Cenas', count: 76 },
]

export default function DestacadosPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Sparkles className="h-8 w-8 text-yellow-500" />
              Recetas Destacadas
            </h1>
            <p className="text-muted-foreground">
              Las recetas más populares y mejor valoradas por la comunidad
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          {/* Top Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                    <Star className="h-5 w-5 text-yellow-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">4.7</div>
                    <div className="text-sm text-muted-foreground">Valoración media</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                    <Flame className="h-5 w-5 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">23K</div>
                    <div className="text-sm text-muted-foreground">Vistas esta semana</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                    <Heart className="h-5 w-5 text-red-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">1.2K</div>
                    <div className="text-sm text-muted-foreground">Favoritos</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <TrendingUp className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">+15%</div>
                    <div className="text-sm text-muted-foreground">Crecimiento</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Featured Recipes Grid */}
            <div className="lg:col-span-3">
              <h2 className="text-xl font-semibold mb-4">Más populares</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {featuredRecipes.map((recipe, index) => (
                  <motion.div
                    key={recipe.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link href={`/recetas/${recipe.id}`}>
                      <Card className="h-full overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer">
                        <div className="relative h-48 overflow-hidden">
                          <img
                            src={recipe.imageUrl}
                            alt={recipe.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute top-3 left-3">
                            <Badge className="bg-yellow-500 text-white">
                              #{index + 1}
                            </Badge>
                          </div>
                          <div className="absolute top-3 right-3">
                            <Badge className="bg-white/90 text-gray-800">
                              <Star className="h-3 w-3 mr-1 text-yellow-500 fill-yellow-500" />
                              {recipe.averageRating.toFixed(1)}
                            </Badge>
                          </div>
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle className="line-clamp-1">{recipe.title}</CardTitle>
                          <CardDescription className="line-clamp-2">
                            {recipe.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pb-2">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              {recipe.totalTime} min
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {recipe.difficulty === 'facil' ? 'Fácil' : 
                               recipe.difficulty === 'medio' ? 'Medio' : 'Difícil'}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            {recipe.isGlutenFree && (
                              <Badge className="bg-green-500 text-xs">Sin Gluten</Badge>
                            )}
                            <span className="text-xs text-muted-foreground">
                              {recipe.viewCount.toLocaleString()} vistas
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Trending Tags */}
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Tendencias
                  </CardTitle>
                  <CardDescription>
                    Etiquetas más buscadas
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {trendingTags.map(tag => (
                      <Link key={tag.name} href={`/recetas?search=${tag.name}`}>
                        <Badge variant="secondary" className="cursor-pointer hover:bg-orange-100">
                          {tag.name} ({tag.count})
                        </Badge>
                      </Link>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
