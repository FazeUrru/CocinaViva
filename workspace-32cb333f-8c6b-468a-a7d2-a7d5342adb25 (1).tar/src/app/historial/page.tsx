'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  History,
  Clock,
  Calendar,
  ChefHat,
  TrendingUp,
  BarChart3,
  StickyNote,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'

// Demo history data
const cookingHistory = [
  {
    id: '1',
    recipeId: '1',
    recipeTitle: 'Paella Valenciana',
    recipeImage: '/images/recipes/paella.png',
    cookedAt: new Date(Date.now() - 86400000),
    portions: 4,
    notes: 'Quedó perfecta, repetir la próxima vez',
  },
  {
    id: '2',
    recipeId: '4',
    recipeTitle: 'Tarta de Chocolate',
    recipeImage: '/images/recipes/chocolate-cake.png',
    cookedAt: new Date(Date.now() - 86400000 * 3),
    portions: 8,
    notes: 'Le añadí frambuesas extra',
  },
  {
    id: '3',
    recipeId: '6',
    recipeTitle: 'Pasta Carbonara',
    recipeImage: '/images/recipes/carbonara.png',
    cookedAt: new Date(Date.now() - 86400000 * 5),
    portions: 2,
    notes: null,
  },
  {
    id: '4',
    recipeId: '3',
    recipeTitle: 'Ensalada Mediterránea',
    recipeImage: '/images/recipes/salad.png',
    cookedAt: new Date(Date.now() - 86400000 * 7),
    portions: 2,
    notes: 'Añadí queso feta',
  },
]

// Stats
const stats = {
  totalRecipes: 24,
  thisMonth: 8,
  topCategory: 'Postres',
  averageRating: 4.6,
}

const recentCategories = [
  { name: 'Postres', count: 10, color: 'bg-pink-500' },
  { name: 'Cenas', count: 8, color: 'bg-purple-500' },
  { name: 'Almuerzos', count: 6, color: 'bg-blue-500' },
]

export default function HistorialPage() {
  const formatDate = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const days = Math.floor(diff / (1000 * 60 * 60 * 24))
    
    if (days === 0) return 'Hoy'
    if (days === 1) return 'Ayer'
    if (days < 7) return `Hace ${days} días`
    return date.toLocaleDateString('es-ES', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <History className="h-8 w-8 text-purple-500" />
              Historial de Cocina
            </h1>
            <p className="text-muted-foreground">
              Registro de todas las recetas que has preparado
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                    <ChefHat className="h-5 w-5 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{stats.totalRecipes}</div>
                    <div className="text-sm text-muted-foreground">Recetas totales</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{stats.thisMonth}</div>
                    <div className="text-sm text-muted-foreground">Este mes</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                    <TrendingUp className="h-5 w-5 text-purple-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{stats.topCategory}</div>
                    <div className="text-sm text-muted-foreground">Categoría top</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                    <BarChart3 className="h-5 w-5 text-yellow-500" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{stats.averageRating}</div>
                    <div className="text-sm text-muted-foreground">Valoración media</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* History List */}
            <div className="lg:col-span-2 space-y-4">
              <h2 className="text-xl font-semibold">Recientes</h2>
              {cookingHistory.length === 0 ? (
                <Card className="text-center py-12">
                  <CardContent>
                    <History className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Sin historial</h3>
                    <p className="text-muted-foreground mb-4">
                      Comienza a cocinar para ver tu historial
                    </p>
                    <Link href="/recetas">
                      <Button>Explorar recetas</Button>
                    </Link>
                  </CardContent>
                </Card>
              ) : (
                cookingHistory.map((entry, index) => (
                  <motion.div
                    key={entry.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link href={`/recetas/${entry.recipeId}`}>
                      <Card className="hover:shadow-md transition-all cursor-pointer">
                        <div className="flex">
                          <div className="w-24 h-24 relative flex-shrink-0 overflow-hidden rounded-l-lg">
                            <img
                              src={entry.recipeImage}
                              alt={entry.recipeTitle}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 p-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="font-medium">{entry.recipeTitle}</h3>
                                <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
                                  <span className="flex items-center gap-1">
                                    <Calendar className="h-3 w-3" />
                                    {formatDate(entry.cookedAt)}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <ChefHat className="h-3 w-3" />
                                    {entry.portions} porciones
                                  </span>
                                </div>
                              </div>
                              {entry.notes && (
                                <Badge variant="secondary" className="flex items-center gap-1">
                                  <StickyNote className="h-3 w-3" />
                                  Nota
                                </Badge>
                              )}
                            </div>
                            {entry.notes && (
                              <p className="text-sm text-muted-foreground mt-2 line-clamp-1">
                                {entry.notes}
                              </p>
                            )}
                          </div>
                        </div>
                      </Card>
                    </Link>
                  </motion.div>
                ))
              )}
            </div>

            {/* Categories Sidebar */}
            <div className="space-y-6">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg">Categorías frecuentes</CardTitle>
                  <CardDescription>
                    Tus tipos de recetas más cocinadas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recentCategories.map((cat, index) => (
                    <div key={cat.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{cat.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {cat.count} recetas
                        </span>
                      </div>
                      <Progress 
                        value={(cat.count / stats.totalRecipes) * 100} 
                        className="h-2"
                      />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
