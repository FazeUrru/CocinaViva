'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Plus,
  ChefHat,
  Image as ImageIcon,
  Clock,
  Users,
  Tag,
  Save,
  Eye,
  Trash2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Separator } from '@/components/ui/separator'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { toast } from 'sonner'
import { cn } from '@/lib/utils'

export default function CrearPage() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [prepTime, setPrepTime] = useState(15)
  const [cookTime, setCookTime] = useState(30)
  const [servings, setServings] = useState(4)
  const [difficulty, setDifficulty] = useState('facil')
  const [toolType, setToolType] = useState('tradicional')
  const [isGlutenFree, setIsGlutenFree] = useState(false)
  const [isPublic, setIsPublic] = useState(true)
  const [mealType, setMealType] = useState('all')
  const [cuisineType, setCuisineType] = useState('all')
  const [ingredients, setIngredients] = useState([
    { id: '1', name: '', quantity: 1, unit: 'unidades', notes: '' }
  ])
  const [steps, setSteps] = useState([
    { id: '1', instruction: '', duration: null, tip: '' }
  ])

  const addIngredient = () => {
    setIngredients(prev => [
      ...prev,
      { id: Date.now().toString(), name: '', quantity: 1, unit: 'unidades', notes: '' }
    ])
  }

  const updateIngredient = (id: string, field: string, value: string | number) => {
    setIngredients(prev =>
      prev.map(ing => ing.id === id ? { ...ing, [field]: value } : ing)
    )
  }

  const removeIngredient = (id: string) => {
    if (ingredients.length > 1) {
      setIngredients(prev => prev.filter(ing => ing.id !== id))
    }
  }

  const addStep = () => {
    setSteps(prev => [
      ...prev,
      { id: Date.now().toString(), instruction: '', duration: null, tip: '' }
    ])
  }

  const updateStep = (id: string, field: string, value: string | number | null) => {
    setSteps(prev =>
      prev.map(step => step.id === id ? { ...step, [field]: value } : step)
    )
  }

  const removeStep = (id: string) => {
    if (steps.length > 1) {
      setSteps(prev => prev.filter(step => step.id !== id))
    }
  }

  const saveRecipe = () => {
    // Validate
    if (!title.trim()) {
      toast.error('El título es obligatorio')
      return
    }
    if (ingredients.some(ing => !ing.name.trim())) {
      toast.error('Todos los ingredientes deben tener nombre')
      return
    }
    if (steps.some(step => !step.instruction.trim())) {
      toast.error('Todos los pasos deben tener instrucciones')
      return
    }

    // Here you would save to the API
    toast.success('¡Receta guardada correctamente!')
  }

  const totalTime = prepTime + cookTime

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <ChefHat className="h-8 w-8 text-orange-500" />
              Crear Receta
            </h1>
            <p className="text-muted-foreground">
              Comparte tu receta con la comunidad
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Información básica</CardTitle>
                  <CardDescription>
                    Datos principales de tu receta
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Título *</Label>
                    <Input
                      id="title"
                      placeholder="Ej: Paella Valenciana"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Descripción</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe brevemente tu receta..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="prepTime">Preparación (min)</Label>
                      <Input
                        id="prepTime"
                        type="number"
                        min={0}
                        value={prepTime}
                        onChange={(e) => setPrepTime(parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="cookTime">Cocción (min)</Label>
                      <Input
                        id="cookTime"
                        type="number"
                        min={0}
                        value={cookTime}
                        onChange={(e) => setCookTime(parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="servings">Porciones</Label>
                      <Input
                        id="servings"
                        type="number"
                        min={1}
                        value={servings}
                        onChange={(e) => setServings(parseInt(e.target.value) || 1)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Dificultad</Label>
                      <Select value={difficulty} onValueChange={setDifficulty}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="facil">Fácil</SelectItem>
                          <SelectItem value="medio">Medio</SelectItem>
                          <SelectItem value="dificil">Difícil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Tipo de cocina</Label>
                      <Select value={toolType} onValueChange={setToolType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="tradicional">Tradicional</SelectItem>
                          <SelectItem value="thermomix">Thermomix</SelectItem>
                          <SelectItem value="crockpot">Crockpot</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Tipo de plato</Label>
                      <Select value={mealType} onValueChange={setMealType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Seleccionar...</SelectItem>
                          <SelectItem value="desayuno">Desayuno</SelectItem>
                          <SelectItem value="almuerzo">Almuerzo</SelectItem>
                          <SelectItem value="cena">Cena</SelectItem>
                          <SelectItem value="postre">Postre</SelectItem>
                          <SelectItem value="snack">Snack</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Cocina</Label>
                      <Select value={cuisineType} onValueChange={setCuisineType}>
                        <SelectTrigger>
                          <SelectValue placeholder="Seleccionar..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Seleccionar...</SelectItem>
                          <SelectItem value="española">Española</SelectItem>
                          <SelectItem value="italiana">Italiana</SelectItem>
                          <SelectItem value="mexicana">Mexicana</SelectItem>
                          <SelectItem value="asiatica">Asiática</SelectItem>
                          <SelectItem value="mediterranea">Mediterránea</SelectItem>
                          <SelectItem value="otra">Otra</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2">
                      <Switch
                        id="glutenFree"
                        checked={isGlutenFree}
                        onCheckedChange={setIsGlutenFree}
                      />
                      <Label htmlFor="glutenFree">Sin gluten</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        id="isPublic"
                        checked={isPublic}
                        onCheckedChange={setIsPublic}
                      />
                      <Label htmlFor="isPublic">Pública</Label>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Image Upload */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ImageIcon className="h-5 w-5" />
                    Imagen
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed rounded-lg p-8 text-center">
                    <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground mb-4">
                      Arrastra una imagen o haz clic para seleccionar
                    </p>
                    <Button variant="outline">
                      Seleccionar imagen
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Ingredients */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Ingredientes</CardTitle>
                      <CardDescription>
                        Añade todos los ingredientes necesarios
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={addIngredient}>
                      <Plus className="h-4 w-4 mr-2" />
                      Añadir
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {ingredients.map((ing, index) => (
                    <div key={ing.id} className="flex gap-2 items-start">
                      <span className="w-6 h-6 rounded-full bg-orange-100 text-orange-600 flex items-center justify-center text-sm font-medium mt-2">
                        {index + 1}
                      </span>
                      <div className="flex-1 grid grid-cols-4 gap-2">
                        <Input
                          placeholder="Ingrediente"
                          value={ing.name}
                          onChange={(e) => updateIngredient(ing.id, 'name', e.target.value)}
                          className="col-span-2"
                        />
                        <Input
                          type="number"
                          placeholder="Cant."
                          value={ing.quantity}
                          onChange={(e) => updateIngredient(ing.id, 'quantity', parseFloat(e.target.value) || 0)}
                        />
                        <Input
                          placeholder="Unidad"
                          value={ing.unit}
                          onChange={(e) => updateIngredient(ing.id, 'unit', e.target.value)}
                        />
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeIngredient(ing.id)}
                        disabled={ingredients.length === 1}
                      >
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Steps */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Pasos</CardTitle>
                      <CardDescription>
                        Instrucciones detalladas de preparación
                      </CardDescription>
                    </div>
                    <Button variant="outline" size="sm" onClick={addStep}>
                      <Plus className="h-4 w-4 mr-2" />
                      Añadir paso
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {steps.map((step, index) => (
                    <div key={step.id} className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-green-500 flex items-center justify-center text-white font-bold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <Textarea
                            placeholder="Describe este paso..."
                            value={step.instruction}
                            onChange={(e) => updateStep(step.id, 'instruction', e.target.value)}
                            rows={2}
                          />
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeStep(step.id)}
                          disabled={steps.length === 1}
                        >
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                      <div className="flex gap-4 ml-11">
                        <div className="flex items-center gap-2">
                          <Label className="text-sm text-muted-foreground">Duración (min):</Label>
                          <Input
                            type="number"
                            min={0}
                            placeholder="Opcional"
                            value={step.duration || ''}
                            onChange={(e) => updateStep(step.id, 'duration', parseInt(e.target.value) || null)}
                            className="w-24"
                          />
                        </div>
                        <Input
                          placeholder="Consejo opcional..."
                          value={step.tip || ''}
                          onChange={(e) => updateStep(step.id, 'tip', e.target.value)}
                          className="flex-1"
                        />
                      </div>
                      {index < steps.length - 1 && <Separator className="mt-4" />}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Preview Card */}
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="text-lg">Vista previa</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
                    <ImageIcon className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">
                      {title || 'Título de la receta'}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {description || 'Descripción de tu receta...'}
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-xs">
                      <Clock className="h-3 w-3 mr-1" />
                      {totalTime} min
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      <Users className="h-3 w-3 mr-1" />
                      {servings} pers.
                    </Badge>
                    <Badge variant="outline" className="text-xs">
                      {difficulty === 'facil' ? 'Fácil' : difficulty === 'medio' ? 'Medio' : 'Difícil'}
                    </Badge>
                    {isGlutenFree && (
                      <Badge className="bg-green-500 text-xs">Sin Gluten</Badge>
                    )}
                  </div>
                  <Separator />
                  <div className="text-sm text-muted-foreground">
                    <div>{ingredients.length} ingredientes</div>
                    <div>{steps.length} pasos</div>
                  </div>
                </CardContent>
                <div className="p-4 pt-0 space-y-2">
                  <Button onClick={saveRecipe} className="w-full bg-gradient-to-r from-orange-500 to-green-500">
                    <Save className="h-4 w-4 mr-2" />
                    Guardar receta
                  </Button>
                  <Button variant="outline" className="w-full">
                    <Eye className="h-4 w-4 mr-2" />
                    Vista previa
                  </Button>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
