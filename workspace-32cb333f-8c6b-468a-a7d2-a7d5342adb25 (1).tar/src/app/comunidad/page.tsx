'use client'

import { useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
  Users,
  Trophy,
  Calendar,
  Heart,
  MessageCircle,
  Share2,
  Camera,
  Flame,
  Star,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { cn } from '@/lib/utils'

// Demo challenges data
const activeChallenges = [
  {
    id: '1',
    title: 'Reto Semanal: Postres de Verano',
    description: 'Comparte tu mejor postre refrescante para estos días de calor',
    imageUrl: '/images/recipes/chocolate-cake.png',
    participants: 45,
    endDate: new Date(Date.now() + 86400000 * 5),
    posts: 23,
    type: 'semanal',
  },
  {
    id: '2',
    title: 'Cocina Sin Gluten',
    description: 'Recetas deliciosas aptas para celíacos',
    imageUrl: '/images/recipes/salad.png',
    participants: 32,
    endDate: new Date(Date.now() + 86400000 * 10),
    posts: 18,
    type: 'mensual',
  },
]

// Demo community posts
const communityPosts = [
  {
    id: '1',
    userId: 'user1',
    userName: 'María García',
    userAvatar: null,
    title: 'Mi primera paella!',
    description: 'Por fin me animé a hacer paella valenciana y quedó espectacular 🥘',
    imageUrl: '/images/recipes/paella.png',
    likes: 24,
    comments: 8,
    createdAt: new Date(Date.now() - 3600000),
    challengeId: null,
  },
  {
    id: '2',
    userId: 'user2',
    userName: 'Carlos López',
    userAvatar: null,
    title: 'Tarta de chocolate para el reto',
    description: 'Mi contribución al reto de postres de verano 🍫',
    imageUrl: '/images/recipes/chocolate-cake.png',
    likes: 56,
    comments: 12,
    createdAt: new Date(Date.now() - 86400000),
    challengeId: '1',
  },
  {
    id: '3',
    userId: 'user3',
    userName: 'Ana Martínez',
    userAvatar: null,
    title: 'Ensalada mediterránea light',
    description: 'Versión ligera de la clásica ensalada, perfecta para el verano 🥗',
    imageUrl: '/images/recipes/salad.png',
    likes: 38,
    comments: 5,
    createdAt: new Date(Date.now() - 86400000 * 2),
    challengeId: null,
  },
]

// Leaderboard
const leaderboard = [
  { rank: 1, name: 'María García', points: 1250, recipes: 45, avatar: null },
  { rank: 2, name: 'Carlos López', points: 1180, recipes: 38, avatar: null },
  { rank: 3, name: 'Ana Martínez', points: 920, recipes: 32, avatar: null },
  { rank: 4, name: 'Pedro Sánchez', points: 850, recipes: 28, avatar: null },
  { rank: 5, name: 'Laura Fernández', points: 780, recipes: 25, avatar: null },
]

export default function ComunidadPage() {
  const [postContent, setPostContent] = useState('')

  const formatTimeAgo = (date: Date) => {
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const hours = Math.floor(diff / (1000 * 60 * 60))
    
    if (hours < 1) return 'Hace un momento'
    if (hours < 24) return `Hace ${hours}h`
    const days = Math.floor(hours / 24)
    return `Hace ${days}d`
  }

  const formatDaysLeft = (endDate: Date) => {
    const now = new Date()
    const diff = endDate.getTime() - now.getTime()
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24))
    return days
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navigation />
      
      <main className="flex-1">
        <section className="bg-gradient-to-br from-orange-50 to-green-50 dark:from-orange-950/20 dark:to-green-950/20 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
              <Users className="h-8 w-8 text-green-500" />
              Comunidad
            </h1>
            <p className="text-muted-foreground">
              Comparte tus creaciones y participa en los retos culinarios
            </p>
          </div>
        </section>

        <div className="container mx-auto px-4 py-8">
          <Tabs defaultValue="challenges" className="space-y-6">
            <TabsList>
              <TabsTrigger value="challenges">
                <Trophy className="h-4 w-4 mr-2" />
                Retos Activos
              </TabsTrigger>
              <TabsTrigger value="feed">
                <Camera className="h-4 w-4 mr-2" />
                Publicaciones
              </TabsTrigger>
              <TabsTrigger value="leaderboard">
                <Star className="h-4 w-4 mr-2" />
                Clasificación
              </TabsTrigger>
            </TabsList>

            {/* Challenges Tab */}
            <TabsContent value="challenges" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {activeChallenges.map((challenge, index) => (
                  <motion.div
                    key={challenge.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="overflow-hidden hover:shadow-lg transition-all">
                      <div className="relative h-48">
                        <img
                          src={challenge.imageUrl}
                          alt={challenge.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                        <div className="absolute bottom-4 left-4 right-4">
                          <Badge className={cn(
                            "mb-2",
                            challenge.type === 'semanal' ? 'bg-orange-500' : 'bg-green-500'
                          )}>
                            {challenge.type === 'semanal' ? 'Reto Semanal' : 'Reto Mensual'}
                          </Badge>
                          <h3 className="text-xl font-bold text-white">{challenge.title}</h3>
                        </div>
                      </div>
                      <CardContent className="pt-4">
                        <p className="text-muted-foreground mb-4">
                          {challenge.description}
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Users className="h-4 w-4" />
                              {challenge.participants}
                            </span>
                            <span className="flex items-center gap-1">
                              <Camera className="h-4 w-4" />
                              {challenge.posts}
                            </span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline">
                              <Calendar className="h-3 w-3 mr-1" />
                              {formatDaysLeft(challenge.endDate)} días
                            </Badge>
                            <Button size="sm" className="bg-gradient-to-r from-orange-500 to-green-500">
                              Unirse
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Feed Tab */}
            <TabsContent value="feed" className="space-y-6">
              {/* Create Post */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Comparte tu creación</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="¿Qué has cocinado hoy?"
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    rows={3}
                  />
                  <div className="flex justify-between items-center">
                    <Button variant="outline" size="sm">
                      <Camera className="h-4 w-4 mr-2" />
                      Añadir foto
                    </Button>
                    <Button disabled={!postContent.trim()}>
                      Publicar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Posts */}
              <div className="space-y-4">
                {communityPosts.map((post, index) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card>
                      <CardHeader>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>
                              {post.userName.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{post.userName}</div>
                            <div className="text-sm text-muted-foreground">
                              {formatTimeAgo(post.createdAt)}
                            </div>
                          </div>
                          {post.challengeId && (
                            <Badge variant="secondary" className="ml-auto">
                              <Trophy className="h-3 w-3 mr-1" />
                              Reto
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="pt-0">
                        <h3 className="font-medium mb-2">{post.title}</h3>
                        <p className="text-muted-foreground mb-4">{post.description}</p>
                        <img
                          src={post.imageUrl}
                          alt={post.title}
                          className="w-full h-64 object-cover rounded-lg"
                        />
                      </CardContent>
                      <CardFooter className="border-t pt-4">
                        <div className="flex items-center gap-6">
                          <Button variant="ghost" size="sm">
                            <Heart className="h-4 w-4 mr-2" />
                            {post.likes}
                          </Button>
                          <Button variant="ghost" size="sm">
                            <MessageCircle className="h-4 w-4 mr-2" />
                            {post.comments}
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Share2 className="h-4 w-4 mr-2" />
                            Compartir
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Leaderboard Tab */}
            <TabsContent value="leaderboard">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-yellow-500" />
                    Tabla de Clasificación
                  </CardTitle>
                  <CardDescription>
                    Los cocineros más activos de la comunidad
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {leaderboard.map((user, index) => (
                      <div
                        key={user.rank}
                        className={cn(
                          "flex items-center gap-4 p-4 rounded-lg",
                          index < 3 && "bg-muted"
                        )}
                      >
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center font-bold",
                          user.rank === 1 && "bg-yellow-500 text-white",
                          user.rank === 2 && "bg-gray-400 text-white",
                          user.rank === 3 && "bg-amber-600 text-white",
                          user.rank > 3 && "bg-muted text-muted-foreground"
                        )}>
                          {user.rank}
                        </div>
                        <Avatar>
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="font-medium">{user.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {user.recipes} recetas
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-orange-500">{user.points}</div>
                          <div className="text-xs text-muted-foreground">puntos</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <Footer />
    </div>
  )
}
