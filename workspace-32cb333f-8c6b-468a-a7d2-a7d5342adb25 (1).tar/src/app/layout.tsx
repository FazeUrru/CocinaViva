import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { ThemeProvider } from "next-themes";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CocinaViva - Tu cocina integral",
  description: "Aplicación web de cocina integral con recetario personalizado, gestión de ingredientes, herramientas de cocina y organización de contenido culinario.",
  keywords: ["cocina", "recetas", "thermomix", "crockpot", "comida", "español"],
  authors: [{ name: "CocinaViva Team" }],
  icons: {
    icon: "/images/logo.png",
  },
  openGraph: {
    title: "CocinaViva - Tu cocina integral",
    description: "Descubre recetas deliciosas, organiza tu cocina y comparte con la comunidad",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster position="top-right" richColors />
        </ThemeProvider>
      </body>
    </html>
  );
}
