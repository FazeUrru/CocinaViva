import { create } from 'zustand'
import { persist } from 'zustand middleware'

// User Plan Types
export type UserPlan = 'basic' | 'ultra' | 'masterchef'

// Trial State
export interface TrialState {
  isActive: boolean
  startDate: string | null
  endDate: string | null
  daysRemaining: number
  hasUsedTrial: boolean
}

// User State
export interface UserState {
  userId: string
  userName: string
  userEmail: string
  isAuthenticated: boolean
  authProvider: 'google' | 'facebook' | 'twitter' | 'apple' | 'email' | null
  avatarUrl: string | null
  
  // Plan & Subscription
  plan: UserPlan
  trial: TrialState
  subscriptionStartDate: string | null
  subscriptionEndDate: string | null
  
  // Progress
  userPoints: number
  level: number
  achievementsUnlocked: number
  totalAchievements: number
  streak: number
  lastActiveDate: string | null
  
  // Usage Limits
  favoritesUsed: number
  favoritesLimit: number
  recipesCreated: number
  
  // Settings
  hideUnachievedAchievements: boolean
  language: string
  darkMode: boolean
  fontSize: number
  autoUpdate: boolean
  notifications: boolean
  soundEffects: boolean
  
  // Admin
  isAdmin: boolean
  
  // Actions
  login: (id: string, name: string, email: string, provider: UserState['authProvider'], avatar?: string) => void
  logout: () => void
  setPlan: (plan: UserPlan) => void
  startTrial: () => void
  endTrial: () => void
  addPoints: (points: number) => void
  unlockAchievement: (achievementId: string, points: number) => void
  incrementStreak: () => void
  resetStreak: () => void
  addFavorite: () => void
  removeFavorite: () => void
  createRecipe: () => void
  updateSettings: (settings: Partial<UserState>) => void
  setAdmin: (isAdmin: boolean) => void
  checkTrialStatus: () => void
}

// Helper functions
const calculateDaysRemaining = (endDate: string): number => {
  const end = new Date(endDate)
  const now = new Date()
  const diff = end.getTime() - now.getTime()
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)))
}

const getFavoritesLimit = (plan: UserPlan): number => {
  switch (plan) {
    case 'ultra': return 27
    case 'masterchef': return Infinity
    default: return 10
  }
}

const calculateLevel = (points: number): number => {
  return Math.floor(points / 500) + 1
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      // Initial State
      userId: '',
      userName: '',
      userEmail: '',
      isAuthenticated: false,
      authProvider: null,
      avatarUrl: null,
      
      plan: 'basic',
      trial: {
        isActive: false,
        startDate: null,
        endDate: null,
        daysRemaining: 0,
        hasUsedTrial: false,
      },
      subscriptionStartDate: null,
      subscriptionEndDate: null,
      
      userPoints: 0,
      level: 1,
      achievementsUnlocked: 0,
      totalAchievements: 350,
      streak: 0,
      lastActiveDate: null,
      
      favoritesUsed: 0,
      favoritesLimit: 10,
      recipesCreated: 0,
      
      hideUnachievedAchievements: true,
      language: 'es',
      darkMode: false,
      fontSize: 100,
      autoUpdate: true,
      notifications: true,
      soundEffects: true,
      
      isAdmin: false,
      
      // Actions
      login: (id, name, email, provider, avatar) => {
        const isAdmin = email === 'iiribasu2010@gmail.com'
        set({
          userId: id,
          userName: name,
          userEmail: email,
          isAuthenticated: true,
          authProvider: provider,
          avatarUrl: avatar || null,
          isAdmin,
        })
      },
      
      logout: () => set({
        userId: '',
        userName: '',
        userEmail: '',
        isAuthenticated: false,
        authProvider: null,
        avatarUrl: null,
      }),
      
      setPlan: (plan) => {
        const now = new Date()
        const endDate = new Date(now)
        endDate.setFullYear(endDate.getFullYear() + 1)
        
        set({
          plan,
          favoritesLimit: getFavoritesLimit(plan),
          subscriptionStartDate: now.toISOString(),
          subscriptionEndDate: endDate.toISOString(),
        })
      },
      
      startTrial: () => {
        const state = get()
        if (state.trial.hasUsedTrial) return
        
        const now = new Date()
        const endDate = new Date(now)
        endDate.setDate(endDate.getDate() + 7)
        
        set({
          plan: 'ultra',
          trial: {
            isActive: true,
            startDate: now.toISOString(),
            endDate: endDate.toISOString(),
            daysRemaining: 7,
            hasUsedTrial: true,
          },
          favoritesLimit: 27,
        })
      },
      
      endTrial: () => {
        set({
          plan: 'basic',
          trial: {
            ...get().trial,
            isActive: false,
            daysRemaining: 0,
          },
          favoritesLimit: 10,
        })
      },
      
      addPoints: (points) => {
        const newPoints = get().userPoints + points
        set({
          userPoints: newPoints,
          level: calculateLevel(newPoints),
        })
      },
      
      unlockAchievement: (achievementId, points) => {
        const state = get()
        const newPoints = state.userPoints + points
        set({
          achievementsUnlocked: state.achievementsUnlocked + 1,
          userPoints: newPoints,
          level: calculateLevel(newPoints),
        })
      },
      
      incrementStreak: () => {
        const state = get()
        const today = new Date().toDateString()
        const lastActive = state.lastActiveDate ? new Date(state.lastActiveDate).toDateString() : null
        
        if (lastActive === today) return
        
        const yesterday = new Date()
        yesterday.setDate(yesterday.getDate() - 1)
        
        const newStreak = lastActive === yesterday.toDateString() 
          ? state.streak + 1 
          : 1
        
        set({
          streak: newStreak,
          lastActiveDate: new Date().toISOString(),
        })
      },
      
      resetStreak: () => set({ streak: 0 }),
      
      addFavorite: () => {
        const state = get()
        if (state.favoritesUsed < state.favoritesLimit) {
          set({ favoritesUsed: state.favoritesUsed + 1 })
        }
      },
      
      removeFavorite: () => {
        const state = get()
        if (state.favoritesUsed > 0) {
          set({ favoritesUsed: state.favoritesUsed - 1 })
        }
      },
      
      createRecipe: () => {
        const state = get()
        set({ recipesCreated: state.recipesCreated + 1 })
      },
      
      updateSettings: (settings) => set(settings),
      
      setAdmin: (isAdmin) => set({ isAdmin }),
      
      checkTrialStatus: () => {
        const state = get()
        if (state.trial.isActive && state.trial.endDate) {
          const daysRemaining = calculateDaysRemaining(state.trial.endDate)
          if (daysRemaining <= 0) {
            get().endTrial()
          } else {
            set({
              trial: {
                ...state.trial,
                daysRemaining,
              }
            })
          }
        }
      },
    }),
    { name: 'cocinaviva-user' }
  )
)

// Export helper to check if user can use feature
export const canUseFeature = (feature: string): boolean => {
  const state = useUserStore.getState()
  
  switch (feature) {
    case 'advanced-search':
    case 'pro-filters':
      return state.plan === 'ultra' || state.plan === 'masterchef' || state.trial.isActive
    case 'ai-filters':
    case 'voice-assistant':
    case 'cloud-sync':
    case 'priority-support':
      return state.plan === 'masterchef'
    case 'export-recipes':
      return state.plan === 'masterchef'
    case 'thermomix-mode':
    case 'nutritional-calculator':
    case 'weekly-planner':
      return state.plan !== 'basic' || state.trial.isActive
    case 'verified-reviews':
      return state.plan === 'ultra' || state.plan === 'masterchef' || state.trial.isActive
    case 'unlimited-favorites':
      return state.plan === 'masterchef'
    default:
      return true
  }
}

export const getAvailableAchievements = (plan: UserPlan): number => {
  switch (plan) {
    case 'masterchef': return 350
    case 'ultra': return 175
    default: return 50
  }
}
