import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// Subscription Plans
export type PlanType = 'basic' | 'ultra' | 'masterchef'

export interface SubscriptionState {
  plan: PlanType
  trialStartDate: string | null
  trialEndDate: string | null
  isTrialActive: boolean
  favoritesLimit: number
  hasAdvancedSearch: boolean
  hasIAFilters: boolean
  hasProFilters: boolean
  hasVerifiedReviews: boolean
  hasVoiceAssistant: boolean
  hasPrioritySupport: boolean
  hasCloudSync: boolean
  hasNutritionCalculator: boolean
  hasThermomixMode: boolean
  hasWeeklyPlanner: boolean
  achievementsAvailable: number
  recipesAccess: number
  
  // Actions
  startTrial: (plan: PlanType) => void
  subscribe: (plan: PlanType) => void
  cancelSubscription: () => void
  checkTrialStatus: () => void
  canAddFavorite: (currentCount: number) => boolean
}

// Calculate trial end date (7 days from start)
const calculateTrialEnd = (startDate: Date): Date => {
  const endDate = new Date(startDate)
  endDate.setDate(endDate.getDate() + 7)
  return endDate
}

export const useSubscriptionStore = create<SubscriptionState>()(
  persist(
    (set, get) => ({
      plan: 'basic',
      trialStartDate: null,
      trialEndDate: null,
      isTrialActive: false,
      favoritesLimit: 0, // 0 = unlimited for basic (but basic has no favorites)
      hasAdvancedSearch: false,
      hasIAFilters: false,
      hasProFilters: false,
      hasVerifiedReviews: false,
      hasVoiceAssistant: false,
      hasPrioritySupport: false,
      hasCloudSync: false,
      hasNutritionCalculator: false,
      hasThermomixMode: false,
      hasWeeklyPlanner: false,
      achievementsAvailable: 0,
      recipesAccess: 100,

      startTrial: (plan: PlanType) => {
        const now = new Date()
        const endDate = calculateTrialEnd(now)
        
        const planFeatures = {
          ultra: {
            favoritesLimit: 27,
            hasAdvancedSearch: true,
            hasIAFilters: false,
            hasProFilters: true,
            hasVerifiedReviews: true,
            hasVoiceAssistant: false,
            hasPrioritySupport: false,
            hasCloudSync: false,
            hasNutritionCalculator: true,
            hasThermomixMode: true,
            hasWeeklyPlanner: true,
            achievementsAvailable: 175,
            recipesAccess: 800,
          },
          masterchef: {
            favoritesLimit: 999999, // unlimited
            hasAdvancedSearch: true,
            hasIAFilters: true,
            hasProFilters: true,
            hasVerifiedReviews: true,
            hasVoiceAssistant: true,
            hasPrioritySupport: true,
            hasCloudSync: true,
            hasNutritionCalculator: true,
            hasThermomixMode: true,
            hasWeeklyPlanner: true,
            achievementsAvailable: 350,
            recipesAccess: 1000,
          },
          basic: {
            favoritesLimit: 0,
            hasAdvancedSearch: false,
            hasIAFilters: false,
            hasProFilters: false,
            hasVerifiedReviews: false,
            hasVoiceAssistant: false,
            hasPrioritySupport: false,
            hasCloudSync: false,
            hasNutritionCalculator: false,
            hasThermomixMode: false,
            hasWeeklyPlanner: false,
            achievementsAvailable: 0,
            recipesAccess: 100,
          },
        }

        set({
          plan,
          trialStartDate: now.toISOString(),
          trialEndDate: endDate.toISOString(),
          isTrialActive: true,
          ...planFeatures[plan],
        })
      },

      subscribe: (plan: PlanType) => {
        const planFeatures = {
          ultra: {
            favoritesLimit: 27,
            hasAdvancedSearch: true,
            hasIAFilters: false,
            hasProFilters: true,
            hasVerifiedReviews: true,
            hasVoiceAssistant: false,
            hasPrioritySupport: false,
            hasCloudSync: false,
            hasNutritionCalculator: true,
            hasThermomixMode: true,
            hasWeeklyPlanner: true,
            achievementsAvailable: 175,
            recipesAccess: 800,
          },
          masterchef: {
            favoritesLimit: 999999,
            hasAdvancedSearch: true,
            hasIAFilters: true,
            hasProFilters: true,
            hasVerifiedReviews: true,
            hasVoiceAssistant: true,
            hasPrioritySupport: true,
            hasCloudSync: true,
            hasNutritionCalculator: true,
            hasThermomixMode: true,
            hasWeeklyPlanner: true,
            achievementsAvailable: 350,
            recipesAccess: 1000,
          },
          basic: {
            favoritesLimit: 0,
            hasAdvancedSearch: false,
            hasIAFilters: false,
            hasProFilters: false,
            hasVerifiedReviews: false,
            hasVoiceAssistant: false,
            hasPrioritySupport: false,
            hasCloudSync: false,
            hasNutritionCalculator: false,
            hasThermomixMode: false,
            hasWeeklyPlanner: false,
            achievementsAvailable: 0,
            recipesAccess: 100,
          },
        }

        set({
          plan,
          isTrialActive: false,
          ...planFeatures[plan],
        })
      },

      cancelSubscription: () => {
        set({
          plan: 'basic',
          trialStartDate: null,
          trialEndDate: null,
          isTrialActive: false,
          favoritesLimit: 0,
          hasAdvancedSearch: false,
          hasIAFilters: false,
          hasProFilters: false,
          hasVerifiedReviews: false,
          hasVoiceAssistant: false,
          hasPrioritySupport: false,
          hasCloudSync: false,
          hasNutritionCalculator: false,
          hasThermomixMode: false,
          hasWeeklyPlanner: false,
          achievementsAvailable: 0,
          recipesAccess: 100,
        })
      },

      checkTrialStatus: () => {
        const { trialEndDate, plan } = get()
        if (trialEndDate && plan !== 'basic') {
          const now = new Date()
          const end = new Date(trialEndDate)
          if (now >= end) {
            // Trial expired, revert to basic
            get().cancelSubscription()
          }
        }
      },

      canAddFavorite: (currentCount: number) => {
        const { plan, favoritesLimit, isTrialActive } = get()
        if (plan === 'basic') return false
        if (plan === 'masterchef') return true
        return currentCount < favoritesLimit
      },
    }),
    { name: 'cocinaviva-subscription' }
  )
)

// Supported Languages (25 total)
export const supportedLanguages = [
  { code: 'es', name: 'Español', flag: '🇪🇸' },
  { code: 'en', name: 'English', flag: '🇬🇧' },
  { code: 'pt', name: 'Português', flag: '🇵🇹' },
  { code: 'fr', name: 'Français', flag: '🇫🇷' },
  { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
  { code: 'it', name: 'Italiano', flag: '🇮🇹' },
  { code: 'nl', name: 'Nederlands', flag: '🇳🇱' },
  { code: 'pl', name: 'Polski', flag: '🇵🇱' },
  { code: 'ru', name: 'Русский', flag: '🇷🇺' },
  { code: 'zh', name: '中文', flag: '🇨🇳' },
  { code: 'ja', name: '日本語', flag: '🇯🇵' },
  { code: 'ko', name: '한국어', flag: '🇰🇷' },
  { code: 'ar', name: 'العربية', flag: '🇸🇦' },
  { code: 'hi', name: 'हिन्दी', flag: '🇮🇳' },
  { code: 'tr', name: 'Türkçe', flag: '🇹🇷' },
  { code: 'vi', name: 'Tiếng Việt', flag: '🇻🇳' },
  { code: 'th', name: 'ไทย', flag: '🇹🇭' },
  { code: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩' },
  { code: 'ms', name: 'Bahasa Melayu', flag: '🇲🇾' },
  { code: 'sv', name: 'Svenska', flag: '🇸🇪' },
  { code: 'no', name: 'Norsk', flag: '🇳🇴' },
  { code: 'da', name: 'Dansk', flag: '🇩🇰' },
  { code: 'fi', name: 'Suomi', flag: '🇫🇮' },
  { code: 'el', name: 'Ελληνικά', flag: '🇬🇷' },
  { code: 'he', name: 'עברית', flag: '🇮🇱' },
]

// Admin email for hidden features
export const ADMIN_EMAIL = 'iiiribasu2010@gmail.com'

export const isAdmin = (email: string | undefined) => {
  return email === ADMIN_EMAIL
}
