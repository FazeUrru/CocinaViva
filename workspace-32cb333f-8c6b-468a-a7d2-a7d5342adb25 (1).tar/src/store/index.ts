import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Recipe, Timer, ShoppingItem } from '@/types'

// Subscription Plans
export type PlanType = 'basic' | 'ultra' | 'masterchef'

export interface SubscriptionState {
  plan: PlanType
  trialStartDate: string | null
  trialEndDate: string | null
  isTrialActive: boolean
  daysRemainingInTrial: number
  subscriptionStartDate: string | null
  subscriptionEndDate: string | null
  isSubscriptionActive: boolean
  hasUsedTrial: boolean // Solo se puede usar 1 vez
  trialPlanUsed: PlanType | null // Qué plan se probó
}

export interface UserProgress {
  userPoints: number
  totalPoints: number
  achievementsUnlocked: number
  totalAchievements: number
  recipesCreated: number
  recipesCompleted: number
  daysActive: number
  firstLoginDate: string | null
  lastLoginDate: string | null
  hideUnearnedAchievements: boolean
  favoriteCount: number
  maxFavorites: number
}

// Profile Settings Interface - 58 settings total
export interface ProfileSettingsData {
  // Datos Personales (9)
  fullName: string
  displayName: string
  dateOfBirth: string
  gender: string
  country: string
  city: string
  phone: string
  bio: string
  website: string
  
  // Preferencias Culinarias (12)
  favoriteCuisines: string[]
  cookingLevel: string
  preferredLanguage: string
  measurementSystem: string
  servingSizeDefault: number
  cookingGoals: string[]
  spiceLevel: string
  preferredProtein: string
  dietaryRestrictions: string[]
  mealPlanning: boolean
  groceryStore: string
  cookingFrequency: string
  
  // Dieta y Salud (9)
  dietType: string
  allergies: string[]
  calorieGoal: number
  proteinGoal: number
  carbGoal: number
  fatGoal: number
  healthConditions: string[]
  nutritionalTracking: boolean
  medicalNotes: string
  
  // Social (16)
  publicProfile: boolean
  showRecipes: boolean
  showFavorites: boolean
  showAchievements: boolean
  showActivity: boolean
  allowComments: boolean
  allowMessages: boolean
  allowFollows: boolean
  showOnlineStatus: boolean
  shareOnSocial: boolean
  linkedInstagram: string
  linkedTwitter: string
  linkedFacebook: string
  linkedTiktok: string
  linkedYoutube: string
  linkedPinterest: string
  
  // Privacidad (8)
  dataCollection: boolean
  personalizedAds: boolean
  analyticsSharing: boolean
  thirdPartySharing: boolean
  locationSharing: boolean
  searchHistory: boolean
  viewedRecipes: boolean
  downloadData: boolean
  
  // Experiencia (4)
  theme: string
  fontSize: string
  colorScheme: string
  reducedMotion: boolean
}

// Current User Store
interface UserState {
  userId: string
  userName: string
  userEmail: string
  isAuthenticated: boolean
  profilePicture: string | null
  isAdmin: boolean
  adminUnlockedAt: string | null
  subscription: SubscriptionState
  progress: UserProgress
  profileSettings: ProfileSettingsData
  registeredEmails: string[]
  
  setUserId: (id: string) => void
  setUserName: (name: string) => void
  setUserEmail: (email: string) => void
  setProfilePicture: (url: string | null) => void
  login: (id: string, name: string, email: string, picture?: string) => void
  logout: () => void
  enableAdmin: () => void
  disableAdmin: () => void
  startTrial: (plan: PlanType) => void
  subscribe: (plan: PlanType) => void
  cancelSubscription: () => void
  checkTrialStatus: () => void
  updatePlan: (plan: PlanType) => void
  addPoints: (points: number) => void
  unlockAchievement: (achievementId: string) => void
  incrementRecipesCreated: () => void
  incrementRecipesCompleted: () => void
  updateDaysActive: () => void
  toggleHideUnearnedAchievements: () => void
  incrementFavoriteCount: () => void
  decrementFavoriteCount: () => void
  updateProfileSettings: (settings: Partial<ProfileSettingsData>) => void
  registerEmail: (email: string) => void
}

// Available Languages (25)
export const availableLanguages = [
  { code: 'es', name: 'Español', nativeName: 'Español' },
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano' },
  { code: 'nl', name: 'Dutch', nativeName: 'Nederlands' },
  { code: 'pl', name: 'Polish', nativeName: 'Polski' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский' },
  { code: 'zh', name: 'Chinese', nativeName: '中文' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語' },
  { code: 'ko', name: 'Korean', nativeName: '한국어' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'tr', name: 'Turkish', nativeName: 'Türkçe' },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu' },
  { code: 'sv', name: 'Swedish', nativeName: 'Svenska' },
  { code: 'no', name: 'Norwegian', nativeName: 'Norsk' },
  { code: 'da', name: 'Danish', nativeName: 'Dansk' },
  { code: 'fi', name: 'Finnish', nativeName: 'Suomi' },
  { code: 'el', name: 'Greek', nativeName: 'Ελληνικά' },
  { code: 'he', name: 'Hebrew', nativeName: 'עברית' },
]

// Subscription Plans Configuration
export const subscriptionPlans = {
  basic: {
    name: 'Básico',
    price: 0,
    features: ['Acceso a 500 recetas', 'Búsqueda simple', 'Favoritos (limitado a 10)', 'Crear recetas propias (Gratis)', 'Reseñas de recetas', '125 logros disponibles', 'Modo Thermomix', 'Calculadora nutricional', 'Recetario Social (Beta)', 'Sin publicidad'],
    maxFavorites: 10,
    maxAchievements: 125,
  },
  ultra: {
    name: 'Ultra',
    price: 6.99,
    priceAnnual: 68.64, // 18% discount from 85.68
    trialDays: 7,
    discountPercent: 18,
    sharePrice: 1.99,
    features: ['Acceso a 800 recetas', 'Búsqueda avanzada con filtros', 'Favoritos limitado a 25', 'Crear recetas propias', 'Reseñas verificadas', 'Filtros Pro (Populares/Cooksnaps)', '175 logros disponibles', 'Modo Thermomix completo', 'Planificador semanal', 'Calculadora nutricional', 'Sin publicidad', 'Acceso anticipado a funciones', 'Exportar recetas', 'Compartir plan (+1,99€/2 personas)'],
    maxFavorites: 25,
    maxAchievements: 175,
  },
  masterchef: {
    name: 'MasterChef',
    price: 12.99,
    priceAnnual: 128.40, // 18% discount from 155.88
    trialDays: 7,
    discountPercent: 18,
    sharePrice: 1.99,
    features: ['Acceso a 1.000+ recetas completas', 'Filtros IA y Pro', 'Guardado y Favoritos Ilimitados', 'Crear recetas propias', 'Reseñas verificadas', '350 logros disponibles', 'Modo Thermomix completo', 'Planificador semanal avanzado', 'Calculadora nutricional avanzada', 'Asistente de voz (Beta)', 'Sin publicidad', 'Soporte prioritario 24/7', 'Sincronización en la nube', 'Chef Virtual IA (Beta)', 'Análisis Nutricional IA (Beta)', 'Compartir plan (+1,99€/2 personas)'],
    maxFavorites: Infinity,
    maxAchievements: 350,
  },
}

// Default profile settings
const defaultProfileSettings: ProfileSettingsData = {
  // Datos Personales (9)
  fullName: '',
  displayName: '',
  dateOfBirth: '',
  gender: '',
  country: '',
  city: '',
  phone: '',
  bio: '',
  website: '',
  
  // Preferencias Culinarias (12)
  favoriteCuisines: [],
  cookingLevel: 'beginner',
  preferredLanguage: 'es',
  measurementSystem: 'metric',
  servingSizeDefault: 4,
  cookingGoals: [],
  spiceLevel: 'medium',
  preferredProtein: 'chicken',
  dietaryRestrictions: [],
  mealPlanning: false,
  groceryStore: '',
  cookingFrequency: 'weekly',
  
  // Dieta y Salud (9)
  dietType: 'omnivore',
  allergies: [],
  calorieGoal: 2000,
  proteinGoal: 50,
  carbGoal: 250,
  fatGoal: 65,
  healthConditions: [],
  nutritionalTracking: false,
  medicalNotes: '',
  
  // Social (16)
  publicProfile: true,
  showRecipes: true,
  showFavorites: false,
  showAchievements: true,
  showActivity: true,
  allowComments: true,
  allowMessages: true,
  allowFollows: true,
  showOnlineStatus: false,
  shareOnSocial: false,
  linkedInstagram: '',
  linkedTwitter: '',
  linkedFacebook: '',
  linkedTiktok: '',
  linkedYoutube: '',
  linkedPinterest: '',
  
  // Privacidad (8)
  dataCollection: true,
  personalizedAds: false,
  analyticsSharing: true,
  thirdPartySharing: false,
  locationSharing: false,
  searchHistory: true,
  viewedRecipes: true,
  downloadData: false,
  
  // Experiencia (4)
  theme: 'system',
  fontSize: 'medium',
  colorScheme: 'default',
  reducedMotion: false,
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      userId: '',
      userName: '',
      userEmail: '',
      isAuthenticated: false,
      profilePicture: null,
      isAdmin: false,
      adminUnlockedAt: null,
      
      subscription: {
        plan: 'basic',
        trialStartDate: null,
        trialEndDate: null,
        isTrialActive: false,
        daysRemainingInTrial: 0,
        subscriptionStartDate: null,
        subscriptionEndDate: null,
        isSubscriptionActive: false,
        hasUsedTrial: false,
        trialPlanUsed: null,
      },
      
      progress: {
        userPoints: 0,
        totalPoints: 10000,
        achievementsUnlocked: 0,
        totalAchievements: 350,
        recipesCreated: 0,
        recipesCompleted: 0,
        daysActive: 0,
        firstLoginDate: null,
        lastLoginDate: null,
        hideUnearnedAchievements: true,
        favoriteCount: 0,
        maxFavorites: 10,
      },
      
      profileSettings: defaultProfileSettings,
      registeredEmails: [],
      
      setUserId: (id) => set({ userId: id }),
      setUserName: (name) => set({ userName: name }),
      setUserEmail: (email) => set({ userEmail: email }),
      setProfilePicture: (url) => set({ profilePicture: url }),
      
      login: (id, name, email, picture) => {
        const state = get()
        const now = new Date()
        const isFirstLogin = !state.progress.firstLoginDate
        // Check if admin
        const isAdminEmail = email.toLowerCase() === 'iiribasu2010@gmail.com'
        set({
          userId: id,
          userName: name,
          userEmail: email,
          isAuthenticated: true,
          profilePicture: picture || null,
          isAdmin: isAdminEmail,
          adminUnlockedAt: isAdminEmail ? now.toISOString() : null,
          progress: {
            ...state.progress,
            firstLoginDate: isFirstLogin ? now.toISOString() : state.progress.firstLoginDate,
            lastLoginDate: now.toISOString(),
          }
        })
      },
      
      logout: () => set({
        userId: '',
        userName: '',
        userEmail: '',
        isAuthenticated: false,
        profilePicture: null,
        isAdmin: false,
        adminUnlockedAt: null,
      }),
      
      enableAdmin: () => set({ isAdmin: true, adminUnlockedAt: new Date().toISOString() }),
      disableAdmin: () => set({ isAdmin: false, adminUnlockedAt: null }),
      
      startTrial: (plan) => {
        const state = get()
        // Si ya usó la prueba, no puede usar otra
        if (state.subscription.hasUsedTrial) {
          return
        }
        const now = new Date()
        const endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
        const planConfig = subscriptionPlans[plan]
        set({
          subscription: {
            plan, trialStartDate: now.toISOString(), trialEndDate: endDate.toISOString(),
            isTrialActive: true, daysRemainingInTrial: 7,
            subscriptionStartDate: null, subscriptionEndDate: null, isSubscriptionActive: false,
            hasUsedTrial: true, trialPlanUsed: plan,
          },
          progress: { ...get().progress, maxFavorites: planConfig.maxFavorites, totalAchievements: planConfig.maxAchievements }
        })
      },
      
      subscribe: (plan) => {
        const now = new Date()
        const endDate = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)
        const planConfig = subscriptionPlans[plan]
        set({
          subscription: {
            plan, trialStartDate: null, trialEndDate: null, isTrialActive: false, daysRemainingInTrial: 0,
            subscriptionStartDate: now.toISOString(), subscriptionEndDate: endDate.toISOString(), isSubscriptionActive: true,
            hasUsedTrial: get().subscription.hasUsedTrial, trialPlanUsed: get().subscription.trialPlanUsed,
          },
          progress: { ...get().progress, maxFavorites: planConfig.maxFavorites, totalAchievements: planConfig.maxAchievements }
        })
      },
      
      cancelSubscription: () => set({
        subscription: { 
          plan: 'basic', trialStartDate: null, trialEndDate: null, isTrialActive: false, daysRemainingInTrial: 0, 
          subscriptionStartDate: null, subscriptionEndDate: null, isSubscriptionActive: false,
          hasUsedTrial: get().subscription.hasUsedTrial, trialPlanUsed: get().subscription.trialPlanUsed,
        },
        progress: { ...get().progress, maxFavorites: subscriptionPlans.basic.maxFavorites, totalAchievements: subscriptionPlans.basic.maxAchievements }
      }),
      
      checkTrialStatus: () => {
        const state = get()
        if (state.subscription.isTrialActive && state.subscription.trialEndDate) {
          const now = new Date()
          const trialEnd = new Date(state.subscription.trialEndDate)
          const daysRemaining = Math.ceil((trialEnd.getTime() - now.getTime()) / (24 * 60 * 60 * 1000))
          if (daysRemaining <= 0) {
            set({ subscription: { ...state.subscription, plan: 'basic', isTrialActive: false, daysRemainingInTrial: 0 } })
          } else {
            set({ subscription: { ...state.subscription, daysRemainingInTrial: daysRemaining } })
          }
        }
      },
      
      updatePlan: (plan) => {
        const planConfig = subscriptionPlans[plan]
        set({ subscription: { ...get().subscription, plan }, progress: { ...get().progress, maxFavorites: planConfig.maxFavorites, totalAchievements: planConfig.maxAchievements } })
      },
      
      addPoints: (points) => set(state => ({ progress: { ...state.progress, userPoints: state.progress.userPoints + points } })),
      unlockAchievement: () => set(state => ({ progress: { ...state.progress, achievementsUnlocked: state.progress.achievementsUnlocked + 1 } })),
      incrementRecipesCreated: () => set(state => ({ progress: { ...state.progress, recipesCreated: state.progress.recipesCreated + 1 } })),
      incrementRecipesCompleted: () => set(state => ({ progress: { ...state.progress, recipesCompleted: state.progress.recipesCompleted + 1 } })),
      updateDaysActive: () => set(state => ({ progress: { ...state.progress, daysActive: state.progress.daysActive + 1 } })),
      toggleHideUnearnedAchievements: () => set(state => ({ progress: { ...state.progress, hideUnearnedAchievements: !state.progress.hideUnearnedAchievements } })),
      incrementFavoriteCount: () => set(state => ({ progress: { ...state.progress, favoriteCount: state.progress.favoriteCount + 1 } })),
      decrementFavoriteCount: () => set(state => ({ progress: { ...state.progress, favoriteCount: Math.max(0, state.progress.favoriteCount - 1) } })),
      updateProfileSettings: (settings) => set(state => ({ profileSettings: { ...state.profileSettings, ...settings } })),
      registerEmail: (email) => set(state => ({ 
        registeredEmails: state.registeredEmails.includes(email) ? state.registeredEmails : [...state.registeredEmails, email] 
      })),
    }),
    { name: 'cocinaviva-user-v3' }
  )
)

// Timer Store
interface TimerState {
  timers: Timer[]
  addTimer: (timer: Omit<Timer, 'id' | 'createdAt'>) => string
  removeTimer: (id: string) => void
  updateTimer: (id: string, updates: Partial<Timer>) => void
  startTimer: (id: string) => void
  pauseTimer: (id: string) => void
  resetTimer: (id: string) => void
  tickTimer: (id: string) => void
  clearAllTimers: () => void
}

export const useTimerStore = create<TimerState>()(
  persist(
    (set, get) => ({
      timers: [],
      addTimer: (timerData) => {
        const id = `timer-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        set((state) => ({ timers: [...state.timers, { ...timerData, id, createdAt: new Date() }] }))
        return id
      },
      removeTimer: (id) => set((state) => ({ timers: state.timers.filter((t) => t.id !== id) })),
      updateTimer: (id, updates) => set((state) => ({ timers: state.timers.map((t) => (t.id === id ? { ...t, ...updates } : t)) })),
      startTimer: (id) => set((state) => ({ timers: state.timers.map((t) => t.id === id ? { ...t, isRunning: true, isPaused: false } : t) })),
      pauseTimer: (id) => set((state) => ({ timers: state.timers.map((t) => t.id === id ? { ...t, isRunning: false, isPaused: true } : t) })),
      resetTimer: (id) => {
        const timer = get().timers.find((t) => t.id === id)
        if (timer) set((state) => ({ timers: state.timers.map((t) => t.id === id ? { ...t, remaining: t.duration, isRunning: false, isPaused: false } : t) }))
      },
      tickTimer: (id) => set((state) => ({
        timers: state.timers.map((t) => {
          if (t.id === id && t.isRunning) {
            const newRemaining = Math.max(0, t.remaining - 1)
            return { ...t, remaining: newRemaining, isRunning: newRemaining > 0 }
          }
          return t
        }),
      })),
      clearAllTimers: () => set({ timers: [] }),
    }),
    { name: 'cocinaviva-timers' }
  )
)

// Shopping List Store
interface ShoppingListState {
  items: ShoppingItem[]
  addItem: (item: Omit<ShoppingItem, 'id' | 'addedAt'>) => void
  removeItem: (id: string) => void
  updateItem: (id: string, updates: Partial<ShoppingItem>) => void
  toggleItem: (id: string) => void
  clearChecked: () => void
  clearAll: () => void
}

export const useShoppingListStore = create<ShoppingListState>()(
  persist(
    (set) => ({
      items: [],
      addItem: (itemData) => {
        const item: ShoppingItem = { ...itemData, id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`, addedAt: new Date() }
        set((state) => ({ items: [...state.items, item] }))
      },
      removeItem: (id) => set((state) => ({ items: state.items.filter((i) => i.id !== id) })),
      updateItem: (id, updates) => set((state) => ({ items: state.items.map((i) => (i.id === id ? { ...i, ...updates } : i)) })),
      toggleItem: (id) => set((state) => ({ items: state.items.map((i) => (i.id === id ? { ...i, isChecked: !i.isChecked } : i)) })),
      clearChecked: () => set((state) => ({ items: state.items.filter((i) => !i.isChecked) })),
      clearAll: () => set({ items: [] }),
    }),
    { name: 'cocinaviva-shopping' }
  )
)

// Offline Store
interface OfflineState {
  savedRecipes: string[]
  saveRecipe: (recipeId: string) => void
  removeRecipe: (recipeId: string) => void
  isRecipeSaved: (recipeId: string) => boolean
}

export const useOfflineStore = create<OfflineState>()(
  persist(
    (set, get) => ({
      savedRecipes: [],
      saveRecipe: (recipeId) => {
        const { savedRecipes } = get()
        if (!savedRecipes.includes(recipeId)) set({ savedRecipes: [...savedRecipes, recipeId] })
      },
      removeRecipe: (recipeId) => set((state) => ({ savedRecipes: state.savedRecipes.filter((id) => id !== recipeId) })),
      isRecipeSaved: (recipeId) => get().savedRecipes.includes(recipeId),
    }),
    { name: 'cocinaviva-offline' }
  )
)

// Step Tracking Store
interface StepTrackingState {
  currentRecipeId: string | null
  currentStep: number
  totalSteps: number
  completedSteps: Set<number>
  handsFreeMode: boolean
  setRecipe: (recipeId: string, totalSteps: number) => void
  nextStep: () => void
  prevStep: () => void
  goToStep: (step: number) => void
  toggleStepComplete: (step: number) => void
  setHandsFreeMode: (enabled: boolean) => void
  reset: () => void
}

export const useStepTrackingStore = create<StepTrackingState>()(
  persist(
    (set, get) => ({
      currentRecipeId: null,
      currentStep: 0,
      totalSteps: 0,
      completedSteps: new Set(),
      handsFreeMode: false,
      setRecipe: (recipeId, totalSteps) => set({ currentRecipeId: recipeId, currentStep: 0, totalSteps, completedSteps: new Set() }),
      nextStep: () => { const { currentStep, totalSteps } = get(); if (currentStep < totalSteps - 1) set({ currentStep: currentStep + 1 }) },
      prevStep: () => { const { currentStep } = get(); if (currentStep > 0) set({ currentStep: currentStep - 1 }) },
      goToStep: (step) => { const { totalSteps } = get(); if (step >= 0 && step < totalSteps) set({ currentStep: step }) },
      toggleStepComplete: (step) => {
        const { completedSteps } = get()
        const newCompleted = new Set(completedSteps)
        if (newCompleted.has(step)) newCompleted.delete(step)
        else newCompleted.add(step)
        set({ completedSteps: newCompleted })
      },
      setHandsFreeMode: (enabled) => set({ handsFreeMode: enabled }),
      reset: () => set({ currentRecipeId: null, currentStep: 0, totalSteps: 0, completedSteps: new Set(), handsFreeMode: false }),
    }),
    {
      name: 'cocinaviva-step-tracking',
      storage: {
        getItem: (name) => {
          const str = localStorage.getItem(name)
          if (!str) return null
          const data = JSON.parse(str)
          return { ...data, state: { ...data.state, completedSteps: new Set(data.state.completedSteps || []) } }
        },
        setItem: (name, value) => localStorage.setItem(name, JSON.stringify({ ...value, state: { ...value.state, completedSteps: Array.from(value.state.completedSteps || []) } })),
        removeItem: (name) => localStorage.removeItem(name),
      },
    }
  )
)
