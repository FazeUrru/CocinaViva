'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  ChefHat,
  Search,
  Heart,
  History,
  ShoppingCart,
  Users,
  PlusCircle,
  Menu,
  X,
  Timer,
  Image as ImageIcon,
  Home,
  Sparkles,
  Settings,
  Crown,
  Trophy,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useShoppingListStore, useUserStore } from '@/store'
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet'

const navItems = [
  { href: '/', label: 'Inicio', icon: Home },
  { href: '/recetas', label: 'Recetario', icon: ChefHat },
  { href: '/destacados', label: 'Destacados', icon: Sparkles },
  { href: '/favoritos', label: 'Favoritos', icon: Heart },
  { href: '/historial', label: 'Historial', icon: History },
  { href: '/compras', label: 'Compras', icon: ShoppingCart },
  { href: '/comunidad', label: 'Comunidad', icon: Users },
  { href: '/crear', label: 'Crear Receta', icon: PlusCircle },
  { href: '/galeria', label: 'Galería', icon: ImageIcon },
]

export function Navigation() {
  const pathname = usePathname()
  const [searchQuery, setSearchQuery] = useState('')
  const [isOpen, setIsOpen] = useState(false)
  const { items } = useShoppingListStore()
  const { subscription } = useUserStore()
  const uncheckedCount = items.filter(item => !item.isChecked).length

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      window.location.href = `/recetas?search=${encodeURIComponent(searchQuery)}`
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <img
            src="/images/logo.png"
            alt="CocinaViva"
            className="h-8 w-8 rounded-lg object-cover"
          />
          <span className="hidden sm:inline bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
            CocinaViva
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.slice(0, 5).map((item) => {
            const Icon = item.icon
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
                    : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                }`}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Search Bar - Desktop */}
        <form onSubmit={handleSearch} className="hidden md:flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar recetas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64 pl-10"
            />
          </div>
        </form>

        {/* Right Side Actions */}
        <div className="flex items-center gap-2">
          {/* Plans Button */}
          <Link href="/planes" className="hidden sm:block">
            <Button 
              variant="outline" 
              size="sm" 
              className={`gap-1.5 ${
                subscription.plan === 'masterchef' 
                  ? 'border-purple-500 text-purple-600 hover:bg-purple-50' 
                  : subscription.plan === 'ultra'
                  ? 'border-orange-500 text-orange-600 hover:bg-orange-50'
                  : 'border-green-500 text-green-600 hover:bg-green-50'
              }`}
            >
              <Crown className="h-4 w-4" />
              {subscription.plan === 'basic' ? 'Planes' : subscription.plan === 'ultra' ? 'Ultra' : 'MasterChef'}
            </Button>
          </Link>

          {/* Logros Button */}
          <Link href="/logros">
            <Button variant="ghost" size="icon" className="relative">
              <Trophy className="h-5 w-5 text-yellow-500" />
              <Badge className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 text-[10px] bg-yellow-500 text-white">
                350
              </Badge>
            </Button>
          </Link>

          {/* Timer Quick Access */}
          <Link href="/temporizadores">
            <Button variant="ghost" size="icon" className="relative">
              <Timer className="h-5 w-5" />
            </Button>
          </Link>

          {/* Settings */}
          <Link href="/ajustes">
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
          </Link>

          {/* Shopping Cart with Badge */}
          <Link href="/compras" className="hidden sm:block">
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {uncheckedCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-orange-500">
                  {uncheckedCount}
                </Badge>
              )}
            </Button>
          </Link>

          {/* Mobile Menu */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <SheetHeader>
                <SheetTitle className="flex items-center gap-2">
                  <img
                    src="/images/logo.png"
                    alt="CocinaViva"
                    className="h-8 w-8 rounded-lg object-cover"
                  />
                  <span className="bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                    CocinaViva
                  </span>
                </SheetTitle>
              </SheetHeader>

              {/* Mobile Search */}
              <form onSubmit={handleSearch} className="mt-6 mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Buscar recetas..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10"
                  />
                </div>
              </form>

              {/* Mobile Navigation */}
              <nav className="flex flex-col gap-1">
                <Link
                  href="/planes"
                  onClick={() => setIsOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors bg-gradient-to-r from-orange-100 to-green-100 text-orange-700 dark:from-orange-900/30 dark:to-green-900/30 dark:text-orange-400"
                >
                  <Crown className="h-5 w-5" />
                  Ver Planes
                  <Badge className="ml-auto bg-orange-500">Pro</Badge>
                </Link>
                {navItems.map((item) => {
                  const Icon = item.icon
                  const isActive = pathname === item.href
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setIsOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                        isActive
                          ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
                          : 'hover:bg-muted text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      {item.label}
                    </Link>
                  )
                })}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
