'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Mail, Lock, Eye, EyeOff, Chrome, Facebook, Twitter, Apple } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { useUserStore } from '@/store'
import { toast } from 'sonner'

interface LoginModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess?: () => void
  title?: string
}

export function LoginModal({ isOpen, onClose, onSuccess, title = 'Iniciar Sesión' }: LoginModalProps) {
  const [mode, setMode] = useState<'options' | 'email'>('options')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useUserStore()

  const handleSocialLogin = async (provider: string) => {
    setIsLoading(true)
    // Simulate social login
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Simulate successful login
    login(
      `user-${provider}-${Date.now()}`,
      `Usuario ${provider}`,
      `user@${provider}.com`
    )
    
    toast.success(`Sesión iniciada con ${provider}`)
    setIsLoading(false)
    onClose()
    onSuccess?.()
  }

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!email || !password) {
      toast.error('Por favor completa todos los campos')
      return
    }
    
    setIsLoading(true)
    // Simulate email login
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    login(
      `user-email-${Date.now()}`,
      email.split('@')[0],
      email
    )
    
    toast.success('Sesión iniciada correctamente')
    setIsLoading(false)
    onClose()
    onSuccess?.()
  }

  if (!isOpen) return null

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center"
      >
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        />
        
        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md mx-4 bg-background rounded-2xl shadow-2xl overflow-hidden"
        >
          {/* Header */}
          <div className="relative bg-gradient-to-r from-orange-500 to-green-500 p-6 text-white">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
            <h2 className="text-2xl font-bold">{title}</h2>
            <p className="text-white/80 mt-1">
              {mode === 'options' 
                ? 'Elige tu método de inicio de sesión' 
                : 'Introduce tus credenciales'}
            </p>
          </div>

          {/* Content */}
          <div className="p-6">
            {mode === 'options' ? (
              <div className="space-y-3">
                {/* Social Login Options */}
                <Button
                  variant="outline"
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => handleSocialLogin('Google')}
                  disabled={isLoading}
                >
                  <Chrome className="h-5 w-5 text-red-500" />
                  Continuar con Google
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => handleSocialLogin('Facebook')}
                  disabled={isLoading}
                >
                  <Facebook className="h-5 w-5 text-blue-600" />
                  Continuar con Facebook
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => handleSocialLogin('X')}
                  disabled={isLoading}
                >
                  <Twitter className="h-5 w-5" />
                  Continuar con X (Twitter)
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full justify-start gap-3 h-12"
                  onClick={() => handleSocialLogin('Apple')}
                  disabled={isLoading}
                >
                  <Apple className="h-5 w-5" />
                  Continuar con Apple
                </Button>

                <div className="relative my-4">
                  <Separator />
                  <span className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2 bg-background px-2 text-xs text-muted-foreground">
                    o
                  </span>
                </div>

                <Button
                  variant="default"
                  className="w-full h-12 bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                  onClick={() => setMode('email')}
                >
                  <Mail className="h-5 w-5 mr-2" />
                  Iniciar con correo electrónico
                </Button>
              </div>
            ) : (
              <form onSubmit={handleEmailLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Correo electrónico</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="tu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full h-12 bg-gradient-to-r from-orange-500 to-green-500 hover:from-orange-600 hover:to-green-600"
                  disabled={isLoading}
                >
                  {isLoading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
                </Button>

                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => setMode('options')}
                >
                  Volver a opciones
                </Button>
              </form>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  )
}

export default LoginModal
