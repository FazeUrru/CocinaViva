// Types for CocinaViva Application

export interface Recipe {
  id: string
  title: string
  slug: string
  description: string | null
  imageUrl: string | null
  prepTime: number
  cookTime: number | null
  totalTime: number
  servings: number
  difficulty: 'facil' | 'medio' | 'dificil'
  cuisineType: string | null
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack' | null
  toolType: 'tradicional' | 'thermomix' | 'crockpot'
  isGlutenFree: boolean
  isPublic: boolean
  authorId: string | null
  averageRating: number
  ratingCount: number
  viewCount: number
  isFeatured: boolean
  featuredAt: Date | null
  createdAt: Date
  updatedAt: Date
  category?: Category
  categoryId?: string | null
  tags: Tag[]
  ingredients: RecipeIngredient[]
  steps: RecipeStep[]
  comments: Comment[]
  ratings: Rating[]
  isFavorite?: boolean
  userRating?: number
}

export interface Category {
  id: string
  name: string
  slug: string
  icon: string | null
  description: string | null
  createdAt: Date
}

export interface Tag {
  id: string
  name: string
  slug: string
  color: string | null
  createdAt: Date
}

export interface Ingredient {
  id: string
  name: string
  slug: string
  category: string
  imageUrl: string | null
  unit: string | null
  calories: number | null
  protein: number | null
  carbs: number | null
  fat: number | null
  fiber: number | null
  isGlutenFree: boolean
  commonAllergens: string | null
  createdAt: Date
}

export interface RecipeIngredient {
  id: string
  recipeId: string
  ingredientId: string
  quantity: number
  unit: string
  notes: string | null
  order: number
  ingredient?: Ingredient
}

export interface RecipeStep {
  id: string
  recipeId: string
  stepNumber: number
  instruction: string
  imageUrl: string | null
  duration: number | null
  tip: string | null
}

export interface Comment {
  id: string
  recipeId: string
  userId: string
  content: string
  rating: number | null
  parentId: string | null
  createdAt: Date
  updatedAt: Date
  user?: User
  replies?: Comment[]
}

export interface Rating {
  id: string
  recipeId: string
  userId: string
  rating: number
  createdAt: Date
  updatedAt: Date
}

export interface User {
  id: string
  email: string
  name: string | null
  avatar: string | null
  createdAt: Date
  updatedAt: Date
}

export interface Favorite {
  id: string
  recipeId: string
  userId: string
  createdAt: Date
  recipe?: Recipe
}

export interface Collection {
  id: string
  userId: string
  name: string
  description: string | null
  icon: string | null
  isPublic: boolean
  createdAt: Date
  items: CollectionItem[]
}

export interface CollectionItem {
  id: string
  collectionId: string
  recipeId: string
  addedAt: Date
  recipe?: Recipe
}

export interface History {
  id: string
  userId: string
  recipeId: string
  cookedAt: Date
  portions: number | null
  notes: string | null
  recipe?: Recipe
}

export interface ShoppingList {
  id: string
  userId: string
  name: string | null
  createdAt: Date
  updatedAt: Date
  items: ShoppingItem[]
}

export interface ShoppingItem {
  id: string
  shoppingListId: string
  ingredientId: string | null
  customName: string | null
  quantity: number
  unit: string
  isChecked: boolean
  notes: string | null
  addedAt: Date
  ingredient?: Ingredient
}

export interface Challenge {
  id: string
  title: string
  description: string
  imageUrl: string | null
  startDate: Date
  endDate: Date
  challengeType: 'semanal' | 'mensual'
  isActive: boolean
  createdAt: Date
  participants: ChallengeParticipant[]
  posts: ChallengePost[]
}

export interface ChallengeParticipant {
  id: string
  challengeId: string
  userId: string
  joinedAt: Date
  completedAt: Date | null
  user?: User
}

export interface ChallengePost {
  id: string
  challengeId: string
  userId: string
  recipeId: string | null
  imageUrl: string
  title: string
  description: string | null
  likesCount: number
  createdAt: Date
  user?: User
  recipe?: Recipe
  comments: ChallengePostComment[]
}

export interface ChallengePostComment {
  id: string
  postId: string
  userId: string
  content: string
  createdAt: Date
  user?: User
}

export interface IngredientSubstitution {
  id: string
  ingredientId: string
  substituteId: string
  ratio: number
  notes: string | null
  createdAt: Date
  ingredient?: Ingredient
  substitute?: Ingredient
}

export interface Timer {
  id: string
  name: string
  duration: number // in seconds
  remaining: number
  isRunning: boolean
  isPaused: boolean
  createdAt: Date
}

export interface TimerPreset {
  id: string
  name: string
  duration: number
  icon: string | null
  color: string | null
  isDefault: boolean
  createdAt: Date
}

// API Response types
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}

// Filter types
export interface RecipeFilters {
  search?: string
  ingredients?: string[]
  toolType?: 'tradicional' | 'thermomix' | 'crockpot' | 'all'
  isGlutenFree?: boolean
  difficulty?: string
  mealType?: string
  cuisineType?: string
  maxTime?: number
  categoryId?: string
}

// Recipe form types
export interface RecipeFormData {
  title: string
  description: string
  imageUrl: string
  prepTime: number
  cookTime: number | null
  servings: number
  difficulty: string
  cuisineType: string
  mealType: string
  toolType: string
  isGlutenFree: boolean
  isPublic: boolean
  categoryId: string | null
  ingredients: {
    ingredientId: string
    quantity: number
    unit: string
    notes: string
  }[]
  steps: {
    instruction: string
    duration: number | null
    tip: string
  }[]
  tags: string[]
}
