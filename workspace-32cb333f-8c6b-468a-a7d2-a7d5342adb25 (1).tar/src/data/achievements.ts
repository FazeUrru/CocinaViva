// Achievement System - 350 Total Achievements
// Organized by: Recetas, Cocina, Social, Exploracion, Maestria, Thermomix, Coleccion, Tiempo, Especial, Retos

export type AchievementCategory = 'recetas' | 'cocina' | 'social' | 'exploracion' | 'maestria' | 'thermomix' | 'coleccion' | 'tiempo' | 'especial' | 'retos'

export interface Achievement {
  id: string
  title: string
  description: string
  icon: string
  category: AchievementCategory
  points: number
  unlocked: boolean
  unlockedAt?: string
  progress: number
  maxProgress: number
  isPremium?: boolean
  requiredPlan?: 'ultra' | 'masterchef'
  hidden?: boolean
}

const generateId = (prefix: string, index: number) => `${prefix}-${String(index).padStart(3, '0')}`

// ============================================
// RECETAS ACHIEVEMENTS (35) - Recipe creation/completion
// ============================================
const recetasAchievements: Achievement[] = [
  { id: generateId('rec', 1), title: 'Primer Plato', description: 'Crea tu primera receta', icon: '🍳', category: 'recetas', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('rec', 2), title: 'Cocinero Novato', description: 'Crea 5 recetas', icon: '👨‍🍳', category: 'recetas', points: 25, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('rec', 3), title: 'Cocinero Amateur', description: 'Crea 10 recetas', icon: '🥘', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 4), title: 'Chef en Entrenamiento', description: 'Crea 25 recetas', icon: '🔪', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('rec', 5), title: 'Chef Profesional', description: 'Crea 50 recetas', icon: '⭐', category: 'recetas', points: 200, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('rec', 6), title: 'Maestro Culinario', description: 'Crea 100 recetas', icon: '🏆', category: 'recetas', points: 500, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('rec', 7), title: 'Primera Vez', description: 'Completa tu primera receta', icon: '✨', category: 'recetas', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('rec', 8), title: 'En Racha', description: 'Completa 10 recetas', icon: '🔥', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 9), title: 'Cocinero Activo', description: 'Completa 50 recetas', icon: '💪', category: 'recetas', points: 150, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('rec', 10), title: 'Experto en Cocina', description: 'Completa 100 recetas', icon: '🎯', category: 'recetas', points: 300, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('rec', 11), title: 'Leyenda Culinaria', description: 'Completa 500 recetas', icon: '👑', category: 'recetas', points: 1000, unlocked: false, progress: 0, maxProgress: 500 },
  { id: generateId('rec', 12), title: 'Fácil y Rápido', description: 'Completa 10 recetas fáciles', icon: '🟢', category: 'recetas', points: 30, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 13), title: 'Nivel Medio', description: 'Completa 10 recetas de dificultad media', icon: '🟡', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 14), title: 'Desafío Aceptado', description: 'Completa 10 recetas difíciles', icon: '🔴', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 15), title: 'Maestro de Desafíos', description: 'Completa 50 recetas difíciles', icon: '💀', category: 'recetas', points: 300, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('rec', 16), title: 'Mañana Energético', description: 'Completa 20 desayunos', icon: '🥐', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 17), title: 'Chef de Mediodía', description: 'Completa 20 almuerzos', icon: '🍽️', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 18), title: 'Chef Nocturno', description: 'Completa 20 cenas', icon: '🌙', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 19), title: 'Dulce Tentación', description: 'Completa 20 postres', icon: '🍰', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 20), title: 'Snacker Pro', description: 'Completa 20 snacks', icon: '🍿', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 21), title: 'Internacional', description: 'Cocina recetas de 5 cocinas diferentes', icon: '🌍', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('rec', 22), title: 'Mediterráneo', description: 'Completa 15 recetas mediterráneas', icon: '🫒', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 23), title: 'Asiático', description: 'Completa 15 recetas asiáticas', icon: '🥢', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 24), title: 'Mexicano', description: 'Completa 15 recetas mexicanas', icon: '🌮', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 25), title: 'Italiano', description: 'Completa 15 recetas italianas', icon: '🍝', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 26), title: 'Francés', description: 'Completa 15 recetas francesas', icon: '🥖', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 27), title: 'Vegetariano', description: 'Completa 20 recetas vegetarianas', icon: '🥗', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 28), title: 'Vegano', description: 'Completa 20 recetas veganas', icon: '🌱', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 29), title: 'Baja Caloría', description: 'Completa 15 recetas bajas en calorías', icon: '🥬', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 30), title: 'Alta Proteína', description: 'Completa 15 recetas altas en proteína', icon: '💪', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 31), title: 'Rápido y Fácil', description: 'Completa 25 recetas en menos de 30 min', icon: '⚡', category: 'recetas', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('rec', 32), title: 'Elaborado', description: 'Completa 10 recetas de más de 2 horas', icon: '⏰', category: 'recetas', points: 150, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('rec', 33), title: 'Para Toda la Familia', description: 'Completa 20 recetas familiares', icon: '👨‍👩‍👧‍👦', category: 'recetas', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('rec', 34), title: 'Chef Solitario', description: 'Completa 15 recetas individuales', icon: '👤', category: 'recetas', points: 50, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('rec', 35), title: 'Recetario Completo', description: 'Completa recetas de todas las categorías', icon: '📚', category: 'recetas', points: 200, unlocked: false, progress: 0, maxProgress: 6 },
]

// ============================================
// COCINA ACHIEVEMENTS (35) - Kitchen tools and techniques
// ============================================
const cocinaAchievements: Achievement[] = [
  { id: generateId('coc', 1), title: 'Sartén Maestra', description: 'Usa la sartén 50 veces', icon: '🍳', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('coc', 2), title: 'Horno Experto', description: 'Usa el horno 50 veces', icon: '🔥', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('coc', 3), title: 'Vapor Maestro', description: 'Cocina al vapor 25 veces', icon: '♨️', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('coc', 4), title: 'Freidor Pro', description: 'Fríe 20 platos', icon: '🥘', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 5), title: 'A la Parrilla', description: 'Cocina a la parrilla 30 veces', icon: '🍖', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 6), title: 'Hervidor', description: 'Hierve ingredientes 50 veces', icon: '🫕', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('coc', 7), title: 'Microondas Pro', description: 'Usa el microondas 30 veces', icon: '📡', category: 'cocina', points: 30, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 8), title: 'Wok Master', description: 'Cocina con wok 20 veces', icon: '🥡', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 9), title: 'Olla a Presión', description: 'Usa la olla a presión 15 veces', icon: '🔒', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 10), title: 'Air Fryer', description: 'Usa la freidora de aire 25 veces', icon: '🍟', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('coc', 11), title: 'Blender Pro', description: 'Usa la batidora 30 veces', icon: '🥤', category: 'cocina', points: 40, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 12), title: 'Procesador', description: 'Usa el procesador de alimentos 20 veces', icon: '⚙️', category: 'cocina', points: 40, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 13), title: 'Mortero Tradicional', description: 'Usa el mortero 15 veces', icon: '🥣', category: 'cocina', points: 30, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 14), title: 'Chef Knife', description: 'Perfecciona el uso del cuchillo', icon: '🔪', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('coc', 15), title: 'Técnicas Básicas', description: 'Aprende 10 técnicas de cocina', icon: '📖', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 16), title: 'Técnicas Avanzadas', description: 'Aprende 5 técnicas avanzadas', icon: '🎓', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('coc', 17), title: 'Sous Vide', description: 'Cocina sous vide 10 veces', icon: '🌡️', category: 'cocina', points: 150, unlocked: false, progress: 0, maxProgress: 10, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('coc', 18), title: 'Ahumador', description: 'Ahúma alimentos 10 veces', icon: '💨', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 19), title: 'Fermentación', description: 'Fermenta 5 alimentos', icon: '🧫', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('coc', 20), title: 'Panadero', description: 'Hornea 20 panes', icon: '🍞', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 21), title: 'Pastelero', description: 'Prepara 15 pasteles', icon: '🎂', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 22), title: 'Heladero', description: 'Prepara 10 helados', icon: '🍦', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 23), title: 'Pizzero', description: 'Prepara 15 pizzas caseras', icon: '🍕', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 24), title: 'Pastas Frescas', description: 'Prepara 10 pastas frescas', icon: '🍝', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 25), title: 'Salsas Maestro', description: 'Prepara 20 salsas diferentes', icon: '🫙', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 26), title: 'Adobos', description: 'Crea 15 adobos diferentes', icon: '🧂', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 27), title: 'Marinadas', description: 'Prepara 15 marinadas', icon: '🥩', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 28), title: 'Caldos y Sopas', description: 'Prepara 25 caldos o sopas', icon: '🍲', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('coc', 29), title: 'Arrocero', description: 'Prepara 20 arroces diferentes', icon: '🍚', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('coc', 30), title: 'Cocina al Vapor', description: 'Cocina 30 platos al vapor', icon: '♨️', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 31), title: 'Fritura Perfecta', description: 'Logra 10 frituras perfectas', icon: '🍤', category: 'cocina', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('coc', 32), title: 'Horneado Perfecto', description: 'Logra 15 horneados perfectos', icon: '🥧', category: 'cocina', points: 100, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('coc', 33), title: 'Limpieza Pro', description: 'Mantén la cocina limpia 30 días', icon: '✨', category: 'cocina', points: 50, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('coc', 34), title: 'Organización', description: 'Organiza tu cocina perfectamente', icon: '📦', category: 'cocina', points: 30, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('coc', 35), title: 'Chef Completo', description: 'Usa todos los métodos de cocción', icon: '👨‍🍳', category: 'cocina', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
]

// ============================================
// SOCIAL ACHIEVEMENTS (35) - Community interaction
// ============================================
const socialAchievements: Achievement[] = [
  { id: generateId('soc', 1), title: 'Bienvenido', description: 'Crea tu cuenta', icon: '👋', category: 'social', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 2), title: 'Perfil Completo', description: 'Completa tu perfil al 100%', icon: '✅', category: 'social', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 3), title: 'Foto de Perfil', description: 'Añade una foto de perfil', icon: '📸', category: 'social', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 4), title: 'Primer Favorito', description: 'Guarda tu primera receta favorita', icon: '❤️', category: 'social', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 5), title: 'Coleccionista', description: 'Guarda 10 recetas favoritas', icon: '💖', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 6), title: 'Experto en Favoritos', description: 'Guarda 25 recetas favoritas', icon: '💕', category: 'social', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('soc', 7), title: 'Favoritos Master', description: 'Guarda 50 recetas favoritas', icon: '💗', category: 'social', points: 200, unlocked: false, progress: 0, maxProgress: 50, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('soc', 8), title: 'Primer Comentario', description: 'Deja tu primer comentario', icon: '💬', category: 'social', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 9), title: 'Opinador', description: 'Deja 10 comentarios', icon: '🗣️', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 10), title: 'Crítico', description: 'Deja 50 comentarios', icon: '📝', category: 'social', points: 150, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('soc', 11), title: 'Conversador', description: 'Deja 100 comentarios', icon: '💭', category: 'social', points: 300, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('soc', 12), title: 'Primera Reseña', description: 'Escribe tu primera reseña', icon: '⭐', category: 'social', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 13), title: 'Reseñador', description: 'Escribe 10 reseñas', icon: '🌟', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 14), title: 'Crítico Experto', description: 'Escribe 25 reseñas', icon: '✨', category: 'social', points: 150, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('soc', 15), title: 'Verificado', description: 'Escribe una reseña verificada', icon: '✓', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('soc', 16), title: 'Verificado Pro', description: 'Escribe 25 reseñas verificadas', icon: '🎖️', category: 'social', points: 200, unlocked: false, progress: 0, maxProgress: 25, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('soc', 17), title: 'Compartidor', description: 'Comparte una receta', icon: '📤', category: 'social', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 18), title: 'Influencer', description: 'Comparte 20 recetas', icon: '📱', category: 'social', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('soc', 19), title: 'Viral', description: 'Comparte 50 recetas', icon: '🚀', category: 'social', points: 200, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('soc', 20), title: 'Seguidor', description: 'Sigue a 5 usuarios', icon: '👥', category: 'social', points: 25, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('soc', 21), title: 'Conectado', description: 'Sigue a 25 usuarios', icon: '🤝', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('soc', 22), title: 'Popular', description: 'Consigue 10 seguidores', icon: '🌟', category: 'social', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 23), title: 'Estrella', description: 'Consigue 50 seguidores', icon: '⭐', category: 'social', points: 150, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('soc', 24), title: 'Celebridad', description: 'Consigue 100 seguidores', icon: '👑', category: 'social', points: 300, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('soc', 25), title: 'Ídolo', description: 'Consigue 500 seguidores', icon: '🏆', category: 'social', points: 500, unlocked: false, progress: 0, maxProgress: 500 },
  { id: generateId('soc', 26), title: 'Primera Receta Compartida', description: 'Comparte tu primera receta propia', icon: '🥘', category: 'social', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 27), title: 'Chef Compartido', description: 'Comparte 10 recetas propias', icon: '👨‍🍳', category: 'social', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 28), title: 'Receta Destacada', description: 'Una de tus recetas es destacada', icon: '🏅', category: 'social', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 29), title: 'Receta del Día', description: 'Tu receta es elegida como del día', icon: '📅', category: 'social', points: 300, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 30), title: 'Receta de la Semana', description: 'Tu receta es elegida como de la semana', icon: '🗓️', category: 'social', points: 500, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('soc', 31), title: 'Cooksnap', description: 'Comparte 10 fotos de tus platos', icon: '📸', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('soc', 32), title: 'Fotógrafo Culinario', description: 'Comparte 50 fotos de tus platos', icon: '📷', category: 'social', points: 200, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('soc', 33), title: 'Me Gusta', description: 'Recibe 50 me gusta en tus recetas', icon: '👍', category: 'social', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('soc', 34), title: 'Amado', description: 'Recibe 200 me gusta en tus recetas', icon: '❤️', category: 'social', points: 200, unlocked: false, progress: 0, maxProgress: 200 },
  { id: generateId('soc', 35), title: 'Leyenda Social', description: 'Alcanza 1000 interacciones totales', icon: '💎', category: 'social', points: 500, unlocked: false, progress: 0, maxProgress: 1000 },
]

// ============================================
// EXPLORACION ACHIEVEMENTS (35) - Discovering features
// ============================================
const exploracionAchievements: Achievement[] = [
  { id: generateId('exp', 1), title: 'Explorador', description: 'Visita 10 páginas diferentes', icon: '🧭', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('exp', 2), title: 'Navegante', description: 'Visita 50 páginas diferentes', icon: '🗺️', category: 'exploracion', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('exp', 3), title: 'Viajero', description: 'Visita 100 páginas diferentes', icon: '🚀', category: 'exploracion', points: 150, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('exp', 4), title: 'Buscador', description: 'Realiza 10 búsquedas', icon: '🔍', category: 'exploracion', points: 25, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('exp', 5), title: 'Investigador', description: 'Realiza 50 búsquedas', icon: '🔎', category: 'exploracion', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('exp', 6), title: 'Buscador Pro', description: 'Realiza 100 búsquedas', icon: '🎯', category: 'exploracion', points: 150, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('exp', 7), title: 'Búsqueda Avanzada', description: 'Usa filtros de búsqueda', icon: '🎛️', category: 'exploracion', points: 30, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('exp', 8), title: 'Filtro Pro', description: 'Usa filtros Pro 10 veces', icon: '🎨', category: 'exploracion', points: 100, unlocked: false, progress: 0, maxProgress: 10, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('exp', 9), title: 'Filtro IA', description: 'Usa filtros IA 10 veces', icon: '🤖', category: 'exploracion', points: 150, unlocked: false, progress: 0, maxProgress: 10, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('exp', 10), title: 'Galería', description: 'Visita la galería de fotos', icon: '🖼️', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 11), title: 'Historial', description: 'Revisa tu historial', icon: '📜', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 12), title: 'Destacados', description: 'Visita recetas destacadas', icon: '⭐', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 13), title: 'Comunidad', description: 'Visita la página de comunidad', icon: '👥', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 14), title: 'Ajustes', description: 'Personaliza tus ajustes', icon: '⚙️', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 15), title: 'Perfil', description: 'Visita tu perfil', icon: '👤', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 16), title: 'Planificador', description: 'Visita el planificador semanal', icon: '📋', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('exp', 17), title: 'Calculadora', description: 'Usa la calculadora nutricional', icon: '📊', category: 'exploracion', points: 25, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('exp', 18), title: 'Temporizador', description: 'Usa el temporizador por primera vez', icon: '⏱️', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 19), title: 'Lista de Compras', description: 'Crea tu primera lista de compras', icon: '🛒', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 20), title: 'Favoritos Explorador', description: 'Visita tu sección de favoritos', icon: '❤️', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 21), title: 'Recetas Propias', description: 'Visita tus recetas creadas', icon: '📝', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 22), title: 'Descubre', description: 'Usa la función de descubrir', icon: '💡', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 23), title: 'Categorías', description: 'Explora todas las categorías', icon: '🏷️', category: 'exploracion', points: 50, unlocked: false, progress: 0, maxProgress: 6 },
  { id: generateId('exp', 24), title: 'Herramientas', description: 'Explora todas las herramientas', icon: '🔧', category: 'exploracion', points: 50, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('exp', 25), title: 'Tendencias', description: 'Visita recetas en tendencia', icon: '📈', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 26), title: 'Nuevas Recetas', description: 'Visita recetas nuevas', icon: '🆕', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 27), title: 'Populares', description: 'Visita recetas populares', icon: '🔥', category: 'exploracion', points: 20, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 28), title: 'Cooksnaps', description: 'Visita la galería de cooksnaps', icon: '📸', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 29), title: 'Reseñas', description: 'Lee 20 reseñas de recetas', icon: '📖', category: 'exploracion', points: 30, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('exp', 30), title: 'Perfector', description: 'Completa todos los ajustes de perfil', icon: '✅', category: 'exploracion', points: 100, unlocked: false, progress: 0, maxProgress: 58 },
  { id: generateId('exp', 31), title: 'FAQs', description: 'Lee las preguntas frecuentes', icon: '❓', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 32), title: 'Ayuda', description: 'Visita la sección de ayuda', icon: '🆘', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 33), title: 'Logros', description: 'Visita tu página de logros', icon: '🏆', category: 'exploracion', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 34), title: 'Planes', description: 'Visita la página de planes', icon: '💎', category: 'exploracion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('exp', 35), title: 'Explorador Completo', description: 'Descubre todas las secciones', icon: '🗺️', category: 'exploracion', points: 200, unlocked: false, progress: 0, maxProgress: 20 },
]

// ============================================
// MAESTRIA ACHIEVEMENTS (35) - Mastery and expertise
// ============================================
const maestriaAchievements: Achievement[] = [
  { id: generateId('mae', 1), title: 'Aprendiz', description: 'Alcanza el nivel 5', icon: '📚', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 2), title: 'Novato Avanzado', description: 'Alcanza el nivel 10', icon: '🎯', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 3), title: 'Intermedio', description: 'Alcanza el nivel 25', icon: '⭐', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 4), title: 'Avanzado', description: 'Alcanza el nivel 50', icon: '🌟', category: 'maestria', points: 400, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 5), title: 'Experto', description: 'Alcanza el nivel 75', icon: '💫', category: 'maestria', points: 600, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 6), title: 'Maestro', description: 'Alcanza el nivel 100', icon: '👑', category: 'maestria', points: 1000, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 7), title: 'Leyenda', description: 'Alcanza el nivel 150', icon: '🏆', category: 'maestria', points: 2000, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 8), title: 'Mitología', description: 'Alcanza el nivel 200', icon: '💎', category: 'maestria', points: 5000, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 9), title: '100 Puntos', description: 'Acumula 100 puntos', icon: '💯', category: 'maestria', points: 25, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('mae', 10), title: '500 Puntos', description: 'Acumula 500 puntos', icon: '🎯', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 500 },
  { id: generateId('mae', 11), title: '1000 Puntos', description: 'Acumula 1000 puntos', icon: '⭐', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 1000 },
  { id: generateId('mae', 12), title: '5000 Puntos', description: 'Acumula 5000 puntos', icon: '🌟', category: 'maestria', points: 300, unlocked: false, progress: 0, maxProgress: 5000 },
  { id: generateId('mae', 13), title: '10000 Puntos', description: 'Acumula 10000 puntos', icon: '👑', category: 'maestria', points: 500, unlocked: false, progress: 0, maxProgress: 10000 },
  { id: generateId('mae', 14), title: 'Primer Logro', description: 'Desbloquea tu primer logro', icon: '🏅', category: 'maestria', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 15), title: 'Coleccionista de Logros', description: 'Desbloquea 10 logros', icon: '🎖️', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('mae', 16), title: 'Cazador de Logros', description: 'Desbloquea 25 logros', icon: '🏆', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('mae', 17), title: 'Maestro de Logros', description: 'Desbloquea 50 logros', icon: '💎', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('mae', 18), title: 'Leyenda de Logros', description: 'Desbloquea 100 logros', icon: '🌟', category: 'maestria', points: 500, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('mae', 19), title: 'Perfeccionista', description: 'Desbloquea 175 logros', icon: '✨', category: 'maestria', points: 750, unlocked: false, progress: 0, maxProgress: 175, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('mae', 20), title: 'Completista', description: 'Desbloquea 250 logros', icon: '🎊', category: 'maestria', points: 1000, unlocked: false, progress: 0, maxProgress: 250, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('mae', 21), title: 'Maestro Absoluto', description: 'Desbloquea 350 logros', icon: '👑', category: 'maestria', points: 5000, unlocked: false, progress: 0, maxProgress: 350, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('mae', 22), title: 'Racha de 7 días', description: 'Usa la app 7 días seguidos', icon: '🔥', category: 'maestria', points: 75, unlocked: false, progress: 0, maxProgress: 7 },
  { id: generateId('mae', 23), title: 'Racha de 30 días', description: 'Usa la app 30 días seguidos', icon: '💪', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('mae', 24), title: 'Racha de 100 días', description: 'Usa la app 100 días seguidos', icon: '🏆', category: 'maestria', points: 500, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('mae', 25), title: 'Racha de 365 días', description: 'Usa la app 365 días seguidos', icon: '👑', category: 'maestria', points: 2000, unlocked: false, progress: 0, maxProgress: 365 },
  { id: generateId('mae', 26), title: 'Receta Perfecta', description: 'Completa una receta sin errores', icon: '✅', category: 'maestria', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 27), title: '10 Recetas Perfectas', description: 'Completa 10 recetas sin errores', icon: '🎯', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('mae', 28), title: 'Tiempo Perfecto', description: 'Completa una receta en el tiempo exacto', icon: '⏱️', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('mae', 29), title: 'Nutricionista', description: 'Alcanza 25 recetas balanceadas', icon: '🥗', category: 'maestria', points: 150, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('mae', 30), title: 'Variedad', description: 'Cocina de 10 cocinas diferentes', icon: '🌍', category: 'maestria', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('mae', 31), title: 'Experimentador', description: 'Prueba 20 ingredientes nuevos', icon: '🧪', category: 'maestria', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('mae', 32), title: 'Maestro de Técnicas', description: 'Domina 15 técnicas de cocina', icon: '🎓', category: 'maestria', points: 300, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('mae', 33), title: 'Velocista', description: 'Completa 5 recetas en un día', icon: '⚡', category: 'maestria', points: 75, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('mae', 34), title: 'Productivo', description: 'Completa 10 recetas en una semana', icon: '📊', category: 'maestria', points: 150, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('mae', 35), title: 'Maestro Supremo', description: 'Completa todos los logros de maestría', icon: '👑', category: 'maestria', points: 1000, unlocked: false, progress: 0, maxProgress: 34 },
]

// ============================================
// THERMOMIX ACHIEVEMENTS (35) - Thermomix-specific
// ============================================
const thermomixAchievements: Achievement[] = [
  { id: generateId('thx', 1), title: 'Bienvenido a Thermomix', description: 'Usa Thermomix por primera vez', icon: '🤖', category: 'thermomix', points: 15, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('thx', 2), title: 'Termo Novato', description: 'Completa 5 recetas Thermomix', icon: '⭐', category: 'thermomix', points: 30, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('thx', 3), title: 'Termo Amateur', description: 'Completa 15 recetas Thermomix', icon: '🌟', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 4), title: 'Termo Pro', description: 'Completa 30 recetas Thermomix', icon: '💫', category: 'thermomix', points: 150, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('thx', 5), title: 'Termo Master', description: 'Completa 50 recetas Thermomix', icon: '👑', category: 'thermomix', points: 300, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('thx', 6), title: 'Termo Leyenda', description: 'Completa 100 recetas Thermomix', icon: '🏆', category: 'thermomix', points: 500, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('thx', 7), title: 'Velocidad 1', description: 'Usa velocidad 1 en 10 recetas', icon: '1️⃣', category: 'thermomix', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 8), title: 'Velocidad 2', description: 'Usa velocidad 2 en 10 recetas', icon: '2️⃣', category: 'thermomix', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 9), title: 'Velocidad 3', description: 'Usa velocidad 3 en 10 recetas', icon: '3️⃣', category: 'thermomix', points: 20, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 10), title: 'Velocidad 4', description: 'Usa velocidad 4 en 10 recetas', icon: '4️⃣', category: 'thermomix', points: 30, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 11), title: 'Velocidad 5', description: 'Usa velocidad 5 en 10 recetas', icon: '5️⃣', category: 'thermomix', points: 30, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 12), title: 'Velocidad Máxima', description: 'Usa velocidad máxima 5 veces', icon: '🚀', category: 'thermomix', points: 50, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('thx', 13), title: 'Espiga', description: 'Usa la función espiga 10 veces', icon: '🌾', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 14), title: 'Amasador', description: 'Usa el modo amasar 10 veces', icon: '🥖', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 15), title: 'Triturador', description: 'Tritura ingredientes 20 veces', icon: '🔪', category: 'thermomix', points: 30, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('thx', 16), title: 'Cocción Lenta', description: 'Usa cocción lenta 10 veces', icon: '🌡️', category: 'thermomix', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 17), title: 'Varoma', description: 'Usa Varoma 15 veces', icon: '♨️', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 18), title: 'Cestillo', description: 'Usa el cestillo 15 veces', icon: '🧺', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 19), title: 'Mariposa', description: 'Usa la mariposa 10 veces', icon: '🦋', category: 'thermomix', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 20), title: 'Cuchilla', description: 'Usa la cuchilla 50 veces', icon: '⚔️', category: 'thermomix', points: 50, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('thx', 21), title: 'Sopas Thermomix', description: 'Prepara 20 sopas con Thermomix', icon: '🍲', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('thx', 22), title: 'Salsas Thermomix', description: 'Prepara 15 salsas con Thermomix', icon: '🫙', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 23), title: 'Pan Thermomix', description: 'Prepara 15 panes con Thermomix', icon: '🍞', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 24), title: 'Postres Thermomix', description: 'Prepara 25 postres con Thermomix', icon: '🍰', category: 'thermomix', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('thx', 25), title: 'Batidos Thermomix', description: 'Prepara 30 batidos con Thermomix', icon: '🥤', category: 'thermomix', points: 50, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('thx', 26), title: 'Helados Thermomix', description: 'Prepara 10 helados con Thermomix', icon: '🍦', category: 'thermomix', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 27), title: 'Masas Thermomix', description: 'Prepara 15 masas con Thermomix', icon: '🥟', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 28), title: 'Arroces Thermomix', description: 'Prepara 15 arroces con Thermomix', icon: '🍚', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 29), title: 'Verduras Thermomix', description: 'Prepara 25 verduras con Thermomix', icon: '🥦', category: 'thermomix', points: 50, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('thx', 30), title: 'Carne Thermomix', description: 'Prepara 20 carnes con Thermomix', icon: '🥩', category: 'thermomix', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('thx', 31), title: 'Pescado Thermomix', description: 'Prepara 15 pescados con Thermomix', icon: '🐟', category: 'thermomix', points: 60, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('thx', 32), title: 'Limpieza Thermomix', description: 'Usa la función de limpieza 20 veces', icon: '✨', category: 'thermomix', points: 30, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('thx', 33), title: 'Programa Personalizado', description: 'Crea 5 programas personalizados', icon: '⚙️', category: 'thermomix', points: 100, unlocked: false, progress: 0, maxProgress: 5, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('thx', 34), title: 'Receta Propia Thermomix', description: 'Crea 10 recetas propias para Thermomix', icon: '📝', category: 'thermomix', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('thx', 35), title: 'Maestro Thermomix', description: 'Completa todas las funciones Thermomix', icon: '🏆', category: 'thermomix', points: 500, unlocked: false, progress: 0, maxProgress: 34 },
]

// ============================================
// COLECCION ACHIEVEMENTS (35) - Collections and favorites
// ============================================
const coleccionAchievements: Achievement[] = [
  { id: generateId('col', 1), title: 'Primer Favorito', description: 'Añade tu primera receta a favoritos', icon: '❤️', category: 'coleccion', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 2), title: 'Coleccionista', description: 'Añade 10 recetas a favoritos', icon: '💖', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 3), title: 'Archivador', description: 'Añade 25 recetas a favoritos', icon: '📚', category: 'coleccion', points: 100, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 4), title: 'Bibliófilo', description: 'Añade 50 recetas a favoritos', icon: '📖', category: 'coleccion', points: 200, unlocked: false, progress: 0, maxProgress: 50, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('col', 5), title: 'Biblioteca', description: 'Añade 100 recetas a favoritos', icon: '🏛️', category: 'coleccion', points: 400, unlocked: false, progress: 0, maxProgress: 100, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('col', 6), title: 'Primera Colección', description: 'Crea tu primera colección', icon: '📁', category: 'coleccion', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 7), title: 'Organizador', description: 'Crea 5 colecciones', icon: '🗂️', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('col', 8), title: 'Archivero', description: 'Crea 10 colecciones', icon: '🗃️', category: 'coleccion', points: 150, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 9), title: 'Museo', description: 'Crea 20 colecciones', icon: '🏰', category: 'coleccion', points: 300, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 10), title: 'Desayunos Favoritos', description: 'Guarda 20 desayunos', icon: '🥐', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 11), title: 'Almuerzos Favoritos', description: 'Guarda 20 almuerzos', icon: '🍽️', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 12), title: 'Postres Favoritos', description: 'Guarda 20 postres', icon: '🍰', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 13), title: 'Snacks Favoritos', description: 'Guarda 20 snacks', icon: '🍿', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 14), title: 'Thermomix Favoritos', description: 'Guarda 25 recetas Thermomix', icon: '🤖', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 15), title: 'Crockpot Favoritos', description: 'Guarda 25 recetas Crockpot', icon: '🍲', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 16), title: 'Tradicionales Favoritos', description: 'Guarda 25 recetas tradicionales', icon: '👨‍🍳', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 17), title: 'Internacional', description: 'Guarda recetas de 10 cocinas diferentes', icon: '🌍', category: 'coleccion', points: 150, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 18), title: 'Saludable', description: 'Guarda 30 recetas saludables', icon: '🥗', category: 'coleccion', points: 100, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('col', 19), title: 'Vegetariano', description: 'Guarda 20 recetas vegetarianas', icon: '🥬', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 20), title: 'Vegano', description: 'Guarda 20 recetas veganas', icon: '🌱', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 21), title: 'Rápidas', description: 'Guarda 25 recetas rápidas', icon: '⚡', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 22), title: 'Fáciles', description: 'Guarda 25 recetas fáciles', icon: '✅', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 23), title: 'Especiales', description: 'Guarda 15 recetas especiales', icon: '⭐', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('col', 24), title: 'Familiares', description: 'Guarda 20 recetas familiares', icon: '👨‍👩‍👧‍👦', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 25), title: 'Fiestas', description: 'Guarda 15 recetas para fiestas', icon: '🎉', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('col', 26), title: 'Navideñas', description: 'Guarda 10 recetas navideñas', icon: '🎄', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 27), title: 'Verano', description: 'Guarda 15 recetas de verano', icon: '☀️', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('col', 28), title: 'Invierno', description: 'Guarda 15 recetas de invierno', icon: '❄️', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('col', 29), title: 'Exportador', description: 'Exporta una colección', icon: '📤', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('col', 30), title: 'Compartidor', description: 'Comparte una colección', icon: '🔗', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 31), title: 'Etiquetas', description: 'Añade etiquetas a 20 recetas', icon: '🏷️', category: 'coleccion', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('col', 32), title: 'Notas', description: 'Añade notas a 10 recetas', icon: '📝', category: 'coleccion', points: 40, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('col', 33), title: 'Calificaciones', description: 'Califica 25 recetas', icon: '⭐', category: 'coleccion', points: 75, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('col', 34), title: 'Historial', description: 'Revisa tu historial de cocinado', icon: '📜', category: 'coleccion', points: 20, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('col', 35), title: 'Coleccionista Supremo', description: 'Completa todos los logros de colección', icon: '🏆', category: 'coleccion', points: 500, unlocked: false, progress: 0, maxProgress: 34 },
]

// ============================================
// TIEMPO ACHIEVEMENTS (35) - Time-based achievements
// ============================================
const tiempoAchievements: Achievement[] = [
  { id: generateId('tie', 1), title: 'Primer Día', description: 'Usa la app por primera vez', icon: '🌅', category: 'tiempo', points: 10, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 2), title: 'Semana Completa', description: 'Usa la app durante 7 días', icon: '📅', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 7 },
  { id: generateId('tie', 3), title: 'Quincena', description: 'Usa la app durante 15 días', icon: '🗓️', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('tie', 4), title: 'Mes en Cocina', description: 'Usa la app durante 30 días', icon: '📆', category: 'tiempo', points: 200, unlocked: false, progress: 0, maxProgress: 30 },
  { id: generateId('tie', 5), title: 'Trimestre', description: 'Usa la app durante 90 días', icon: '🎯', category: 'tiempo', points: 500, unlocked: false, progress: 0, maxProgress: 90 },
  { id: generateId('tie', 6), title: 'Medio Año', description: 'Usa la app durante 180 días', icon: '🏆', category: 'tiempo', points: 750, unlocked: false, progress: 0, maxProgress: 180 },
  { id: generateId('tie', 7), title: 'Año Completo', description: 'Usa la app durante 365 días', icon: '👑', category: 'tiempo', points: 1500, unlocked: false, progress: 0, maxProgress: 365 },
  { id: generateId('tie', 8), title: 'Veterano', description: 'Usa la app durante 2 años', icon: '🎖️', category: 'tiempo', points: 3000, unlocked: false, progress: 0, maxProgress: 730 },
  { id: generateId('tie', 9), title: 'Leyenda', description: 'Usa la app durante 5 años', icon: '⭐', category: 'tiempo', points: 10000, unlocked: false, progress: 0, maxProgress: 1825 },
  { id: generateId('tie', 10), title: 'Sesión de 1 hora', description: 'Usa la app durante 1 hora seguida', icon: '⏱️', category: 'tiempo', points: 25, unlocked: false, progress: 0, maxProgress: 60 },
  { id: generateId('tie', 11), title: 'Maratón de Cocina', description: 'Usa la app durante 3 horas seguidas', icon: '🏃', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 180 },
  { id: generateId('tie', 12), title: 'Super Usuario', description: 'Usa la app durante 5 horas seguidas', icon: '💪', category: 'tiempo', points: 150, unlocked: false, progress: 0, maxProgress: 300 },
  { id: generateId('tie', 13), title: 'Madrugador', description: 'Usa la app antes de las 7am', icon: '🌅', category: 'tiempo', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 14), title: 'Nocturno', description: 'Usa la app después de las 11pm', icon: '🌙', category: 'tiempo', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 15), title: 'Fiel', description: 'Usa la app todos los días de una semana', icon: '✨', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 7 },
  { id: generateId('tie', 16), title: 'Madrugador Extremo', description: 'Usa la app antes de las 6am 10 veces', icon: '☀️', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('tie', 17), title: 'Búho Nocturno', description: 'Usa la app después de las 12am 10 veces', icon: '🦉', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('tie', 18), title: 'Fin de Semana', description: 'Usa la app 10 fines de semana seguidos', icon: '🎉', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('tie', 19), title: 'Laboral', description: 'Usa la app 20 días laborales seguidos', icon: '💼', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('tie', 20), title: 'Hora Punta', description: 'Usa la app a las 12pm o 8pm 20 veces', icon: '⏰', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 20 },
  { id: generateId('tie', 21), title: 'Desayunador', description: 'Usa la app a la hora del desayuno 15 veces', icon: '🥐', category: 'tiempo', points: 40, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('tie', 22), title: 'Almuerzador', description: 'Usa la app a la hora del almuerzo 15 veces', icon: '🍽️', category: 'tiempo', points: 40, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('tie', 23), title: 'Cenador', description: 'Usa la app a la hora de la cena 15 veces', icon: '🌙', category: 'tiempo', points: 40, unlocked: false, progress: 0, maxProgress: 15 },
  { id: generateId('tie', 24), title: 'Temporizador 10', description: 'Usa el temporizador 10 veces', icon: '⏱️', category: 'tiempo', points: 25, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('tie', 25), title: 'Temporizador 50', description: 'Usa el temporizador 50 veces', icon: '⏰', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('tie', 26), title: 'Temporizador 100', description: 'Usa el temporizador 100 veces', icon: '🕐', category: 'tiempo', points: 150, unlocked: false, progress: 0, maxProgress: 100 },
  { id: generateId('tie', 27), title: 'Multi-Timer', description: 'Usa 3 temporizadores a la vez', icon: '⏲️', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 28), title: 'Puntual', description: 'Completa una receta en el tiempo exacto', icon: '✅', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 29), title: 'Velocista', description: 'Completa 5 recetas rápidas en un día', icon: '⚡', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('tie', 30), title: 'Paciencia', description: 'Completa una receta de más de 4 horas', icon: '🐢', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 31), title: 'Planificador', description: 'Planifica 10 comidas con antelación', icon: '📋', category: 'tiempo', points: 75, unlocked: false, progress: 0, maxProgress: 10, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('tie', 32), title: 'Semanal', description: 'Planifica una semana completa', icon: '📆', category: 'tiempo', points: 100, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('tie', 33), title: 'Mensual', description: 'Planifica un mes completo', icon: '🗓️', category: 'tiempo', points: 200, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('tie', 34), title: 'Récord Personal', description: 'Supera tu récord de días consecutivos', icon: '🏆', category: 'tiempo', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('tie', 35), title: 'Maestro del Tiempo', description: 'Completa todos los logros de tiempo', icon: '⌚', category: 'tiempo', points: 500, unlocked: false, progress: 0, maxProgress: 34 },
]

// ============================================
// ESPECIAL ACHIEVEMENTS (35) - Special events and milestones
// ============================================
const especialAchievements: Achievement[] = [
  { id: generateId('esp', 1), title: 'Pionero', description: 'Sé uno de los primeros 1000 usuarios', icon: '🚀', category: 'especial', points: 500, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 2), title: 'Beta Tester', description: 'Participa en el programa beta', icon: '🧪', category: 'especial', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 3), title: 'Feedback', description: 'Envía una sugerencia', icon: '💡', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 4), title: 'Colaborador', description: 'Envía 10 sugerencias', icon: '🎯', category: 'especial', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('esp', 5), title: 'Traductor', description: 'Ayuda a traducir la app', icon: '🌍', category: 'especial', points: 300, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 6), title: 'Invitado Especial', description: 'Usa un código de invitación', icon: '🎫', category: 'especial', points: 75, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 7), title: 'Mecenas', description: 'Apoya el desarrollo', icon: '💎', category: 'especial', points: 500, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 8), title: 'Eventos', description: 'Participa en un evento especial', icon: '🎉', category: 'especial', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 9), title: 'Navidad', description: 'Usa la app en Navidad', icon: '🎄', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 10), title: 'Año Nuevo', description: 'Usa la app en Año Nuevo', icon: '🎆', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 11), title: 'San Valentín', description: 'Usa la app en San Valentín', icon: '💕', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 12), title: 'Halloween', description: 'Usa la app en Halloween', icon: '🎃', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 13), title: 'Pascua', description: 'Usa la app en Pascua', icon: '🐰', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 14), title: 'Día de la Madre', description: 'Usa la app en Día de la Madre', icon: '👩', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 15), title: 'Día del Padre', description: 'Usa la app en Día del Padre', icon: '👨', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 16), title: 'Ultra Subscriber', description: 'Suscríbete al plan Ultra', icon: '⚡', category: 'especial', points: 300, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'ultra' },
  { id: generateId('esp', 17), title: 'MasterChef Subscriber', description: 'Suscríbete al plan MasterChef', icon: '👑', category: 'especial', points: 500, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('esp', 18), title: 'Trial Completado', description: 'Completa el período de prueba', icon: '✅', category: 'especial', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 19), title: 'Verano', description: 'Usa la app en verano', icon: '☀️', category: 'especial', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 20), title: 'Invierno', description: 'Usa la app en invierno', icon: '❄️', category: 'especial', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 21), title: 'Primavera', description: 'Usa la app en primavera', icon: '🌸', category: 'especial', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 22), title: 'Otoño', description: 'Usa la app en otoño', icon: '🍂', category: 'especial', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 23), title: 'Cumpleaños', description: 'Usa la app en tu cumpleaños', icon: '🎂', category: 'especial', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 24), title: 'Aniversario', description: 'Usa la app en el aniversario de tu registro', icon: '🥳', category: 'especial', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 25), title: 'Influencer', description: 'Comparte la app con 10 amigos', icon: '📱', category: 'especial', points: 200, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('esp', 26), title: 'Código Promocional', description: 'Usa un código promocional', icon: '🎟️', category: 'especial', points: 75, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 27), title: 'Sorteo', description: 'Participa en un sorteo', icon: '🎲', category: 'especial', points: 50, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 28), title: 'Ganador', description: 'Gana un sorteo', icon: '🏆', category: 'especial', points: 300, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 29), title: 'Embajador', description: 'Invita a 25 usuarios', icon: '🤝', category: 'especial', points: 500, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('esp', 30), title: 'VIP', description: 'Alcanza el estatus VIP', icon: '⭐', category: 'especial', points: 400, unlocked: false, progress: 0, maxProgress: 1, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('esp', 31), title: 'IA Chef', description: 'Usa el asistente IA 10 veces', icon: '🤖', category: 'especial', points: 300, unlocked: false, progress: 0, maxProgress: 10, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('esp', 32), title: 'Voz Master', description: 'Usa el control por voz 20 veces', icon: '🎤', category: 'especial', points: 250, unlocked: false, progress: 0, maxProgress: 20, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('esp', 33), title: 'Cloud Master', description: 'Sincroniza 50 recetas en la nube', icon: '☁️', category: 'especial', points: 200, unlocked: false, progress: 0, maxProgress: 50, isPremium: true, requiredPlan: 'masterchef' },
  { id: generateId('esp', 34), title: 'Soporte', description: 'Ayuda a otro usuario', icon: '🆘', category: 'especial', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('esp', 35), title: 'Leyenda Especial', description: 'Completa todos los logros especiales', icon: '🌟', category: 'especial', points: 1000, unlocked: false, progress: 0, maxProgress: 34 },
]

// ============================================
// RETOS ACHIEVEMENTS (35) - Challenge achievements
// ============================================
const retosAchievements: Achievement[] = [
  { id: generateId('ret', 1), title: 'Primer Reto', description: 'Participa en tu primer reto', icon: '🎯', category: 'retos', points: 25, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 2), title: 'Retador', description: 'Participa en 5 retos', icon: '🔥', category: 'retos', points: 75, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('ret', 3), title: 'Competitivo', description: 'Participa en 10 retos', icon: '💪', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('ret', 4), title: 'Retador Pro', description: 'Participa en 25 retos', icon: '⭐', category: 'retos', points: 300, unlocked: false, progress: 0, maxProgress: 25 },
  { id: generateId('ret', 5), title: 'Leyenda de Retos', description: 'Participa en 50 retos', icon: '🏆', category: 'retos', points: 500, unlocked: false, progress: 0, maxProgress: 50 },
  { id: generateId('ret', 6), title: 'Primer Podio', description: 'Queda en el podio de un reto', icon: '🥉', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 7), title: 'Segundo Lugar', description: 'Queda segundo en un reto', icon: '🥈', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 8), title: 'Campeón', description: 'Gana tu primer reto', icon: '🥇', category: 'retos', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 9), title: 'Multi-Campeón', description: 'Gana 5 retos', icon: '👑', category: 'retos', points: 500, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('ret', 10), title: 'Dominador', description: 'Gana 10 retos', icon: '💎', category: 'retos', points: 1000, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('ret', 11), title: 'Reto Semanal', description: 'Completa 10 retos semanales', icon: '📅', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 10 },
  { id: generateId('ret', 12), title: 'Reto Mensual', description: 'Completa 5 retos mensuales', icon: '🗓️', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('ret', 13), title: 'Reto Especial', description: 'Completa un reto especial', icon: '⭐', category: 'retos', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 14), title: 'Reto de Tiempo', description: 'Completa un reto contrarreloj', icon: '⏱️', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 15), title: 'Reto de Ingredientes', description: 'Completa un reto de ingredientes', icon: '🥗', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 16), title: 'Reto Temático', description: 'Completa 5 retos temáticos', icon: '🎨', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('ret', 17), title: 'Reto de Cocina', description: 'Completa un reto de cocina específica', icon: '🍳', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 18), title: 'Reto Saludable', description: 'Completa un reto saludable', icon: '🥬', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 19), title: 'Reto Vegetariano', description: 'Completa un reto vegetariano', icon: '🌱', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 20), title: 'Reto de Postres', description: 'Completa 3 retos de postres', icon: '🍰', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('ret', 21), title: 'Reto Thermomix', description: 'Completa 3 retos Thermomix', icon: '🤖', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('ret', 22), title: 'Reto Crockpot', description: 'Completa 3 retos Crockpot', icon: '🍲', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('ret', 23), title: 'Reto Tradicional', description: 'Completa 3 retos tradicionales', icon: '👨‍🍳', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('ret', 24), title: 'Reto Fotográfico', description: 'Participa en un reto de fotos', icon: '📸', category: 'retos', points: 75, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 25), title: 'Reto Creativo', description: 'Participa en un reto creativo', icon: '🎨', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 26), title: 'Reto de Equipo', description: 'Participa en un reto en equipo', icon: '👥', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 27), title: 'Reto Internacional', description: 'Participa en un reto internacional', icon: '🌍', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 28), title: 'Reto de Navidad', description: 'Completa el reto de Navidad', icon: '🎄', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 29), title: 'Reto de Verano', description: 'Completa el reto de verano', icon: '☀️', category: 'retos', points: 150, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 30), title: 'Reto Express', description: 'Completa 5 retos express', icon: '⚡', category: 'retos', points: 100, unlocked: false, progress: 0, maxProgress: 5 },
  { id: generateId('ret', 31), title: 'Reto Difícil', description: 'Completa un reto de dificultad alta', icon: '💀', category: 'retos', points: 200, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 32), title: 'Reto Extremo', description: 'Completa 3 retos extremos', icon: '🔥', category: 'retos', points: 400, unlocked: false, progress: 0, maxProgress: 3 },
  { id: generateId('ret', 33), title: 'Racha de Retos', description: 'Completa retos 4 semanas seguidas', icon: '📈', category: 'retos', points: 200, unlocked: false, progress: 0, maxProgress: 4 },
  { id: generateId('ret', 34), title: 'Top 10', description: 'Queda en el top 10 de un reto', icon: '🏅', category: 'retos', points: 75, unlocked: false, progress: 0, maxProgress: 1 },
  { id: generateId('ret', 35), title: 'Maestro de Retos', description: 'Completa todos los logros de retos', icon: '🏆', category: 'retos', points: 500, unlocked: false, progress: 0, maxProgress: 34 },
]

// ============================================
// COMBINE ALL ACHIEVEMENTS
// ============================================
export const allAchievements: Achievement[] = [
  ...recetasAchievements,      // 35
  ...cocinaAchievements,       // 35
  ...socialAchievements,       // 35
  ...exploracionAchievements,  // 35
  ...maestriaAchievements,     // 35
  ...thermomixAchievements,    // 35
  ...coleccionAchievements,    // 35
  ...tiempoAchievements,       // 35
  ...especialAchievements,     // 35
  ...retosAchievements,        // 35
] // Total: 350 achievements

// Category definitions for UI
export const achievementCategories = [
  { id: 'recetas', name: 'Recetas', icon: '🍳', count: 35, color: 'from-orange-500 to-red-500' },
  { id: 'cocina', name: 'Cocina', icon: '👨‍🍳', count: 35, color: 'from-red-500 to-pink-500' },
  { id: 'social', name: 'Social', icon: '👥', count: 35, color: 'from-blue-500 to-cyan-500' },
  { id: 'exploracion', name: 'Exploración', icon: '🧭', count: 35, color: 'from-green-500 to-emerald-500' },
  { id: 'maestria', name: 'Maestría', icon: '🏆', count: 35, color: 'from-yellow-500 to-orange-500' },
  { id: 'thermomix', name: 'Thermomix', icon: '🤖', count: 35, color: 'from-cyan-500 to-blue-500' },
  { id: 'coleccion', name: 'Colección', icon: '📚', count: 35, color: 'from-purple-500 to-pink-500' },
  { id: 'tiempo', name: 'Tiempo', icon: '⏰', count: 35, color: 'from-indigo-500 to-purple-500' },
  { id: 'especial', name: 'Especial', icon: '⭐', count: 35, color: 'from-amber-500 to-yellow-500' },
  { id: 'retos', name: 'Retos', icon: '🎯', count: 35, color: 'from-rose-500 to-red-500' },
] as const

// Helper functions
export const getAchievementsByCategory = (category: AchievementCategory): Achievement[] => {
  return allAchievements.filter(a => a.category === category)
}

export const getVisibleAchievements = (userPlan: 'basic' | 'ultra' | 'masterchef', hideUnearned: boolean = true): Achievement[] => {
  return allAchievements.filter(achievement => {
    // Hide premium achievements for non-premium users
    if (achievement.isPremium && achievement.requiredPlan) {
      if (achievement.requiredPlan === 'masterchef' && userPlan !== 'masterchef') {
        return false
      }
      if (achievement.requiredPlan === 'ultra' && userPlan === 'basic') {
        return false
      }
    }
    
    // Hide unearned achievements if setting is enabled
    if (hideUnearned && !achievement.unlocked && achievement.hidden) {
      return false
    }
    
    return true
  })
}

export const getTotalPoints = (): number => {
  return allAchievements.reduce((sum, a) => sum + (a.unlocked ? a.points : 0), 0)
}

export const getLastUpdateDate = (): string => {
  return '21 de febrero de 2026'
}

export const getAchievementStats = () => {
  const stats = {
    total: allAchievements.length,
    unlocked: allAchievements.filter(a => a.unlocked).length,
    points: getTotalPoints(),
    byCategory: {} as Record<AchievementCategory, { total: number; unlocked: number }>
  }
  
  achievementCategories.forEach(cat => {
    const categoryAchievements = getAchievementsByCategory(cat.id as AchievementCategory)
    stats.byCategory[cat.id as AchievementCategory] = {
      total: categoryAchievements.length,
      unlocked: categoryAchievements.filter(a => a.unlocked).length,
    }
  })
  
  return stats
}
