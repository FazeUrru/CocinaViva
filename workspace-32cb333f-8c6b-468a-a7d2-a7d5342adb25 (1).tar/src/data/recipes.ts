// Comprehensive Recipe Database - 2700+ Recipes
// Categories: Desayuno (400), Almuerzo (400), Postre (500), Snack (500), Thermomix (300), Crockpot (300), Tradicional (300)

export interface Recipe {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  prepTime: number;
  cookTime: number;
  totalTime: number;
  difficulty: 'facil' | 'medio' | 'dificil';
  toolType: 'tradicional' | 'thermomix' | 'crockpot';
  isGlutenFree: boolean;
  averageRating: number;
  ratingCount: number;
  mealType: 'desayuno' | 'almuerzo' | 'cena' | 'postre' | 'snack';
  cuisine?: string;
}

// Helper to generate unique IDs
let recipeIdCounter = 1;
const generateId = () => `recipe-${recipeIdCounter++}`;

// Image URL helpers - using placeholder images that match recipe types
const getBreakfastImage = (index: number) => `/images/recipes/breakfast-${(index % 10) + 1}.png`;
const getLunchImage = (index: number) => `/images/recipes/lunch-${(index % 10) + 1}.png`;
const getDessertImage = (index: number) => `/images/recipes/dessert-${(index % 10) + 1}.png`;
const getSnackImage = (index: number) => `/images/recipes/snack-${(index % 10) + 1}.png`;
const getThermomixImage = (index: number) => `/images/recipes/thermomix-${(index % 10) + 1}.png`;
const getCrockpotImage = (index: number) => `/images/recipes/crockpot-${(index % 10) + 1}.png`;
const getTraditionalImage = (index: number) => `/images/recipes/traditional-${(index % 10) + 1}.png`;

// Random helpers
const randomRating = () => Math.round((3.5 + Math.random() * 1.5) * 10) / 10;
const randomRatingCount = () => Math.floor(50 + Math.random() * 300);
const randomBool = () => Math.random() > 0.7;

// DESAYUNO RECIPES (400 recipes)
const desayunoRecipes: Recipe[] = [
  // Spanish Breakfasts
  { id: generateId(), title: 'Tostadas con Tomate', description: 'Clásicas tostadas españolas con tomate rallado y aceite de oliva virgen extra', imageUrl: getBreakfastImage(1), prepTime: 5, cookTime: 2, totalTime: 7, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 234, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Tortilla Española', description: 'Tortilla de patatas tradicional con cebolla caramelizada', imageUrl: getBreakfastImage(2), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 567, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Churros con Chocolate', description: 'Churros caseros crujientes con chocolate espeso para mojar', imageUrl: getBreakfastImage(3), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 456, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Torrijas', description: 'Torrijas tradicionales con canela y miel', imageUrl: getBreakfastImage(4), prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 189, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Huevos Rotos con Jamón', description: 'Huevos fritos sobre patatas con jamón ibérico', imageUrl: getBreakfastImage(5), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 321, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Migas Extremeñas', description: 'Migas tradicionales con torreznos y pimientos', imageUrl: getBreakfastImage(6), prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.4, ratingCount: 156, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Pan con Aceite', description: 'Pan tostado con aceite de oliva y sal', imageUrl: getBreakfastImage(7), prepTime: 2, cookTime: 3, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.3, ratingCount: 98, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Huevos al Plato', description: 'Huevos al plato con guisantes y jamón', imageUrl: getBreakfastImage(8), prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.2, ratingCount: 145, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Desayuno Andaluz', description: 'Pan cateto con aceite, tomate y jamón serrano', imageUrl: getBreakfastImage(9), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 234, mealType: 'desayuno', cuisine: 'española' },
  { id: generateId(), title: 'Embutidos Ibéricos', description: 'Tabla de embutidos ibéricos con pan', imageUrl: getBreakfastImage(10), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 345, mealType: 'desayuno', cuisine: 'española' },

  // French Breakfasts
  { id: generateId(), title: 'Croissants de Mantequilla', description: 'Croissants franceses hojaldrados y crujientes', imageUrl: getBreakfastImage(1), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.9, ratingCount: 456, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Pain au Chocolat', description: 'Napolitanas de chocolate francesas', imageUrl: getBreakfastImage(2), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 389, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Crêpes Suzette', description: 'Crêpes con salsa de naranja y Grand Marnier', imageUrl: getBreakfastImage(3), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 267, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Omelette aux Fines Herbes', description: 'Tortilla francesa con hierbas frescas', imageUrl: getBreakfastImage(4), prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 198, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Brioche', description: 'Pan brioche francés suave y esponjoso', imageUrl: getBreakfastImage(5), prepTime: 30, cookTime: 35, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 234, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Pain Perdu', description: 'Torrijas francesas con vainilla', imageUrl: getBreakfastImage(6), prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 287, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Croissant aux Amandes', description: 'Croissant de almendra con crema', imageUrl: getBreakfastImage(7), prepTime: 50, cookTime: 20, totalTime: 70, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 178, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Galette de Sarrasin', description: 'Crêpe de trigo sarraceno con huevo', imageUrl: getBreakfastImage(8), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 156, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Viennoiserie', description: 'Pastelería vienesa francesa variada', imageUrl: getBreakfastImage(9), prepTime: 40, cookTime: 25, totalTime: 65, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 201, mealType: 'desayuno', cuisine: 'francesa' },
  { id: generateId(), title: 'Madeleines', description: 'Pequeños bizcochos franceses con forma de concha', imageUrl: getBreakfastImage(10), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 189, mealType: 'desayuno', cuisine: 'francesa' },

  // American Breakfasts
  { id: generateId(), title: 'Pancakes Americanos', description: 'Tortitas esponjosas con sirope de arce', imageUrl: getBreakfastImage(1), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 567, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Bacon and Eggs', description: 'Huevos fritos con bacon crujiente', imageUrl: getBreakfastImage(2), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 432, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Hash Browns', description: 'Tortitas de patata crujientes', imageUrl: getBreakfastImage(3), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 298, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'French Toast', description: 'Pan francés con canela y sirope', imageUrl: getBreakfastImage(4), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 345, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Bagel con Queso Crema', description: 'Bagel tostado con queso crema y salmón', imageUrl: getBreakfastImage(5), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 267, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Waffles Belgas', description: 'Waffles crujientes con frutas frescas', imageUrl: getBreakfastImage(6), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 389, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Eggs Benedict', description: 'Huevos benedictinos con salsa holandesa', imageUrl: getBreakfastImage(7), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.9, ratingCount: 456, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Granola con Yogur', description: 'Granola casera con yogur griego y frutas', imageUrl: getBreakfastImage(8), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Breakfast Burrito', description: 'Burrito de desayuno con huevos y bacon', imageUrl: getBreakfastImage(9), prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 312, mealType: 'desayuno', cuisine: 'americana' },
  { id: generateId(), title: 'Blueberry Muffins', description: 'Muffins de arándanos frescos', imageUrl: getBreakfastImage(10), prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 278, mealType: 'desayuno', cuisine: 'americana' },

  // Italian Breakfasts
  { id: generateId(), title: 'Cappuccino e Cornetto', description: 'Desayuno italiano clásico con cappuccino y croissant', imageUrl: getBreakfastImage(1), prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 456, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Focaccia al Rosmarino', description: 'Focaccia italiana con romero', imageUrl: getBreakfastImage(2), prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 234, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Biscotti', description: 'Galletas italianas crujientes para mojar', imageUrl: getBreakfastImage(3), prepTime: 15, cookTime: 35, totalTime: 50, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.4, ratingCount: 189, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Panettone', description: 'Pan dulce milanés con frutas escarchadas', imageUrl: getBreakfastImage(4), prepTime: 45, cookTime: 50, totalTime: 95, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 345, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Ciabatta con Prosciutto', description: 'Pan ciabatta con jamón italiano', imageUrl: getBreakfastImage(5), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 267, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Bomboloni', description: 'Donuts italianos rellenos de crema', imageUrl: getBreakfastImage(6), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 298, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Frittata di Pasta', description: 'Tortilla italiana de pasta', imageUrl: getBreakfastImage(7), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.3, ratingCount: 156, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Panini alla Nutella', description: 'Sándwich de pan con Nutella', imageUrl: getBreakfastImage(8), prepTime: 3, cookTime: 5, totalTime: 8, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 389, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Ricotta e Miele', description: 'Ricotta fresca con miel y frutos secos', imageUrl: getBreakfastImage(9), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 201, mealType: 'desayuno', cuisine: 'italiana' },
  { id: generateId(), title: 'Brioscina', description: 'Pequeños bollos sicilianos', imageUrl: getBreakfastImage(10), prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 178, mealType: 'desayuno', cuisine: 'italiana' },

  // Mexican Breakfasts
  { id: generateId(), title: 'Huevos Rancheros', description: 'Huevos con salsa ranchera y tortillas', imageUrl: getBreakfastImage(1), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 345, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Chilaquiles', description: 'Totopos con salsa verde y crema', imageUrl: getBreakfastImage(2), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 456, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Molletes', description: 'Pan con frijoles y queso gratinado', imageUrl: getBreakfastImage(3), prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 234, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Enchiladas de Desayuno', description: 'Enchiladas con huevo y queso', imageUrl: getBreakfastImage(4), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 289, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Tamales de Elote', description: 'Tamales dulces de maíz tierno', imageUrl: getBreakfastImage(5), prepTime: 30, cookTime: 60, totalTime: 90, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 312, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Huevos a la Mexicana', description: 'Huevos revueltos con tomate y chile', imageUrl: getBreakfastImage(6), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 267, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Quesadillas de Maíz', description: 'Quesadillas con queso Oaxaca', imageUrl: getBreakfastImage(7), prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 298, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Atole de Chocolate', description: 'Bebida espesa de chocolate mexicano', imageUrl: getBreakfastImage(8), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 189, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Tostadas de Ceviche', description: 'Tostadas con ceviche de pescado', imageUrl: getBreakfastImage(9), prepTime: 20, cookTime: 0, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 234, mealType: 'desayuno', cuisine: 'mexicana' },
  { id: generateId(), title: 'Conchas', description: 'Pan dulce mexicano típico', imageUrl: getBreakfastImage(10), prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 278, mealType: 'desayuno', cuisine: 'mexicana' },

  // Mediterranean Breakfasts
  { id: generateId(), title: 'Shakshuka', description: 'Huevos en salsa de tomate especiada', imageUrl: getBreakfastImage(1), prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 456, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Labneh con Zaatar', description: 'Queso fresco con hierbas mediterráneas', imageUrl: getBreakfastImage(2), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 234, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Foul Medames', description: 'Habas con especias egipcias', imageUrl: getBreakfastImage(3), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 156, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Menemen', description: 'Huevos turcos con pimientos y tomate', imageUrl: getBreakfastImage(4), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 289, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Fatteh', description: 'Pan con garbanzos y yogur', imageUrl: getBreakfastImage(5), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 178, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Borek', description: 'Pastel turco de phyllo con queso', imageUrl: getBreakfastImage(6), prepTime: 30, cookTime: 35, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 312, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Simit', description: 'Pan turco con semillas de sésamo', imageUrl: getBreakfastImage(7), prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.4, ratingCount: 201, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Ful Nabed', description: 'Sopa de habas egipcia', imageUrl: getBreakfastImage(8), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.3, ratingCount: 145, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Halloumi a la Plancha', description: 'Queso chipriota a la plancha', imageUrl: getBreakfastImage(9), prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 267, mealType: 'desayuno', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Manaqeesh', description: 'Pan plano con zaatar y aceite', imageUrl: getBreakfastImage(10), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 189, mealType: 'desayuno', cuisine: 'mediterranea' },

  // Asian Breakfasts
  { id: generateId(), title: 'Congee', description: 'Gachas de arroz chinas', imageUrl: getBreakfastImage(1), prepTime: 10, cookTime: 45, totalTime: 55, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 234, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Dim Sum', description: 'Variedad de bollitos chinos al vapor', imageUrl: getBreakfastImage(2), prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 456, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Tamagoyaki', description: 'Tortilla japonesa enrollada', imageUrl: getBreakfastImage(3), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 289, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Onigiri', description: 'Bolas de arroz japonés rellenas', imageUrl: getBreakfastImage(4), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 267, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Miso Soup', description: 'Sopa japonesa de miso con tofu', imageUrl: getBreakfastImage(5), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 312, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Nasi Goreng', description: 'Arroz frito indonesio con huevo', imageUrl: getBreakfastImage(6), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 378, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Pho', description: 'Sopa vietnamita de fideos', imageUrl: getBreakfastImage(7), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 423, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Banh Mi', description: 'Sándwich vietnamita con cerdo', imageUrl: getBreakfastImage(8), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 345, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Idli', description: 'Pasteles de arroz del sur de India', imageUrl: getBreakfastImage(9), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 189, mealType: 'desayuno', cuisine: 'asiatica' },
  { id: generateId(), title: 'Dosa', description: 'Crepe india crujiente de arroz', imageUrl: getBreakfastImage(10), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 298, mealType: 'desayuno', cuisine: 'asiatica' },

  // Healthy Breakfasts
  { id: generateId(), title: 'Smoothie Bowl', description: 'Bowl de batido con frutas y granola', imageUrl: getBreakfastImage(1), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 345, mealType: 'desayuno' },
  { id: generateId(), title: 'Açaí Bowl', description: 'Bowl de açaí con frutas tropicales', imageUrl: getBreakfastImage(2), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 389, mealType: 'desayuno' },
  { id: generateId(), title: 'Overnight Oats', description: 'Avena preparada la noche anterior', imageUrl: getBreakfastImage(3), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 267, mealType: 'desayuno' },
  { id: generateId(), title: 'Chia Pudding', description: 'Pudin de chía con leche de almendras', imageUrl: getBreakfastImage(4), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'desayuno' },
  { id: generateId(), title: 'Quinoa Breakfast Bowl', description: 'Bowl de quinoa con frutas y nueces', imageUrl: getBreakfastImage(5), prepTime: 5, cookTime: 15, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 198, mealType: 'desayuno' },
  { id: generateId(), title: 'Avocado Toast', description: 'Tostada de aguacate con huevo', imageUrl: getBreakfastImage(6), prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 456, mealType: 'desayuno' },
  { id: generateId(), title: 'Greek Yogurt Parfait', description: 'Yogur griego en capas con granola', imageUrl: getBreakfastImage(7), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 289, mealType: 'desayuno' },
  { id: generateId(), title: 'Egg White Omelette', description: 'Tortilla de claras con vegetales', imageUrl: getBreakfastImage(8), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.3, ratingCount: 178, mealType: 'desayuno' },
  { id: generateId(), title: 'Protein Pancakes', description: 'Tortitas con proteína y avena', imageUrl: getBreakfastImage(9), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'desayuno' },
  { id: generateId(), title: 'Buddha Bowl', description: 'Bowl nutritivo con vegetales y legumbres', imageUrl: getBreakfastImage(10), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 201, mealType: 'desayuno' },
];

// Generate remaining breakfast recipes to reach 400
const breakfastTemplates = [
  { prefix: 'Tostada de ', ingredients: ['Aguacate', 'Jamón', 'Queso', 'Tomate', 'Mermelada', 'Nocilla', 'Mantequilla', 'Miel', 'Frutas', 'Crema'] },
  { prefix: 'Bowl de ', ingredients: ['Frutas', 'Yogur', 'Avena', 'Quinoa', 'Chía', 'Granola', 'Smoothie', 'Proteína', 'Cacao', 'Coco'] },
  { prefix: 'Huevos ', suffix: ['', ' con Bacon', ' Revueltos', ' Fritos', ' Poché', ' al Plato', ' con Queso', ' con Jamón', ' a la Mexicana', ' Benedict'] },
  { prefix: 'Muffin de ', ingredients: ['Arándanos', 'Chocolate', 'Plátano', 'Nueces', 'Avena', 'Zanahoria', 'Limón', 'Vainilla', 'Mora', 'Manzana'] },
  { prefix: 'Smoothie de ', ingredients: ['Plátano', 'Fresa', 'Mango', 'Papaya', 'Kiwi', 'Pera', 'Manzana', 'Piña', 'Uva', 'Melón'] },
];

let breakfastCount = desayunoRecipes.length;
while (breakfastCount < 400) {
  const template = breakfastTemplates[breakfastCount % breakfastTemplates.length];
  let title: string;
  if (template.suffix) {
    title = template.prefix + template.suffix[breakfastCount % template.suffix.length];
  } else if (template.ingredients) {
    title = template.prefix + template.ingredients[breakfastCount % template.ingredients.length];
  } else {
    title = template.prefix;
  }
  
  desayunoRecipes.push({
    id: generateId(),
    title,
    description: `Delicioso desayuno de ${title.toLowerCase()}`,
    imageUrl: getBreakfastImage(breakfastCount),
    prepTime: 5 + (breakfastCount % 20),
    cookTime: 5 + (breakfastCount % 15),
    totalTime: 10 + (breakfastCount % 30),
    difficulty: breakfastCount % 3 === 0 ? 'facil' : breakfastCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'tradicional',
    isGlutenFree: breakfastCount % 3 === 0,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: 'desayuno',
  });
  breakfastCount++;
}

// ALMUERZO RECIPES (400 recipes)
const almuerzoRecipes: Recipe[] = [
  // Spanish Lunch
  { id: generateId(), title: 'Paella Valenciana', description: 'La auténtica paella valenciana con pollo, conejo y judías verdes', imageUrl: getLunchImage(1), prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 567, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Cocido Madrileño', description: 'Potaje tradicional con garbanzos y carnes', imageUrl: getLunchImage(2), prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 345, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Gazpacho Andaluz', description: 'Sopa fría de tomate tradicional', imageUrl: getLunchImage(3), prepTime: 15, cookTime: 0, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 456, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Fabada Asturiana', description: 'Guiso de fabes con compango', imageUrl: getLunchImage(4), prepTime: 30, cookTime: 90, totalTime: 120, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 389, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Pulpo a la Gallega', description: 'Pulpo con pimentón y aceite de oliva', imageUrl: getLunchImage(5), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 423, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Judiones a la Llanesca', description: 'Alubias con marisco', imageUrl: getLunchImage(6), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 234, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Marmitako', description: 'Guiso de bonito con patatas', imageUrl: getLunchImage(7), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 298, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Callos a la Madrileña', description: 'Guiso tradicional de callos', imageUrl: getLunchImage(8), prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 267, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Coque de Sant Jordi', description: 'Coca catalana con butifarra', imageUrl: getLunchImage(9), prepTime: 45, cookTime: 30, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 189, mealType: 'almuerzo', cuisine: 'española' },
  { id: generateId(), title: 'Escalivada', description: 'Verduras asadas catalanas', imageUrl: getLunchImage(10), prepTime: 15, cookTime: 45, totalTime: 60, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 201, mealType: 'almuerzo', cuisine: 'española' },

  // Italian Lunch
  { id: generateId(), title: 'Spaghetti Carbonara', description: 'Pasta con huevo, queso pecorino y guanciale', imageUrl: getLunchImage(1), prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 567, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Risotto ai Funghi', description: 'Risotto de setas porcini', imageUrl: getLunchImage(2), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 423, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Lasagna Bolognese', description: 'Lasaña con ragú y bechamel', imageUrl: getLunchImage(3), prepTime: 45, cookTime: 45, totalTime: 90, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.9, ratingCount: 512, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Ossobuco alla Milanese', description: 'Jarrete de ternera con gremolata', imageUrl: getLunchImage(4), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 345, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Pasta al Pomodoro', description: 'Pasta con salsa de tomate fresco', imageUrl: getLunchImage(5), prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 478, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Cotoletta alla Milanese', description: 'Chuleta de ternera empanada', imageUrl: getLunchImage(6), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 298, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Saltimbocca alla Romana', description: 'Ternera con jamón y salvia', imageUrl: getLunchImage(7), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 267, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Minestrone', description: 'Sopa de verduras italiana', imageUrl: getLunchImage(8), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Gnocchi di Patate', description: 'Ñoquis de patata caseros', imageUrl: getLunchImage(9), prepTime: 45, cookTime: 15, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 312, mealType: 'almuerzo', cuisine: 'italiana' },
  { id: generateId(), title: 'Pollo alla Cacciatora', description: 'Pollo guisado estilo cazador', imageUrl: getLunchImage(10), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 289, mealType: 'almuerzo', cuisine: 'italiana' },

  // Mexican Lunch
  { id: generateId(), title: 'Tacos al Pastor', description: 'Tacos de cerdo con piña', imageUrl: getLunchImage(1), prepTime: 30, cookTime: 45, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 534, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Enchiladas Verdes', description: 'Enchiladas con salsa de tomatillo', imageUrl: getLunchImage(2), prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 389, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Pozole Rojo', description: 'Sopa de maíz con cerdo', imageUrl: getLunchImage(3), prepTime: 30, cookTime: 90, totalTime: 120, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 312, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Mole Poblano', description: 'Pollo con mole de chocolate', imageUrl: getLunchImage(4), prepTime: 45, cookTime: 120, totalTime: 165, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 456, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Tamales de Cerdo', description: 'Tamales con salsa de chile', imageUrl: getLunchImage(5), prepTime: 60, cookTime: 60, totalTime: 120, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 378, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Cochinita Pibil', description: 'Cerdo desmenuzado achiote', imageUrl: getLunchImage(6), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 423, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Carnitas', description: 'Cerdo confitado mexicano', imageUrl: getLunchImage(7), prepTime: 20, cookTime: 150, totalTime: 170, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 389, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Quesadillas de Flor de Calabaza', description: 'Quesadillas con flor de calabaza', imageUrl: getLunchImage(8), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 267, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Sopes con Frijoles', description: 'Antojitos con frijoles y queso', imageUrl: getLunchImage(9), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'almuerzo', cuisine: 'mexicana' },
  { id: generateId(), title: 'Birria de Chivo', description: 'Guiso de chivo con chiles', imageUrl: getLunchImage(10), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 298, mealType: 'almuerzo', cuisine: 'mexicana' },

  // Asian Lunch
  { id: generateId(), title: 'Pad Thai', description: 'Fideos de arroz tailandeses con gambas', imageUrl: getLunchImage(1), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 534, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Kung Pao Chicken', description: 'Pollo con cacahuetes y chile', imageUrl: getLunchImage(2), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 423, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Sushi Rolls', description: 'Rollitos de sushi variados', imageUrl: getLunchImage(3), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 489, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Ramen de Cerdo', description: 'Sopa de fideos con chashu', imageUrl: getLunchImage(4), prepTime: 30, cookTime: 120, totalTime: 150, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.9, ratingCount: 567, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Bibimbap', description: 'Arroz coreano con verduras', imageUrl: getLunchImage(5), prepTime: 30, cookTime: 20, totalTime: 50, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 378, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Green Curry', description: 'Curry verde tailandés con pollo', imageUrl: getLunchImage(6), prepTime: 20, cookTime: 25, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 345, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Mapo Tofu', description: 'Tofu con salsa picante sichuanesa', imageUrl: getLunchImage(7), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 289, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Tom Yum', description: 'Sopa tailandesa picante', imageUrl: getLunchImage(8), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 412, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Peking Duck', description: 'Pato laqueado pekinés', imageUrl: getLunchImage(9), prepTime: 60, cookTime: 90, totalTime: 150, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.9, ratingCount: 456, mealType: 'almuerzo', cuisine: 'asiatica' },
  { id: generateId(), title: 'Bulgogi', description: 'Ternera coreana marinada', imageUrl: getLunchImage(10), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 389, mealType: 'almuerzo', cuisine: 'asiatica' },
];

// Generate remaining lunch recipes to reach 400
let lunchCount = almuerzoRecipes.length;
while (lunchCount < 400) {
  const dishTypes = ['Arroz', 'Pasta', 'Pollo', 'Carne', 'Pescado', 'Sopa', 'Ensalada', 'Legumbres', 'Verduras', 'Marisco'];
  const styles = ['Mediterráneo', 'Criollo', 'Casero', 'Tradicional', 'Moderno', 'Fusión', 'Light', 'Especial', 'Gourmet', 'Regional'];
  
  almuerzoRecipes.push({
    id: generateId(),
    title: `${dishTypes[lunchCount % dishTypes.length]} ${styles[lunchCount % styles.length]}`,
    description: `Delicioso ${dishTypes[lunchCount % dishTypes.length].toLowerCase()} preparado al estilo ${styles[lunchCount % styles.length].toLowerCase()}`,
    imageUrl: getLunchImage(lunchCount),
    prepTime: 10 + (lunchCount % 30),
    cookTime: 15 + (lunchCount % 45),
    totalTime: 25 + (lunchCount % 60),
    difficulty: lunchCount % 3 === 0 ? 'facil' : lunchCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'tradicional',
    isGlutenFree: lunchCount % 3 === 0,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: 'almuerzo',
  });
  lunchCount++;
}

// POSTRE RECIPES (500 recipes)
const postreRecipes: Recipe[] = [
  // Spanish Desserts
  { id: generateId(), title: 'Tarta de Santiago', description: 'Tarta de almendras gallega', imageUrl: getDessertImage(1), prepTime: 20, cookTime: 40, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 345, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Crema Catalana', description: 'Crema quemada tradicional', imageUrl: getDessertImage(2), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 456, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Flan de Huevo', description: 'Flan casero tradicional', imageUrl: getDessertImage(3), prepTime: 15, cookTime: 45, totalTime: 60, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 389, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Arroz con Leche', description: 'Postre de arroz con canela', imageUrl: getDessertImage(4), prepTime: 10, cookTime: 45, totalTime: 55, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 312, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Tocino de Cielo', description: 'Postre dulce de huevo', imageUrl: getDessertImage(5), prepTime: 15, cookTime: 40, totalTime: 55, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 278, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Buñuelos de Viento', description: 'Buñuelos rellenos de crema', imageUrl: getDessertImage(6), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 234, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Pestiños', description: 'Dulces fritos con miel', imageUrl: getDessertImage(7), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.4, ratingCount: 189, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Leche Frita', description: 'Postre cremoso frito', imageUrl: getDessertImage(8), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 267, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Rosquillas', description: 'Donuts tradicionales españoles', imageUrl: getDessertImage(9), prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.3, ratingCount: 201, mealType: 'postre', cuisine: 'española' },
  { id: generateId(), title: 'Yemas de Ávila', description: 'Dulces de yema de huevo', imageUrl: getDessertImage(10), prepTime: 20, cookTime: 20, totalTime: 40, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 178, mealType: 'postre', cuisine: 'española' },

  // French Desserts
  { id: generateId(), title: 'Crème Brûlée', description: 'Crema quemada francesa', imageUrl: getDessertImage(1), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 512, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Macarons', description: 'Pastelitos franceses de almendra', imageUrl: getDessertImage(2), prepTime: 45, cookTime: 15, totalTime: 60, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 456, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Mille-Feuille', description: 'Pastel de mil hojas', imageUrl: getDessertImage(3), prepTime: 60, cookTime: 30, totalTime: 90, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 345, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Éclair', description: 'Pastel alargado de crema', imageUrl: getDessertImage(4), prepTime: 45, cookTime: 25, totalTime: 70, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 289, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Opera Cake', description: 'Tarta de café y chocolate', imageUrl: getDessertImage(5), prepTime: 90, cookTime: 30, totalTime: 120, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 312, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Tarte Tatin', description: 'Tarta de manzana invertida', imageUrl: getDessertImage(6), prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 267, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Profiteroles', description: 'Bollos de nata con chocolate', imageUrl: getDessertImage(7), prepTime: 40, cookTime: 25, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 234, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Paris-Brest', description: 'Pastel circular de praliné', imageUrl: getDessertImage(8), prepTime: 50, cookTime: 30, totalTime: 80, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 201, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Ile Flottante', description: 'Islas flotantes de merengue', imageUrl: getDessertImage(9), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 178, mealType: 'postre', cuisine: 'francesa' },
  { id: generateId(), title: 'Baba au Rhum', description: 'Pastel empapado de ron', imageUrl: getDessertImage(10), prepTime: 40, cookTime: 35, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 156, mealType: 'postre', cuisine: 'francesa' },

  // Italian Desserts
  { id: generateId(), title: 'Tiramisú', description: 'Postre de café y mascarpone', imageUrl: getDessertImage(1), prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.9, ratingCount: 567, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Panna Cotta', description: 'Crema italiana cuajada', imageUrl: getDessertImage(2), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 456, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Cannoli', description: 'Tubos de masa rellenos de ricotta', imageUrl: getDessertImage(3), prepTime: 45, cookTime: 20, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 389, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Gelato', description: 'Helado italiano cremoso', imageUrl: getDessertImage(4), prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 534, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Cassata Siciliana', description: 'Tarta siciliana de ricotta', imageUrl: getDessertImage(5), prepTime: 60, cookTime: 0, totalTime: 60, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 234, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Semifreddo', description: 'Postre semicongelado italiano', imageUrl: getDessertImage(6), prepTime: 30, cookTime: 0, totalTime: 30, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 201, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Zuccotto', description: 'Postre con forma de cúpula', imageUrl: getDessertImage(7), prepTime: 45, cookTime: 0, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.4, ratingCount: 178, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Crostata di Marmellata', description: 'Tarta de mermelada italiana', imageUrl: getDessertImage(8), prepTime: 30, cookTime: 40, totalTime: 70, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.3, ratingCount: 234, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Zabaglione', description: 'Crema de yemas con vino', imageUrl: getDessertImage(9), prepTime: 10, cookTime: 15, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 189, mealType: 'postre', cuisine: 'italiana' },
  { id: generateId(), title: 'Torta Caprese', description: 'Tarta de chocolate y almendra', imageUrl: getDessertImage(10), prepTime: 20, cookTime: 45, totalTime: 65, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 267, mealType: 'postre', cuisine: 'italiana' },

  // American Desserts
  { id: generateId(), title: 'Cheesecake New York', description: 'Tarta de queso neoyorquina', imageUrl: getDessertImage(1), prepTime: 30, cookTime: 60, totalTime: 90, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 512, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Brownies', description: 'Pastelitos de chocolate densos', imageUrl: getDessertImage(2), prepTime: 15, cookTime: 30, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 456, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Apple Pie', description: 'Tarta de manzana americana', imageUrl: getDessertImage(3), prepTime: 45, cookTime: 50, totalTime: 95, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 389, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Pumpkin Pie', description: 'Tarta de calabaza', imageUrl: getDessertImage(4), prepTime: 30, cookTime: 55, totalTime: 85, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 312, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Key Lime Pie', description: 'Tarta de lima de Key West', imageUrl: getDessertImage(5), prepTime: 25, cookTime: 20, totalTime: 45, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 267, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Pecan Pie', description: 'Tarta de nueces pecanas', imageUrl: getDessertImage(6), prepTime: 20, cookTime: 50, totalTime: 70, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 234, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Red Velvet Cake', description: 'Tarta de terciopelo rojo', imageUrl: getDessertImage(7), prepTime: 40, cookTime: 35, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.7, ratingCount: 345, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Carrot Cake', description: 'Tarta de zanahoria con nueces', imageUrl: getDessertImage(8), prepTime: 30, cookTime: 45, totalTime: 75, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 298, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'Doughnuts', description: 'Donuts glaseados americanos', imageUrl: getDessertImage(9), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.4, ratingCount: 278, mealType: 'postre', cuisine: 'americana' },
  { id: generateId(), title: 'S\'mores', description: 'Postre de fuego con malvaviscos', imageUrl: getDessertImage(10), prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 201, mealType: 'postre', cuisine: 'americana' },
];

// Generate remaining dessert recipes to reach 500
let dessertCount = postreRecipes.length;
const dessertTypes = ['Tarta', 'Pastel', 'Galletas', 'Flan', 'Mousse', 'Helado', 'Crema', 'Pudin', 'Bizcocho', 'Cupcake'];
const dessertFlavors = ['Chocolate', 'Vainilla', 'Fresa', 'Limón', 'Caramelo', 'Frutos Rojos', 'Naranja', 'Café', 'Coco', 'Canela'];

while (dessertCount < 500) {
  postreRecipes.push({
    id: generateId(),
    title: `${dessertTypes[dessertCount % dessertTypes.length]} de ${dessertFlavors[dessertCount % dessertFlavors.length]}`,
    description: `Delicioso ${dessertTypes[dessertCount % dessertTypes.length].toLowerCase()} con sabor a ${dessertFlavors[dessertCount % dessertFlavors.length].toLowerCase()}`,
    imageUrl: getDessertImage(dessertCount),
    prepTime: 10 + (dessertCount % 30),
    cookTime: 15 + (dessertCount % 40),
    totalTime: 25 + (dessertCount % 50),
    difficulty: dessertCount % 3 === 0 ? 'facil' : dessertCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'tradicional',
    isGlutenFree: dessertCount % 4 === 0,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: 'postre',
  });
  dessertCount++;
}

// SNACK RECIPES (500 recipes)
const snackRecipes: Recipe[] = [
  // Spanish Snacks
  { id: generateId(), title: 'Patatas Bravas', description: 'Patatas con salsa brava picante', imageUrl: getSnackImage(1), prepTime: 15, cookTime: 20, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 456, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Croquetas de Jamón', description: 'Croquetas cremosas de jamón serrano', imageUrl: getSnackImage(2), prepTime: 30, cookTime: 10, totalTime: 40, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.8, ratingCount: 512, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Pinchos Morunos', description: 'Brochetas de cerdo especiadas', imageUrl: getSnackImage(3), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 345, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Gildas', description: 'Pincho de aceituna y anchoa', imageUrl: getSnackImage(4), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Aceitunas Aliñadas', description: 'Aceitunas con hierbas y especias', imageUrl: getSnackImage(5), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.3, ratingCount: 189, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Empanadillas', description: 'Empanadillas de atún', imageUrl: getSnackImage(6), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 298, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Huevos Rellenos', description: 'Huevos rellenos de atún', imageUrl: getSnackImage(7), prepTime: 20, cookTime: 15, totalTime: 35, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 267, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Pimientos de Padrón', description: 'Pimientos fritos con sal', imageUrl: getSnackImage(8), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 312, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Torreznos', description: 'Panceta de cerdo crujiente', imageUrl: getSnackImage(9), prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 278, mealType: 'snack', cuisine: 'española' },
  { id: generateId(), title: 'Gambas al Ajillo', description: 'Gambas con ajo y guindilla', imageUrl: getSnackImage(10), prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 389, mealType: 'snack', cuisine: 'española' },

  // International Snacks
  { id: generateId(), title: 'Nachos con Queso', description: 'Totopos con queso fundido', imageUrl: getSnackImage(1), prepTime: 10, cookTime: 10, totalTime: 20, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.5, ratingCount: 423, mealType: 'snack', cuisine: 'mexicana' },
  { id: generateId(), title: 'Guacamole', description: 'Pasta de aguacate con especias', imageUrl: getSnackImage(2), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 512, mealType: 'snack', cuisine: 'mexicana' },
  { id: generateId(), title: 'Spring Rolls', description: 'Rollos primavera crujientes', imageUrl: getSnackImage(3), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.6, ratingCount: 345, mealType: 'snack', cuisine: 'asiatica' },
  { id: generateId(), title: 'Edamame', description: 'Habas de soja al vapor', imageUrl: getSnackImage(4), prepTime: 5, cookTime: 10, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 267, mealType: 'snack', cuisine: 'asiatica' },
  { id: generateId(), title: 'Bruschetta', description: 'Tostadas con tomate y albahaca', imageUrl: getSnackImage(5), prepTime: 10, cookTime: 5, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 389, mealType: 'snack', cuisine: 'italiana' },
  { id: generateId(), title: 'Caprese Skewers', description: 'Brochetas de mozzarella y tomate', imageUrl: getSnackImage(6), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'snack', cuisine: 'italiana' },
  { id: generateId(), title: 'Buffalo Wings', description: 'Alitas de pollo picantes', imageUrl: getSnackImage(7), prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 456, mealType: 'snack', cuisine: 'americana' },
  { id: generateId(), title: 'Onion Rings', description: 'Aros de cebolla empanizados', imageUrl: getSnackImage(8), prepTime: 15, cookTime: 10, totalTime: 25, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.3, ratingCount: 298, mealType: 'snack', cuisine: 'americana' },
  { id: generateId(), title: 'Falafel', description: 'Croquetas de garbanzos especiadas', imageUrl: getSnackImage(9), prepTime: 30, cookTime: 15, totalTime: 45, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 378, mealType: 'snack', cuisine: 'mediterranea' },
  { id: generateId(), title: 'Hummus con Pita', description: 'Crema de garbanzo con pan', imageUrl: getSnackImage(10), prepTime: 15, cookTime: 0, totalTime: 15, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: false, averageRating: 4.5, ratingCount: 312, mealType: 'snack', cuisine: 'mediterranea' },
];

// Generate remaining snack recipes to reach 500
let snackCount = snackRecipes.length;
const snackTypes = ['Chips', 'Nachos', 'Dip', 'Rolls', 'Bites', 'Sticks', 'Balls', 'Wings', 'Fingers', 'Poppers'];
const snackFlavors = ['Queso', 'Picante', 'BBQ', 'Ajo', 'Hierbas', 'Ranch', 'Chili', 'Cebolla', 'Pimentón', 'Curry'];

while (snackCount < 500) {
  snackRecipes.push({
    id: generateId(),
    title: `${snackTypes[snackCount % snackTypes.length]} ${snackFlavors[snackCount % snackFlavors.length]}`,
    description: `Crujientes ${snackTypes[snackCount % snackTypes.length].toLowerCase()} con sabor ${snackFlavors[snackCount % snackFlavors.length].toLowerCase()}`,
    imageUrl: getSnackImage(snackCount),
    prepTime: 5 + (snackCount % 15),
    cookTime: 5 + (snackCount % 20),
    totalTime: 10 + (snackCount % 25),
    difficulty: snackCount % 3 === 0 ? 'facil' : snackCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'tradicional',
    isGlutenFree: snackCount % 3 === 0,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: 'snack',
  });
  snackCount++;
}

// THERMOMIX RECIPES (300 recipes)
const thermomixRecipes: Recipe[] = [
  { id: generateId(), title: 'Pan de Molde Thermomix', description: 'Pan de molde esponjoso en Thermomix', imageUrl: getThermomixImage(1), prepTime: 15, cookTime: 45, totalTime: 60, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: false, averageRating: 4.7, ratingCount: 456, mealType: 'desayuno' },
  { id: generateId(), title: 'Sopa de Verduras Thermomix', description: 'Sopa cremosa de verduras', imageUrl: getThermomixImage(2), prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.5, ratingCount: 345, mealType: 'almuerzo' },
  { id: generateId(), title: 'Sorbete de Limón Thermomix', description: 'Sorbete refrescante de limón', imageUrl: getThermomixImage(3), prepTime: 5, cookTime: 5, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.6, ratingCount: 389, mealType: 'postre' },
  { id: generateId(), title: 'Hummus Thermomix', description: 'Crema de garbanzos perfecta', imageUrl: getThermomixImage(4), prepTime: 5, cookTime: 0, totalTime: 5, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.8, ratingCount: 512, mealType: 'snack' },
  { id: generateId(), title: 'Bizcocho de Yogur Thermomix', description: 'Bizcocho esponjoso de yogur', imageUrl: getThermomixImage(5), prepTime: 10, cookTime: 40, totalTime: 50, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: false, averageRating: 4.6, ratingCount: 423, mealType: 'postre' },
  { id: generateId(), title: 'Puré de Patata Thermomix', description: 'Puré de patata cremoso', imageUrl: getThermomixImage(6), prepTime: 10, cookTime: 30, totalTime: 40, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.4, ratingCount: 267, mealType: 'almuerzo' },
  { id: generateId(), title: 'Helado de Vainilla Thermomix', description: 'Helado cremoso de vainilla', imageUrl: getThermomixImage(7), prepTime: 10, cookTime: 0, totalTime: 10, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.7, ratingCount: 378, mealType: 'postre' },
  { id: generateId(), title: 'Masa de Pizza Thermomix', description: 'Masa de pizza perfecta', imageUrl: getThermomixImage(8), prepTime: 10, cookTime: 20, totalTime: 30, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: false, averageRating: 4.5, ratingCount: 312, mealType: 'almuerzo' },
  { id: generateId(), title: 'Crema de Calabaza Thermomix', description: 'Crema suave de calabaza', imageUrl: getThermomixImage(9), prepTime: 10, cookTime: 25, totalTime: 35, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.6, ratingCount: 298, mealType: 'almuerzo' },
  { id: generateId(), title: 'Mermelada de Fresa Thermomix', description: 'Mermelada casera de fresa', imageUrl: getThermomixImage(10), prepTime: 10, cookTime: 30, totalTime: 40, difficulty: 'facil', toolType: 'thermomix', isGlutenFree: true, averageRating: 4.8, ratingCount: 456, mealType: 'desayuno' },
];

// Generate remaining Thermomix recipes to reach 300
let thermomixCount = thermomixRecipes.length;
const thermomixDishes = ['Arroz', 'Pasta', 'Sopa', 'Crema', 'Puré', 'Salsa', 'Masa', 'Batido', 'Sorbete', 'Helado'];
const thermomixVariants = ['Clásico', 'Especial', 'Cremoso', 'Ligero', 'Intenso', 'Suave', 'Casero', 'Fácil', 'Rápido', 'Gourmet'];

while (thermomixCount < 300) {
  thermomixRecipes.push({
    id: generateId(),
    title: `${thermomixDishes[thermomixCount % thermomixDishes.length]} ${thermomixVariants[thermomixCount % thermomixVariants.length]} Thermomix`,
    description: `${thermomixDishes[thermomixCount % thermomixDishes.length]} preparado de forma ${thermomixVariants[thermomixCount % thermomixVariants.length].toLowerCase()} en Thermomix`,
    imageUrl: getThermomixImage(thermomixCount),
    prepTime: 5 + (thermomixCount % 15),
    cookTime: 10 + (thermomixCount % 25),
    totalTime: 15 + (thermomixCount % 35),
    difficulty: thermomixCount % 3 === 0 ? 'facil' : thermomixCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'thermomix',
    isGlutenFree: thermomixCount % 3 === 0,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: ['desayuno', 'almuerzo', 'cena', 'postre', 'snack'][thermomixCount % 5] as Recipe['mealType'],
  });
  thermomixCount++;
}

// CROCKPOT RECIPES (300 recipes)
const crockpotRecipes: Recipe[] = [
  { id: generateId(), title: 'Pulled Pork Crockpot', description: 'Cerdo desmenuzado a fuego lento', imageUrl: getCrockpotImage(1), prepTime: 20, cookTime: 480, totalTime: 500, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.9, ratingCount: 534, mealType: 'almuerzo' },
  { id: generateId(), title: 'Chili con Carne Crockpot', description: 'Chili especiado de larga cocción', imageUrl: getCrockpotImage(2), prepTime: 15, cookTime: 360, totalTime: 375, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.7, ratingCount: 456, mealType: 'almuerzo' },
  { id: generateId(), title: 'Beef Stew Crockpot', description: 'Estofado de ternera con verduras', imageUrl: getCrockpotImage(3), prepTime: 20, cookTime: 420, totalTime: 440, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.8, ratingCount: 489, mealType: 'cena' },
  { id: generateId(), title: 'Pollo a la Cerveza Crockpot', description: 'Pollo guisado con cerveza', imageUrl: getCrockpotImage(4), prepTime: 15, cookTime: 300, totalTime: 315, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.6, ratingCount: 378, mealType: 'cena' },
  { id: generateId(), title: 'Ribs BBQ Crockpot', description: 'Costillas barbacoa tiernas', imageUrl: getCrockpotImage(5), prepTime: 15, cookTime: 360, totalTime: 375, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.9, ratingCount: 512, mealType: 'almuerzo' },
  { id: generateId(), title: 'Lentil Soup Crockpot', description: 'Sopa de lentejas casera', imageUrl: getCrockpotImage(6), prepTime: 15, cookTime: 300, totalTime: 315, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.5, ratingCount: 312, mealType: 'almuerzo' },
  { id: generateId(), title: 'Pot Roast Crockpot', description: 'Asado de ternera clásico', imageUrl: getCrockpotImage(7), prepTime: 15, cookTime: 480, totalTime: 495, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.8, ratingCount: 423, mealType: 'almuerzo' },
  { id: generateId(), title: 'Chicken Curry Crockpot', description: 'Curry de pollo especiado', imageUrl: getCrockpotImage(8), prepTime: 15, cookTime: 300, totalTime: 315, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.6, ratingCount: 345, mealType: 'cena' },
  { id: generateId(), title: 'Oatmeal Crockpot', description: 'Avena de cocción lenta', imageUrl: getCrockpotImage(9), prepTime: 5, cookTime: 360, totalTime: 365, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.4, ratingCount: 234, mealType: 'desayuno' },
  { id: generateId(), title: 'Apple Butter Crockpot', description: 'Mantequilla de manzana casera', imageUrl: getCrockpotImage(10), prepTime: 15, cookTime: 600, totalTime: 615, difficulty: 'facil', toolType: 'crockpot', isGlutenFree: true, averageRating: 4.7, ratingCount: 298, mealType: 'desayuno' },
];

// Generate remaining Crockpot recipes to reach 300
let crockpotCount = crockpotRecipes.length;
const crockpotDishes = ['Estofado', 'Guiso', 'Sopa', 'Asado', 'Curry', 'Chili', 'Ragú', 'Cocido', 'Puchero', 'Olla'];
const crockpotProteins = ['Ternera', 'Cerdo', 'Pollo', 'Cordero', 'Pavo', 'Legumbres', 'Verduras', 'Pescado', 'Marisco', 'Mixto'];

while (crockpotCount < 300) {
  crockpotRecipes.push({
    id: generateId(),
    title: `${crockpotDishes[crockpotCount % crockpotDishes.length]} de ${crockpotProteins[crockpotCount % crockpotProteins.length]} Crockpot`,
    description: `${crockpotDishes[crockpotCount % crockpotDishes.length]} de ${crockpotProteins[crockpotCount % crockpotProteins.length].toLowerCase()} cocinado lentamente`,
    imageUrl: getCrockpotImage(crockpotCount),
    prepTime: 10 + (crockpotCount % 20),
    cookTime: 180 + (crockpotCount % 300),
    totalTime: 190 + (crockpotCount % 320),
    difficulty: 'facil',
    toolType: 'crockpot',
    isGlutenFree: true,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: ['almuerzo', 'cena'][crockpotCount % 2] as Recipe['mealType'],
  });
  crockpotCount++;
}

// TRADITIONAL RECIPES (300 recipes)
const traditionalRecipes: Recipe[] = [
  { id: generateId(), title: 'Asado de Cordero', description: 'Cordero asado tradicional', imageUrl: getTraditionalImage(1), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 456, mealType: 'almuerzo' },
  { id: generateId(), title: 'Cochinillo Asado', description: 'Cochinillo crujiente tradicional', imageUrl: getTraditionalImage(2), prepTime: 30, cookTime: 180, totalTime: 210, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 512, mealType: 'almuerzo' },
  { id: generateId(), title: 'Bacalao al Pil Pil', description: 'Bacalao con salsa de ajo', imageUrl: getTraditionalImage(3), prepTime: 30, cookTime: 30, totalTime: 60, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 389, mealType: 'almuerzo' },
  { id: generateId(), title: 'Cordero Segoviano', description: 'Cordero asado estilo segoviano', imageUrl: getTraditionalImage(4), prepTime: 20, cookTime: 150, totalTime: 170, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 345, mealType: 'almuerzo' },
  { id: generateId(), title: 'Pollo al Ajillo', description: 'Pollo con ajos fritos', imageUrl: getTraditionalImage(5), prepTime: 15, cookTime: 40, totalTime: 55, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 378, mealType: 'cena' },
  { id: generateId(), title: 'Lomo de Orza', description: 'Lomo confitado tradicional', imageUrl: getTraditionalImage(6), prepTime: 20, cookTime: 60, totalTime: 80, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.7, ratingCount: 298, mealType: 'almuerzo' },
  { id: generateId(), title: 'Chuletillas de Cordero', description: 'Chuletillas a la brasa', imageUrl: getTraditionalImage(7), prepTime: 15, cookTime: 15, totalTime: 30, difficulty: 'facil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.8, ratingCount: 423, mealType: 'cena' },
  { id: generateId(), title: 'Merluza a la Vasca', description: 'Merluza con salsa verde', imageUrl: getTraditionalImage(8), prepTime: 15, cookTime: 25, totalTime: 40, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.6, ratingCount: 312, mealType: 'almuerzo' },
  { id: generateId(), title: 'Rabo de Toro', description: 'Rabo de toro estofado', imageUrl: getTraditionalImage(9), prepTime: 30, cookTime: 240, totalTime: 270, difficulty: 'dificil', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 389, mealType: 'almuerzo' },
  { id: generateId(), title: 'Lechazo Asado', description: 'Lechazo asado tradicional', imageUrl: getTraditionalImage(10), prepTime: 20, cookTime: 120, totalTime: 140, difficulty: 'medio', toolType: 'tradicional', isGlutenFree: true, averageRating: 4.9, ratingCount: 456, mealType: 'almuerzo' },
];

// Generate remaining Traditional recipes to reach 300
let traditionalCount = traditionalRecipes.length;
const traditionalDishes = ['Asado', 'Guiso', 'Estofado', 'Frito', 'A la Plancha', 'Al Horno', 'En Salsa', 'Guisado', 'Salteado', 'Confitado'];
const traditionalIngredients = ['Ternera', 'Cerdo', 'Cordero', 'Pollo', 'Pescado', 'Marisco', 'Caza', 'Legumbres', 'Verduras', 'Arroz'];

while (traditionalCount < 300) {
  traditionalRecipes.push({
    id: generateId(),
    title: `${traditionalDishes[traditionalCount % traditionalDishes.length]} de ${traditionalIngredients[traditionalCount % traditionalIngredients.length]} Tradicional`,
    description: `${traditionalDishes[traditionalCount % traditionalDishes.length].toLowerCase()} de ${traditionalIngredients[traditionalCount % traditionalIngredients.length].toLowerCase()} preparado de forma tradicional`,
    imageUrl: getTraditionalImage(traditionalCount),
    prepTime: 15 + (traditionalCount % 25),
    cookTime: 30 + (traditionalCount % 90),
    totalTime: 45 + (traditionalCount % 100),
    difficulty: traditionalCount % 3 === 0 ? 'facil' : traditionalCount % 3 === 1 ? 'medio' : 'dificil',
    toolType: 'tradicional',
    isGlutenFree: true,
    averageRating: randomRating(),
    ratingCount: randomRatingCount(),
    mealType: ['almuerzo', 'cena'][traditionalCount % 2] as Recipe['mealType'],
  });
  traditionalCount++;
}

// Combine all recipes
export const allRecipes: Recipe[] = [
  ...desayunoRecipes,
  ...almuerzoRecipes,
  ...postreRecipes,
  ...snackRecipes,
  ...thermomixRecipes,
  ...crockpotRecipes,
  ...traditionalRecipes,
];

// Export counts
export const recipeCounts = {
  desayuno: desayunoRecipes.length,
  almuerzo: almuerzoRecipes.length,
  postre: postreRecipes.length,
  snack: snackRecipes.length,
  thermomix: thermomixRecipes.length,
  crockpot: crockpotRecipes.length,
  tradicional: traditionalRecipes.length,
  total: allRecipes.length,
};

export default allRecipes;
