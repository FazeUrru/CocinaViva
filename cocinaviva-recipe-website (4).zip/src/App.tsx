import { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { RecipeDetail } from './components/RecipeDetail';
import { HomePage } from './pages/HomePage';
import { RecipesPage } from './pages/RecipesPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { FeaturesPage } from './pages/FeaturesPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';
import { PlansPage } from './pages/PlansPage';
import { AuthPage } from './pages/AuthPage';
import type { Recipe } from './data/recipes';
import { recipeStats } from './data/recipes';
import { Logo } from './components/Logo';
import { Heart, Github } from 'lucide-react';

const fontSizeMap: Record<string, string> = {
  'pequeno': '12px',
  'mediano': '14px',
  'grande': '16px',
  'enorme': '20px',
};

export function App() {
  const [user, setUser] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [devMode, setDevMode] = useState(false);
  const [fontSize, setFontSize] = useState('mediano');
  const [activePlan, setActivePlan] = useState<string>('free');

  // Mock Analytics for Admin
  const [analytics, setAnalytics] = useState({
    users: [
      { id: 1, name: 'María G.', email: 'maria.g@gmail.com', method: 'Google', date: new Date().toLocaleString(), plan: 'free' },
      { id: 2, name: 'Juan P.', email: 'juanperez89@hotmail.com', method: 'Facebook', date: new Date(Date.now() - 3600000).toLocaleString(), plan: 'ultra' },
      { id: 3, name: 'Carlos C.', email: 'carlos.chef@apple.com', method: 'Apple', date: new Date(Date.now() - 86400000).toLocaleString(), plan: 'masterchef' },
      { id: 4, name: 'Laura M.', email: 'laura_cocina@gmail.com', method: 'Google', date: new Date(Date.now() - 172800000).toLocaleString(), plan: 'free' },
      { id: 5, name: 'Pedro S.', email: 'pedro_s@twitter.com', method: 'X (Twitter)', date: new Date(Date.now() - 259200000).toLocaleString(), plan: 'free' }
    ],
    purchaseIntents: [
      { plan: 'ultra', clicks: 142, lastClick: new Date().toLocaleString() },
      { plan: 'masterchef', clicks: 89, lastClick: new Date(Date.now() - 1500000).toLocaleString() }
    ]
  });

  const trackPurchaseIntent = useCallback((plan: string) => {
    setAnalytics(prev => {
      const newIntents = prev.purchaseIntents.map(p => 
        p.plan === plan ? { ...p, clicks: p.clicks + 1, lastClick: new Date().toLocaleString() } : p
      );
      return { ...prev, purchaseIntents: newIntents };
    });
  }, []);

  // Apply font size to document
  useEffect(() => {
    document.documentElement.style.fontSize = fontSizeMap[fontSize] || '14px';
  }, [fontSize]);

  const handleNavigate = useCallback((page: string) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleSelectRecipe = useCallback((recipe: Recipe) => {
    setSelectedRecipe(recipe);
  }, []);

  const handleToggleFavorite = useCallback((id: number) => {
    setFavorites(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const handleSearchChange = useCallback((q: string) => {
    setSearchQuery(q);
    if (q && currentPage !== 'recipes') {
      setCurrentPage('recipes');
    }
  }, [currentPage]);

  const handleDevModeChange = useCallback((enabled: boolean) => {
    setDevMode(enabled);
  }, []);

  const handleFontSizeChange = useCallback((size: string) => {
    setFontSize(size);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} activePlan={activePlan} />;
      case 'recipes':
        return <RecipesPage onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} searchQuery={searchQuery} />;
      case 'categories':
        return <CategoriesPage onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} />;
      case 'features':
        return <FeaturesPage />;
      case 'settings':
        return <SettingsPage devMode={devMode} onDevModeChange={handleDevModeChange} fontSize={fontSize} onFontSizeChange={handleFontSizeChange} analytics={analytics} />;
      case 'plans':
        return <PlansPage devMode={devMode} activePlan={activePlan} setActivePlan={setActivePlan} trackPurchaseIntent={trackPurchaseIntent} />;
      case 'about':
        return <AboutPage />;
      default:
        return <HomePage onNavigate={handleNavigate} onSelectRecipe={handleSelectRecipe} favorites={favorites} onToggleFavorite={handleToggleFavorite} />;
    }
  };

  if (!user) {
    return <AuthPage onLogin={setUser} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        currentPage={currentPage}
        onNavigate={handleNavigate}
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
      />
      
      <main>
        {renderPage()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Brand */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-3">
                <Logo size={32} />
                <div>
                  <h3 className="text-sm font-black">CocinaViva</h3>
                  <span className="text-[8px] bg-gradient-to-r from-green-500 to-emerald-600 px-1.5 py-0.5 rounded-full font-bold text-white">v2.0.0 ESTABLE</span>
                </div>
              </div>
              <p className="text-gray-400 text-xs">
                Tu compañero perfecto en la cocina con más de {recipeStats.total} recetas tradicionales y de Thermomix.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Navegacion</h4>
              <ul className="space-y-1">
                {[
                  { key: 'home', label: 'Inicio' },
                  { key: 'recipes', label: 'Recetas' },
                  { key: 'categories', label: 'Categorias' },
                  { key: 'features', label: 'Funciones' },
                  { key: 'plans', label: 'Planes' },
                  { key: 'settings', label: 'Ajustes' },
                  { key: 'about', label: 'Acerca de' },
                ].map(page => (
                  <li key={page.key}>
                    <button onClick={() => handleNavigate(page.key)} className="text-gray-400 hover:text-orange-400 text-xs transition-colors">
                      {page.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Plans */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Planes</h4>
              <ul className="space-y-1.5">
                <li className="text-gray-400 text-xs">Basico — Gratis</li>
                <li>
                  <button onClick={() => handleNavigate('plans')} className="text-orange-400 hover:text-orange-300 text-xs transition-colors font-medium">
                    Ultra — 5,99EUR/mes
                  </button>
                </li>
                <li>
                  <button onClick={() => handleNavigate('plans')} className="text-purple-400 hover:text-purple-300 text-xs transition-colors font-medium">
                    Master Chef — 10,99EUR/mes
                  </button>
                </li>
                <li className="text-green-400 text-xs font-medium">Ahorro anual: -5,65%</li>
              </ul>
              <div className="mt-3">
                <h4 className="font-bold mb-2 text-gray-300 text-sm">Categorias Populares</h4>
                <div className="flex flex-wrap gap-1">
                  {['Entrantes', 'Carnes', 'Pescados', 'Postres', 'Arroces', 'Tapas'].map(cat => (
                    <button key={cat} onClick={() => handleNavigate('recipes')} className="text-gray-500 hover:text-orange-400 text-[10px] bg-gray-800 px-2 py-0.5 rounded-full transition-colors">
                      {cat}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Info */}
            <div>
              <h4 className="font-bold mb-3 text-gray-300 text-sm">Informacion</h4>
              <div className="space-y-1 text-xs text-gray-400">
                <p>📖 1.800+ recetas</p>
                <p>🤖 {recipeStats.thermomix} Thermomix</p>
                <p>⚡ 21 funciones</p>
                <p>⚙️ 58+ ajustes</p>
                <p>🏆 230 logros</p>
                <p>👤 30 ajustes perfil</p>
                <p>💰 2 planes premium</p>
                <p>✅ Version 2.0.0 Estable</p>
              </div>
              {devMode && (
                <div className="mt-2 bg-green-900/30 border border-green-500/30 rounded-lg p-2">
                  <p className="text-green-400 text-[10px] font-bold">🛡️ ADMIN MODE ACTIVO</p>
                  <p className="text-green-500/60 text-[10px]">Prueba Ultra activada</p>
                </div>
              )}
            </div>
          </div>

          <div className="border-t border-gray-800 mt-6 pt-6 flex flex-col md:flex-row items-center justify-between gap-3">
            <p className="text-gray-500 text-xs">
              © 2026 CocinaViva — Todos los derechos reservados — v2.0.0
            </p>
            <div className="flex items-center gap-3">
              <span className="text-gray-500 text-xs flex items-center gap-1">
                Hecho con <Heart className="w-3 h-3 text-red-500 fill-red-500" /> en Espana
              </span>
              <a href="#" className="text-gray-500 hover:text-white transition-colors">
                <Github className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Recipe Detail Modal */}
      {selectedRecipe && (
        <RecipeDetail
          recipe={selectedRecipe}
          onClose={() => setSelectedRecipe(null)}
          isFavorite={favorites.has(selectedRecipe.id)}
          onToggleFavorite={handleToggleFavorite}
        />
      )}
    </div>
  );
}
