import { useState, useEffect } from 'react';
import { ads } from '../data/ads';
import { X, ExternalLink } from 'lucide-react';

interface AdBannerProps {
  plan: string;
}

export function AdBanner({ plan }: AdBannerProps) {
  const [ad, setAd] = useState<typeof ads[0] | null>(null);
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    if (plan !== 'free') return;
    // Pick a random ad out of 100
    const randomIndex = Math.floor(Math.random() * ads.length);
    setAd(ads[randomIndex]);
    setClosed(false);
  }, [plan]);

  // Si el plan no es gratuito o el anuncio se cerro localmente, no renderizamos nada
  if (plan !== 'free' || !ad || closed) return null;

  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm my-6 relative group">
      <div className="absolute top-2 right-2 z-10 flex items-center gap-2">
        <span className="bg-black/50 backdrop-blur-md text-white px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider">
          Publicidad
        </span>
        <button 
          onClick={(e) => { e.preventDefault(); setClosed(true); }}
          className="bg-black/50 hover:bg-black/70 backdrop-blur-md text-white p-1 rounded-full transition-colors"
          title="Cerrar anuncio"
        >
          <X className="w-3 h-3" />
        </button>
      </div>

      <div className="cursor-pointer relative overflow-hidden" style={{ aspectRatio: '16/9', maxHeight: '200px', width: '100%' }}>
        {ad.type === 'video' ? (
          <video 
            src={ad.url} 
            autoPlay 
            loop 
            muted 
            className="w-full h-full object-cover"
          />
        ) : (
          <img 
            src={ad.url} 
            alt={ad.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        )}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-4 flex items-end justify-between">
          <div>
            <p className="text-white text-xs font-bold mb-0.5 drop-shadow-md">{ad.brand}</p>
            <h4 className="text-white text-sm md:text-base font-black drop-shadow-lg max-w-sm">{ad.title}</h4>
          </div>
          <div className="flex-shrink-0 ml-4">
            <span className="bg-orange-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-lg flex items-center gap-1 hover:bg-orange-400 transition-colors">
              Ver mas <ExternalLink className="w-3 h-3" />
            </span>
          </div>
        </div>
      </div>
      
      {/* Boton falso para incitar a suscribirse para quitar anuncios */}
      <div className="bg-gray-50 border-t border-gray-100 p-2 text-center flex items-center justify-between">
        <p className="text-[10px] text-gray-500">¿Cansado de los anuncios?</p>
        <button className="text-[10px] font-bold text-orange-600 hover:text-orange-500 flex items-center gap-1">
          Prueba Ultra gratis por 7 dias
        </button>
      </div>
    </div>
  );
}
